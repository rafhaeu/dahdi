#include <stdio.h>
#include <getopt.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <errno.h>

#include <dahdi/user.h>
#include "dahdi_tools_version.h"

#include "../linux/include/dahdi/ap_user.h"

static int verbose = 0;

#define AP_SPI_SECTOR_SIZE	0x10000
#define	AP_SPI_FW_SIZE		0xE0000

/* SPI commands
 * 
 * Command		Code	Address	Data
 * Write Enable		0x06	0	0
 * Write Disable	0x04	0	0
 * Read Identification	0x9F	0	1-3
 * Read Status		0x05	0	1
 * Read Data		0x03	3	1+
 * Read Data (Fast)	0x0B	3	2+	(first byte is dummy)
 * Page Program		0x02	3	1-256
 * Sector Erase		0xD8	3	0
 * Bulk Erase		0xC7	0	0
*/

int spi_write_enable(int dev)
{
	struct ap_ioctl_spi_cmd cmd;
	
	/* Write Enable */
	cmd.len = 1;
	cmd.data[0] = 0x06;
	
	if (ioctl(dev, AP_IOC_SPI, &cmd) < 0)
		return -1;
	return 0;
}

int spi_write_disable(int dev)
{
	struct ap_ioctl_spi_cmd cmd;
	
	/* Write Disable */
	cmd.len = 1;
	cmd.data[0] = 0x04;
	
	if (ioctl(dev, AP_IOC_SPI, &cmd) < 0)
		return -1;
	return 0;
}

int spi_erase(int dev, int offset)
{
	struct ap_ioctl_spi_cmd cmd;
	
	/* Write enable */
	if (spi_write_enable(dev))
		return -1;
	
	/* Sector Erase */
	cmd.len = 4;
	cmd.data[0] = 0xD8;
	cmd.data[1] = (offset >> 16) & 0xFF;
	cmd.data[2] = (offset >> 8) & 0xFF;
	cmd.data[3] = offset & 0xFF;
	
	if (ioctl(dev, AP_IOC_SPI, &cmd) < 0)
		return -1;
		
	/* Poll Status Register */
	do {
		cmd.len = 2;
		cmd.data[0] = 0x05;
		if (ioctl(dev, AP_IOC_SPI, &cmd) < 0)
			return -1;
	} while (cmd.data[1] & 0x1);
	return 0;
}

int spi_write(int dev, int offset, char *buf, int len)
{
	struct ap_ioctl_spi_cmd cmd;
	int i;
	
	/* Write enable */
	if (spi_write_enable(dev))
		return -1;
	
	/* Write */
	cmd.len = 4 + len;
	cmd.data[0] = 0x02;
	cmd.data[1] = (offset >> 16) & 0xFF;
	cmd.data[2] = (offset >> 8) & 0xFF;
	cmd.data[3] = offset & 0xFF;
	
	for (i = 0; i < len; i++) {
		cmd.data[4 + i] = buf[i];
	}
	
	if (ioctl(dev, AP_IOC_SPI, &cmd) < 0) {
		fprintf(stderr, "Error writing to device!\n");
		return -1;
	}
	
	/* Poll Status Register */
	do {
		cmd.len = 2;
		cmd.data[0] = 0x05;
		if (ioctl(dev, AP_IOC_SPI, &cmd) < 0) {
			fprintf(stderr, "Error writing to device!\n");
			return -1;
		}
	} while (cmd.data[1] & 0x1);
	return 0;
}

int spi_read(int dev, int offset, char *buf, int len)
{
	struct ap_ioctl_spi_cmd cmd;
	int i;
	
	/* Read */
	cmd.len = 4 + len;
	cmd.data[0] = 0x03;
	cmd.data[1] = (offset >> 16) & 0xFF;
	cmd.data[2] = (offset >> 8) & 0xFF;
	cmd.data[3] = offset & 0xFF;
	
	if (ioctl(dev, AP_IOC_SPI, &cmd) < 0) {
		fprintf(stderr, "Error reading from device!\n");
		return -1;
	}
		
	for (i = 0; i < len; i++) {
		buf[i] = cmd.data[4 + i];
	}
	return 0;
}

int spi_check_id(int dev)
{
	struct ap_ioctl_spi_cmd cmd;

	/* Read Identification */
	cmd.len = 4;
	cmd.data[0] = 0x9F;

	if (ioctl(dev, AP_IOC_SPI, &cmd) < 0) {
		fprintf(stderr, "Error reading from device!\n");
		return -1;
	}

	printf("SPI Flash ID %02hhx%02hhx%02hhx\n", cmd.data[1], cmd.data[2], cmd.data[3]);

	return 0;
}

struct apf_header {
	char magic[8];	/* APF */
	char type[8];
	char product[32];
	char version[16];
	char date[20];
	int epoch;
	int data_len;
	int header_len;
	char data_md5[16];
	char header_md5[16];
};

int firmware_check_file(int dev, FILE *fw)
{

	FILE *tmp;
	int i;
	int bytes;
	int res;
	char buf[256];
	struct apf_header *hdr;
	struct ap_ioctl_hwinfo hw_info;
	
	/* Read header */
	fread(buf, 1, sizeof(struct apf_header), fw);
	hdr = (void *) buf;

	/* Read device info */
	if (ioctl(dev, AP_GET_HWINFO, &hw_info) < 0) {
		fprintf(stderr, "Error reading from device!\n");
		return -1;
	}

	/* Check firmware product name */
	if (strncmp(hw_info.prod_name, hdr->product, 31)) {
		fprintf(stderr, "Wrong product (device is %s, firmware is for %s)!\n",
				hw_info.prod_name, hdr->product);
		return -1;
	}

	/* Create md5 temp file */
	tmp = fopen(".ap_fw.md5", "w");

	for (i = 0; i < 16; i++) {
		fprintf(tmp, "%02hhx", hdr->data_md5[i]);
	}
	fprintf(tmp, "  .ap_fw.dat\n");

	for (i = 0; i < 16; i++) {
		fprintf(tmp, "%02hhx", hdr->header_md5[i]);
	}
	fprintf(tmp, "  .ap_fw.hdr\n");

	fclose(tmp);
	
	/* Create header temp file */
	tmp = fopen(".ap_fw.hdr", "w");
	fwrite(hdr, 1, 112, tmp);
	fclose(tmp);

	/* Create data temp file */
	tmp = fopen(".ap_fw.dat", "w");
	while ((bytes = fread(buf, 1, 256, fw)) > 0) {
		fwrite(buf, 1, bytes, tmp);
	}
	fclose(tmp);

	/* Check header with md5sum */
	res = system("md5sum -c .ap_fw.md5 --status");
	
	if (res) {
		fprintf(stderr, "Firmware file corrupted!\n");
	} else {
		fprintf(stderr, "Firmware file OK!\n");
	}

#if 0
	/* Remove temp files */
	remove(".ap_fw.hdr");
	remove(".ap_fw.dat");
	remove(".ap_fw.md5");
#endif

	return res;
}

int firmware_upgrade(char *devname, char *fwname)
{
	int dev;
	FILE *fw;
	char buf[256];
	char readbuf[256];
	int offset;
	int bytes;
	int res;

	/* Open device */
	dev = open(devname, O_RDWR);
	if (dev < 0) {
		fprintf(stderr, "Unable to open device %s: %s\n", devname, strerror(errno));
		return -1;
	}

	/* Open firmware */
	fw = fopen(fwname, "rb");
	if (fw == NULL) {
		fprintf(stderr, "Unable to open firmware file: %s\n", strerror(errno));
		return -1;
	}

	/* Check firmware file integrity */
	res = firmware_check_file(dev, fw);
	if (res) {
		return res;
	}
	
	/* Check SPI Flash ID */
	res = spi_check_id(dev);
	if (res) {
		return res;
	}

	/* Write Firmware */
	printf("Writing firmware to device...\n");
	fseek(fw, sizeof(struct apf_header), SEEK_SET);
	offset = 0;
	while ((bytes = fread(buf, 1, 256, fw)) > 0) {
		/* Erase sector if necessary */
		if (offset % AP_SPI_SECTOR_SIZE == 0) {
			if (spi_erase(dev, offset)) {
				fclose(fw);
				close(dev);
				return -1;
			}
		}
		/* Write data */
		if (spi_write(dev, offset, buf, bytes)) {
			fclose(fw);
			close(dev);
			return -1;
		}

		/* Read back data */
		spi_read(dev, offset, readbuf, bytes);
		if (memcmp(buf, readbuf, bytes)) {
			int i;
			printf("Read back verification failed @ 0x%08X:\n", offset);
			if (verbose) {
				for (i = 0; i < bytes; i++) {
					printf("Read: %02hhx Write: %02hhx\n",
							readbuf[i], buf[i]);
				}
			}
			return -1;
		} else if (verbose) {
			printf("Read back verification OK @ 0x%08X:\n", offset);
		}
		offset += bytes;
	}
	
	fclose(fw);
	printf("Firmware successfully upgraded!\n");

	/* Try to reload FPGA program */
	if (ioctl(dev, AP_FPGA_PROG) >= 0) {
		printf("Firmware successfully reloaded! Please reboot!\n");
	}

	close(dev);
	return 0;
}

void print_usage()
{
	fprintf(stderr, "Usage: ap_fw [-v] [-n channel] [-f fw-file] [-h]\n");
	fprintf(stderr, "  -v\tBe verbose\n");
	fprintf(stderr, "  -n\tChannel number (Default: 1)\n");
	fprintf(stderr, "  -f\tFirmware file\n");
	fprintf(stderr, "  -h\tThis help\n");
}

int main(int argc, char *argv[])
{
	char devname[64] = "/dev/dahdi/1\0";	/* Default channel 1 */
	char fwname[256];
	int got_fw = 0;
	int opt;
		
	/* Get parameters */
	while ((opt = getopt(argc, argv, "in:f:hv")) != -1) {
		switch (opt) {
	        	case 'n':
				snprintf(devname, sizeof(devname), "/dev/dahdi/%s", optarg);
	        		break;
	        	case 'f':
				strncpy(fwname, optarg, sizeof(fwname));
	        		got_fw = 1;
	        		break;
	        	case 'v':
	        		verbose++;
	        		break;
	        	case 'h':
	        		break;
	        	default: /* '?' */
	        		break;
		}
	}

	/* Upgrade firmware */
	if (got_fw) {
		return firmware_upgrade(devname, fwname);
	}
	
	/* No parameters passed */
	print_usage();
	return 0;	
}
