#include <stdio.h>
#include <getopt.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <errno.h>

#include <dahdi/user.h>
#include "dahdi_tools_version.h"

#include "../linux/include/dahdi/ap_user.h"

static int ctl = -1;
static int verbose;

#define PRINT_SPANINFO_INT(a) printf("\t\t"#a" = %d\n", s[span].a)
#define PRINT_SPANINFO_STRING(a) printf("\t\t"#a" = %s\n", s[span].a)
#define PRINT_SPANINFO_U32(a) printf("\t\t"#a" = %lu\n", s[span].a)

/**
 * For some obscure reason, it's kind of impossible to know
 * what is the channel number of a span's channel. So we do this...
 */
int find_first_channel(int span)
{
	int res, i, channels;
	struct dahdi_spaninfo s;

	if( span >= DAHDI_MAX_SPANS )
		return -1;

	for(i = 1, channels = 0; i < span; i++) {
		s.spanno = i;
		res = ioctl(ctl, DAHDI_SPANSTAT, &s);
		if (res) return -1;

		channels += s.totalchans;
	}
	return channels+1;
}

int dahdi_indirect_ioctl(int span, int cmd, void* data)
{
	struct dahdi_indirect_data ind;

	ind.chan = span;
	ind.op = cmd;
	ind.data = data;

	return ioctl(ctl, DAHDI_INDIRECT, &ind);
}

int print_span_info(int span)
{
	int res;
	struct dahdi_spaninfo s[DAHDI_MAX_SPANS];

	s[span].spanno = span;
	res = ioctl(ctl, DAHDI_SPANSTAT, &s[span]);
	if (res) {
		return -1;
	}

	printf("\tSpan %d Info:\n", s[span].spanno);
	PRINT_SPANINFO_INT(spanno);
	PRINT_SPANINFO_STRING(name);
	PRINT_SPANINFO_STRING(desc);
	PRINT_SPANINFO_INT(bpvcount);
	PRINT_SPANINFO_INT(crc4count);
	PRINT_SPANINFO_INT(ebitcount);
	PRINT_SPANINFO_INT(fascount);
	PRINT_SPANINFO_U32(fecount);
	PRINT_SPANINFO_U32(cvcount);
	PRINT_SPANINFO_U32(becount);
	PRINT_SPANINFO_STRING(manufacturer);
	PRINT_SPANINFO_STRING(devicetype);
	PRINT_SPANINFO_STRING(spantype);

	return 0;
}

#define PRINT_STATS(a,b) printf("%40s : %lu\n", #a, b)

int print_span_stats(int span)
{
	int res, alarms, config, channel;
	struct ap4_ioctl_span_stats span_stats;

	struct ap_ioctl_hwinfo hw_info;
	struct dahdi_spaninfo spaninfo;
	struct dahdi_versioninfo versioninfo;


	memset(&spaninfo, '\0', sizeof(struct dahdi_spaninfo));
	spaninfo.spanno = span;
	res = ioctl(ctl, DAHDI_SPANSTAT, &spaninfo);
	if (res) return -1;

	channel = find_first_channel(span);

	memset(&hw_info, '\0', sizeof(struct ap_ioctl_hwinfo));
	res = dahdi_indirect_ioctl(channel, AP_GET_HWINFO, (void*) &hw_info);
	if (res) return -1;

	res = dahdi_indirect_ioctl(channel, AP4_GET_ALARMS, (void*) &alarms);
	if (res) return -1;

	res = dahdi_indirect_ioctl(channel, AP4_GET_CONFIG, (void*) &config);
	if (res) return -1;

	memset(&span_stats, '\0', sizeof(struct ap4_ioctl_span_stats));

	span_stats.span = span;
	res = dahdi_indirect_ioctl(channel, AP4_GET_STATS, (void*) &span_stats);
	if (res) return -1;

	memset(&versioninfo, '\0', sizeof(struct dahdi_versioninfo));
	res = ioctl(ctl, DAHDI_GETVERSION, &versioninfo);
	if (res) return -1;

	if( verbose ) {
		printf("\n");
		printf("DAHDI Version: %s\n", versioninfo.version);
		printf("Board Info:\n");
		printf("\tModel: %s\n", spaninfo.devicetype);
		printf("\tFimware Version: %d.%d\n", hw_info.fpga_major, hw_info.fpga_minor);
		printf("\tIRQ: %d\n", hw_info.irq);
	}

	printf("Span %d:\n", span);

	if( verbose ) {
		printf("\tFraming : %s\n", (config&AP4_CONFIG_PCM30) ? "CAS":"CCS");
		printf("\tCRC4 : %s\n", (config&AP4_CONFIG_CRC4) ? "Enabled":"Disabled");
		printf("\tHardware Echo : %s\n", (config&AP4_CONFIG_ECHO) ? "Present":"Not Present");
		printf("\n");
	}

	if( (alarms&(AP4_ALARM_LOS|AP4_ALARM_AIS|AP4_ALARM_BFAE|AP4_ALARM_RAI|AP4_ALARM_MFAE|AP4_ALARM_CAS)) ) {
		printf("%40s :%s%s%s%s%s%s\n","Active Alarms",
				((alarms&AP4_ALARM_LOS)? " LOS":""),
				((alarms&AP4_ALARM_AIS)? " AIS":""),
				((alarms&AP4_ALARM_BFAE)? " BFAE":""),
				((alarms&AP4_ALARM_RAI)? " RAI":""),
				((alarms&AP4_ALARM_MFAE)? " MFAE":""),
				((alarms&AP4_ALARM_CAS)? " CAS":""));
	} else
		printf("%40s : No Alarms\n","Active Alarms");

	printf("\n");
	printf("%40s : %02d:","Time since last clear", span_stats.seconds/3600);
	span_stats.seconds = span_stats.seconds%3600;
	printf("%02d:", span_stats.seconds/60);
	span_stats.seconds = span_stats.seconds%60;
	printf("%02d\n", span_stats.seconds);
	PRINT_STATS(Slip errors, span_stats.slipcount);
	PRINT_STATS(IRQ misses, span_stats.irqmisses);
	PRINT_STATS(LOS events, span_stats.los_count);
	PRINT_STATS(LOS seconds, span_stats.los_seconds);
	PRINT_STATS(AIS events, span_stats.ais_count);
	PRINT_STATS(AIS seconds, span_stats.ais_seconds);
	PRINT_STATS(Remote Alarm Indication (RAI) events, span_stats.rai_count);
	PRINT_STATS(Remote Alarm Indication (RAI) seconds, span_stats.rai_seconds);
	PRINT_STATS(Frame aligment error events, span_stats.bfae_count);
	PRINT_STATS(Frame aligment error seconds, span_stats.bfae_seconds);
	PRINT_STATS(Multiframe aligment error events, span_stats.mfae_count);
	PRINT_STATS(Multiframe aligment error seconds, span_stats.mfae_seconds);
	PRINT_STATS(CRC4 errors, span_stats.crc_count);
	PRINT_STATS(Bipolar violations, span_stats.bpv_count);
	PRINT_STATS(CAS errors, span_stats.cas_count);

	return 0;
}

int clear_span_stats(int span)
{
	int res, channel;

	int k=span;

	channel = find_first_channel(span);
	res = dahdi_indirect_ioctl(channel, AP4_RESET_STATS, (void*) &k);
	if (res)
		return -1;
	return 0;
}

int set_log_level(int span, int level)
{
	int old, res, channel;
	struct ap4_ioctl_log log;

	log.span = span;

	channel = find_first_channel(span);
	res = dahdi_indirect_ioctl(channel, AP4_GET_LOGLEVEL, (void*) &log);
	if (res)
		return -1;
	old = log.level;
	log.span = span;
	log.level = level;

	res = dahdi_indirect_ioctl(channel, AP4_SET_LOGLEVEL, (void*) &log);
	if (res)
		return -1;

	printf("Set log span %d level to %d, was %d\n", span, level, old);

	return 0;
}

int print_usage(char *argv)
{
	fprintf(stderr, "Usage: %s [-s] [-v] [-c] [-n span] [-l level] [-h]\n",
			argv);
	fprintf(stderr, "  -s\tShow statistics\n");
	fprintf(stderr, "  -v\tBe verbose\n");
	fprintf(stderr, "  -c\tClear statistics\n");
	fprintf(stderr, "  -n\tSpan number: 1 to %d\n", DAHDI_MAX_SPANS);
	fprintf(stderr, "  -l\tdmesg log level:\n\t\t0 to disable,\n\t\t1 logs LOS, AIS, RAI, BFAE events;\n\t\t2 logs MFAE, slip events (use with care);\n");
	fprintf(stderr, "  -y\tAssume 'Yes' for questions\n");
	fprintf(stderr, "  -h\tThis help\n");
	return 0;
}

int main (int argc, char *argv[])
{
	int i, opt, log;
	int do_stats, do_clear, do_log, yes_yes, got_args;

	ctl = open("/dev/dahdi/ctl", O_RDWR);
	if (ctl < 0) {
		fprintf(stderr, "Unable to open /dev/dahdi/ctl: %s\n", strerror(errno));
		fprintf(stderr, "Check if DAHDI is loaded!\n");
		print_usage(argv[0]);
		exit(1);
	}
	do_stats = 0;
	do_clear = 0;
	do_log = 0;
	yes_yes = 0;
	verbose = 0;
	got_args = 0;
	i = 0;
	log = 0;

	while ((opt = getopt(argc, argv, "in:scyhvl:")) != -1) {
		switch (opt) {
			case 's':
				got_args = 1;
				do_stats = 1;
				break;
	        	case 'n':
	        		i = atoi(optarg);
	        		if( i > 0 && i <= DAHDI_MAX_SPANS )
	        			got_args = 1;
	        		else
	        			fprintf(stderr, "Bad span number! Should be from 1 to %d\n", DAHDI_MAX_SPANS);
	        		break;
	        	case 'c':
	        		got_args = 1;
	        		do_clear = 1;
	        		break;
	        	case 'y':
	        		yes_yes = 1;
	        		break;
	        	case 'v':
	        		verbose++;
	        		break;
	        	case 'h':
	        		break;
	        	case 'l':
	        		log = atoi(optarg);
	        		if( log >= AP400_LOGLEVEL_min && log <= AP400_LOGLEVEL_max )
	        			got_args = 1;
	        		else
	        			fprintf(stderr, "Bad log level! Should be %d to %d\n", AP400_LOGLEVEL_min, AP400_LOGLEVEL_max);
	        		do_log = 1;
	        		break;
	        	default: /* '?' */
	        		break;
		}
	}

	if( got_args == 0 ) {
		print_usage(argv[0]);
	} else if( do_stats ) {
		if( i == 0 ) {
			for (i=0;i<DAHDI_MAX_SPANS;i++) {
				print_span_stats(i);
				if( verbose > 0 )
					print_span_info(i);
			}
		} else {
			print_span_stats(i);
			if( verbose > 0 )
				print_span_info(i);
		}
	} else if (do_clear) {
		if( i == 0 ) {
			if( yes_yes == 0 ) {
				printf("Clearing stats for all spans. Are you sure ? [y/N] ");
				opt = getchar();
				if( opt == 'y' || opt == 'Y' )
					yes_yes = 1;
			} else {
				printf("Clearing stats for all spans. Assuming 'yes'.\n");
			}
			if( yes_yes == 1 ) {
				for (i=0;i<DAHDI_MAX_SPANS;i++) {
					clear_span_stats(i);
				}
			}
		} else {
			if( yes_yes == 0 ) {
				printf("Clearing stats for span %d. Are you sure ? [y/N] ", i);
				opt = getchar();
				if( opt == 'y' || opt == 'Y' )
					yes_yes = 1;
			} else {
				printf("Clearing stats for span %d. Assuming 'yes'.\n", i);
			}
			if( yes_yes == 1 )
				clear_span_stats(i);
		}
	} else if ( do_log ) {
		if( i == 0 ) {
			for (i=0;i<DAHDI_MAX_SPANS;i++)
				set_log_level(i, log);
		} else {
			set_log_level(i, log);
		}
	} else
		print_usage(argv[0]);

	close(ctl);

	return 0;
}
