/*
 * Name: fxo_voicedaa.h
 * Description: FXO Silabs 3050 VoiceDAA driver (header)
 *
 * Creator: Wagner Gegler <wagner@aligera.com.br>
 * Company: Aligera - www.aligera.com.br
 * Date: 2010/09/17
 *
 * Copyright (C) 2011-2016, Aligera
  *
 * This program is free software; you can redistribute  it and/or modify it
 * under  the terms of  the GNU General  Public License as published by the
 * Free Software Foundation;  either version 2 of the  License, or (at your
 * option) any later version.
 */

#ifndef FXO_VOICEDAA_H_
#define FXO_VOICEDAA_H_

#include <dahdi/kernel.h>

enum battery_state {
	BATTERY_UNKNOWN = 0,
	BATTERY_PRESENT,
	BATTERY_LOST,
};

struct fxo_voicedaa {
	int txs_delay;	/* First Tx bit delay from Tx Sync */
	int rxs_delay;	/* First Rx bit delay from Rx Sync */
	int mode;	/* International settings mode */
	int offhook;
	int ringing;
	int ringdebounce;
	unsigned int battdebounce;
	unsigned int battalarm;
	enum battery_state battery;
	int lastpol;
	int polarity;
	int poldebounce;
};

struct ap_chan;

/* Function prototypes */
int fxo_is_ringing(struct ap_chan *chan);
int fxo_is_offhook(struct ap_chan *chan);
int fxo_voicedaa_init(struct ap_chan *chan);
int fxo_voicedaa_hooksig(struct ap_chan *chan, enum dahdi_txsig txsig);
void fxo_voicedaa_check_hook(struct ap_chan *chan);
int fxo_voicedaa_set_hwgain(struct ap_chan *chan, int gain, int tx);
int fxo_voicedaa_sanity_check(struct ap_chan *chan);
int fxo_voicedaa_detect(struct ap_chan *chan);


#endif /* FXO_VOICEDAA_H_ */
