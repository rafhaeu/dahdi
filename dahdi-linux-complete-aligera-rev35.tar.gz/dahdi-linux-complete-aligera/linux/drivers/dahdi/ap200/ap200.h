/*
 * AP200 FXS/FXO PCI Card Driver (header)
 *
 * Written by Wagner Gegler <wagner@aligera.com.br>
 *
 * Copyright (C) 2011-2016, Aligera
 *
 * All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#ifndef AP200_H_
#define AP200_H_

#include <linux/spinlock.h>
#include <dahdi/kernel.h>
#include "fxo_voicedaa.h"
#include "fxs_proslic.h"

#define AP200_PCI_DEVICE_ID	0x1005
#define AP200_CARD_ID		0x41503230		/* "AP20" */

#define AP200_MAX_CHANNELS	8
#define AP200_DMA

#define AP_IRQ_ENABLE		0x01
#define AP_TDM_IRQ_MASK		0x02

#define AP_DMA_ENABLE		0x01
#define AP_DMA_RESET		0x02
#define AP_DMA_ERROR		0x04

#define AP_SPI_READY		0x0100
#define AP_SPI_RESET		0x0200
#define AP_SPI_SEL_MASK		0x001F
#define AP_SPI_SEL_FLASH	0x0080
#define AP_SPI_KEY_ADDRESS	0x0E0000

#define AP_MOD_RESET		0x0001

#define AP_LED_GREEN		0x0000
#define AP_LED_AMBAR		0x0004
#define AP_LED_OFF		0x0000
#define AP_LED_ON		0x0001
#define AP_LED_SLOW		0x0002
#define AP_LED_FAST		0x0003


typedef enum {
	AP_CHAN_TYPE_FX = 0,
	AP_CHAN_TYPE_FXS,
	AP_CHAN_TYPE_FXO
} mod_type;

struct ap2;

struct oct_regs {
	volatile u32 ctrl;
	volatile u32 data;
} __attribute__ ((packed));

struct ap2_regs {
	volatile u32 card_id;		/* 0 */
	volatile u16 fpga_ver;		/* 1 */
	volatile u16 num_channels;
	volatile u8 tdm_page;		/* 2 */
	volatile u8 tdm_page_num;
	volatile u16 tdm_page_bytes;
	volatile u8 irq_status;		/* 3 */
	volatile u8 irq_config;
	volatile u16 irq_count;
	volatile u32 dma_config;	/* 4 */
	volatile u32 dma_baseaddr;	/* 5 */
	volatile u32 dna_low;		/* 6 */
	volatile u32 dna_high;		/* 7 */
	volatile u32 auth;		/* 8 */
	volatile u16 spi_data;		/* 9 */
	volatile u16 spi_ctrl;
	volatile u16 mod_config;	/* 10 */
	volatile u16 mod_status;
	volatile u16 led_config;	/* 11 */
	volatile u16 led_sel;
	volatile u32 oct_ctrl;		/* 12 */
	volatile u16 oct_addr;		/* 13 */
	volatile u16 oct_data;
	volatile u16 ec_ctrl;		/* 14 */
	volatile u16 ec_addr;
	volatile u32 ec_data;		/* 15 */
#if 0
	volatile u32 ddr_ctrl;		/* 16 */
	volatile u32 ddr_data;		/* 17 */
#endif
	volatile u32 debug;		/* Last */
} __attribute__ ((packed));

struct ap_chan {
	struct ap2 *card;
	struct dahdi_chan *dahdi;
	struct dahdi_echocan_state ec;
	unsigned index;
	int type;
	int online;
	union {
		struct fxo_voicedaa fxo;
		struct fxs_proslic fxs;
	};
};

struct ap2 {
	struct pci_dev *dev;		/* Pointer to PCI device */
	struct ap2_regs *regs;
	int fpga_version;		/* Version of FPGA */
	int hw_id;			/* Hardware ID */
	int num_channels;		/* Number of FX channels */
	int irq;			/* IRQ used by device */
	int num;			/* Card number */
	unsigned int intcount;		/* Interrupt Counter */
	volatile void *data;		/* Data base address */
	spinlock_t spi_lock;		/* SPI lock */
	spinlock_t reg_lock;		/* Register lock */
	void *writechunk;		/* Write buffer */
	void *readchunk;		/* Read buffer */
	unsigned int readpage;
	unsigned int writepage;
	unsigned int numpages;
	unsigned int pagesize;
	unsigned int pageoffset;
	struct devtype *dt;
	char *variety;
	struct ap_chan apchans[AP200_MAX_CHANNELS];
	struct dahdi_span span;
	struct dahdi_chan *chans[AP200_MAX_CHANNELS];
	struct dahdi_device *ddev;
#ifdef AP200_DMA
	dma_addr_t dma_addr;
#endif
#ifdef APEC_OCT_SUPPORT
	unsigned int apec_oct_ctrl_mask;
	struct apec_oct *oct;
#endif
};

/* Function prototypes */
void ap2_spi_write_byte(struct ap2 *ap, unsigned char data);
unsigned char ap2_spi_read_byte(struct ap2 *ap);

#endif /* AP200_H_ */
