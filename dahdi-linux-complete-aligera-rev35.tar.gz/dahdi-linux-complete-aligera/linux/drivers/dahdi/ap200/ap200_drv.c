/*
 * AP200 FXS/FXO PCI Card Driver
 *
 * Written by Wagner Gegler <wagner@aligera.com.br>
 *
 * Copyright (C) 2011-2016, Aligera
 *
 * All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/init.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/time.h>
#include <linux/delay.h>
#include <linux/proc_fs.h>
#include <linux/moduleparam.h>

#include <dahdi/ap_user.h>
#include "ap200.h"
#include "fxo_voicedaa.h"
#include "fxs_proslic.h"

/* #define AP200_DEBUG */
#ifdef AP200_DEBUG
#define PDEBUG(fmt, args...) { \
	printk(KERN_DEBUG "AP200 (%d): ",__LINE__); \
	printk(fmt "\n", ## args); \
}
#else
#define PDEBUG(fmt, args...)
#endif

#ifdef APEC_OCT_SUPPORT
#include "apec_oct.h"
#endif

static int dma_enable = 1;
static int apec_enable = 1;
static int tdm_loop = 0;
static int tdm_test = 0;
module_param(dma_enable, int, 0400);
module_param(apec_enable, int, 0400);
module_param(tdm_loop, int, 0600);
module_param(tdm_test, int, 0600);

static int tdm_errors[AP200_MAX_CHANNELS];
module_param_array(tdm_errors, int, NULL, 0600);


#define MAX_AP200_CARDS	8
static struct ap2 *cards[8];

struct devtype {
	char *desc;
	unsigned int flags;
};

static struct devtype ap200  = { "Aligera AP200", 0 };

static inline struct ap_chan *apchan_from_dahdi_chan(struct dahdi_chan *chan)
{
	return (struct ap_chan *) chan->pvt;
}

static inline struct ap2 *ap2_from_dahdi_chan(struct dahdi_chan *chan)
{
	struct ap_chan *apchan = apchan_from_dahdi_chan(chan);
	return apchan->card;
}

void ap2_irq_disable(struct ap2 *ap)
{
	ap->regs->irq_config &= ~AP_IRQ_ENABLE;
}

void ap2_irq_enable(struct ap2 *ap)
{
	ap->regs->irq_config |= AP_IRQ_ENABLE | AP_TDM_IRQ_MASK;
}

void inline ap2_spi_poll_ready_bit(struct ap2 *ap)
{
	unsigned timeout = 1000000;

	while (!(ap->regs->spi_ctrl & AP_SPI_READY) && (--timeout) > 0);
}

void ap2_spi_write_byte(struct ap2 *ap, unsigned char data)
{
	ap->regs->spi_data = data;
	ap2_spi_poll_ready_bit(ap);
}

unsigned char ap2_spi_read_byte(struct ap2 *ap)
{
	unsigned short data;

	ap->regs->spi_data = 0;	/* Write dummy data */
	ap2_spi_poll_ready_bit(ap);
	data = ap->regs->spi_data & 0xFF;

	return (unsigned char) data;
}

static inline int ap2_spi_byte(struct ap2 *ap, unsigned char *data)
{
	/* Write data to SPI */
	ap->regs->spi_data = (u16) *data;

	/* Wait SPI completion */
	ap2_spi_poll_ready_bit(ap);

	/* Check if SPI completed */
	if (!(ap->regs->spi_ctrl & AP_SPI_READY)) {
		printk("SPI access timeout!\n");
		return -1;
	}

	/* Read data from SPI */
	*data = (u8) ap->regs->spi_data;

	return 0;
}

static int ap2_ioctl_spi(struct ap2 *ap, unsigned long data)
{
	struct ap_ioctl_spi_cmd cmd;
	unsigned long flags;
	int i;

	/* Read data buffer from userspace */
	if (copy_from_user(&cmd, (void *) data, sizeof(cmd)))
		return -EFAULT;

	/* Get SPI Lock and assert Chip Select */
	spin_lock_irqsave(&ap->spi_lock, flags);
	ap->regs->spi_ctrl = AP_SPI_SEL_FLASH;

	/* Move data */
	for (i = 0; i < cmd.len; i++) {
		if (ap2_spi_byte(ap, &cmd.data[i]))
			return -EIO;
	}

	/* De-assert Chip Select and release SPI Lock */
	ap->regs->spi_ctrl = 0;
	spin_unlock_irqrestore(&ap->spi_lock, flags);

	/* Write data buffer to userspace */
	if (copy_to_user((void *) data, &cmd, sizeof(cmd)))
		return -EFAULT;

	return 0;
}

#define APEC_OCT_CTRL_RESET_WORD	0xE0000000

#ifdef APEC_OCT_SUPPORT

#define APEC_OCT_CTRL_RESET		0x80000000
#define APEC_OCT_CTRL_DDR_NCKE		0x40000000
#define APEC_OCT_CTRL_EC_DISABLE	0x20000000
#define APEC_OCT_CTRL_EC_ENABLE		0x00000000
#define APEC_OCT_CTRL_DAS		0x08000000
#define APEC_OCT_CTRL_RD		0x04000000
#define APEC_OCT_CTRL_REQ		0x02000000
#define APEC_OCT_CTRL_READY		0x01000000

#define APEC_OCT_ACCESS_TIMEOUT		1000


/* Poll echo machine ready bit until timeout */
static inline void oct_ready_poll(struct ap2 *ap)
{
	int i = APEC_OCT_ACCESS_TIMEOUT;

	do {
		udelay(1);
	} while ((ap->regs->oct_ctrl & APEC_OCT_CTRL_READY) == 0 && i-- > 0);

	if (i == 0)
		printk("APEC Timeout!\n");
}

static inline u16 oct_raw_read (struct ap2 *ap, unsigned short addr)
{
	unsigned short data;

	/* Write control bits and address */
	ap->regs->oct_addr = addr;
	ap->regs->oct_ctrl = APEC_OCT_CTRL_RD | APEC_OCT_CTRL_REQ;
	/* Poll ready bit */
	oct_ready_poll(ap);
	data = ap->regs->oct_data;
	PDEBUG("Raw Read 0x%04hX @ 0x%04X", data, addr);
	return data;
}

static inline void oct_raw_write(struct ap2 *ap, unsigned short addr, unsigned short data)
{
	/* Write data, then control bits and address */
	ap->regs->oct_data = data;
	ap->regs->oct_addr = addr;
	ap->regs->oct_ctrl = APEC_OCT_CTRL_REQ;
	/* Poll ready bit */
	oct_ready_poll(ap);
	PDEBUG("Raw Write 0x%04hX @ 0x%04X", data, addr);
#ifdef AP200_DEBUG
	//oct_raw_read(ap, addr);
#endif
}

static inline void oct_ext_wait (struct ap2 *ap)
{
	int i = APEC_OCT_ACCESS_TIMEOUT;

	do {
		udelay(40);
	} while ((oct_raw_read(ap, 0x0) & 0x100) && (i-- > 0));

	if (i == -1)
		printk(KERN_WARNING "Wait access request timeout\n");
}

static inline u16 oct_ind_read(struct ap2 *ap, unsigned int addr)
{
	/* Write extended indirect registers */
	oct_raw_write(ap, 0x8, (addr >> 20) & 0x0FFF);
	oct_raw_write(ap, 0xA, (addr >> 4) & 0xFFFF);
	oct_raw_write(ap, 0x0, ((addr & 0xE) << 8) | 0x101);
	/* Poll access_req bit */
	oct_ext_wait(ap);
	/* Return data */
	return oct_raw_read(ap, 0x4);
}

static inline void oct_ind_write (struct ap2 *ap, unsigned int addr, unsigned short data)
{
	oct_raw_write(ap, 0x8, (addr >> 20) & 0x0FFF);
	oct_raw_write(ap, 0xA, (addr >> 4) & 0xFFFF);
	oct_raw_write(ap, 0x4, data);
	oct_raw_write(ap, 0x0, ((addr & 0xE) << 8) | 0x3101);
	/* Poll access_req bit */
	oct_ext_wait(ap);
}

static inline u16 oct_dir_read(struct ap2 *ap, unsigned int addr)
{
	/* Write extended direct registers */
	oct_raw_write(ap, 0x8, (addr >> 20) & 0x0FFF);
	oct_raw_write(ap, 0xA, (addr >> 4) & 0xFFFF);
	oct_raw_write(ap, 0x0, 0x1);

	ap->regs->oct_addr = addr & 0xFFFF;
	ap->regs->oct_ctrl = APEC_OCT_CTRL_DAS | APEC_OCT_CTRL_RD | APEC_OCT_CTRL_REQ;
	/* Poll ready bit */
	oct_ready_poll(ap);
	/* Return data */
	return (u16) ap->regs->oct_data;
}

static inline void oct_dir_write(struct ap2 *ap, unsigned int addr, unsigned short data)
{
	/* Write extended direct registers */
	oct_raw_write(ap, 0x8, (addr >> 20) & 0x0FFF);
	oct_raw_write(ap, 0xA, (addr >> 4) & 0xFFFF);
	oct_raw_write(ap, 0x0, 0x3001);

	ap->regs->oct_data = data;
	ap->regs->oct_addr = addr & 0xFFFF;
	ap->regs->oct_ctrl = APEC_OCT_CTRL_DAS | APEC_OCT_CTRL_REQ;
	/* Poll ready bit */
	oct_ready_poll(ap);
}

unsigned int oct_read(void *card, unsigned int addr)
{
	struct ap2 *ap = card;
	unsigned long flags;
	unsigned short data = 0;
	spin_lock_irqsave(&ap->reg_lock, flags);
	data = oct_ind_read(ap, addr);
	spin_unlock_irqrestore(&ap->reg_lock, flags);
	PDEBUG("Read 0x%04hX @ 0x%08X", data, addr);
	return data;
}

void oct_write(void *card, unsigned int addr, unsigned int data)
{
	struct ap2 *ap = card;
	unsigned long flags;
	spin_lock_irqsave(&ap->reg_lock, flags);
	oct_ind_write(ap, addr, data);
	spin_unlock_irqrestore(&ap->reg_lock, flags);
	PDEBUG("Write 0x%04hX @ 0x%08X", data, addr);
}

static int ap2_oct_init(struct ap2 *ap)
{
	unsigned int cap;
	struct firmware embedded_firmware;
	extern void _binary_OCT6114E_32D_ima_size;
	extern u8 _binary_OCT6114E_32D_ima_start[];

	/* Test if already initiated */
	if (ap->oct)
		return 0;

	/* Enable DDR and Reset Octasic */
	ap->regs->oct_ctrl = APEC_OCT_CTRL_RESET_WORD;
	udelay(500);
	ap->regs->oct_ctrl = 0;

	/* Get Octasic capacity */
	switch (cap = apec_oct_get_capacity(ap)) {
	case 32:
		embedded_firmware.data = _binary_OCT6114E_32D_ima_start;
		/* Yes... this is weird. objcopy gives us a symbol containing
		   the size of the firmware, not a pointer to a variable
		   containing the size. The only way we can get the value of
		   the symbol is to take its address, so we define it as a
		   pointer and then cast that value to the proper type.
		*/
		embedded_firmware.size = (size_t) &_binary_OCT6114E_32D_ima_size;
		break;
	default:
		printk(KERN_INFO "Unsupported channel capacity found on echo "
				"cancellation module (%d).\n", cap);
		return -1;
	}

	/* Init Octasic */
	ap->oct = apec_oct_init(ap, ap->num_channels, &embedded_firmware);
	if (!ap->oct) {
		printk(KERN_WARNING "APEC: Failed to initialize\n");
		return -1;
	}

	printk(KERN_INFO "APEC_OCT: Present and operational\n");
	return 0;
}

void ap2_oct_release(struct ap2 *ap)
{
	/* Disable DDR and reset Octasic */
	ap->regs->oct_ctrl = APEC_OCT_CTRL_RESET_WORD;
	if (ap->oct)
		apec_oct_release(ap->oct);
}
#endif

#define APEC_TDM_ENABLE		0x1
#define APEC_CHAN_ENABLE	0x7

static void apec_free(struct dahdi_chan *chan, struct dahdi_echocan_state *ec)
{
	struct ap2 *ap = ap2_from_dahdi_chan(chan);

	memset(ec, 0, sizeof(*ec));

#ifdef APEC_OCT_SUPPORT
	if (ap->oct) {
		apec_oct_setec(ap->oct, chan->chanpos - 1, 0);
		PDEBUG("APEC_OCT echo canceller enabled on Channel %d\n",
		       	       chan->chanpos);
		return;
	}
#endif

	/* Disable echo cancellation on channel */
	ap->regs->ec_addr = chan->chanpos - 1;
	ap->regs->ec_data = 0;

	PDEBUG("APEC echo canceller disabled on Channel %d\n", chan->chanpos);
}

static const struct dahdi_echocan_ops apec_ops = {
	.echocan_free = apec_free,
};

static const struct dahdi_echocan_features apec_features = {
	.NLP_automatic = 1,
	.CED_tx_detect = 1,
	.CED_rx_detect = 1,
};

const char *apec_oct_name = "APEC_OCT";
const char *apec_name = "APEC";

static const char *ap2_echocan_name(const struct dahdi_chan *chan)
{
	struct ap2 *ap = ap2_from_dahdi_chan((struct dahdi_chan *) chan);

#ifdef APEC_OCT_SUPPORT
	if (ap->oct) {
		return apec_oct_name;
	}
#endif
	return apec_name;
}

static int ap2_echocan_create(struct dahdi_chan *chan,
                                 struct dahdi_echocanparams *ecp,
                                 struct dahdi_echocanparam *p,
                                 struct dahdi_echocan_state **ec)
{
	struct ap2 *ap = ap2_from_dahdi_chan(chan);
	struct ap_chan *apchan = apchan_from_dahdi_chan(chan);

	if (!apec_enable)
		return -ENODEV;

#ifdef APEC_OCT_SUPPORT
	if (ap->oct) {
		if (ecp->param_count > 0) {
			printk(KERN_WARNING "APEC_OCT echo canceller does "
					"not support parameters. "
					"Failing request.\n");
			return -EINVAL;
		}

		*ec = &apchan->ec;
		(*ec)->ops = &apec_ops;
		(*ec)->features = apec_features;

		apec_oct_setec(ap->oct, chan->chanpos - 1, ecp->tap_length);

		PDEBUG("APEC_OCT echo canceller enabled on Channel %d ",
		       	       chan->chanpos);
		return 0;
	}
#endif

	if (ecp->param_count > 0) {
		printk(KERN_WARNING "APEC echo canceller does not support "
				"parameters. Failing request.\n");
		return -EINVAL;
	}

	*ec = &apchan->ec;
	(*ec)->ops = &apec_ops;
	(*ec)->features = apec_features;

	ap->regs->ec_addr = chan->chanpos - 1;
	ap->regs->ec_data = APEC_CHAN_ENABLE;

	PDEBUG("APEC echo canceller enabled on Channel %d\n", chan->chanpos);

	return 0;
}

static int ap2_hooksig(struct dahdi_chan *chan, enum dahdi_txsig txsig)
{
	struct ap_chan *apchan = apchan_from_dahdi_chan(chan);
	PDEBUG("channel %d (type: %d) change hooksig to %d", chan->chanpos,
	       	       apchan->type, txsig);

	if (apchan->type == AP_CHAN_TYPE_FXS)
		return fxs_proslic_hooksig(apchan, txsig);

	if (apchan->type == AP_CHAN_TYPE_FXO)
		return fxo_voicedaa_hooksig(apchan, txsig);

	return -1;
}

#define TDM_TEST_TIME	4000
static inline void ap2_tdm_test(struct ap2 *ap)
{
	u8 pattern[8] = { 0xd5, 0x83, 0xb5, 0x83, 0x55, 0x03, 0x35, 0x03 };
	u8 data[8];
	int i;

	/* Begin test */
	if (tdm_test == 1) {
		/* Set channels to offhook */
		for (i = 0; i < AP200_MAX_CHANNELS; ++i) {
			tdm_errors[i] = 0;
			ap2_hooksig(ap->chans[i], DAHDI_TXSIG_OFFHOOK);
		}
	}

	/* Write test pattern */
	if (tdm_test <= TDM_TEST_TIME / 2) {
		for (i = 0; i < AP200_MAX_CHANNELS / 2; ++i) {
			memset(ap->chans[i]->writechunk, 0xd5, 8);
			memcpy(ap->chans[i+4]->writechunk, pattern, 8);
		}
	} else {
		for (i = 0; i < AP200_MAX_CHANNELS / 2; ++i) {
			memset(ap->chans[i+4]->writechunk, 0xd5, 8);
			memcpy(ap->chans[i]->writechunk, pattern, 8);
		}
	}

	/* Check read data */
	for (i = 0; i < AP200_MAX_CHANNELS; ++i) {
		int j;
		int dc = 0;
		int level = 0;

		/* Read data from channel */
		memcpy(data, ap->chans[i]->readchunk, 8);

		/* Calculate DC level */
		for (j = 0; j < 8; ++j) {
			dc += DAHDI_ALAW(data[j]);
		}

		/* Calculate level */
		for (j = 0; j < 8; ++j) {
			level += abs(DAHDI_ALAW(data[j]) - dc);
		}

		/* Check DC and channel level */
		if (tdm_test % (TDM_TEST_TIME / 2)  > (TDM_TEST_TIME / 4) &&
				tdm_test / (TDM_TEST_TIME / 2) == i / 4) {
			if (abs(dc) > 2048 || level < 8192 || level > 131072) {
				tdm_errors[i]++;
			}
		}
		if (tdm_test % (TDM_TEST_TIME / 2) == 0)
			printk("AP200: TDM Test on channel %d (dc = %d, level = %d)\n", i + 1, dc, level);
	}

	/* End test */
	if (tdm_test++ >= TDM_TEST_TIME) {
		/* Set channels to onhook */
		for (i = 0; i < AP200_MAX_CHANNELS; ++i) {
			if (ap2_hooksig(ap->chans[i], DAHDI_TXSIG_ONHOOK)) {
				/* If channel is not FXS or FXO, return error */
				tdm_errors[i] = -1;
			}
		}
		tdm_test = 0;
	}
}

static inline void ap2_handle_dma(struct ap2 *ap)
{
	/* Check DMA error */
	if (ap->regs->dma_config & AP_DMA_ERROR) {
		printk(KERN_WARNING "%s: DMA Error! Restarting...\n",
						ap->variety);
		ap->regs->dma_config |= AP_DMA_RESET;
		return;
	}

	/* Loop */
	if (tdm_loop) {
		memcpy(ap->writechunk, ap->readchunk, ap->pageoffset);
		return;
	}

	/* TDM Test */
	if (tdm_test > 0) {
		ap2_tdm_test(ap);
		return;
	}

	dahdi_ec_span(&ap->span);
	dahdi_receive(&ap->span);
	dahdi_transmit(&ap->span);
}

#if (DAHDI_CHUNKSIZE != 8)
#error Sorry, AP200 driver does not support chunksize != 8
#endif

static inline void ap2_receiveprep(struct ap2 *ap)
{
	volatile void *readdata;
	int i;

	/* Update read page number */
	ap->readpage = (ap->regs->tdm_page + 1) % 2;
	readdata = ap->data + ap->readpage * ap->pageoffset;

	for (i = 0; i < ap->num_channels; ++i) {
		if (ap->chans[i]->flags & DAHDI_FLAG_OPEN)
			memcpy_fromio(ap->chans[i]->readchunk, readdata,
					DAHDI_CHUNKSIZE);
		readdata += DAHDI_CHUNKSIZE;
	}

	dahdi_ec_span(&ap->span);
	dahdi_receive(&ap->span);
}

static inline void ap2_transmitprep(struct ap2 *ap)
{
	volatile void *writedata;
	int i;

	dahdi_transmit(&ap->span);

	ap->writepage = (ap->regs->tdm_page + 1) % 2;
	writedata = ap->data + ap->writepage * ap->pageoffset;
	for (i = 0; i < ap->num_channels; ++i) {
		if (ap->chans[i]->flags & DAHDI_FLAG_OPEN) {
			memcpy_toio(writedata, ap->chans[i]->writechunk,
					DAHDI_CHUNKSIZE);
		}
		writedata += DAHDI_CHUNKSIZE;
	}
}

static inline void ap2_tdm_loop(struct ap2 *ap)
{
	volatile u8 *readdata;
	volatile u8 *writedata;
	int i;

	/* Update page number */
	ap->readpage = (ap->regs->tdm_page + 1) % 2;
	readdata = ap->data + ap->readpage * ap->pageoffset;
	ap->writepage = (ap->regs->tdm_page + 1) % 2;
	writedata = ap->data + ap->writepage * ap->pageoffset;

	for (i = 0; i < ap->pageoffset; ++i) {
		writedata[i] = readdata[i];
	}
}

static inline void ap2_set_led(struct ap_chan *apchan, int mode)
{
	apchan->card->regs->led_sel = apchan->index;
	apchan->card->regs->led_config = mode;
}

static inline void ap2_handle_leds(struct ap_chan *apchan)
{
	/* Set LED indication according with channel status */
	if (apchan->type == AP_CHAN_TYPE_FXS) {
		if (!apchan->online) {
			ap2_set_led(apchan, AP_LED_OFF | AP_LED_GREEN);
		} else if (fxs_is_ringing(apchan)) {
			ap2_set_led(apchan, AP_LED_FAST | AP_LED_GREEN);
		} else if (fxs_is_offhook(apchan)) {
			ap2_set_led(apchan, AP_LED_SLOW | AP_LED_GREEN);
		} else {
			ap2_set_led(apchan, AP_LED_ON | AP_LED_GREEN);
		}
	} else if (apchan->type == AP_CHAN_TYPE_FXO) {
		if (!apchan->online) {
			ap2_set_led(apchan, AP_LED_OFF | AP_LED_AMBAR);
		} else if (fxo_is_ringing(apchan)) {
			ap2_set_led(apchan, AP_LED_FAST | AP_LED_AMBAR);
		} else if (fxo_is_offhook(apchan)) {
			ap2_set_led(apchan, AP_LED_SLOW | AP_LED_AMBAR);
		} else {
			ap2_set_led(apchan, AP_LED_ON | AP_LED_AMBAR);
		}
	}
}

static inline void ap2_check_hook(struct ap_chan *apchan)
{
	if (apchan->type == AP_CHAN_TYPE_FXS)
		fxs_proslic_check_hook(apchan);

	if (apchan->type == AP_CHAN_TYPE_FXO)
		fxo_voicedaa_check_hook(apchan);
}

DAHDI_IRQ_HANDLER(ap2_interrupt)
{
	struct ap2 *ap = dev_id;
	unsigned int temp;

	/* Check if it is our IRQ and acknowledge it */
	temp = ap->regs->irq_config & ap->regs->irq_status;
	if (!(temp & AP_IRQ_ENABLE)) {
		return IRQ_NONE;
	}

	/* Read IRQ counter, should be 1, else we missed some IRQ */
	temp = ap->regs->irq_count;
	/* Increment IRQ misses */
	if (temp > 0) {
		ap->ddev->irqmisses += (temp - 1);
	}

	ap->intcount++;

#ifdef AP200_DMA
	ap2_handle_dma(ap);
#else
	if (!tdm_loop) {
		ap2_receiveprep(ap);
		ap2_transmitprep(ap);
	} else {
		ap2_tdm_loop(ap);
	}
#endif

	/* Check hook every 16 ms */
	if (ap->intcount % 2) {
		ap2_check_hook(&ap->apchans[(ap->intcount / 2) % 8]);
		ap2_handle_leds(&ap->apchans[(ap->intcount / 2) % 8]);
	}

	return IRQ_HANDLED;
}

static int ap2_ioctl(struct dahdi_chan *chan, unsigned int cmd,
		       unsigned long data)
{
	struct ap_chan *apchan = apchan_from_dahdi_chan(chan);
	struct ap2 *ap = ap2_from_dahdi_chan(chan);
	int value;
	struct dahdi_hwgain hwgain;
	struct ap_ioctl_hwinfo hw_info;

	switch (cmd) {
	case DAHDI_ONHOOKTRANSFER:
		if (apchan->type != AP_CHAN_TYPE_FXS)
			return -EINVAL;
		if (get_user(value, (__user int *) data))
			return -EFAULT;

		fxs_proslic_onhook_transfer(apchan, value);
		break;
	case DAHDI_SETPOLARITY:
		if (apchan->type != AP_CHAN_TYPE_FXS)
			return -EINVAL;
		if (get_user(value, (__user int *) data))
			return -EFAULT;

		fxs_proslic_set_polarity(apchan, value);
		printk(KERN_INFO "ioctl: Start OnHookTrans, card %d\n",
					chan->chanpos - 1);
		break;
	case DAHDI_SET_HWGAIN:
		if (copy_from_user(&hwgain, (__user void *) data, sizeof(hwgain)))
			return -EFAULT;
		if (apchan->type == AP_CHAN_TYPE_FXO) {
			fxo_voicedaa_set_hwgain(apchan, hwgain.newgain, hwgain.tx);
		} else if (apchan->type == AP_CHAN_TYPE_FXS) {
			fxs_proslic_set_hwgain(apchan, hwgain.newgain, hwgain.tx);
		} else {
			printk(KERN_NOTICE "Cannot adjust gain. Unsupported module type!\n");
			return -1;
		}
		break;
	case AP_GET_HWINFO:
		memset(&hw_info, '\0', sizeof(struct ap_ioctl_hwinfo));
		hw_info.fpga_major = ap->fpga_version >> 8;
		hw_info.fpga_minor = ap->fpga_version & 0xFF;
		hw_info.irq = ap->irq;
		strncpy(hw_info.prod_name, ap->variety, 31);

		if (copy_to_user((struct ap_ioctl_hwinfo*) data,
				&hw_info, sizeof(struct ap_ioctl_hwinfo)))
			return -EFAULT;

		break;
	case AP_IOC_SPI:
		return ap2_ioctl_spi(ap, data);
	case AP_FPGA_PROG:
		/* Disable IRQ and DMA before reloading FPGA Program */
		ap2_irq_disable(ap);
		free_irq(ap->dev->irq, ap);
		ap->dev->irq = 0;
		ap->regs->dma_config = 0;
		ap->regs->spi_ctrl = 0x8000;
		return 0;
	default:
		return -ENOTTY;
	}
	return 0;
}

static int ap2_open(struct dahdi_chan *chan)
{
	return 0;
}

static int ap2_close(struct dahdi_chan *chan)
{
	return 0;
}

static const struct dahdi_span_ops ap2_span_ops = {
	.owner = THIS_MODULE,
	.hooksig = ap2_hooksig,
	.open = ap2_open,
	.close = ap2_close,
	.ioctl = ap2_ioctl,
	.echocan_create = ap2_echocan_create,
	.echocan_name = ap2_echocan_name,
};

static int ap2_chan_init(struct ap_chan *chan)
{
	int ret;

	switch (chan->type) {
	case AP_CHAN_TYPE_FXS:
		/* Initialize module */
		ret = fxs_proslic_init(chan);
		if (ret)
			return ret;
		break;
	case AP_CHAN_TYPE_FXO:
		/* Initialize module */
		ret = fxo_voicedaa_init(chan);
		if (ret)
			return ret;
		break;
	default:
		return -1;
	}
	chan->online = 1;
	return 0;
}

static inline void ap2_reset_channels(struct ap2 *ap)
{

	ap->regs->mod_config |= AP_MOD_RESET;
	udelay(1);
	ap->regs->mod_config &= ~AP_MOD_RESET;
	udelay(1000);
}

static void ap2_detect_channels(struct ap2 *ap)
{
	int i;
	
	/* Reset FX Modules */
	ap2_reset_channels(ap);

	/* Detect FXS Proslic 3215 Modules */
	for (i = 0; i < ap->num_channels; ++i) {
		if (ap->apchans[i].type != AP_CHAN_TYPE_FX)
			continue;
		if (fxs_proslic_detect(&ap->apchans[i]) >= 0) {
			ap->apchans[i].type = AP_CHAN_TYPE_FXS;
			printk(KERN_INFO "AP200: Found FXS module on channel %d\n", i + 1);
		}
	}

	/* Reset FX Modules */
	ap2_reset_channels(ap);
	
	/* Detect FXO VoiceDAA Modules */
	for (i = 0; i < ap->num_channels; ++i) {
		if (ap->apchans[i].type != AP_CHAN_TYPE_FX)
			continue;
		if (fxo_voicedaa_detect(&ap->apchans[i]) >= 0) {
			ap->apchans[i].type = AP_CHAN_TYPE_FXO;
			printk(KERN_INFO "AP200: Found FXO module on channel %d\n", i + 1);
		}
	}

	/* Reset FX Modules */
	ap2_reset_channels(ap);
}

static inline int ap2_init_span(struct ap2 *ap)
{
	int i;

	/* Init DAHDI span data */
	sprintf(ap->span.name, "AP200/%d", ap->num + 1);
	snprintf(ap->span.desc, sizeof(ap->span.desc) - 1, "%s Card %d",
	         ap->variety, ap->num + 1);
	ap->span.deflaw = DAHDI_LAW_ALAW;
	ap->span.spantype = SPANTYPE_ANALOG_MIXED;

	for (i = 0; i < ap->num_channels; ++i) {
		sprintf(ap->chans[i]->name, "AP200/%d/%d", ap->num + 1, i + 1);
		ap->chans[i]->sigcap = DAHDI_SIG_FXSKS | DAHDI_SIG_FXSLS |
				DAHDI_SIG_FXOKS | DAHDI_SIG_FXOLS | DAHDI_SIG_FXOGS |
				DAHDI_SIG_SF | DAHDI_SIG_EM | DAHDI_SIG_CLEAR;
		ap->chans[i]->chanpos = i + 1;
		ap->chans[i]->pvt = &ap->apchans[i];
		ap->chans[i]->writechunk = ap->writechunk + DAHDI_CHUNKSIZE * i;
		ap->chans[i]->readchunk = ap->readchunk + DAHDI_CHUNKSIZE * i;
	}
	ap->span.chans = ap->chans;
	ap->span.channels = ap->num_channels;
	ap->span.flags = DAHDI_FLAG_RBS;
	ap->span.ops = &ap2_span_ops;

	list_add_tail(&ap->span.device_node, &ap->ddev->spans);
	return 0;
}

static int ap2_bus_test(struct ap2 *ap)
{
	int res = 0;
	unsigned int val;

	ap->regs->debug = 0xAAAAAAAA;
	val = ap->regs->debug;
	if (val != 0xAAAAAAAA) {
		printk("Wrote 0xAAAAAAAA, Read 0x%08X!\n", val);
		res++;
	}
	ap->regs->debug = 0x55555555;
	val = ap->regs->debug;
	if (val != 0x55555555) {
		printk("Wrote 0x55555555, Read 0x%08X!\n", val);
		res++;
	}
	ap->regs->debug = 0xFFFFFFFF;
	val = ap->regs->debug;
	if (val != 0xFFFFFFFF) {
		printk("Wrote 0xFFFFFFFF, Read 0x%08X!\n", val);
		res++;
	}
	ap->regs->debug = 0x00000000;
	val = ap->regs->debug;
	if (val != 0x00000000) {
		printk("Wrote 0x00000000, Read 0x%08X!\n", val);
		res++;
	}
	return res;
}

static inline int ap2_detect_card(struct ap2 *ap)
{
	int i;

	/* Check Card ID */
	if (ap->regs->card_id != AP200_CARD_ID) {
		printk(KERN_ERR "AP200: Unknown card ID(0x%08X)! "
				"Aborting...\n", ap->regs->card_id);
		return -EPERM;
	}

	/* Test bus integrity */
	for (i = 0; i < 1000; i++) {
		if (ap2_bus_test(ap)) {
			printk("AP200: Bus integrity test failed! "
					"Aborting...\n");
			return -EIO;
		}
	}
	printk("AP200: Bus integrity OK!\n");

#if 0
	/* DDR Test */
#define AP_DDR_CALIB_OK		0x80000000
#define AP_DDR_RESET		0x40000000
#define AP_DDR_READ_REQ		0x20000000
#define AP_DDR_BUSY		0x08000000
#define AP_DDR_ADDR_MASK	0x01FFFFFF

	printk("AP200: DDR Status: %08x\n", ap->regs->ddr_ctrl);
	if (ap->regs->ddr_ctrl & AP_DDR_CALIB_OK) {
		/* Writes */
		for (i = 0; i < 256; i++) {
			ap->regs->ddr_ctrl = (i * 0x0404) & AP_DDR_ADDR_MASK;
			ap->regs->ddr_data = (i * 0x01010101) & 0xFFFFFFFF;
			while (ap->regs->ddr_ctrl & AP_DDR_BUSY);
		}
		/* Reads */
		for (i = 0; i < 256; i++) {
			unsigned data;
			ap->regs->ddr_ctrl = ((i * 0x0404) & AP_DDR_ADDR_MASK) | AP_DDR_READ_REQ;
			while (ap->regs->ddr_ctrl & AP_DDR_BUSY);
			data = ap->regs->ddr_data;
			if (((i * 0x01010101) & 0xFFFFFFFF) != data) {
				printk("DDR Error! Write %08x Read %08x Status %08x\n",
						(i * 0x01010101) & 0xFFFFFFFF, data,
						ap->regs->ddr_ctrl);
			}

		}
	}
#endif

	/* Init Card data */
	ap->fpga_version = ap->regs->fpga_ver;
	ap->num_channels = ap->regs->num_channels;
	ap->data = ioremap_nocache(pci_resource_start(ap->dev, 1),
				pci_resource_len(ap->dev, 1));
	if (ap->data == NULL) {
		printk(KERN_ERR "AP200: Unable to remap card data!\n");
		return -EIO;
	}
	ap->numpages = ap->regs->tdm_page_num;
	ap->pagesize = ap->regs->tdm_page_bytes;
	ap->pageoffset = ap->pagesize * ap->num_channels;

	ap->dt = (struct devtype *) &ap200;
	ap->variety = ap->dt->desc;

	printk("Found a %s (firmware version %d.%d) at %p\n", ap->variety,
			ap->fpga_version >> 8, ap->fpga_version & 0xFF, ap->regs);
	return 0;
}

static void __devexit ap2_remove_one(struct pci_dev *pdev);

static int __devinit ap2_init_one(struct pci_dev *pdev,
                                     const struct pci_device_id *ent)
{
	int res = 0;
	struct ap2 *ap;
	int i;
	int basesize;
	struct dahdi_chan *chan;

	/* Initialize PCI Device */
	if ((res = pci_enable_device(pdev)) != 0) {
		goto out;
	}

	/* Allocate card struct */
	ap = kmalloc(sizeof(struct ap2), GFP_KERNEL);
	if (ap == NULL) {
		res = -ENOMEM;
		goto out;
	}

	memset(ap, 0, sizeof(struct ap2));
	spin_lock_init(&ap->spi_lock);

	ap->dev = pdev;

	/* Request PCI regions */
	if ((res = pci_request_regions(pdev, "ap200")) != 0) {
		printk(KERN_ERR "AP200: Unable to request regions!\n");
		goto out;
	}

	/* Remap PCI address */
	ap->regs = (struct ap2_regs *) ioremap_nocache(
			pci_resource_start(pdev, 2), pci_resource_len(pdev, 2));
	if (ap->regs == NULL) {
		printk(KERN_ERR "AP200: Unable to remap registers!\n");
		res = -EIO;
		goto out;
	}

	/* Detect Card model */
	if ((res = ap2_detect_card(ap)) != 0)
		goto out;

	basesize = DAHDI_MAX_CHUNKSIZE * ap->num_channels;

#ifdef AP200_DMA
	ap->writechunk = pci_alloc_consistent(pdev, 2 * basesize,
			&ap->dma_addr);
	if (!ap->writechunk) {
		printk("%s: Unable to allocate DMA-able memory!\n",
				ap->variety);
		res = -ENOMEM;
		goto out;
	}
	/* Enable bus mastering */
	pci_set_master(pdev);

	/* Enable card DMA */
	ap->regs->dma_baseaddr = ap->dma_addr;
	ap->regs->dma_config = AP_DMA_ENABLE;
#else
	/* n channels, Double-buffer, Read/Write */
	ap->writechunk = kmalloc(2 * basesize, GFP_KERNEL);
	if (!ap->writechunk) {
		printk("%s: Unable to allocate memory!\n", ap->variety);
		res = -ENOMEM;
		goto out;
	}
#endif /* AP200_DMA */

	/* Read is after the whole write piece (in words) */
	ap->readchunk = ap->writechunk + basesize;

	/* Initialize Write/Buffers to all blank data */
	memset(ap->writechunk, 0x00, basesize);
	memset(ap->readchunk, 0xff, basesize);

	/* Keep track of which device we are */
	pci_set_drvdata(pdev, ap);

	/* Reset interruption counter */
	ap->intcount = 0;

	/* Allocate Card in Global array */
	for(i = 0; i < MAX_AP200_CARDS; i++) {
		if (!cards[i]) break;
	}
	if (i >= MAX_AP200_CARDS) {
		printk("No cards[] slot available!!\n");
		res = -ENOMEM;
		goto out;
	}
	ap->ddev = dahdi_create_device();
	if (ap->ddev == NULL) {
		printk("Error creating DAHDI device!!\n");
		res = -ENOMEM;
		goto out;
	}
	ap->num = i;
	cards[i] = ap;

	/* Allocate pieces we need here */
	for (i = 0; i < ap->num_channels; i++) {
		chan = kmalloc(sizeof(struct dahdi_chan), GFP_KERNEL);
		if (!chan) {
			res = -ENOMEM;
			goto out;
		}
		memset(chan, 0, sizeof(struct dahdi_chan));
		ap->chans[i] = chan;
		ap->apchans[i].dahdi = chan;
		ap->apchans[i].card = ap;
		ap->apchans[i].index = i;
	}

	/* Allocate IRQ handler */
	if (request_irq(pdev->irq, ap2_interrupt, IRQF_SHARED, "ap200", ap)) {
		printk("%s: Unable to request IRQ %d\n", ap->variety, pdev->irq);
		res = -EIO;
		goto out;
	}
	ap->irq = pdev->irq;

	ap->ddev->manufacturer = "Aligera";
	ap->ddev->devicetype = ap->variety;
	ap->ddev->location = kasprintf(GFP_KERNEL, "PCI Bus %02d Slot %02d",
			ap->dev->bus->number, PCI_SLOT(ap->dev->devfn) + 1);
	if (!ap->ddev->location) {
		res = -ENOMEM;
		goto out;
	}

	/* Init DAHDI span data */
	ap2_init_span(ap);

	/* Detect and init modules */
	ap2_detect_channels(ap);
	for (i = 0; i < ap->num_channels; ++i) {
		ap2_chan_init(&ap->apchans[i]);
	}

	/* Probe Octasic echo canceller module */
	ap->regs->oct_ctrl = APEC_OCT_CTRL_RESET_WORD;
#ifdef APEC_OCT_SUPPORT
	if (apec_enable == 1)
		ap2_oct_init(ap);
	if (!ap->oct)
		ap->regs->oct_ctrl = APEC_OCT_CTRL_RESET_WORD;
#endif

	/* Enable embedded Echo Canceller */
	if (apec_enable)
		ap->regs->ec_ctrl = APEC_TDM_ENABLE;
	else
		ap->regs->ec_ctrl = 0;
	if (ap->regs->ec_ctrl) {
		printk(KERN_INFO "APEC: Echo cancellation for %d channels\n",
				ap->num_channels);
	}

	/* Register DAHDI device */
	if (dahdi_register_device(ap->ddev, &ap->dev->dev)) {
		printk(KERN_NOTICE "Unable to register span with DAHDI\n");
		res = -ENOMEM;
		goto out;
	}

	/* Enable IRQ */
	ap2_irq_enable(ap);

out:
	if (res != 0) {
		ap2_remove_one(pdev);
	}
	return res;
}

static void __devexit ap2_remove_one(struct pci_dev *pdev)
{
	struct ap2 *ap = pci_get_drvdata(pdev);

	if (ap) {
		/* Disable Interrupt */
		ap2_irq_disable(ap);
		dahdi_unregister_device(ap->ddev);
		if (pdev->irq)
			free_irq(pdev->irq, ap);

#ifdef APEC_OCT_SUPPORT
		/* Stop echo cancellation module */
		ap2_oct_release(ap);
#endif

		/* Disable card DMA and unmap registers */
		if (ap->regs) {
			ap->regs->dma_config = 0;
			iounmap((void *) ap->regs);
			ap->regs = NULL;
		}

		/* Unmap addresses */
		if (ap->data)
			iounmap(ap->data);

		/* Immediately free resources */
#ifdef AP200_DMA
		pci_free_consistent(ap->dev,
		                    DAHDI_MAX_CHUNKSIZE * ap->num_channels,
		                    (void *) ap->writechunk, ap->dma_addr);
#else
		kfree((void *) ap->writechunk);
#endif
		dahdi_free_device(ap->ddev);
		kfree(ap);
	}

	/* Release PCI resources */
	pci_release_regions(pdev);
	pci_disable_device(pdev);
	pci_set_drvdata(pdev, NULL);

	printk(KERN_INFO "AP200 driver removed\n");
}

static struct pci_device_id ap2_pci_tbl[] __devinitdata =
{
	{ PCI_DEVICE(PCI_VENDOR_ID_XILINX, AP200_PCI_DEVICE_ID), },
	{ 0, }
};

static struct pci_driver ap2_driver = {
	name: 	"Aligera AP200 driver",
	probe: 	ap2_init_one,
	remove:	__devexit_p(ap2_remove_one),
	suspend: NULL,
	resume:	NULL,
	id_table: ap2_pci_tbl,
};

static int __init ap2_init(void)
{
	int res;
	printk(KERN_INFO "Aligera AP200 driver loaded\n");
	res = dahdi_pci_module(&ap2_driver);
	if (res) {
		return -ENODEV;
	}
	/* Initialize global array with all AP200 cards */
	memset(cards, 0, (sizeof(struct ap2 *)) * MAX_AP200_CARDS);
	return 0;
}

static void __exit ap2_cleanup(void)
{
	printk(KERN_INFO "Aligera AP200 driver cleanup\n");
	pci_unregister_driver(&ap2_driver);
}

MODULE_DESCRIPTION("Aligera AP200 driver");
MODULE_AUTHOR("Aligera AP200 maintainer (ap400@aligera.com.br)");
MODULE_LICENSE("GPL");

module_init(ap2_init);
module_exit(ap2_cleanup);
