/*
 * Name: fxs_proslic.c
 * Description: FXS Silicon Labs SI3215 ProSLIC driver
 *
 * Creator: Wagner Gegler <wagner@aligera.com.br>
 * Company: Aligera - www.aligera.com.br
 * Date: 2010/09/17
 *
 * Copyright (c) 2010 Aligera
 *
 * This program is free software; you can redistribute  it and/or modify it
 * under  the terms of  the GNU General  Public License as published by the
 * Free Software Foundation;  either version 2 of the  License, or (at your
 * option) any later version.
 */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/errno.h>
#include <linux/types.h>
#include <linux/interrupt.h>
#include <linux/time.h>
#include <linux/skbuff.h>
#include <linux/proc_fs.h>
#include <linux/delay.h>
#include <linux/dma-mapping.h>
#include <linux/string.h>
#include <linux/irq.h>
#include <linux/io.h>
#include <linux/wait.h>
#include <linux/timer.h>
#include <linux/init.h>
#include <linux/moduleparam.h>

#include "ap200.h"
#include "fxs_proslic.h"

#define DRV_NAME "FXS_ProSLIC"

/* #define DEBUG */
#ifdef DEBUG
#define PDEBUG(fmt, args...) { \
	printk(KERN_DEBUG DRV_NAME ": %s(%d): ", __FUNCTION__, __LINE__); \
	printk(fmt "\n", ## args); \
}
#else
#define PDEBUG(fmt, args...)
#endif

#define FXS_POWERUP_TIMEOUT	(HZ / 10)	/* 100 ms */
#define FXS_CALIBRATE_TIMEOUT	(6 * HZ / 10)	/* 600 ms (Datasheet: max = 600 ms) */

/* #define FXS_USE_HOOK_INTERRUPT */
#ifdef FXS_USE_HOOK_INTERRUPT
#define FXS_HOOK_DEBOUNCE	0
#else
#define FXS_HOOK_DEBOUNCE	1
#endif

#define FXS_OHT_TIMER		375		/* 6000 ms */

/* Direct Registers (SI3215) */
typedef enum {
	SPI_MODE = 0,
	PCM_MODE = 1,
	PCM_TXS_DELAY_LO = 2,
	PCM_TXS_DELAY_HI = 3,
	PCM_RXS_DELAY_LO = 4,
	PCM_RXS_DELAY_HI = 5,
	PN_ID = 6,
	AUDIO_LOOPBACK = 8,
	AUDIO_GAIN = 9,
	LINE_IMPEDANCE = 10,
	HYBRID = 11,
	POWERDOWN1 = 14,
	POWERDOWN2 = 15,
	INT_STATUS1 = 18,
	INT_STATUS2 = 19,
	INT_STATUS3 = 20,
	INT_ENABLE1 = 21,
	INT_ENABLE2 = 22,
	INT_ENABLE3 = 23,
	IND_DATA_LO = 28,
	IND_DATA_HI = 29,
	IND_ADDR = 30,
	IND_STATUS = 31,
	OSC1 = 32,
	OSC2 = 33,
	RING_OSC = 34,
	OSC1_ON_TIMER_LO = 36,
	OSC1_ON_TIMER_HI = 37,
	OSC1_OFF_TIMER_LO = 38,
	OSC1_OFF_TIMER_HI = 39,
	OSC2_ON_TIMER_LO = 40,
	OSC2_ON_TIMER_HI = 41,
	OSC2_OFF_TIMER_LO = 42,
	OSC2_OFF_TIMER_HI = 43,
	RING_OSC_ON_TIMER_LO = 48,
	RING_OSC_ON_TIMER_HI = 49,
	RING_OSC_OFF_TIMER_LO = 50,
	RING_OSC_OFF_TIMER_HI = 51,
	FSK_DATA = 52,
	LOOP_DEBOUNCE_AUTO = 63,
	LINEFEED = 64,
	EXT_BIPOLAR = 65,
	BAT_FEED = 66,
	AUTO_MANUAL = 67,
	LOOP_STATUS = 68,
	LOOP_DEBOUNCE = 69,
	RING_TRIP_DEBOUNCE = 70,
	LOOP_I_LIMIT = 71,
	ONHOOK_V = 72,
	COMMON_V = 73,
	BAT_HI_V = 74,
	BAT_LO_V = 75,
	POWER_MONITOR_PTR = 76,
	POWER_MONITOR = 77,
	LOOP_V_SENSE = 78,
	LOOP_I_SENSE = 79,
	TIP_V_SENSE = 80,
	RING_V_SENSE = 81,
	BAT_V_SENSE1 = 82,
	BAT_V_SENSE2 = 83,
	Q1_I_SENSE = 84,
	Q2_I_SENSE = 85,
	Q3_I_SENSE = 86,
	Q4_I_SENSE = 87,
	Q5_I_SENSE = 88,
	Q6_I_SENSE = 89,
	DCDC_PWM_PERIOD = 92,
	DCDC_DELAY = 93,
	PWM_PULSE_WIDTH = 94,
	CALIBRATION1 = 96,
	CALIBRATION2 = 97,
	RING_GAIN_CAL = 98,
	TIP_GAIN_CAL = 99,
	DIFF_I_GAIN_CAL = 100,
	COMMON_I_GAIN_CAL = 101,
	I_LIMIT_CAL = 102,
	ADC_OFFSET_CAL = 103,
	DAC_ADC_OFFSET = 104,
	DAC_OFFSET_CAL = 105,
	DC_PEAK_I_CAL = 107,
	ENHANCE_ENABLE = 108
} direct_regs;

/* Indirect Regs (SI3215) */
typedef enum {
	OSC1_FREQ = 0,
	OSC1_AMP = 1,
	OSC1_PHASE = 2,
	OSC2_FREQ = 3,
	OSC2_AMP = 4,
	OSC2_PHASE = 5,
	RING_OSC_DC = 6,
	RING_OSC_FREQ = 7,
	RING_OSC_AMP = 8,
	RING_OSC_PHASE = 9,
	RX_DAC_GAIN = 13,
	TX_ADC_GAIN = 14,
	LOOP_THRES = 15,
	RING_TRIP_THRES = 16,
	COMMON_MIN_THRES = 17,
	COMMON_MAX_THRES = 18,
	POWER_ALARM_Q1Q2 = 19,
	POWER_ALARM_Q3Q4 = 20,
	POWER_ALARM_Q5Q6 = 21,
	LOOP_FILTER = 22,
	RING_TRIP_FILTER = 23,
	THERM_LP_POLE_Q1Q2 = 24,
	THERM_LP_POLE_Q3Q4 = 25,
	THERM_LP_POLE_Q5Q6 = 26,
	COMMON_BIAS_RINGING = 27,
	DCDC_MIN_V = 64,
	LOOP_THRES_LOW = 66,
	FSK_AMP_SPACE = 69,
	FSK_FREQ_SPACE = 70,
	FSK_AMP_MARK = 71,
	FSK_FREQ_MARK = 72,
	FSK_RISE_TRANS = 73,
	FSK_FALL_TRANS = 74,
} indirect_regs;

#define FXS_INT_LOOP		0x02
#define FXS_INT_RING_TRIP	0x01

typedef enum {
	FXS_LF_OPEN = 0,
	FXS_LF_FWD_ACTIVE,
	FXS_LF_FWD_OHT,
	FXS_LF_TIP_OPEN,
	FXS_LF_RINGING,
	FXS_LF_RVD_ACTIVE,
	FXS_LF_RVD_OHT,
	FXS_LF_RING_OPEN
} linefeed_mode;

#define FXS_LF_POL_MASK		0x04

enum proslic_power_warn {
	PROSLIC_POWER_UNKNOWN = 0,
	PROSLIC_POWER_ON,
	PROSLIC_POWER_WARNED,
};

/* FXS ProSLIC intial indirect registers value */
struct {
	unsigned short address;
	unsigned short value;
} fxs_proslic_indirect_regs_init[] = {
	{OSC1_FREQ, 0x7B30},
	{OSC1_AMP, 0x0063},
	{OSC1_PHASE, 0x0000},
	{OSC2_FREQ, 0x7870},
	{OSC2_AMP, 0x007D},
	{OSC2_PHASE, 0x0000},
	{RING_OSC_DC, 0x1E00},
	{RING_OSC_FREQ, 0x7EF0},
	{RING_OSC_AMP, 0x0176},
	{RING_OSC_PHASE, 0x0000},
	{RX_DAC_GAIN, 0x2000},
	{TX_ADC_GAIN, 0x4000},
	{LOOP_THRES, 0x1000},
	{RING_TRIP_THRES, 0x3600},
	{COMMON_MIN_THRES, 0x1000},
	{COMMON_MAX_THRES, 0x0200},
	{POWER_ALARM_Q1Q2, 0x07C0},
	{POWER_ALARM_Q3Q4, 0x2600},
	{POWER_ALARM_Q5Q6, 0x1B80},
	{LOOP_FILTER, 0x8000},
	{RING_TRIP_FILTER, 0x0320},
	{THERM_LP_POLE_Q1Q2, 0x008C},
	{THERM_LP_POLE_Q3Q4, 0x0100},
	{THERM_LP_POLE_Q5Q6, 0x0010},
	{COMMON_BIAS_RINGING, 0x0C00},
	{DCDC_MIN_V, 0x0C00},
	{LOOP_THRES_LOW, 0x1000}
};

typedef struct
{
    int   gain;
    int   scale;
} ProSLIC_GainScaleLookup;

/* Gain tables for Si321x */
static const ProSLIC_GainScaleLookup gainScaleTable_0dB[] =
/*  gain, scale=16384* 10^(gain/20) - sorted order */
{
    { -12,0x1013},
    { -11,0x1209},
    { -10,0x143D},
    { -9, 0x16B5},
    { -8, 0x197A},
    { -7, 0x1C96},
    { -6, 0x2013},
    { -5, 0x23FD},
    { -4, 0x2861},
    { -3, 0x2D4E},
    { -2, 0x32D6},
    { -1, 0x390A},
    { 0,  0x4000},
    { 1,  0x47CF},
    { 2,  0x5092},
    { 3,  0x5A67},
    { 4,  0x656E},
    { 5,  0x71CF},
    { 6,  0x7FB2},
    {0xff,0} /* terminator */
};

static void fxs_proslic_set_reg(struct ap_chan *chan,
                                unsigned char reg, unsigned char value)
{
	struct ap2 *ap = chan->card;
	unsigned long flags;

	spin_lock_irqsave(&ap->spi_lock, flags);
	ap->regs->spi_ctrl = chan->index & AP_SPI_SEL_MASK;
	ap2_spi_write_byte(ap, reg & 0x7F);
	ap2_spi_write_byte(ap, value);
	spin_unlock_irqrestore(&ap->spi_lock, flags);
}

static unsigned char fxs_proslic_get_reg(struct ap_chan *chan,
                                         unsigned char reg)
{
	struct ap2 *ap = chan->card;
	unsigned long flags;
	unsigned char data;

	spin_lock_irqsave(&ap->spi_lock, flags);
	ap->regs->spi_ctrl = chan->index & AP_SPI_SEL_MASK;
	ap2_spi_write_byte(ap, (reg & 0x7F) | 0x80);
	data = ap2_spi_read_byte(ap);
	spin_unlock_irqrestore(&ap->spi_lock, flags);

	return data;
}

static int fxs_proslic_wait_indirect_access(struct ap_chan *chan)
{
	int timeout = 0;
	/* Wait for indirect access */
	while (fxs_proslic_get_reg(chan, IND_STATUS)) {
		if (timeout >= HZ) {
			printk(KERN_WARNING DRV_NAME ": Error! "
					"Indirect access timeout!\n");
			return -1;
		} else {
			schedule_timeout(1);
			timeout++;
		}
	}

	return 0;
}

/*
 * Write ProSLIC indirect register
 * Returns -1, if access timed out
 */
static int fxs_proslic_set_indirect_reg(struct ap_chan *chan,
                                        unsigned reg,
                                        unsigned short value)
{
	/* Wait for pending indirect register access */
	int ret = fxs_proslic_wait_indirect_access(chan);
	if (!ret) {
		fxs_proslic_set_reg(chan, IND_DATA_LO, value & 0xFF);
		fxs_proslic_set_reg(chan, IND_DATA_HI, (value >> 8) & 0xFF);
		fxs_proslic_set_reg(chan, IND_ADDR, reg);
	}

	return ret;
}

/*
 * Read ProSLIC indirect register
 * Returns -1, if access timed out
 */
static int fxs_proslic_get_indirect_reg(struct ap_chan *chan,
                                        unsigned reg,
                                        unsigned short *value)
{
	/* Wait for pending indirect access */
	int ret = fxs_proslic_wait_indirect_access(chan);
	if (!ret) {
		fxs_proslic_set_reg(chan, IND_ADDR, reg);

		/* Wait for pending indirect read */
		ret = fxs_proslic_wait_indirect_access(chan);
		if (!ret) {
			*value = fxs_proslic_get_reg(chan, IND_DATA_HI) << 8;
			*value |= fxs_proslic_get_reg(chan, IND_DATA_LO) & 0xFF;
		}
	}

	return ret;
}

/*
 * Write initial values to ProSLIC indirect registers
 * Returns -1, if any access timed out
 */
static int fxs_proslic_init_indirect_regs(struct ap_chan *chan)
{
	int i;
	int len = sizeof(fxs_proslic_indirect_regs_init)
	                / sizeof(fxs_proslic_indirect_regs_init[0]);

	for (i = 0; i < len; i++) {
		if (fxs_proslic_set_indirect_reg(chan,
		                fxs_proslic_indirect_regs_init[i].address,
		                fxs_proslic_indirect_regs_init[i].value))
			return -1;
	}

	return 0;
}

/*
 * Verify if ProSLIC indirect registers has initial values
 * Returns -1, if register has wrong value
 * Returns -2, if any access timed out
 */
static int fxs_proslic_verify_indirect_regs(struct ap_chan *chan)
{
	int i;
	int ret;
	int len = sizeof(fxs_proslic_indirect_regs_init)
	                / sizeof(fxs_proslic_indirect_regs_init[0]);
	unsigned short initial, value;
	unsigned char address;

	for (i = 0; i < len; i++) {
		initial = fxs_proslic_indirect_regs_init[i].value;
		address = fxs_proslic_indirect_regs_init[i].address;

		ret = fxs_proslic_get_indirect_reg(chan, address, &value);
		if (ret < 0) {
			ret = -2;
			break;
		}
#ifdef DEBUG
		if (value != initial) {
			PDEBUG(KERN_DEBUG DRV_NAME ": Read %d @ %d, should be "
					"%d\n", value, address, initial);
		}
#endif
	}

	if (ret) {
		printk(KERN_WARNING DRV_NAME ": Failed to verify "
				"indirect registers initial value\n");
		return ret;
	}
#ifdef DEBUG
	printk(KERN_DEBUG DRV_NAME ": Indirect registers initial value "
		       "sucessfully verified\n");
#endif
	return 0;
}

static inline int fxs_proslic_get_polarity(struct ap_chan *chan)
{
	return chan->fxs.reversepolarity;
}

int fxs_proslic_set_polarity(struct ap_chan *chan, int polarity)
{
	struct fxs_proslic *fxs = &chan->fxs;

	/* Can't change polarity while ringing or when open */
	if ((fxs->lasttxhook == FXS_LF_RINGING) ||
	    (fxs->lasttxhook == FXS_LF_OPEN))
		return -EINVAL;
	fxs->reversepolarity = polarity;
	if (fxs_proslic_get_polarity(chan)) {
		fxs->lasttxhook |= FXS_LF_POL_MASK;
		printk(KERN_INFO "ioctl: Reverse Polarity on channel %d\n",
				chan->index + 1);
	} else {
		fxs->lasttxhook &= ~FXS_LF_POL_MASK;
		printk(KERN_INFO "ioctl: Normal Polarity on channel %d\n",
				chan->index + 1);
	}
	fxs_proslic_set_reg(chan, LINEFEED, fxs->lasttxhook);
	return 0;
}

int fxs_proslic_onhook_transfer(struct ap_chan *chan, int timer)
{
	struct fxs_proslic *fxs = &chan->fxs;

	fxs->ohttimer = timer;

	/* Active mode when idle */
	if (fxs_proslic_get_polarity(chan)) {
		fxs->idletxhook = FXS_LF_RVD_ACTIVE;
		fxs->lasttxhook = FXS_LF_RVD_ACTIVE;
	} else {
		fxs->idletxhook = FXS_LF_FWD_ACTIVE;
		fxs->lasttxhook = FXS_LF_FWD_ACTIVE;
	}

	fxs_proslic_set_reg(chan, LINEFEED, fxs->lasttxhook);
	return 0;
}

void fxs_proslic_check_oht(struct ap_chan *chan)
{
	struct fxs_proslic *fxs = &chan->fxs;

	if (fxs->lasttxhook == FXS_LF_RINGING) {
		/* RINGing, prepare for OHT */
		fxs->ohttimer = FXS_OHT_TIMER;

		/* OHT mode when idle */
		if (fxs_proslic_get_polarity(chan))
			fxs->idletxhook = FXS_LF_RVD_OHT;
		else
			fxs->idletxhook = FXS_LF_FWD_OHT;
	} else if (fxs->ohttimer) {
		/* check if still OnHook */
		if (!fxs->lastrxhook) {
			if (--fxs->ohttimer == 0) {
				/* Switch to Active, Rev or Fwd */
				if (fxs_proslic_get_polarity(chan))
					fxs->idletxhook = FXS_LF_RVD_ACTIVE;
				else
					fxs->idletxhook = FXS_LF_FWD_ACTIVE;

				/* if currently OHT */
				if ((fxs->lasttxhook == FXS_LF_FWD_OHT) ||
						(fxs->lasttxhook == FXS_LF_RVD_OHT)) {
					fxs->lasttxhook = fxs->idletxhook;

					/* Apply the change as appropriate */
					fxs_proslic_set_reg(chan, LINEFEED,
							fxs->lasttxhook);
				}
			}
		} else {
			fxs->ohttimer = 0;
			/* Switch to Active, Rev or Fwd */
			if (fxs_proslic_get_polarity(chan))
				fxs->idletxhook = FXS_LF_RVD_ACTIVE;
			else
				fxs->idletxhook = FXS_LF_FWD_ACTIVE;

		}
	}
}

void fxs_proslic_check_hook(struct ap_chan *chan)
{
	struct fxs_proslic *fxs = &chan->fxs;
	int hook;

	/* Check Onhook Transmission settings */
	fxs_proslic_check_oht(chan);

	/* Get new loop closure status (hook) */
	hook = (fxs_proslic_get_reg(chan, LOOP_STATUS) & 0x03);

	/* Debounce hook state */
	if (hook == fxs->lastrxhook) {
		fxs->hookdebounce = 0;
		return;
	}
	if (++fxs->hookdebounce < FXS_HOOK_DEBOUNCE)
		return;

	/* Hook state has changed */
	fxs->hookdebounce = 0;

	PDEBUG("Channel %d has hook %d", chan->index + 1, hook);

	if (hook) {
		/* Offhook */
		switch (fxs->lasttxhook) {
		case FXS_LF_RINGING:
		case FXS_LF_FWD_OHT:
		case FXS_LF_RVD_OHT:
			/* just detected OffHook, during
			 * Ringing or OnHookTransfer */
			if (fxs_proslic_get_polarity(chan)) {
				fxs->idletxhook = FXS_LF_RVD_OHT;
			} else {
				fxs->idletxhook = FXS_LF_FWD_OHT;
			}
			break;
		}
		fxs_proslic_hooksig(chan, DAHDI_TXSIG_OFFHOOK);
		dahdi_hooksig(chan->dahdi, DAHDI_RXSIG_OFFHOOK);
	} else {
		/* Onhook */
		fxs_proslic_hooksig(chan, DAHDI_TXSIG_ONHOOK);
		dahdi_hooksig(chan->dahdi, DAHDI_RXSIG_ONHOOK);
	}

	fxs->lastrxhook = hook;
}

int fxs_proslic_hooksig(struct ap_chan *chan, enum dahdi_txsig txsig)
{
	struct fxs_proslic *fxs = &chan->fxs;

	switch (txsig) {
	case DAHDI_TXSIG_ONHOOK:
		switch (chan->dahdi->sig) {
		case DAHDI_SIG_FXOKS:
		case DAHDI_SIG_FXOLS:
			fxs->lasttxhook = fxs->idletxhook;
			break;
		case DAHDI_SIG_EM:
			fxs->lasttxhook = fxs->idletxhook;
			break;
		case DAHDI_SIG_FXOGS:
			fxs->lasttxhook = FXS_LF_TIP_OPEN;
			break;
		}
		break;
	case DAHDI_TXSIG_OFFHOOK:
		switch (chan->dahdi->sig) {
		case DAHDI_SIG_EM:
			fxs->lasttxhook = FXS_LF_RVD_ACTIVE;
			break;
		default:
			fxs->lasttxhook = fxs->idletxhook;
			break;
		}
		break;
	case DAHDI_TXSIG_START:
		fxs->lasttxhook = FXS_LF_RINGING;
		break;
	case DAHDI_TXSIG_KEWL:
		fxs->lasttxhook = FXS_LF_OPEN;
		break;
#if 0	/* Todo: OHT */
	case DAHDI_TXSIG_OHT:
		fxs->lasttxhook = fxs->reversepolarity ? FXS_LF_RVD_OHT : FXS_LF_FWD_OHT;
		break;
#endif
	default:
		PDEBUG( "Can't set tx state to %d on channel %d\n", txsig,
				chan->index + 1);
		return -1;
	}
	PDEBUG("Setting FXS hook state to %d (%02x) on channel %d",
		       txsig, fxs->lasttxhook, chan->index + 1);
	/* Set new linefeed configuration */
	fxs_proslic_set_reg(chan, LINEFEED, fxs->lasttxhook);
	return 0;
}

int fxs_proslic_sanity_check(struct ap_chan *chan)
{
	unsigned char value;

	/* Check part number ID */
	value = fxs_proslic_get_reg(chan, PCM_MODE);
	if ((value & 0x80) == 0) {
		printk(KERN_NOTICE DRV_NAME ": module %d is not SI3215 "
				"(%02X)\n", chan->index + 1, value);
		return -1;
	}

	/* Test some reset values */
	value = fxs_proslic_get_reg(chan, SPI_MODE);
	if (((value & 0xf) == 0) || ((value & 0xf) == 0xf)) {
		printk(KERN_NOTICE DRV_NAME ": module %d is not loaded "
				"(%02X)\n", chan->index + 1, value);
		return -1;
	}
	return 0;
}

int fxs_proslic_detect(struct ap_chan *chan)
{
	unsigned char value;

	/* Check part number ID */
	value = fxs_proslic_get_reg(chan, PCM_MODE);
	if ((value & 0x80) == 0) {
#ifdef DEBUG
		printk(KERN_NOTICE DRV_NAME ": module %d is not SI3215 "
				"(%02X)\n", chan->index + 1, value);
#endif
		return -1;
	}

	/* Test some reset values */
	value = fxs_proslic_get_reg(chan, SPI_MODE);
	if (((value & 0xf) == 0) || ((value & 0xf) == 0xf)) {
#ifdef DEBUG
		printk(KERN_NOTICE DRV_NAME ": module %d is not loaded "
				"(%02X)\n", chan->index + 1, value);
#endif
		return -1;
	}

	value = fxs_proslic_get_reg(chan, AUDIO_LOOPBACK);
	if (value != 0x2) {
		printk(KERN_NOTICE DRV_NAME ": module %d insane R8 is %02X, "
				"should be 0x2\n",
				chan->index + 1, value);
		return -1;
	}

	value = fxs_proslic_get_reg(chan, LINEFEED);
	if (value != 0x0) {
		printk(KERN_NOTICE DRV_NAME ": module %d insane R64 is %02X, "
				"should be 0x0\n",
				chan->index + 1, value);
		return -1;
	}

	value = fxs_proslic_get_reg(chan, HYBRID);
	if (value != 0x33) {
		printk(KERN_NOTICE DRV_NAME ": module %d insane R11 is %2X, "
				"should be 0x33\n",
				chan->index + 1, value);
		return -1;
	}

	/* Just be sure it's setup right */
	fxs_proslic_set_reg(chan, IND_ADDR, 0);

#ifdef DEBUG
	printk(KERN_DEBUG DRV_NAME ": module %d seems sane.\n",
		       chan->index + 1);
#endif
	return 0;
}

static int fxs_proslic_powerleak_test(struct ap_chan *chan)
{
	unsigned long origjiffies;
	unsigned long timeout = 0;
	unsigned char vbat;

	/* Turn off linefeed */
	fxs_proslic_set_reg(chan, LINEFEED, FXS_LF_OPEN);

	/* Power down */
	fxs_proslic_set_reg(chan, POWERDOWN1, 0x10);

	/* Wait for half a second */
	origjiffies = jiffies;

	while ((vbat = fxs_proslic_get_reg(chan, BAT_V_SENSE1)) > 0x6) {
		timeout = jiffies - origjiffies;
		if (timeout >= FXS_POWERUP_TIMEOUT) {
			break;
		} else {
			schedule_timeout(FXS_POWERUP_TIMEOUT - timeout);
		}
	}

	if (vbat < 0x06) {
		printk(KERN_WARNING DRV_NAME ": Excessive leakage detected "
				"on module %d: %d volts (%02x) after %ld ms\n",
		                chan->index + 1, 376 * vbat / 1000, vbat,
		                timeout * 1000 / HZ);
		return -1;
#ifdef DEBUG
	} else {
		printk(KERN_DEBUG DRV_NAME ": Post-leakage voltage: %d volts\n",
				376 * vbat / 1000);
#endif
	}

	return 0;
}

static int fxs_proslic_powerup(struct ap_chan *chan, int fast)
{
	struct fxs_proslic *fxs = &chan->fxs;
	unsigned char vbat;
	unsigned long origjiffies;
	unsigned long timeout = 0;

	/* Set period of DC-DC converter to (was 1/64 khz) */
	fxs_proslic_set_reg(chan, DCDC_PWM_PERIOD, 0xdb); /* was 0xff */

	/* Wait for VBat to powerup */
	origjiffies = jiffies;

	/* Disable powerdown */
	fxs_proslic_set_reg(chan, POWERDOWN1, 0);

	/* If fast, don't bother checking anymore */
	if (fast)
		return 0;

	while ((vbat = fxs_proslic_get_reg(chan, BAT_V_SENSE1)) < 0xc0) {
		/* Wait no more than 500ms */
		timeout = jiffies - origjiffies;
		if (timeout >= FXS_POWERUP_TIMEOUT) {
			break;
		} else {
			schedule_timeout(FXS_POWERUP_TIMEOUT - timeout);
		}
	}

	/* Each step is 376 mV, 0xa9 * -376 mV = -63544V mV */
	if (vbat < 0xa9) {
		if (fxs->power == PROSLIC_POWER_UNKNOWN)
			printk(KERN_WARNING DRV_NAME ": module %d failed to "
					"powerup within %ld ms (%d mV only)\n",
			                chan->index + 1,
			                timeout * 1000 / HZ,
			                vbat * 376);
		fxs->power = PROSLIC_POWER_WARNED;
		return -1;
#ifdef DEBUG
	} else {
		printk(KERN_DEBUG DRV_NAME ": module %d powered up to -%d volts"
				" (%02x) in %ld ms\n", chan->index + 1,
		                vbat * 376 / 1000, vbat, timeout * 1000 / HZ);
#endif
	}
	fxs->power = PROSLIC_POWER_ON;

#if 1
	/* Set ProSLIC max allowed loop current (LOOP_I_LIMIT) to 20 mA (0) */
	fxs_proslic_set_reg(chan, LOOP_I_LIMIT, 0);
#else
	/* Set ProSLIC max allowed loop current (LOOP_I_LIMIT) to 26 mA (2) */
	fxs_proslic_set_reg(chan, LOOP_I_LIMIT, 2);
#endif

	/* Engage DC-DC converter */
	fxs_proslic_set_reg(chan, DCDC_DELAY, 0x14); /* was 0x19 */

	/* Wait for DC-DC calibration end */
	origjiffies = jiffies;
	while (0x80 & fxs_proslic_get_reg(chan, DCDC_DELAY)) {
		timeout = jiffies - origjiffies;
		if (timeout >= 2 * HZ) {
			printk(KERN_WARNING DRV_NAME ": Timeout waiting for "
					"DC-DC calibration on module %d\n",
					chan->index + 1);
			return -1;
		} else {
			schedule_timeout(2 * HZ - timeout);
		}
	}

	return 0;

}

#ifndef NO_CALIBRATION
static int fxs_proslic_manual_calibrate(struct ap_chan *chan)
{
	unsigned long origjiffies;
	unsigned long timeout = 0;
	unsigned char i;

	/* Disable all interrupts */
	fxs_proslic_set_reg(chan, INT_ENABLE1, 0);
	fxs_proslic_set_reg(chan, INT_ENABLE2, 0);
	fxs_proslic_set_reg(chan, INT_ENABLE3, 0);

	/* Set Linefeed state to Open */
	fxs_proslic_set_reg(chan, LINEFEED, FXS_LF_OPEN);

	/* 0x18: Calibrations  without the ADC and DAC offset
	 * and without common mode calibration */
	fxs_proslic_set_reg(chan, CALIBRATION2, 0x18);

	/* 0x47: Calibrate common mode and differential DAC mode DAC + ILIM */
	fxs_proslic_set_reg(chan, CALIBRATION1, 0x47);

	origjiffies = jiffies;
	while (fxs_proslic_get_reg(chan, CALIBRATION1) != 0) {
		timeout = jiffies - origjiffies;
		if (timeout >= FXS_CALIBRATE_TIMEOUT) {
			return -1;
		} else {
			schedule_timeout(FXS_CALIBRATE_TIMEOUT - timeout);
		}
	}
	/* Initialized RING_GAIN_CAL and TIP_GAIN_CAL registers */
	/* to get consistant results */
	/* These are the results registers */
	/* and the search should have same initial conditions */

	/* The following is the manual gain mismatch calibration */
	/* This is also available as a function */
	msleep(10); /* 10 ms delay */

	/* Reset FSK Control */
	fxs_proslic_set_indirect_reg(chan, FSK_AMP_SPACE, 0);
	fxs_proslic_set_indirect_reg(chan, FSK_FREQ_SPACE, 0);
	fxs_proslic_set_indirect_reg(chan, FSK_AMP_MARK, 0);
	fxs_proslic_set_indirect_reg(chan, FSK_FREQ_MARK, 0);
	fxs_proslic_set_indirect_reg(chan, FSK_RISE_TRANS, 0);
	fxs_proslic_set_indirect_reg(chan, FSK_FALL_TRANS, 0);

	/* Necessary if the calibration occurs other than at reset time */
	fxs_proslic_set_reg(chan, RING_GAIN_CAL, 0x10);
	fxs_proslic_set_reg(chan, TIP_GAIN_CAL, 0x10);

	for (i = 31; i > 0; i--) {
		fxs_proslic_set_reg(chan, RING_GAIN_CAL, i);
		msleep(40);
		if ((fxs_proslic_get_reg(chan, Q5_I_SENSE)) == 0)
			break;
	}

	for (i = 31; i > 0; i--) {
		fxs_proslic_set_reg(chan, TIP_GAIN_CAL, i);
		msleep(40);
		if ((fxs_proslic_get_reg(chan, Q6_I_SENSE)) == 0)
			break;
	}

	/* The preceding is the manual gain mismatch calibration */
	/* The following is the longitudinal Balance Cal */
	fxs_proslic_set_reg(chan, LINEFEED, FXS_LF_FWD_ACTIVE);
	msleep(100);
	fxs_proslic_set_reg(chan, LINEFEED, FXS_LF_OPEN);

	/* This is a singular calibration bit for longitudinal calibration */
	fxs_proslic_set_reg(chan, CALIBRATION2, 0x01);
	fxs_proslic_set_reg(chan, CALIBRATION1, 0x40);

	fxs_proslic_get_reg(chan, CALIBRATION1); /* Read Reg 96 just cause */

	/* The preceding is the longitudinal Balance Cal */
	return 0;
}

static int fxs_proslic_auto_calibrate(struct ap_chan *chan)
{
	unsigned long origjiffies;
	unsigned long timeout = 0;
#ifdef DEBUG
	int i;
#endif

	/* Perform all calibrations */
	fxs_proslic_set_reg(chan, CALIBRATION2, 0x1f);

	/* Begin, no speedup */
	fxs_proslic_set_reg(chan, CALIBRATION1, 0x5f);

	/* Wait for it to finish */
	origjiffies = jiffies;

	while (fxs_proslic_get_reg(chan, CALIBRATION1)) {
		timeout = jiffies - origjiffies;
		if (timeout >= FXS_CALIBRATE_TIMEOUT) {
			printk(KERN_WARNING DRV_NAME ": Automatic calibration "
					"on module %d timed out\n",
					chan->index + 1);
			return -1;
		} else {
			schedule_timeout(FXS_CALIBRATE_TIMEOUT - timeout);
		}
	}

#ifdef DEBUG
	/* Print calibration parameters */
	printk(KERN_DEBUG DRV_NAME ": Calibration vector registers\n");
	for (i = RING_GAIN_CAL; i <= DC_PEAK_I_CAL; i++) {
		printk("Reg %d: %02x\n", i, fxs_proslic_get_reg(chan, i));
	}
#endif
	return 0;
}

static int fxs_proslic_calibrate(struct ap_chan *chan, int manual)
{
	unsigned char value;
	int first, second;
	int i;

	/* Perform calibration */
	if (manual) {
		/* Manual calibration first attempt*/
		first = fxs_proslic_manual_calibrate(chan);

		/* If first attempt fails, try once again */
		if (first)
			second = fxs_proslic_manual_calibrate(chan);

		/* Report manual calibration */
		if (!first) {
			printk(KERN_INFO DRV_NAME ": module %d passed "
					"manual calibration on first attempt\n",
					chan->index + 1);
		} else if (!second) {
			printk(KERN_INFO DRV_NAME ": module %d passed "
				       "manual calibration on second attempt\n",
				       chan->index + 1);
		} else {
			printk(KERN_NOTICE DRV_NAME ": module %d failed manual "
					"calibration on first and second "
					"attempts\n", chan->index + 1);
		}
	} else {
		/* Automatic calibration first attempt*/
		first = fxs_proslic_auto_calibrate(chan);

		/* If first attempt fails, try once again */
		if (first)
			second = fxs_proslic_auto_calibrate(chan);

		/* Report automatic calibration */
		if (!first) {
			printk(KERN_INFO DRV_NAME ": module %d passed automatic"
					" calibration on first attempt\n",
					chan->index + 1);
		} else if (!second) {
			printk(KERN_INFO DRV_NAME ": module %d passed automatic"
				       " calibration on second attempt\n",
				       chan->index + 1);
		} else {
			printk(KERN_NOTICE DRV_NAME ": module %d failed "
					"automatic calibration on both "
					"attempts\n", chan->index + 1);
		}
	}

	/* Perform DC-DC calibration */
	fxs_proslic_set_reg(chan, DCDC_DELAY, 0x99);
	value = fxs_proslic_get_reg(chan, DC_PEAK_I_CAL);
	if ((value < 0x2) || (value > 0xd)) {
#ifdef DEBUG
		printk(KERN_DEBUG DRV_NAME ": module %d "
				"DC-DC cal has a surprising DC_PEAK_I_CAL "
				"of 0x%02x!\n", chan->index + 1, value);
#endif
		fxs_proslic_set_reg(chan, DC_PEAK_I_CAL, 0x8);
	}

	/* Save calibration vectors */
	for (i = 0; i < NUM_CAL_REGS; i++)
		chan->fxs.cal_values[i] = fxs_proslic_get_reg(chan, CALIBRATION1 + i);
	return 0;
}
#endif

static int fxs_proslic_config(struct ap_chan *chan, int fast,
                              int manual, int sane)
{
	int i;
	unsigned short filter[5];

	/* Sanity check the ProSLIC */
	if (!sane && fxs_proslic_detect(chan)) {
		return -2;
	}

	if (sane) {
		/* Make sure we turn off the DC->DC converter to prevent
		 *  anything from blowing up */
		fxs_proslic_set_reg(chan, POWERDOWN1, 0x10);
	}

	if (fxs_proslic_init_indirect_regs(chan)) {
		printk(KERN_WARNING DRV_NAME ": module %d failed to initialize "
				"indirect registers\n", chan->index + 1);
		return -1;
	}

#if 1
	/* Clear scratch pad area */
	fxs_proslic_set_indirect_reg(chan, 97, 0);
#endif

	/* Clear digital loopback */
	fxs_proslic_set_reg(chan, AUDIO_LOOPBACK, 0);

	/* Revision C optimization */
	fxs_proslic_set_reg(chan, ENHANCE_ENABLE, 0xeb);

	/* Disable automatic VBat switching for safety to prevent
	 Q7 from accidently turning on and burning out. */
	fxs_proslic_set_reg(chan, AUTO_MANUAL, 0x17);

	/* Turn off Q7 */
	fxs_proslic_set_reg(chan, BAT_FEED, 1);

	/* wgegler: set loop closure debounce interval 100 ms */
	fxs_proslic_set_reg(chan, LOOP_DEBOUNCE, 0x50);
	fxs_proslic_set_reg(chan, RING_TRIP_DEBOUNCE, 0x50);

	/* wgegler: set Ring OFFSET */
	fxs_proslic_set_reg(chan, RING_OSC, 0x02);

	/* Flush ProSLIC digital filters by setting to clear, while
	 saving old values */
	for (i = 0; i < 5; i++) {
		fxs_proslic_get_indirect_reg(chan, i + LOOP_FILTER, &filter[i]);
		fxs_proslic_set_indirect_reg(chan, i + LOOP_FILTER, 0x8000);
	}

	/* Power up the DC-DC converter */
	if (fxs_proslic_powerup(chan, fast)) {
		printk(KERN_WARNING DRV_NAME ": Unable to do initial powerup "
				"on module %d\n", chan->index + 1);
		return -1;
	}

	if (fast) {
		/* Restore calibration registers */
		for (i = 0; i < NUM_CAL_REGS; i++)
			fxs_proslic_set_reg(chan, CALIBRATION1 + i,
					chan->fxs.cal_values[i]);
	} else {
		/* Check for power leaks */
		if (fxs_proslic_powerleak_test(chan)) {
			printk(KERN_NOTICE DRV_NAME ": module %d failed leakage"
					" test.  Check for short circuit\n",
			                chan->index + 1);
		}

		/* Power up again */
		if (fxs_proslic_powerup(chan, 0)) {
			printk(KERN_WARNING DRV_NAME ": Unable to do final "
					"powerup on module %d\n",
					chan->index + 1);
			return -1;
		}
#ifndef NO_CALIBRATION
		fxs_proslic_calibrate(chan, manual);
#endif
	}

	/* Calibration complete, restore original values */
	for (i = 0; i < 5; i++) {
		fxs_proslic_set_indirect_reg(chan, i + LOOP_FILTER, filter[i]);
	}

	/* Verify indirect registers initial value attribution */
	if (fxs_proslic_verify_indirect_regs(chan)) {
		return -1;
	}

	/* Set a-law and tri-state bit 0 on negative edge of PCLK */
	fxs_proslic_set_reg(chan, PCM_MODE, 0x21);

	/* Set Tx and Rx PCM sync delay */
	fxs_proslic_set_reg(chan, PCM_TXS_DELAY_LO, chan->fxs.txs_delay & 0xFF);
	fxs_proslic_set_reg(chan, PCM_TXS_DELAY_HI, chan->fxs.txs_delay >> 8);
	fxs_proslic_set_reg(chan, PCM_RXS_DELAY_LO, chan->fxs.rxs_delay & 0xFF);
	fxs_proslic_set_reg(chan, PCM_RXS_DELAY_HI, chan->fxs.rxs_delay >> 8);

	/* Clear interrupt status */
	fxs_proslic_set_reg(chan, INT_STATUS1, 0xff);
	fxs_proslic_set_reg(chan, INT_STATUS2, 0xff);
	fxs_proslic_set_reg(chan, INT_STATUS3, 0xff);

	/* Set Common Voltage higher to prevent audio squelch */
	fxs_proslic_set_reg(chan, COMMON_V, 0x04);

	/* Enable two-wire impedance synthesis (600 Ohm) */
	fxs_proslic_set_reg(chan, LINE_IMPEDANCE, 0x08);

#if 0
	/* Set onhook voltage lower for low power */
	if (lowpower)
		fxs_proslic_set_reg(chan, ONHOOK_V, 0x10);
#endif

#ifdef FXS_USE_HOOK_INTERRUPT
	/* Enable interrupts (loop detection) */
	fxs_proslic_set_reg(chan, INT_ENABLE1, 0x00);
	fxs_proslic_set_reg(chan, INT_ENABLE2, FXS_INT_LOOP | FXS_INT_RING_TRIP);
	fxs_proslic_set_reg(chan, INT_ENABLE3, 0x00);
#endif

#if 0
	/* Enable loopback */
	fxs_proslic_set_reg(chan, AUDIO_LOOPBACK, 0x2);
	fxs_proslic_set_reg(chan, POWERDOWN1, 0x0);
	fxs_proslic_set_reg(chan, LINEFEED, FXS_LF_OPEN);
	fxs_proslic_set_reg(chan, PCM_MODE, 0x08);
#endif

	/* Set Linefeed to Forward Active */
	fxs_proslic_set_reg(chan, LINEFEED, FXS_LF_FWD_ACTIVE);

	return 0;
}

static int fxs_proslic_probe(struct ap_chan *chan)
{
	int ret;
	unsigned char value;

	/* Init with Auto Calibration */
	ret = fxs_proslic_config(chan, 0, 0, 0);
	if (!ret) {
		value = fxs_proslic_get_reg(chan, LOOP_I_LIMIT);
#ifdef DEBUG
		printk(KERN_DEBUG DRV_NAME
			       ": module %d loop current is %d mA\n",
			       chan->index + 1, ((value * 3) + 20));
#endif
		return 0;
	}

	if (ret == -2) {
		printk(KERN_WARNING DRV_NAME ": module %d not found\n",
				chan->index + 1);
		return -1;
	}

	/* Init with Manual Calibration */
	ret = fxs_proslic_config(chan, 0, 1, 1);
	if (ret) {
		printk(KERN_WARNING DRV_NAME ": module %d probe failed\n",
				chan->index + 1);
		return -1;
	}

	value = fxs_proslic_get_reg(chan, LOOP_I_LIMIT);
#ifdef DEBUG
	printk(KERN_DEBUG DRV_NAME ": module %d loop current is %d mA\n",
		       chan->index + 1, ((value * 3) + 20));
#endif
	return 0;
}

int fxs_is_ringing(struct ap_chan *chan)
{
	if (chan->fxs.lasttxhook == FXS_LF_RINGING) {
		return 1;
	}
	return 0;
}

int fxs_is_offhook(struct ap_chan *chan)
{
	if (chan->fxs.lastrxhook) {
		return 1;
	}
	return 0;
}

int fxs_lookup_gain(int gain)
{
	int i;
	ProSLIC_GainScaleLookup *gain_table = (ProSLIC_GainScaleLookup *)gainScaleTable_0dB;;

	if(gain < gain_table[0].gain )
	{
		return -1;
	}

	for(i = 0; gain_table[i].gain != 0xFF; i++)
	{
		if( gain == gain_table[i].gain )
		{
			break;
		}
	}

	if( gain_table[i].gain == 0xFF )
	{
		return -1;
	}

	return gain_table[i].scale;
}

int fxs_proslic_set_hwgain(struct ap_chan *chan, int gain, int tx)
{
	int reg_gain = fxs_lookup_gain(gain/10);

	if (reg_gain < 0) {
		PDEBUG("FXS gain is out of range (%d)\n", gain);
		return -1;
	}

	PDEBUG("setting FXS gain to %d on channel %d", gain, chan->index + 1);

	if (tx) {
		/* Tx gain */
		PDEBUG("setting FXS Tx gain to %d on channel %d", gain, chan->index + 1);
		fxs_proslic_set_indirect_reg(chan, TX_ADC_GAIN, reg_gain);
	} else {
		/* Rx gain */
		PDEBUG("setting FXS Rx gain to %d on channel %d", gain, chan->index + 1);
		fxs_proslic_set_indirect_reg(chan, RX_DAC_GAIN, reg_gain);
	}

	return 0;
}

int fxs_proslic_init(struct ap_chan *chan)
{
	/* Set FXS ProSLIC configuration */
	chan->fxs.txs_delay = chan->index * 8 + 1;
	chan->fxs.rxs_delay = chan->fxs.txs_delay;
	chan->fxs.idletxhook = FXS_LF_FWD_ACTIVE;

	/* Probe FXS ProSLIC device */
	if (fxs_proslic_probe(chan)) {
		printk(KERN_WARNING DRV_NAME ": Failed to probe device %d\n",
				chan->index + 1);
		return -ENODEV;
	}

	return 0;
}
