/*
 * Name: fxo_voicedaa.c
 * Description: FXO Silicon Labs SI3050 VoiceDAA driver
 *
 * Creator: Wagner Gegler <wagner@aligera.com.br>
 * Company: Aligera - www.aligera.com.br
 * Date: 2010/12/09
 *
 * Copyright (C) 2011-2016, Aligera
 *
 * This program is free software; you can redistribute  it and/or modify it
 * under  the terms of  the GNU General  Public License as published by the
 * Free Software Foundation;  either version 2 of the  License, or (at your
 * option) any later version.
 */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/errno.h>
#include <linux/types.h>
#include <linux/interrupt.h>
#include <linux/time.h>
#include <linux/skbuff.h>
#include <linux/proc_fs.h>
#include <linux/delay.h>
#include <linux/dma-mapping.h>
#include <linux/string.h>
#include <linux/irq.h>
#include <linux/io.h>
#include <linux/wait.h>
#include <linux/timer.h>
#include <linux/init.h>
#include <linux/moduleparam.h>

#include "ap200.h"
#include "fxo_voicedaa.h"

#define DRV_NAME "FXO_VoiceDAA"

/* #define DEBUG */
#ifdef DEBUG
#define PDEBUG(fmt, args...) { \
	printk(KERN_DEBUG DRV_NAME ": %s(%d): ", __FUNCTION__, __LINE__); \
	printk(fmt "\n", ## args); \
}
#else
#define PDEBUG(fmt, args...)
#endif

/* Control Registers (SI3050) */
typedef enum {
	CONTROL1 = 1,
	CONTROL2 = 2,
	INT_MASK = 3,
	INT_STATUS = 4,
	DAA_CONTROL1 = 5,
	DAA_CONTROL2 = 6,
	SAMPLE_RATE = 7,
	DAA_CONTROL3 = 10,
	SYS_LINE_REV = 11,
	LINE_DEV_STATUS = 12,
	LINE_DEV_REV = 13,
	DAA_CONTROL4 = 14,
	TXRX_GAIN = 15,
	INTERNATIONAL1 = 16,
	INTERNATIONAL2 = 17,
	INTERNATIONAL3 = 18,
	INTERNATIONAL4 = 19,
	RX_ATTENUATION = 20,
	TX_ATTENUATION = 21,
	RING_CONTROL1 = 22,
	RING_CONTROL2 = 23,
	RING_CONTROL3 = 24,
	RES_CALIBRATION = 25,
	DC_TERM_CONTROL = 26,
	LOOP_CURRENT = 28,
	LINE_VOLTAGE = 29,
	AC_TERM_CONTROL = 30,
	DAA_CONTROL5 = 31,
	GS_CONTROL = 32,
	PCM_SPI_MODE = 33,
	PCM_TXS_DELAY_LO = 34,
	PCM_TXS_DELAY_HI = 35,
	PCM_RXS_DELAY_LO = 36,
	PCM_RXS_DELAY_HI = 37,
	TX_GAIN2 = 38,
	RX_GAIN2 = 39,
	TX_GAIN3 = 40,
	RX_GAIN3 = 41,
	GCI_CONTROL = 42,
	LINE_INT_THRES = 43,
	LINE_INT_CONTROL = 44,
	HYBRID1 = 45,
	HYBRID2 = 46,
	HYBRID3 = 47,
	HYBRID4 = 48,
	HYBRID5 = 49,
	HYBRID6 = 50,
	HYBRID7 = 51,
	HYBRID8 = 52,
	SPARK_CONTROL = 59
} si3050_regs;

#define FXO_ISOCAP_TIMEOUT	(2 * HZ)

#define FXO_INT_RING		0x80
#define FXO_INT_LINE_STATUS	0x08
#define FXO_INT_LINE_MASK	0x07

/* #define FXO_USE_HOOK_INTERRUPT */
#ifdef FXO_USE_HOOK_INTERRUPT
#define FXO_RING_DEBOUNCE	0	/* Ringer debounce (64 ms) */
#define FXO_BATTERY_DEBOUNCE	0	/* Battery debounce (64 ms) */
#define FXO_POLARITY_DEBOUNCE 	0	/* Polarity debounce (64 ms) */
#else
#define FXO_RING_DEBOUNCE	4	/* Ringer debounce (64 ms) */
#define FXO_BATTERY_DEBOUNCE	4	/* Battery debounce (64 ms) */
#define FXO_POLARITY_DEBOUNCE 	4	/* Polarity debounce (64 ms) */
#endif

#define FXO_BATTERY_ALARM	60	/* Battery alarm (1024 ms) */
#define FXO_BATTERY_THRES	3	/* Under this is "no battery" */

/* International settings for FXO VoiceDAA */
static struct fxo_mode {
	char *name;
	int ohs;
	int ohs2;
	int rz;
	int rt;
	int ilim;
	int dcv;
	int mini;
	int acim;
	int ring_osc;
	int ring_x;
} fxo_modes[] =
{
	{ "FCC", 0, 0, 0, 1, 0, 0x3, 0, 0, }, 	/* US, Canada */
	{ "TBR21", 0, 0, 0, 0, 1, 0x3, 0, 0x2, 0x7e6c, 0x023a, },
		/* Austria, Belgium, Denmark, Finland, France, Germany,
		   Greece, Iceland, Ireland, Italy, Luxembourg, Netherlands,
		   Norway, Portugal, Spain, Sweden, Switzerland, and UK */
	{ "ARGENTINA", 0, 0, 0, 0, 0, 0x3, 0, 0, },
	{ "AUSTRALIA", 1, 0, 0, 0, 0, 0, 0x3, 0x3, },
	{ "AUSTRIA", 0, 1, 0, 0, 1, 0x3, 0, 0x3, },
	{ "BAHRAIN", 0, 0, 0, 0, 1, 0x3, 0, 0x2, },
	{ "BELGIUM", 0, 1, 0, 0, 1, 0x3, 0, 0x2, },
	{ "BRAZIL", 0, 0, 0, 0, 0, 0, 0x3, 0, },
	{ "BULGARIA", 0, 0, 0, 0, 1, 0x3, 0x0, 0x3, },
	{ "CANADA", 0, 0, 0, 0, 0, 0x3, 0, 0, },
	{ "CHILE", 0, 0, 0, 0, 0, 0x3, 0, 0, },
	{ "CHINA", 0, 0, 0, 0, 0, 0, 0x3, 0xf, },
	{ "COLUMBIA", 0, 0, 0, 0, 0, 0x3, 0, 0, },
	{ "CROATIA", 0, 0, 0, 0, 1, 0x3, 0, 0x2, },
	{ "CYRPUS", 0, 0, 0, 0, 1, 0x3, 0, 0x2, },
	{ "CZECH", 0, 0, 0, 0, 1, 0x3, 0, 0x2, },
	{ "DENMARK", 0, 1, 0, 0, 1, 0x3, 0, 0x2, },
	{ "ECUADOR", 0, 0, 0, 0, 0, 0x3, 0, 0, },
	{ "EGYPT", 0, 0, 0, 0, 0, 0, 0x3, 0, },
	{ "ELSALVADOR", 0, 0, 0, 0, 0, 0x3, 0, 0, },
	{ "FINLAND", 0, 1, 0, 0, 1, 0x3, 0, 0x2, },
	{ "FRANCE", 0, 1, 0, 0, 1, 0x3, 0, 0x2, },
	{ "GERMANY", 0, 1, 0, 0, 1, 0x3, 0, 0x3, },
	{ "GREECE", 0, 1, 0, 0, 1, 0x3, 0, 0x2, },
	{ "GUAM", 0, 0, 0, 0, 0, 0x3, 0, 0, },
	{ "HONGKONG", 0, 0, 0, 0, 0, 0x3, 0, 0, },
	{ "HUNGARY", 0, 0, 0, 0, 0, 0x3, 0, 0, },
	{ "ICELAND", 0, 1, 0, 0, 1, 0x3, 0, 0x2, },
	{ "INDIA", 0, 0, 0, 0, 0, 0x3, 0, 0x4, },
	{ "INDONESIA", 0, 0, 0, 0, 0, 0x3, 0, 0, },
	{ "IRELAND", 0, 1, 0, 0, 1, 0x3, 0, 0x2, },
	{ "ISRAEL", 0, 0, 0, 0, 1, 0x3, 0, 0x2, },
	{ "ITALY", 0, 1, 0, 0, 1, 0x3, 0, 0x2, },
	{ "JAPAN", 0, 0, 0, 0, 0, 0, 0x3, 0, },
	{ "JORDAN", 0, 0, 0, 0, 0, 0, 0x3, 0, },
	{ "KAZAKHSTAN", 0, 0, 0, 0, 0, 0x3, 0, },
	{ "KUWAIT", 0, 0, 0, 0, 0, 0x3, 0, 0, },
	{ "LATVIA", 0, 0, 0, 0, 1, 0x3, 0, 0x2, },
	{ "LEBANON", 0, 0, 0, 0, 1, 0x3, 0, 0x2, },
	{ "LUXEMBOURG", 0, 1, 0, 0, 1, 0x3, 0, 0x2, },
	{ "MACAO", 0, 0, 0, 0, 0, 0x3, 0, 0, },
	{ "MALAYSIA", 0, 0, 0, 0, 0, 0, 0x3, 0, },	/* Current loop >= 20ma */
	{ "MALTA", 0, 0, 0, 0, 1, 0x3, 0, 0x2, },
	{ "MEXICO", 0, 0, 0, 0, 0, 0x3, 0, 0, },
	{ "MOROCCO", 0, 0, 0, 0, 1, 0x3, 0, 0x2, },
	{ "NETHERLANDS", 0, 1, 0, 0, 1, 0x3, 0, 0x2, },
	{ "NEWZEALAND", 0, 0, 0, 0, 0, 0x3, 0, 0x4, },
	{ "NIGERIA", 0, 0, 0, 0, 0x1, 0x3, 0, 0x2, },
	{ "NORWAY", 0, 1, 0, 0, 1, 0x3, 0, 0x2, },
	{ "OMAN", 0, 0, 0, 0, 0, 0, 0x3, 0, },
	{ "PAKISTAN", 0, 0, 0, 0, 0, 0, 0x3, 0, },
	{ "PERU", 0, 0, 0, 0, 0, 0x3, 0, 0, },
	{ "PHILIPPINES", 0, 0, 0, 0, 0, 0, 0x3, 0, },
	{ "POLAND", 0, 0, 1, 1, 0, 0x3, 0, 0, },
	{ "PORTUGAL", 0, 1, 0, 0, 1, 0x3, 0, 0x2, },
	{ "ROMANIA", 0, 0, 0, 0, 0, 3, 0, 0, },
	{ "RUSSIA", 0, 0, 0, 0, 0, 0, 0x3, 0, },
	{ "SAUDIARABIA", 0, 0, 0, 0, 0, 0x3, 0, 0, },
	{ "SINGAPORE", 0, 0, 0, 0, 0, 0x3, 0, 0, },
	{ "SLOVAKIA", 0, 0, 0, 0, 0, 0x3, 0, 0x3, },
	{ "SLOVENIA", 0, 0, 0, 0, 0, 0x3, 0, 0x2, },
	{ "SOUTHAFRICA", 1, 0, 1, 0, 0, 0x3, 0, 0x3, },
	{ "SOUTHKOREA", 0, 0, 0, 0, 0, 0x3, 0, 0, },
	{ "SPAIN", 0, 1, 0, 0, 1, 0x3, 0, 0x2, },
	{ "SWEDEN", 0, 1, 0, 0, 1, 0x3, 0, 0x2, },
	{ "SWITZERLAND", 0, 1, 0, 0, 1, 0x3, 0, 0x2, },
	{ "SYRIA", 0, 0, 0, 0, 0, 0, 0x3, 0, },
	{ "TAIWAN", 0, 0, 0, 0, 0, 0, 0x3, 0, },
	{ "THAILAND", 0, 0, 0, 0, 0, 0, 0x3, 0, },
	{ "UAE", 0, 0, 0, 0, 0, 0x3, 0, 0, },
	{ "UK", 0, 1, 0, 0, 1, 0x3, 0, 0x5, },
	{ "USA", 0, 0, 0, 0, 0, 0x3, 0, 0, },
	{ "YEMEN", 0, 0, 0, 0, 0, 0x3, 0, 0, },
};

static void fxo_voicedaa_set_reg(struct ap_chan *chan,
                                 unsigned char reg, unsigned char value)
{
	struct ap2 *ap = chan->card;
	unsigned long flags;

	spin_lock_irqsave(&ap->spi_lock, flags);
	ap->regs->spi_ctrl = chan->index & AP_SPI_SEL_MASK;
	ap2_spi_write_byte(ap, 0x20);
	ap2_spi_write_byte(ap, reg);
	ap2_spi_write_byte(ap, value);
	spin_unlock_irqrestore(&ap->spi_lock, flags);
}

static unsigned char fxo_voicedaa_get_reg(struct ap_chan *chan,
                                          unsigned char reg)
{
	struct ap2 *ap = chan->card;
	unsigned long flags;
	unsigned char data;

	spin_lock_irqsave(&ap->spi_lock, flags);
	ap->regs->spi_ctrl = chan->index & AP_SPI_SEL_MASK;
	ap2_spi_write_byte(ap, 0x60);
	ap2_spi_write_byte(ap, reg);
	data = ap2_spi_read_byte(ap);
	spin_unlock_irqrestore(&ap->spi_lock, flags);

	return data;
}

int fxo_voicedaa_set_hwgain(struct ap_chan *chan, int gain, int tx)
{
	if (tx) {
		/* Tx gain */
		PDEBUG("setting FXO Tx gain to %d on channel %d", gain,
				chan->index + 1);
		if (gain >= -150 && gain <= 0) {
			fxo_voicedaa_set_reg(chan, TX_GAIN2, 16 + (gain / -10));
			fxo_voicedaa_set_reg(chan, TX_GAIN3, 16 + (-gain % 10));
		} else if (gain <= 120 && gain > 0) {
			fxo_voicedaa_set_reg(chan, TX_GAIN2, gain / 10);
			fxo_voicedaa_set_reg(chan, TX_GAIN3, gain % 10);
		} else {
			printk(KERN_INFO "FXO Tx gain is out of range (%d)\n", gain);
			return -1;
		}
	} else { /* rx */
		PDEBUG("setting FXO Rx gain to %d on channel %d", gain,
						chan->index + 1);
		if (gain >= -150 && gain <= 0) {
			fxo_voicedaa_set_reg(chan, RX_GAIN2, 16 + (gain / -10));
			fxo_voicedaa_set_reg(chan, RX_GAIN3, 16 + (-gain % 10));
		} else if (gain <= 120 && gain > 0) {
			fxo_voicedaa_set_reg(chan, RX_GAIN2, gain / 10);
			fxo_voicedaa_set_reg(chan, RX_GAIN3, gain % 10);
		} else {
			printk(KERN_INFO "FXO Rx gain is out of range (%d)\n", gain);
			return -1;
		}
	}

	return 0;
}

int fxo_voicedaa_hooksig(struct ap_chan *chan, enum dahdi_txsig txsig)
{
	switch (txsig) {
	case DAHDI_TXSIG_START:
	case DAHDI_TXSIG_OFFHOOK:
		chan->fxo.offhook = 1;
		fxo_voicedaa_set_reg(chan, DAA_CONTROL1, 0x09);
		PDEBUG("Setting FXO to OFFHOOK\n");
		break;
	case DAHDI_TXSIG_ONHOOK:
		chan->fxo.offhook = 0;
		fxo_voicedaa_set_reg(chan, DAA_CONTROL1, 0x08);
		PDEBUG("Setting FXO to ONHOOK\n");
		break;
	default:
		printk(KERN_NOTICE DRV_NAME ": Unknown Tx Sig %d\n", txsig);
		return -1;
	}
	return 0;
}

static inline void fxo_voicedaa_check_polarity(struct ap_chan *chan,
                                               unsigned char voltage)
{
	struct fxo_voicedaa *fxo = &chan->fxo;

	if (fxo->lastpol >= 0 && voltage < 0) {
		fxo->lastpol = -1;
		fxo->poldebounce = FXO_POLARITY_DEBOUNCE;
	}
	if (fxo->lastpol <= 0 && voltage > 0) {
		fxo->lastpol = 1;
		fxo->poldebounce = FXO_POLARITY_DEBOUNCE;
	}

	if (fxo->poldebounce) {
		if (--fxo->poldebounce == 0) {
			if (fxo->lastpol != fxo->polarity) {
				PDEBUG("Polarity has reversed (%d -> %d)"
						"on channel %d",
						chan->index + 1,
						fxo->polarity, fxo->lastpol);
				if (fxo->polarity)
					dahdi_qevent_lock(chan->dahdi,
							DAHDI_EVENT_POLARITY);
				fxo->polarity = fxo->lastpol;
			}
		}
	}
}

static inline void fxo_voicedaa_check_battery(struct ap_chan *chan,
		                              unsigned char voltage)
{
	struct fxo_voicedaa *fxo = &chan->fxo;

	if (unlikely(DAHDI_RXSIG_INITIAL == chan->dahdi->rxhooksig)) {
		fxo->battery = BATTERY_UNKNOWN;
	}

	if (abs(voltage) < FXO_BATTERY_THRES) {
		if (fxo->battery == BATTERY_LOST) {
			/* Battery is lost */
			fxo->battdebounce = 0;
		} else {
			/* Losing battery */
			if (++fxo->battdebounce >= FXO_BATTERY_DEBOUNCE) {
				fxo->battery = BATTERY_LOST;
				fxo->battdebounce = 0;
				dahdi_hooksig(chan->dahdi, DAHDI_RXSIG_ONHOOK);
				fxo->battalarm = FXO_BATTERY_ALARM;
				PDEBUG("Battery is lost on channel %d",
						chan->index + 1);
			}
		}
	} else {
		if (fxo->battery == BATTERY_PRESENT) {
			/* Battery present */
			fxo->battdebounce = 0;
		} else {
			/* Recovering battery */
			if (++fxo->battdebounce >= FXO_BATTERY_DEBOUNCE) {
				fxo->battery = BATTERY_PRESENT;
				fxo->battdebounce = 0;
				dahdi_hooksig(chan->dahdi, DAHDI_RXSIG_OFFHOOK);
				fxo->battalarm = FXO_BATTERY_ALARM;
				PDEBUG("Battery is present on channel %d",
						chan->index + 1);
			}
		}
	}

	/* Check alarm */
	if (fxo->battalarm) {
		if (--fxo->battalarm == 0) {
			/* Update alarm, timeout has expired */
			if (fxo->battery == BATTERY_LOST) {
				dahdi_alarm_channel(chan->dahdi, DAHDI_ALARM_RED);
			} else {
				dahdi_alarm_channel(chan->dahdi, DAHDI_ALARM_NONE);
			}
		}
	}
}

static inline void fxo_voicedaa_check_ring(struct ap_chan *chan)
{
	struct fxo_voicedaa *fxo = &chan->fxo;
	unsigned char value;

	/* If FXO is off hook, no need to check ring */
	if (fxo->offhook) {
		fxo->ringing = 0;
		return;
	}

	/* Get ring status */
	value = fxo_voicedaa_get_reg(chan, DAA_CONTROL1);

	if ((value & 0x60) && (fxo->battery == BATTERY_PRESENT)) {
		if (fxo->ringing) {
			/* FXO is ringing */
			fxo->ringdebounce = 0;
		} else {
			/* FXO started ringing */
			if (++fxo->ringdebounce >= FXO_RING_DEBOUNCE) {
				/* Ring detected */
				fxo->ringing = 1;
				fxo->ringdebounce = 0;
				dahdi_hooksig(chan->dahdi, DAHDI_RXSIG_RING);
				PDEBUG("Ring detected on channel %d",
						chan->index + 1);
			}
		}
	} else {
		if (!fxo->ringing) {
			/* FXO is not ringing */
			fxo->ringdebounce = 0;
		} else {
			/* FXO stopped ringing */
			if (++fxo->ringdebounce >= FXO_RING_DEBOUNCE) {
				/* Ring stop detected */
				fxo->ringing = 0;
				fxo->ringdebounce = 0;
				dahdi_hooksig(chan->dahdi, DAHDI_RXSIG_OFFHOOK);
				PDEBUG("Ring stopped on channel %d",
						chan->index + 1);
			}
		}
	}
}

void fxo_voicedaa_check_hook(struct ap_chan *chan)
{
	unsigned char voltage;

	/* Check ring status */
	fxo_voicedaa_check_ring(chan);

	/* Get line voltage status */
	voltage = fxo_voicedaa_get_reg(chan, LINE_VOLTAGE);

	/* Check battery voltage */
	fxo_voicedaa_check_battery(chan, voltage);

	/* Check polarity */
	fxo_voicedaa_check_polarity(chan, voltage);
}

int fxo_is_ringing(struct ap_chan *chan)
{
	if (chan->fxo.ringing) {
		return 1;
	}
	return 0;
}

int fxo_is_offhook(struct ap_chan *chan)
{
	if (chan->fxo.offhook) {
		return 1;
	}
	return 0;
}

int fxo_voicedaa_sanity_check(struct ap_chan *chan)
{
	unsigned char value;

	/* Test some reset values */
	value = fxo_voicedaa_get_reg(chan, CONTROL2);
	if (value != 0x03) {
		printk(KERN_NOTICE DRV_NAME ": module %d is not loaded "
				"(%02X)\n", chan->index + 1, value);
		return -1;
	}
	return 0;
}

int fxo_voicedaa_detect(struct ap_chan *chan)
{
	unsigned char value;

	/* Test some reset values */
	value = fxo_voicedaa_get_reg(chan, CONTROL2);
	if (value != 0x03) {
		printk(KERN_NOTICE DRV_NAME ": module %d is not loaded "
				"(%02X)\n", chan->index + 1, value);
		return -1;
	}

	value = fxo_voicedaa_get_reg(chan, DAA_CONTROL2);
	if (value != 0x10) {
		printk(KERN_NOTICE DRV_NAME ": module %d insane R6 is %02X, "
				"should be 0x10\n",
				chan->index + 1, value);
		return -1;
	}

	value = fxo_voicedaa_get_reg(chan, RING_CONTROL1);
	if (value != 0x96) {
		printk(KERN_NOTICE DRV_NAME ": module %d insane R22 is %02X, "
				"should be 0x96\n",
				chan->index + 1, value);
		return -1;
	}

#ifdef DEBUG
	printk(KERN_DEBUG DRV_NAME ": module %d seems sane.\n",
		       chan->index + 1);
#endif
	return 0;
}

static int fxo_voicedaa_config(struct ap_chan *chan)
{
	struct fxo_voicedaa *fxo = &chan->fxo;
	int mode = fxo->mode;
	unsigned char value;
	unsigned long origjiffies;

	/* Software reset */
	fxo_voicedaa_set_reg(chan, CONTROL1, 0x80);

	/* Wait 10 ms */
	msleep(10);

	/* Set On-hook speed, Ringer impedence, and ringer threshold */
	value = (fxo_modes[mode].ohs << 6);
	value |= (fxo_modes[mode].rz << 1);
	value |= (fxo_modes[mode].rt);
	fxo_voicedaa_set_reg(chan, INTERNATIONAL1, value);

	/* Set DC Termination: Tip/Ring voltage adjust,
	 * minimum operational current, current limitation */
	value = (fxo_modes[mode].dcv << 6);
	value |= (fxo_modes[mode].mini << 4);
	value |= (fxo_modes[mode].ilim << 1);
	fxo_voicedaa_set_reg(chan, DC_TERM_CONTROL, value);

	/* Set AC Impedence */
	value = (fxo_modes[mode].acim);
	fxo_voicedaa_set_reg(chan, AC_TERM_CONTROL, value);

	/* Misc. DAA parameters */
	value = 0x23;
	value |= (fxo_modes[mode].ohs2 << 3);
	fxo_voicedaa_set_reg(chan, DAA_CONTROL5, value);

	/* Set Tx and Rx PCM sync delay */
	fxo_voicedaa_set_reg(chan, PCM_TXS_DELAY_LO, fxo->txs_delay & 0xFF);
	fxo_voicedaa_set_reg(chan, PCM_TXS_DELAY_HI, fxo->txs_delay >> 8);
	fxo_voicedaa_set_reg(chan, PCM_RXS_DELAY_LO, fxo->rxs_delay & 0xFF);
	fxo_voicedaa_set_reg(chan, PCM_RXS_DELAY_HI, fxo->rxs_delay >> 8);

	/* Enable PCM, alaw */
	fxo_voicedaa_set_reg(chan, PCM_SPI_MODE, 0x21);

	/* Enable ISO-Cap */
	fxo_voicedaa_set_reg(chan, DAA_CONTROL2, 0x00);

	/* Wait for ISO-cap to come up */
	origjiffies = jiffies;

	while (!(fxo_voicedaa_get_reg(chan, SYS_LINE_REV) & 0xf0)) {
		if ((origjiffies - jiffies) >= FXO_ISOCAP_TIMEOUT) {
			printk(KERN_NOTICE DRV_NAME ": VoiceDAA did not bring "
					"up ISO link properly!\n");
			return -1;
		} else {
			msleep(100);
		}
	}
#ifdef DEBUG
	printk(KERN_DEBUG DRV_NAME ": ISO-Cap is now up, line side: "
	       	       "%02x rev %02x\n",
		       fxo_voicedaa_get_reg(chan, SYS_LINE_REV) >> 4,
		       (fxo_voicedaa_get_reg(chan, LINE_DEV_REV) >> 2) & 0xf);
#endif

	/* Enable on-hook line monitor */
	fxo_voicedaa_set_reg(chan, DAA_CONTROL1, 0x08);

#if 0
	/* NZ -- crank the tx gain up by 7 dB */
	if (!strcmp(fxo_modes[mode].name, "NEWZEALAND")) {
		printk("Adjusting gain\n");
		fxo_voicedaa_set_reg(chan, 38, 0x7);
	}
#endif

#ifdef FXO_USE_HOOK_INTERRUPT
	/* Enable ring envelope detection interrupt */
	fxo_voicedaa_set_reg(chan, INT_STATUS, 0);
	fxo_voicedaa_set_reg(chan, CONTROL2, 0x87);
	fxo_voicedaa_set_reg(chan, RING_CONTROL2, 0x2A);
	fxo_voicedaa_set_reg(chan, RING_CONTROL3, 0x99);
	fxo_voicedaa_set_reg(chan, INT_MASK, FXO_INT_RING);
#endif

	/* Enable hook detection interrupt */
#ifdef FXO_USE_HOOK_INTERRUPT
	fxo_voicedaa_set_reg(chan, LINE_INT_THRES, FXO_BATTERY_THRES);
	fxo_voicedaa_set_reg(chan, LINE_INT_CONTROL, FXO_INT_LINE_MASK);
#endif
	return 0;
}

int fxo_voicedaa_init(struct ap_chan *chan)
{
	struct fxo_voicedaa *fxo = &chan->fxo;

	/* Set fxo voicedaa configuration */
	fxo->txs_delay = chan->index * 8 + 1;
	fxo->rxs_delay = fxo->txs_delay;
	fxo->mode = 7;	/* Default: Brazil */

#ifdef DEBUG
	printk(KERN_DEBUG DRV_NAME ": Using %s international settings",
		       fxo_modes[fxo->mode].name);
#endif

	/* Sanity check the VoiceDAA */
	if (fxo_voicedaa_detect(chan)) {
		printk(KERN_WARNING DRV_NAME ": module %d not found\n",
				chan->index + 1);
		return -1;
	}

	/* Configure VoiceDAA */
	if (fxo_voicedaa_config(chan)) {
		printk(KERN_WARNING DRV_NAME ": module %d probe failed\n",
				chan->index + 1);
		return -1;
	}

	printk(KERN_INFO DRV_NAME ": module %d probe successful\n", chan->index + 1);

	return 0;
}
