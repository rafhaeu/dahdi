/*
 * Name: fxs_proslic.h
 * Description: FXS Silabs 3215 ProSlic driver (header)
 *
 * Creator: Wagner Gegler <wagner@aligera.com.br>
 * Company: Aligera - www.aligera.com.br
 * Date: 2010/09/17
 *
 * Copyright (c) 2010 Aligera
 *
 * This program is free software; you can redistribute  it and/or modify it
 * under  the terms of  the GNU General  Public License as published by the
 * Free Software Foundation;  either version 2 of the  License, or (at your
 * option) any later version.
 */

#ifndef FXS_PROSLIC_H_
#define FXS_PROSLIC_H_

#include <dahdi/kernel.h>

#define NUM_CAL_REGS	12

struct fxs_proslic {
	int txs_delay;	/* First Tx bit delay from Tx Sync */
	int rxs_delay;	/* First Rx bit delay from Rx Sync */
	int power;
	unsigned char cal_values[NUM_CAL_REGS];
	int lasttxhook;
	int lastrxhook;
	int hookdebounce;
	int idletxhook;
	int ohttimer;
	int reversepolarity;		/* Reverse Line */
};

/* Function prototypes */
int fxs_is_ringing(struct ap_chan *chan);
int fxs_is_offhook(struct ap_chan *chan);
int fxs_proslic_init(struct ap_chan *chan);
int fxs_proslic_hooksig(struct ap_chan *chan, enum dahdi_txsig txsig);
void fxs_proslic_check_hook(struct ap_chan *chan);
int fxs_proslic_onhook_transfer(struct ap_chan *chan, int timer);
int fxs_proslic_set_polarity(struct ap_chan *chan, int polarity);
int fxs_proslic_sanity_check(struct ap_chan *chan);
int fxs_proslic_detect(struct ap_chan *chan);
int fxs_proslic_set_hwgain(struct ap_chan *chan, int gain, int tx);


#endif /* FXS_PROSLIC_H_ */
