/*
 * Aligera PCI/PCIe Cards Octasic OCT61XX Echo Cancelation Hardware support
 *
 * Written by Wagner Gegler <aligera@aligera.com.br>
 * 
 * Based on previous work written by Mark Spencer <markster@digium.com>
 * 
 * Copyright (C) 2005-2006 Digium, Inc.
 *
 * Mark Spencer <markster@digium.com>
 *
 * All Rights Reserved
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#ifndef _APEC_H_
#define _APEC_H_

#include <linux/firmware.h>

struct apec_oct;

/* From APE100 */
unsigned int oct_read(void *card, unsigned int addr);
void oct_write(void *card, unsigned int addr, unsigned int data);

/* From AP_OCTASIC */
struct apec_oct *apec_oct_init(void *ap, int channels,
		const struct firmware *firmware);
unsigned int apec_oct_get_capacity(void *ap);
void apec_oct_setec(struct apec_oct *apec, int channel, int eclen);
int apec_oct_checkirq(struct apec_oct *apec);
void apec_oct_release(struct apec_oct *apec);

#endif /*_APEC_H_*/

