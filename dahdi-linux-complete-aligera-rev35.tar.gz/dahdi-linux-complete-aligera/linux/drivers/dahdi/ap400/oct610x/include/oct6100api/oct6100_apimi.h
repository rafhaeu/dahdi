/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

File:  oct6100_apimi.h

    Copyright (c) 2001-2017 Octasic Inc. All rights reserved.
    
Description: 

	This file contains the declaration of all functions exported from the 
	APIMI block.  The APIMI block contains only one function:
		Oct6100InterruptMask.
	The function is used to mask out the interrupt pin of the chip.  This 
	function is used when a deferred procedure call treats the interrupt (new 
	interrupts must not be generated until the signalled interrupt is treated).

This source code is Octasic Confidential. Use of and access to this code 
is covered by the Octasic Device Enabling Software License Agreement. 
Acknowledgement of the Octasic Device Enabling Software License was 
required for access to this code. A copy was also provided with the release.

$Octasic_Release: OCT610xAPI-01.04.08 $

$Octasic_Revision: 6 $

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

#ifndef __OCT6100_APIMI_H__
#define __OCT6100_APIMI_H__

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

/*****************************  INCLUDE FILES  *******************************/

#include "octdef.h"

/*****************************  TYPES  ***************************************/

typedef struct _OCT6100_INTERRUPT_MASK_
{
	UINT32	ulUserChipIndex;
	PVOID	pProcessContext;


} tOCT6100_INTERRUPT_MASK, *tPOCT6100_INTERRUPT_MASK;

/************************** FUNCTION PROTOTYPES  *****************************/

UINT32 Oct6100InterruptMaskDef(
				OUT		tPOCT6100_INTERRUPT_MASK f_pInterruptMask );
UINT32 Oct6100InterruptMask(
				IN		tPOCT6100_INTERRUPT_MASK f_pInterruptMask );
 
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __OCT6100_APIMI_H__ */
