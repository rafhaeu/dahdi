/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

File:  oct6100_api.h

    Copyright (c) 2001-2017 Octasic Inc. All rights reserved.
    
Description: 

	Header file containing all definitions used throughout the API.

This source code is Octasic Confidential. Use of and access to this code 
is covered by the Octasic Device Enabling Software License Agreement. 
Acknowledgement of the Octasic Device Enabling Software License was 
required for access to this code. A copy was also provided with the release.

$Octasic_Release: OCT610xAPI-01.04.08 $

$Octasic_Revision: 23 $

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

#ifndef __OCT6100_API_H__
#define __OCT6100_API_H__

#ifdef __cplusplus
extern "C" {
#endif

/*****************************  INCLUDE FILES  *******************************/

#include "octdef.h"

#include "oct6100_defines.h"
#include "oct6100_errors.h"

#include "oct6100_apiud.h"
#include "oct6100_tlv_inst.h"
#include "oct6100_chip_stats_inst.h"
#include "oct6100_tsi_cnct_inst.h"
#include "oct6100_mixer_inst.h"
#include "oct6100_events_inst.h"



#include "oct6100_channel_inst.h"
#include "oct6100_interrupts_inst.h"
#include "oct6100_remote_debug_inst.h"
#include "oct6100_debug_inst.h"
#include "oct6100_chip_open_inst.h"
#include "oct6100_api_inst.h"

#include "oct6100_interrupts_pub.h"
#include "oct6100_tsi_cnct_pub.h"
#include "oct6100_events_pub.h"


#include "oct6100_channel_pub.h"
#include "oct6100_remote_debug_pub.h"
#include "oct6100_debug_pub.h"
#include "oct6100_chip_open_pub.h"
#include "oct6100_chip_stats_pub.h"


#ifdef __cplusplus
}
#endif

#endif /* __OCT6100_API_H__ */
