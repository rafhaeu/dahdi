/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

File:  oct6100_tlv_inst.h

    Copyright (c) 2001-2017 Octasic Inc. All rights reserved.
    
Description: 

	File containing all defines, macros, and structures pertaining to the file
	oct6100_tlv.c.  All elements defined in this file are for public
	usage of the API.  All instate elements are defined in the
	oct6100_tlv_inst.h file.

This source code is Octasic Confidential. Use of and access to this code 
is covered by the Octasic Device Enabling Software License Agreement. 
Acknowledgement of the Octasic Device Enabling Software License was 
required for access to this code. A copy was also provided with the release.

$Octasic_Release: OCT610xAPI-01.04.08 $

$Octasic_Revision: 7 $

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

#ifndef __OCT6100_TLV_INST_H__
#define __OCT6100_TLV_INST_H__

/*****************************  INCLUDE FILES  *******************************/

/*****************************  DEFINES  *************************************/

/*****************************  TYPES  ***************************************/

typedef struct _OCT6100_TLV_OFFSET_
{
	/* The dword offset contain the number of dword from a base address to reach the desired dword.
	
		i.e. usDwordOffset = (total bit offset) / 32; */

	UINT16	usDwordOffset;
	
	/* The bit offset will contain the bit offset required to right shift the DWORD read and obtain
	   the desired value. This field is depend on the field size.
	
		i.e. byBitOffset = 31 - ((total bit offset) % 32) - byFieldSize; */

	UINT8	byBitOffset;
	UINT8	byFieldSize;

} tOCT6100_TLV_OFFSET, *tPOCT6100_TLV_OFFSET;

typedef struct _OCT6100_TLV_TONE_INFO_
{
	UINT32	ulToneID;
	UINT32	ulDetectionPort;	

	UINT8	aszToneName[ cOCT6100_TLV_MAX_TONE_NAME_SIZE ];



} tOCT6100_TLV_TONE_INFO, *tPOCT6100_TLV_TONE_INFO;

#endif /* __OCT6100_TLV_INST_H__ */
