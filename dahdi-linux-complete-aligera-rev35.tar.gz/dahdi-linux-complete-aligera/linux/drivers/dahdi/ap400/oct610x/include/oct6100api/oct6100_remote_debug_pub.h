/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

File:  oct6100_remote_debug_pub.h

    Copyright (c) 2001-2017 Octasic Inc. All rights reserved.
    
Description: 

	File containing all defines, macros, and structures pertaining to the file
	oct6100_remote_debug.c.  All elements defined in this file are for public
	usage of the API.  All private elements are defined in the
	oct6100_remote_debug_priv.h file.

This source code is Octasic Confidential. Use of and access to this code 
is covered by the Octasic Device Enabling Software License Agreement. 
Acknowledgement of the Octasic Device Enabling Software License was 
required for access to this code. A copy was also provided with the release.

$Octasic_Release: OCT610xAPI-01.04.08 $

$Octasic_Revision: 6 $

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

#ifndef __OCT6100_REMOTE_DEBUG_PUB_H__
#define __OCT6100_REMOTE_DEBUG_PUB_H__

/*****************************  INCLUDE FILES  *******************************/


/*****************************  DEFINES  *************************************/


/*****************************  TYPES  ***************************************/

typedef struct _OCT6100_REMOTE_DEBUG_
{
	PUINT32	pulReceivedPktPayload;
	UINT32	ulReceivedPktLength;

	PUINT32	pulResponsePktPayload;
	UINT32	ulMaxResponsePktLength;
	UINT32	ulResponsePktLength;

} tOCT6100_REMOTE_DEBUG, *tPOCT6100_REMOTE_DEBUG;

/************************** FUNCTION PROTOTYPES  *****************************/

UINT32 Oct6100RemoteDebugDef(
				OUT		tPOCT6100_REMOTE_DEBUG		f_pRemoteDebug );
UINT32 Oct6100RemoteDebug(
				IN OUT	tPOCT6100_INSTANCE_API		f_pApiInst,
				IN OUT	tPOCT6100_REMOTE_DEBUG		f_pRemoteDebug );

#endif /* __OCT6100_REMOTE_DEBUG_PUB_H__ */
