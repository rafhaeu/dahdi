/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

File:  oct6100_channel_pub.h

    Copyright (c) 2001-2017 Octasic Inc. All rights reserved.
    
Description: 

	File containing all defines, macros, and structures pertaining to the file
	oct6100_channel.c.  All elements defined in this file are for public
	usage of the API.  All private elements are defined in the
	oct6100_channel_priv.h file.

This source code is Octasic Confidential. Use of and access to this code 
is covered by the Octasic Device Enabling Software License Agreement. 
Acknowledgement of the Octasic Device Enabling Software License was 
required for access to this code. A copy was also provided with the release.

$Octasic_Release: OCT610xAPI-01.04.08 $

$Octasic_Revision: 93 $

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

#ifndef __OCT6100_CHANNEL_PUB_H__
#define __OCT6100_CHANNEL_PUB_H__

/*****************************  INCLUDE FILES  *******************************/


/*****************************  DEFINES  *************************************/


/*****************************  TYPES  ***************************************/

/* Channel open structures. */
typedef struct _OCT6100_CHANNEL_OPEN_TDM_
{


	UINT32	ulSinTimeslot;
	UINT32	ulSinStream;
	UINT32	ulSinPcmLaw;

	UINT32	ulSoutTimeslot;
	UINT32	ulSoutStream;
	UINT32	ulSoutPcmLaw;

	UINT32	ulRinTimeslot;
	UINT32	ulRinStream;
	UINT32	ulRinPcmLaw;

	UINT32	ulRoutTimeslot;
	UINT32	ulRoutStream;
	UINT32	ulRoutPcmLaw;

} tOCT6100_CHANNEL_OPEN_TDM, *tPOCT6100_CHANNEL_OPEN_TDM;

typedef struct _OCT6100_CHANNEL_OPEN_VQE_
{
	BOOL	fEnableNlp;
	BOOL	fEnableTailDisplacement;
	UINT32	ulTailDisplacement;
	UINT32	ulTailLength;

	BOOL	fSinDcOffsetRemoval;
	BOOL	fRinDcOffsetRemoval;
	BOOL	fRinLevelControl;
	BOOL	fSoutLevelControl;
	BOOL	fRinAutomaticLevelControl;
	BOOL	fSoutAutomaticLevelControl;
	BOOL	fRinHighLevelCompensation;
	BOOL	fAcousticEcho;
	BOOL	fSoutAdaptiveNoiseReduction;
	BOOL	fDtmfToneRemoval;



	UINT32	ulComfortNoiseMode;
	UINT32	ulNonLinearityBehaviorA;
	UINT32	ulNonLinearityBehaviorB;

	INT32	lRinLevelControlGainDb;
	INT32	lSoutLevelControlGainDb;
	INT32	lRinAutomaticLevelControlTargetDb;
	INT32	lSoutAutomaticLevelControlTargetDb;
	INT32	lRinHighLevelCompensationThresholdDb;
	INT32	lDefaultErlDb;
	INT32	lAecDefaultErlDb;
	UINT32	ulAecTailLength;
	UINT32	ulSoutAutomaticListenerEnhancementGainDb;
	UINT32	ulSoutNaturalListenerEnhancementGainDb;
	BOOL	fSoutNaturalListenerEnhancement;

	BOOL	fRoutNoiseReduction;	/* Unsupported feature */
	INT32	lRoutNoiseReductionLevelGainDb;	/* Unsupported feature */
	BOOL	fEnablePlayout;
	INT32	lAnrSnrEnhancementDb;
	UINT32	ulAnrVoiceNoiseSegregation;
	UINT32	ulDoubleTalkBehavior;
	
	UINT32	ulToneDisablerVqeActivationDelay;

	BOOL	fEnableMusicProtection;
	BOOL	fIdleCodeDetection;
	


} tOCT6100_CHANNEL_OPEN_VQE, *tPOCT6100_CHANNEL_OPEN_VQE;



typedef struct _OCT6100_CHANNEL_OPEN_
{
	PUINT32	pulChannelHndl;
	UINT32	ulUserChanId;

	UINT32	ulEchoOperationMode;

	BOOL	fEnableToneDisabler;



	tOCT6100_CHANNEL_OPEN_TDM	TdmConfig;
	tOCT6100_CHANNEL_OPEN_VQE	VqeConfig;




} tOCT6100_CHANNEL_OPEN, *tPOCT6100_CHANNEL_OPEN;

/* Channel close structure. */
typedef struct _OCT6100_CHANNEL_CLOSE_
{
	UINT32	ulChannelHndl;

} tOCT6100_CHANNEL_CLOSE, *tPOCT6100_CHANNEL_CLOSE;

/* Channel modify structures. */
typedef struct _OCT6100_CHANNEL_MODIFY_TDM_
{

	
	UINT32	ulSinTimeslot;
	UINT32	ulSinStream;
	UINT32	ulSinPcmLaw;

	UINT32	ulSoutTimeslot;
	UINT32	ulSoutStream;
	UINT32	ulSoutPcmLaw;

	UINT32	ulRinTimeslot;
	UINT32	ulRinStream;
	UINT32	ulRinPcmLaw;

	UINT32	ulRoutTimeslot;
	UINT32	ulRoutStream;
	UINT32	ulRoutPcmLaw;

} tOCT6100_CHANNEL_MODIFY_TDM, *tPOCT6100_CHANNEL_MODIFY_TDM;

typedef struct _OCT6100_CHANNEL_MODIFY_VQE_
{
	BOOL	fEnableNlp;
	BOOL	fEnableTailDisplacement;
	UINT32	ulTailDisplacement;

	BOOL	fSinDcOffsetRemoval;
	BOOL	fRinDcOffsetRemoval;
	BOOL	fRinLevelControl;
	BOOL	fSoutLevelControl;
	BOOL	fRinAutomaticLevelControl;
	BOOL	fSoutAutomaticLevelControl;
	BOOL	fRinHighLevelCompensation;
	BOOL	fAcousticEcho;
	BOOL	fSoutAdaptiveNoiseReduction;
	BOOL	fDtmfToneRemoval;



	UINT32	ulNonLinearityBehaviorA;
	UINT32	ulNonLinearityBehaviorB;
	UINT32	ulComfortNoiseMode;

	INT32	lRinLevelControlGainDb;
	INT32	lSoutLevelControlGainDb;
	INT32	lRinAutomaticLevelControlTargetDb;
	INT32	lSoutAutomaticLevelControlTargetDb;
	INT32	lRinHighLevelCompensationThresholdDb;
	INT32	lDefaultErlDb;
	INT32	lAecDefaultErlDb;
	UINT32	ulAecTailLength;
	UINT32	ulSoutAutomaticListenerEnhancementGainDb;
	UINT32	ulSoutNaturalListenerEnhancementGainDb;
	BOOL	fSoutNaturalListenerEnhancement;

	BOOL	fRoutNoiseReduction;	/* Unsupported feature, for testing purposes only */
	INT32	lRoutNoiseReductionLevelGainDb;	/* Unsupported feature, for testing purposes only */
	BOOL	fEnablePlayout;
	INT32	lAnrSnrEnhancementDb;
	UINT32	ulAnrVoiceNoiseSegregation;
	UINT32	ulDoubleTalkBehavior;

	UINT32	ulToneDisablerVqeActivationDelay;

	BOOL	fEnableMusicProtection;
	BOOL	fIdleCodeDetection;



} tOCT6100_CHANNEL_MODIFY_VQE, *tPOCT6100_CHANNEL_MODIFY_VQE;



typedef struct _OCT6100_CHANNEL_MODIFY_
{
	UINT32	ulChannelHndl;
	UINT32	ulUserChanId;
	UINT32	ulEchoOperationMode;

	BOOL	fEnableToneDisabler;
	
	BOOL	fApplyToAllChannels;
	



	BOOL	fTdmConfigModified;		/* TRUE/FALSE */
	BOOL	fVqeConfigModified;		/* TRUE/FALSE */



	tOCT6100_CHANNEL_MODIFY_TDM		TdmConfig;
	tOCT6100_CHANNEL_MODIFY_VQE		VqeConfig;


} tOCT6100_CHANNEL_MODIFY, *tPOCT6100_CHANNEL_MODIFY;



/* Channel open structures.*/
typedef struct _OCT6100_CHANNEL_STATS_TDM_
{




	UINT32	ulSinTimeslot;
	UINT32	ulSinStream;
	UINT32	ulSinPcmLaw;

	UINT32	ulSoutTimeslot;
	UINT32	ulSoutStream;
	UINT32	ulSoutPcmLaw;


	
	UINT32	ulRinTimeslot;
	UINT32	ulRinStream;
	UINT32	ulRinPcmLaw;

	UINT32	ulRoutTimeslot;
	UINT32	ulRoutStream;
	UINT32	ulRoutPcmLaw;



} tOCT6100_CHANNEL_STATS_TDM, *tPOCT6100_CHANNEL_STATS_TDM;

typedef struct _OCT6100_CHANNEL_STATS_VQE_
{
	BOOL	fEnableNlp;
	BOOL	fEnableTailDisplacement;
	UINT32	ulTailDisplacement;
	UINT32	ulTailLength;

	BOOL	fSinDcOffsetRemoval;
	BOOL	fRinDcOffsetRemoval;
	BOOL	fRinLevelControl;
	BOOL	fSoutLevelControl;
	BOOL	fRinAutomaticLevelControl;
	BOOL	fSoutAutomaticLevelControl;
	BOOL	fRinHighLevelCompensation;
	BOOL	fAcousticEcho;
	BOOL	fSoutAdaptiveNoiseReduction;
	BOOL	fDtmfToneRemoval;


	
	UINT32	ulComfortNoiseMode;
	UINT32	ulNonLinearityBehaviorA;
	UINT32	ulNonLinearityBehaviorB;

	INT32	lRinLevelControlGainDb;
	INT32	lSoutLevelControlGainDb;
	INT32	lRinAutomaticLevelControlTargetDb;
	INT32	lSoutAutomaticLevelControlTargetDb;
	INT32	lRinHighLevelCompensationThresholdDb;
	INT32	lDefaultErlDb;
	INT32	lAecDefaultErlDb;
	UINT32	ulAecTailLength;
	UINT32	ulSoutAutomaticListenerEnhancementGainDb;
	UINT32	ulSoutNaturalListenerEnhancementGainDb;
	BOOL	fSoutNaturalListenerEnhancement;

	BOOL	fRoutNoiseReduction;	/* Unsupported feature, for testing purposes only */
	INT32	lRoutNoiseReductionLevelGainDb;	/* Unsupported feature, for testing purposes only */
	BOOL	fEnablePlayout;
	INT32	lAnrSnrEnhancementDb;
	UINT32	ulAnrVoiceNoiseSegregation;
	UINT32	ulDoubleTalkBehavior;

	UINT32	ulToneDisablerVqeActivationDelay;

	BOOL	fEnableMusicProtection;
	BOOL	fIdleCodeDetection;



} tOCT6100_CHANNEL_STATS_VQE, *tPOCT6100_CHANNEL_STATS_VQE;



typedef struct _OCT6100_CHANNEL_STATS_
{
	BOOL	fResetStats;
	
	UINT32	ulChannelHndl;
	UINT32	ulUserChanId;

	UINT32	ulEchoOperationMode;
	BOOL	fEnableToneDisabler;

	UINT32	ulMutePortsMask;


	tOCT6100_CHANNEL_STATS_TDM		TdmConfig;
	tOCT6100_CHANNEL_STATS_VQE		VqeConfig;


	/* Real stats. */
	UINT32	ulNumEchoPathChanges;
	UINT32	ulToneDisablerStatus;

	INT32	lCurrentERL;
	INT32	lCurrentERLE;
	UINT32	ulCurrentEchoDelay;

	INT32	lMaxERL;
	INT32	lMaxERLE;
	UINT32	ulMaxEchoDelay;

	INT32	lRinLevel;
	INT32	lSinLevel;
	INT32	lRinAppliedGain;
	INT32	lSoutAppliedGain;
	INT32	lComfortNoiseLevel;
	
	BOOL	fEchoCancellerConverged;
	BOOL	fSinVoiceDetected;



} tOCT6100_CHANNEL_STATS, *tPOCT6100_CHANNEL_STATS;



typedef struct _OCT6100_CHANNEL_MUTE_
{
	UINT32	ulChannelHndl;
	UINT32	ulPortMask;

} tOCT6100_CHANNEL_MUTE, *tPOCT6100_CHANNEL_MUTE;

typedef struct _OCT6100_CHANNEL_UNMUTE_
{
	UINT32	ulChannelHndl;
	UINT32	ulPortMask;

} tOCT6100_CHANNEL_UNMUTE, *tPOCT6100_CHANNEL_UNMUTE;

typedef struct _OCT6100_ENABLE_CHANNEL_RECORDING_
{
	PUINT32	pulChannelHndlConflict;

} tOCT6100_ENABLE_CHANNEL_RECORDING, *tPOCT6100_ENABLE_CHANNEL_RECORDING;

typedef struct _OCT6100_DISABLE_CHANNEL_RECORDING_
{
	UINT32	ulUnused;

} tOCT6100_DISABLE_CHANNEL_RECORDING, *tPOCT6100_DISABLE_CHANNEL_RECORDING;


/************************** FUNCTION PROTOTYPES  *****************************/


UINT32 Oct6100ChannelOpenDef(
				OUT		tPOCT6100_CHANNEL_OPEN					f_pChannelOpen );
UINT32 Oct6100ChannelOpen(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT	tPOCT6100_CHANNEL_OPEN					f_pChannelOpen );

UINT32 Oct6100ChannelCloseDef(
				OUT		tPOCT6100_CHANNEL_CLOSE					f_pChannelClose );
UINT32 Oct6100ChannelClose(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT	tPOCT6100_CHANNEL_CLOSE					f_pChannelClose );

UINT32 Oct6100ChannelModifyDef(
				OUT		tPOCT6100_CHANNEL_MODIFY				f_pChannelModify );
UINT32 Oct6100ChannelModify(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT	tPOCT6100_CHANNEL_MODIFY				f_pChannelModify );



UINT32 Oct6100ChannelGetStatsDef(
				OUT		tPOCT6100_CHANNEL_STATS					f_pChannelStats );
UINT32 Oct6100ChannelGetStats(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT	tPOCT6100_CHANNEL_STATS					f_pChannelStats );



UINT32 Oct6100ChannelMuteDef(
				OUT		tPOCT6100_CHANNEL_MUTE					f_pChannelMute );
UINT32 Oct6100ChannelMute(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT	tPOCT6100_CHANNEL_MUTE					f_pChannelMute );

UINT32 Oct6100ChannelUnMuteDef(
				OUT		tPOCT6100_CHANNEL_UNMUTE				f_pChannelUnMute );
UINT32 Oct6100ChannelUnMute(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT	tPOCT6100_CHANNEL_UNMUTE				f_pChannelUnMute );

UINT32 Oct6100ApiEnableChannelRecordingDef(
				IN OUT	tPOCT6100_ENABLE_CHANNEL_RECORDING		f_pChannelRecord );

UINT32 Oct6100ApiEnableChannelRecording(
				IN		tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT	tPOCT6100_ENABLE_CHANNEL_RECORDING		f_pChannelRecord );

UINT32 Oct6100ApiDisableChannelRecordingDef(
				IN OUT	tPOCT6100_DISABLE_CHANNEL_RECORDING		f_pChannelRecord );

UINT32 Oct6100ApiDisableChannelRecording(
				IN		tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT	tPOCT6100_DISABLE_CHANNEL_RECORDING		f_pChannelRecord );

#endif /* __OCT6100_CHANNEL_PUB_H__ */
