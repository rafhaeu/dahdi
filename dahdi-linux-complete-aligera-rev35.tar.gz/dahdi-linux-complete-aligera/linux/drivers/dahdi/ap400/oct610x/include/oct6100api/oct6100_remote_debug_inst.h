/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

File:  oct6100_remote_debug_inst.h

    Copyright (c) 2001-2017 Octasic Inc. All rights reserved.
    
Description: 

	File containing all defines, macros, and structures pertaining to the file
	oct6100_remote_debug.c.  All elements defined in this file are for public
	usage of the API.  All private elements are defined in the
	oct6100_remote_debug_priv.h file.

This source code is Octasic Confidential. Use of and access to this code 
is covered by the Octasic Device Enabling Software License Agreement. 
Acknowledgement of the Octasic Device Enabling Software License was 
required for access to this code. A copy was also provided with the release.

$Octasic_Release: OCT610xAPI-01.04.08 $

$Octasic_Revision: 6 $

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

#ifndef __OCT6100_REMOTE_DEBUG_INST_H__
#define __OCT6100_REMOTE_DEBUG_INST_H__

/*****************************  INCLUDE FILES  *******************************/


/*****************************  DEFINES  *************************************/


/*****************************  TYPES  ***************************************/

typedef struct _OCT6100_API_REMOTE_DEBUG_INFO_
{
	UINT32	ulSessionTreeOfst;
	UINT32	ulSessionListOfst;
	UINT32	ulSessionListHead;
	UINT32	ulSessionListTail;

	UINT32	ulPktCacheOfst;
	UINT32	ulDataBufOfst;
	
	UINT32	ulNumSessionsOpen;
	UINT32	ulMaxSessionsOpen;

} tOCT6100_API_REMOTE_DEBUG_INFO, *tPOCT6100_API_REMOTE_DEBUG_INFO;

typedef struct _OCT6100_API_REMOTE_DEBUG_SESSION_
{
	UINT32	ulSessionNum;
	UINT32	ulTransactionNum;
	UINT32	ulPktRetryNum;
	UINT32	ulPktByteSize;

	UINT32	aulLastPktTime[ 2 ];
	UINT32	ulForwardLink;
	UINT32	ulBackwardLink;

} tOCT6100_API_REMOTE_DEBUG_SESSION, *tPOCT6100_API_REMOTE_DEBUG_SESSION;

#endif /* __OCT6100_REMOTE_DEBUG_INST_H__ */
