/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

File:  oct6100_tsi_cnct_pub.h

    Copyright (c) 2001-2017 Octasic Inc. All rights reserved.
    
Description: 

	File containing all defines, macros, and structures pertaining to the file
	oct6100_tsi_cnct.c.  All elements defined in this file are for public
	usage of the API.  All private elements are defined in the
	oct6100_tsi_cnct_priv.h file.

This source code is Octasic Confidential. Use of and access to this code 
is covered by the Octasic Device Enabling Software License Agreement. 
Acknowledgement of the Octasic Device Enabling Software License was 
required for access to this code. A copy was also provided with the release.

$Octasic_Release: OCT610xAPI-01.04.08 $

$Octasic_Revision: 11 $

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

#ifndef __OCT6100_TSI_CNCT_PUB_H__
#define __OCT6100_TSI_CNCT_PUB_H__

/*****************************  INCLUDE FILES  *******************************/


/*****************************  DEFINES  *************************************/


/*****************************  TYPES  ***************************************/

typedef struct _OCT6100_TSI_CNCT_OPEN_
{
	PUINT32	pulTsiCnctHndl;

	UINT32	ulInputTimeslot;
	UINT32	ulInputStream;
	UINT32	ulOutputTimeslot;
	UINT32	ulOutputStream;

} tOCT6100_TSI_CNCT_OPEN, *tPOCT6100_TSI_CNCT_OPEN;

typedef struct _OCT6100_TSI_CNCT_CLOSE_
{
	UINT32	ulTsiCnctHndl;

} tOCT6100_TSI_CNCT_CLOSE, *tPOCT6100_TSI_CNCT_CLOSE;

/************************** FUNCTION PROTOTYPES  *****************************/

UINT32 Oct6100TsiCnctOpenDef(
				OUT		tPOCT6100_TSI_CNCT_OPEN				f_pTsiCnctOpen );
UINT32 Oct6100TsiCnctOpen(
				IN OUT	tPOCT6100_INSTANCE_API				f_pApiInstance,
				IN OUT	tPOCT6100_TSI_CNCT_OPEN				f_pTsiCnctOpen );

UINT32 Oct6100TsiCnctCloseDef(
				OUT		tPOCT6100_TSI_CNCT_CLOSE			f_pTsiCnctClose );
UINT32 Oct6100TsiCnctClose(
				IN OUT	tPOCT6100_INSTANCE_API				f_pApiInstance,
				IN OUT	tPOCT6100_TSI_CNCT_CLOSE			f_pTsiCnctClose );

#endif /* __OCT6100_TSI_CNCT_PUB_H__ */
