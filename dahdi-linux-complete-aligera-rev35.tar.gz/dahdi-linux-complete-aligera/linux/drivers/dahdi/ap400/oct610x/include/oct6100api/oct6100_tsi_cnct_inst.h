/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

File:  oct6100_tsi_cnct_inst.h

    Copyright (c) 2001-2017 Octasic Inc. All rights reserved.
    
Description: 

	File containing all defines, macros, and structures pertaining to the file
	oct6100_tsi_cnct.c.  All elements defined in this file are for public
	usage of the API.  All private elements are defined in the
	oct6100_tsi_cnct_priv.h file.

This source code is Octasic Confidential. Use of and access to this code 
is covered by the Octasic Device Enabling Software License Agreement. 
Acknowledgement of the Octasic Device Enabling Software License was 
required for access to this code. A copy was also provided with the release.

$Octasic_Release: OCT610xAPI-01.04.08 $

$Octasic_Revision: 9 $

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

#ifndef __OCT6100_TSI_CNCT_INST_H__
#define __OCT6100_TSI_CNCT_INST_H__

/*****************************  INCLUDE FILES  *******************************/

/*****************************  DEFINES  *************************************/

/*****************************  TYPES  ***************************************/

typedef struct _OCT6100_API_TSI_CNCT_
{
	/* Flag specifying whether the entry is used or not. */
	UINT8	fReserved;
	
	/* Count used to manage entry handles allocated to user. */
	UINT8	byEntryOpenCnt;

	/* Input PCM law. */
	UINT8	byInputPcmLaw;

	/* TSI chariot memory entry. */
	UINT16	usTsiMemIndex;

	/* Input and output timeslot information. */
	UINT16	usInputTimeslot;
	UINT16	usInputStream;

	UINT16	usOutputTimeslot;
	UINT16	usOutputStream;

	/* Internal info for quick access to structures associated to this TSI cnct. */
	UINT16	usInputTsstIndex;
	UINT16	usOutputTsstIndex;

} tOCT6100_API_TSI_CNCT, *tPOCT6100_API_TSI_CNCT;

#endif /* __OCT6100_TSI_CNCT_INST_H__ */
