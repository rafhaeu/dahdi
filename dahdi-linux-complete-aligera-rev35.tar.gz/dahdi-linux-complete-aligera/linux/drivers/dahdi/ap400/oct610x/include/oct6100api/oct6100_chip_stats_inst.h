/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

File:  oct6100_chip_stats_inst.h

    Copyright (c) 2001-2017 Octasic Inc. All rights reserved.
    
Description: 

	File containing all defines, macros, and structures pertaining to the file
	oct6100_chip_stats.c.  All elements defined in this file are for public
	usage of the API.  All private elements are defined in the
	oct6100_chip_stats_priv.h file.

This source code is Octasic Confidential. Use of and access to this code 
is covered by the Octasic Device Enabling Software License Agreement. 
Acknowledgement of the Octasic Device Enabling Software License was 
required for access to this code. A copy was also provided with the release.

$Octasic_Release: OCT610xAPI-01.04.08 $

$Octasic_Revision: 29 $

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

#ifndef __OCT6100_CHIP_STATS_INST_H__
#define __OCT6100_CHIP_STATS_INST_H__

/*****************************  INCLUDE FILES  *******************************/


/*****************************  DEFINES  *************************************/


/*****************************  TYPES  ***************************************/

typedef struct _OCT6100_API_CHIP_ERROR_STATS_
{
	UINT8	fFatalChipError;

	UINT32	ulInternalReadTimeoutCnt;
	UINT32	ulSdramRefreshTooLateCnt;
	UINT32	ulPllJitterErrorCnt;
	UINT32	ulInvalidMemAccessCnt;
	
	/* Internal tone detector error counter. */
	UINT32	ulToneDetectorErrorCnt;

	UINT32	ulOverflowToneEventsCnt;

	UINT32	ulH100OutOfSyncCnt;
	UINT32	ulH100ClkABadCnt;
	UINT32	ulH100ClkBBadCnt;
	UINT32	ulH100FrameABadCnt;
	



	
} tOCT6100_API_CHIP_ERROR_STATS, *tPOCT6100_API_CHIP_ERROR_STATS;

typedef struct _OCT6100_API_CHIP_STATS_
{
	UINT16	usNumberChannels;
	UINT16	usNumberBiDirChannels;
	UINT16	usNumberTsiCncts;





	
} tOCT6100_API_CHIP_STATS, *tPOCT6100_API_CHIP_STATS;

#endif /* __OCT6100_CHIP_STATS_INST_H__ */
