/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

File:  oct6100_mixer_inst.h

    Copyright (c) 2001-2017 Octasic Inc. All rights reserved.
    
Description: 

	File containing all defines, macros, and structures pertaining to the file
	oct6100_mixer.c.  All elements defined in this file are for public
	usage of the API.  All private elements are defined in the
	oct6100_mixer_priv.h file.

This source code is Octasic Confidential. Use of and access to this code 
is covered by the Octasic Device Enabling Software License Agreement. 
Acknowledgement of the Octasic Device Enabling Software License was 
required for access to this code. A copy was also provided with the release.

$Octasic_Release: OCT610xAPI-01.04.08 $

$Octasic_Revision: 13 $

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

#ifndef __OCT6100_MIXER_INST_H__
#define __OCT6100_MIXER_INST_H__

/*****************************  INCLUDE FILES  *******************************/


/*****************************  DEFINES  *************************************/


/*****************************  TYPES  ***************************************/

typedef struct _OCT6100_API_MIXER_EVENT_
{
	/* Flag specifying whether the entry is used or not. */
	UINT8	fReserved;

	/* Type of the event.*/
	UINT16	usEventType;

	/* Source channel index */
	UINT16	usSourceChanIndex;

	/* Destination channel index */
	UINT16	usDestinationChanIndex;
	
	/* Pointer to the next entry.*/
	UINT16	usNextEventPtr;

} tOCT6100_API_MIXER_EVENT, *tPOCT6100_API_MIXER_EVENT;



#endif /* __OCT6100_MIXER_INST_H__ */
