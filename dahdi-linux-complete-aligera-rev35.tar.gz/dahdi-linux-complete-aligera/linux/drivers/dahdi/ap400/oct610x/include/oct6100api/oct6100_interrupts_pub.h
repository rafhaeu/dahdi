/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

File:  oct6100_interrupts_pub.h

    Copyright (c) 2001-2017 Octasic Inc. All rights reserved.
    
Description: 

	File containing all defines, macros, and structures pertaining to the file
	oct6100_interrupts.c.  All elements defined in this file are for public
	usage of the API.  All private elements are defined in the
	oct6100_interrupts_priv.h file.

This source code is Octasic Confidential. Use of and access to this code 
is covered by the Octasic Device Enabling Software License Agreement. 
Acknowledgement of the Octasic Device Enabling Software License was 
required for access to this code. A copy was also provided with the release.

$Octasic_Release: OCT610xAPI-01.04.08 $

$Octasic_Revision: 31 $

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

#ifndef __OCT6100_INTERRUPTS_PUB_H__
#define __OCT6100_INTERRUPTS_PUB_H__

/*****************************  INCLUDE FILES  *******************************/


/*****************************  DEFINES  *************************************/


/*****************************  TYPES  ***************************************/

typedef struct _OCT6100_INTERRUPT_CONFIGURE_
{
	UINT32	ulFatalGeneralConfig;
	UINT32	ulFatalMemoryConfig;

	UINT32	ulErrorMemoryConfig;




	UINT32	ulErrorH100Config;

	UINT32	ulFatalMemoryTimeout;
	UINT32	ulErrorMemoryTimeout;

	UINT32	ulErrorH100Timeout;

} tOCT6100_INTERRUPT_CONFIGURE, *tPOCT6100_INTERRUPT_CONFIGURE;

typedef struct _OCT6100_INTERRUPT_FLAGS_
{
	BOOL	fFatalGeneral;
	UINT32	ulFatalGeneralFlags;

	BOOL	fFatalReadTimeout;
	
	BOOL	fErrorRefreshTooLate; 
	BOOL	fErrorPllJitter;
	BOOL	fErrorInvalidMemAccess;






	BOOL	fErrorH100OutOfSync;
	BOOL	fErrorH100ClkA;
	BOOL	fErrorH100ClkB;
	BOOL	fErrorH100FrameA;




	BOOL	fApiSynch;
	


} tOCT6100_INTERRUPT_FLAGS, *tPOCT6100_INTERRUPT_FLAGS;

/************************** FUNCTION PROTOTYPES  *****************************/

UINT32 Oct6100InterruptConfigureDef(
			OUT		tPOCT6100_INTERRUPT_CONFIGURE		f_pConfigInts );
UINT32 Oct6100InterruptConfigure(
			IN		tPOCT6100_INSTANCE_API				f_pApiInst,
			IN OUT	tPOCT6100_INTERRUPT_CONFIGURE		f_pConfigInts );

UINT32 Oct6100InterruptServiceRoutineDef(
			OUT		tPOCT6100_INTERRUPT_FLAGS			f_pIntFlags );
UINT32 Oct6100InterruptServiceRoutine(
			IN		tPOCT6100_INSTANCE_API				f_pApiInst,
			IN OUT	tPOCT6100_INTERRUPT_FLAGS			f_pIntFlags );

#endif /* __OCT6100_INTERRUPTS_PUB_H__ */

