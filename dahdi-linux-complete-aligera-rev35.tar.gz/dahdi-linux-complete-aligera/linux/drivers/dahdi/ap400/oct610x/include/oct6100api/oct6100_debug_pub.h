/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

File:  oct6100_debug_pub.h

    Copyright (c) 2001-2017 Octasic Inc. All rights reserved.
    
Description: 

	File containing all defines, macros, and structures pertaining to the file
	oct6100_debug.c.  All elements defined in this file are for public
	usage of the API.

This source code is Octasic Confidential. Use of and access to this code 
is covered by the Octasic Device Enabling Software License Agreement. 
Acknowledgement of the Octasic Device Enabling Software License was 
required for access to this code. A copy was also provided with the release.

$Octasic_Release: OCT610xAPI-01.04.08 $

$Octasic_Revision: 14 $

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

#ifndef __OCT6100_DEBUG_PUB_H__
#define __OCT6100_DEBUG_PUB_H__

/*****************************  INCLUDE FILES  *******************************/


/*****************************  DEFINES  *************************************/


/*****************************  TYPES  ***************************************/

typedef struct _OCT6100_DEBUG_SELECT_CHANNEL_
{
	UINT32	ulChannelHndl;

} tOCT6100_DEBUG_SELECT_CHANNEL, *tPOCT6100_DEBUG_SELECT_CHANNEL;

typedef struct _OCT6100_DEBUG_GET_DATA_
{
	UINT32	ulGetDataMode;
	UINT32	ulGetDataContent;
	UINT32	ulRemainingNumBytes;
	UINT32	ulTotalNumBytes;
	UINT32	ulMaxBytes;
	UINT32	ulValidNumBytes;
	PUINT8	pbyData;

} tOCT6100_DEBUG_GET_DATA, *tPOCT6100_DEBUG_GET_DATA;

/************************** FUNCTION PROTOTYPES  *****************************/

UINT32 Oct6100DebugSelectChannelDef(
				OUT		tPOCT6100_DEBUG_SELECT_CHANNEL		f_pSelectDebugChan );
UINT32 Oct6100DebugSelectChannel(
				IN OUT	tPOCT6100_INSTANCE_API				f_pApiInst,
				IN OUT	tPOCT6100_DEBUG_SELECT_CHANNEL		f_pSelectDebugChan );

UINT32 Oct6100DebugGetDataDef(
				OUT		tPOCT6100_DEBUG_GET_DATA			f_pGetData );
UINT32 Oct6100DebugGetData(
				IN OUT	tPOCT6100_INSTANCE_API				f_pApiInst,
				IN OUT	tPOCT6100_DEBUG_GET_DATA			f_pGetData );

#endif /* __OCT6100_DEBUG_PUB_H__ */
