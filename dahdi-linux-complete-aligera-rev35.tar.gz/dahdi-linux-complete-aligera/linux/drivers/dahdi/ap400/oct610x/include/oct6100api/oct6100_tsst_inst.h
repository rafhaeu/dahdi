/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

File:  oct6100_tsst_inst.h

    Copyright (c) 2001-2017 Octasic Inc. All rights reserved.
    
Description: 

	File containing all defines, macros, and structures pertaining to the file
	oct6100_tsst.c.  All elements defined in this file are for public
	usage of the API.  All private elements are defined in the
	oct6100_tsst_priv.h file.

This source code is Octasic Confidential. Use of and access to this code 
is covered by the Octasic Device Enabling Software License Agreement. 
Acknowledgement of the Octasic Device Enabling Software License was 
required for access to this code. A copy was also provided with the release.

$Octasic_Release: OCT610xAPI-01.04.08 $

$Octasic_Revision: 5 $

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

#ifndef __OCT6100_TSST_INST_H__
#define __OCT6100_TSST_INST_H__

/*****************************  INCLUDE FILES  *******************************/


/*****************************  DEFINES  *************************************/


/*****************************  TYPES  ***************************************/

typedef struct _OCT6100_API_TSST_ENTRY_
{
	UINT16	usTsstMemoryIndex;		/* Index in the TSST memory of the TSST */
	UINT16	usTsstValue;			/* Tsst value given by the user. */
									/* bit 5:0 = stream value, bit 13:6 = timeslot value. */

	UINT16	usNextEntry;			/* Pointer to the next entry in the list. */

} tOCT6100_API_TSST_ENTRY, *tPOCT6100_API_TSST_ENTRY;

#endif /* __OCT6100_TSST_INST_H__ */
