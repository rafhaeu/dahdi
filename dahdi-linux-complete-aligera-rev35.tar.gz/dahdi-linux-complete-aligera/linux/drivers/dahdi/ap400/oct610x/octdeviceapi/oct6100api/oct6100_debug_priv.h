/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

File:  oct6100_debug_priv.h

    Copyright (c) 2001-2017 Octasic Inc. All rights reserved.
    
Description: 

	File containing all private defines, macros, structures and prototypes 
	pertaining to the file oct6100_debug.c.  All elements defined in this 
	file are for private usage of the API.  All public elements are defined 
	in the oct6100_debug_pub.h file.

This source code is Octasic Confidential. Use of and access to this code 
is covered by the Octasic Device Enabling Software License Agreement. 
Acknowledgement of the Octasic Device Enabling Software License was 
required for access to this code. A copy was also provided with the release.

$Octasic_Release: OCT610xAPI-01.04.08 $

$Octasic_Revision: 14 $

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

#ifndef __OCT6100_DEBUG_PRIV_H__
#define __OCT6100_DEBUG_PRIV_H__

/*****************************  INCLUDE FILES  *******************************/


/*****************************  DEFINES  *************************************/


/*****************************  TYPES  ***************************************/


/************************** FUNCTION PROTOTYPES  *****************************/


UINT32 Oct6100DebugSelectChannelSer(
				IN OUT	tPOCT6100_INSTANCE_API				f_pApiInstance,
				IN		tPOCT6100_DEBUG_SELECT_CHANNEL		f_pSelectDebugChan,
				IN		BOOL								f_fCheckChannelRecording );

UINT32 Oct6100DebugGetDataSer(
				IN OUT	tPOCT6100_INSTANCE_API				f_pApiInstance,
				IN OUT	tPOCT6100_DEBUG_GET_DATA			f_pGetData );

UINT32 Oct6100DebugCoreDump(
				IN OUT	tPOCT6100_INSTANCE_API				f_pApiInstance,
				IN OUT	tPOCT6100_DEBUG_GET_DATA			f_pGetData,
				IN OUT	PUINT32								f_pulUserBufWriteIndex );

UINT32 Oct6100DebugCoreDumpMemory(
				IN OUT	tPOCT6100_INSTANCE_API				f_pApiInstance,
				IN OUT	tPOCT6100_DEBUG_GET_DATA			f_pGetData,
				IN OUT	PUINT32								f_pulUserBufWriteIndex,
				IN		UINT32								f_ulMemOffsetBottom,
				IN		UINT32								f_ulMemOffsetTop );



#endif /* __OCT6100_DEBUG_PRIV_H__ */
