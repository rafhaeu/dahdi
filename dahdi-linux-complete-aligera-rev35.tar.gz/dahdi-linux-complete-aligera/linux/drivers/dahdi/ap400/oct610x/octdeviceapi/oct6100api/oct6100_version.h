/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

File:  oct6100_version.h

    Copyright (c) 2001-2017 Octasic Inc. All rights reserved.
    
Description: 

	This file contains the version of API. To obtain that version
	number, the user must call the API function Oct6100ApiGetVersion().

This source code is Octasic Confidential. Use of and access to this code 
is covered by the Octasic Device Enabling Software License Agreement. 
Acknowledgement of the Octasic Device Enabling Software License was 
required for access to this code. A copy was also provided with the release.

$Octasic_Release: OCT610xAPI-01.04.08 $

$Octasic_Revision: 76 $

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

#ifndef __OCT6100_VERSION_H__
#define __OCT6100_VERSION_H__

/* String version of the OCT6100 API.*/

#define cOCT6100_API_VERSION "OCT6100API-01.04.06"

#endif /* __OCT6100_VERSION_H__ */
