/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

File:  oct6100_channel_priv.h

    Copyright (c) 2001-2017 Octasic Inc. All rights reserved.
    
Description: 

	File containing all private defines, macros, structures and prototypes 
	pertaining to the file oct6100_channel.c.  All elements defined in this 
	file are for private usage of the API.  All public elements are defined 
	in the oct6100_channel_pub.h file.

This source code is Octasic Confidential. Use of and access to this code 
is covered by the Octasic Device Enabling Software License Agreement. 
Acknowledgement of the Octasic Device Enabling Software License was 
required for access to this code. A copy was also provided with the release.

$Octasic_Release: OCT610xAPI-01.04.08 $

$Octasic_Revision: 65 $

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

#ifndef __OCT6100_CHANNEL_PRIV_H__
#define __OCT6100_CHANNEL_PRIV_H__


/*****************************  INCLUDE FILES  *******************************/


/*****************************  DEFINES  *************************************/

/* ECHO channel list pointer macros. */
#define mOCT6100_GET_CHANNEL_LIST_PNT( pSharedInfo, pList ) \
			pList = ( tPOCT6100_API_CHANNEL )(( PUINT8 )pSharedInfo + pSharedInfo->ulChannelListOfst );

#define mOCT6100_GET_CHANNEL_ENTRY_PNT( pSharedInfo, pEntry, ulIndex ) \
			pEntry = (( tPOCT6100_API_CHANNEL )(( PUINT8 )pSharedInfo + pSharedInfo->ulChannelListOfst)) + ulIndex;

#define mOCT6100_GET_CHANNEL_ALLOC_PNT( pSharedInfo, pAlloc ) \
			pAlloc = ( PVOID )(( PUINT8 )pSharedInfo + pSharedInfo->ulChannelAllocOfst);




/*****************************  TYPES  ***************************************/

typedef struct _OCT6100_API_ECHO_CHAN_INDEX_
{
	/* Index of the channel in the API echo channel list.*/
	UINT16	usEchoChanIndex;
	
	/* TSI chariot memory entry for the Rin/Rout stream. */
	UINT16	usRinRoutTsiMemIndex;

	/* TSI chariot memory entry for the Sin/Sout stream. */
	UINT16	usSinSoutTsiMemIndex;

	/* SSPX memory entry. */
	UINT16	usEchoMemIndex;
	
	/* TDM sample conversion control memory entry. */
	UINT16	usRinRoutConversionMemIndex;
	UINT16	usSinSoutConversionMemIndex;

	/* Internal info for quick access to structures associated to this TSI cnct. */
	UINT16	usRinTsstIndex;
	UINT16	usSinTsstIndex;
	UINT16	usRoutTsstIndex;
	UINT16	usSoutTsstIndex;





} tOCT6100_API_ECHO_CHAN_INDEX, *tPOCT6100_API_ECHO_CHAN_INDEX;


/************************** FUNCTION PROTOTYPES  *****************************/

UINT32 Oct6100ApiGetChannelsEchoSwSizes(
				IN		tPOCT6100_CHIP_OPEN						f_pOpenChip,
				OUT		tPOCT6100_API_INSTANCE_SIZES			f_pInstSizes );

UINT32 Oct6100ApiChannelsEchoSwInit(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance );

UINT32 Oct6100ChannelOpenSer(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT	tPOCT6100_CHANNEL_OPEN					f_pChannelOpen );

UINT32 Oct6100ApiCheckChannelParams(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT	tPOCT6100_CHANNEL_OPEN					f_pChannelOpen,
				IN OUT	tPOCT6100_API_ECHO_CHAN_INDEX			f_pChanIndexConf );

UINT32 Oct6100ApiReserveChannelResources(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_CHANNEL_OPEN					f_pChannelOpen,
				IN OUT	tPOCT6100_API_ECHO_CHAN_INDEX			f_pChanIndexConf );

UINT32 Oct6100ApiWriteChannelStructs(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_CHANNEL_OPEN					f_pChannelOpen,
				IN		tPOCT6100_API_ECHO_CHAN_INDEX			f_pChanIndexConf );

UINT32 Oct6100ApiUpdateChannelEntry(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT	tPOCT6100_CHANNEL_OPEN					f_pChannelOpen,
				IN		tPOCT6100_API_ECHO_CHAN_INDEX			f_pChanIndexConf );

UINT32 Oct6100ChannelCloseSer(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_CHANNEL_CLOSE					f_pChannelClose );

UINT32 Oct6100ApiAssertChannelParams( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_CHANNEL_CLOSE					f_pChannelClose,

				IN OUT	PUINT16									f_pusChanIndex );

UINT32 Oct6100ApiInvalidateChannelStructs( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,

				IN		UINT16									f_usChanIndex );

UINT32 Oct6100ApiReleaseChannelResources( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		UINT16									f_usChannelIndex );

UINT32 Oct6100ChannelModifySer(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_CHANNEL_MODIFY				f_pChannelModify );

UINT32 Oct6100ApiCheckChannelModify(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_CHANNEL_MODIFY				f_pChannelModify,
				IN OUT	tPOCT6100_CHANNEL_OPEN					f_pTempChanOpen,

				OUT		PUINT16									f_pusChanIndex );

UINT32 Oct6100ApiModifyChannelResources(	
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_CHANNEL_MODIFY				f_pChannelModify,
				IN		UINT16									f_usChanIndex,
				OUT		PUINT16									f_pusNewRinTsstIndex,
				OUT		PUINT16									f_pusNewSinTsstIndex,
				OUT		PUINT16									f_pusNewRoutTsstIndex,
				OUT		PUINT16									f_pusNewSoutTsstIndex );

UINT32 Oct6100ApiModifyChannelStructs(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_CHANNEL_MODIFY				f_pChannelModify, 
				IN		tPOCT6100_CHANNEL_OPEN					f_pChannelOpen, 
				IN		UINT16									f_usChanIndex,

				IN		UINT16									f_usNewRinTsstIndex,
				IN		UINT16									f_uslNewSinTsstIndex,
				IN		UINT16									f_usNewRoutTsstIndex,
				IN		UINT16									f_usNewSoutTsstIndex );

UINT32 Oct6100ApiModifyChannelEntry(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT	tPOCT6100_CHANNEL_MODIFY				f_pChannelModify,
				IN		tPOCT6100_CHANNEL_OPEN					f_pChannelOpen,
				IN		UINT16									f_usChanIndex,

				IN		UINT16									f_usNewRinTsstIndex,
				IN		UINT16									f_usNewSinTsstIndex,
				IN		UINT16									f_usNewRoutTsstIndex,
				IN		UINT16									f_usNewSoutTsstIndex );



UINT32 Oct6100ApiChannelGetStatsSer(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT	tPOCT6100_CHANNEL_STATS					f_pChannelStats );

UINT32 Oct6100ApiReserveEchoEntry(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				OUT		PUINT16									f_pusEchoIndex );

UINT32 Oct6100ApiReleaseEchoEntry(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		UINT16									f_usEchoChanIndex );

UINT32 Oct6100ApiCheckTdmConfig( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_CHANNEL_OPEN_TDM				f_pTdmConfig );

UINT32 Oct6100ApiCheckVqeConfig( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_CHANNEL_OPEN_VQE				f_pVqeConfig,
				IN		BOOL									f_fEnableToneDisabler );



UINT32 Oct6100ApiWriteInputTsstControlMemory( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		UINT16									f_usTsstIndex,
				IN		UINT16									f_usTsiMemIndex,
				IN		UINT32									f_ulTsstInputLaw );

UINT32 Oct6100ApiWriteOutputTsstControlMemory( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		UINT16									f_usTsstIndex,

				IN		UINT16									f_usTsiMemIndex );


UINT32 Oct6100ApiWriteLawConversionMemory( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		UINT16									f_usConversionMemIndex,
				IN		UINT16									f_usTsiMemIndex,
				IN		UINT32									f_ulPcmLaw,
				IN		UINT32									f_fRinRoutStream );

UINT32 Oct6100ApiClearConversionMemory( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		UINT16									f_usConversionMemIndex );

UINT32 Oct6100ApiWriteVqeMemory( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_CHANNEL_OPEN_VQE				f_pVqeConfig,
				IN		tPOCT6100_CHANNEL_OPEN					f_pChannelOpen,
				IN		UINT16									f_usChanIndex,
				IN		UINT16									f_usEchoMemIndex,
				IN		BOOL									f_fClearPlayoutPointers,
				IN		BOOL									f_fModifyOnly );

UINT32 Oct6100ApiWriteVqeNlpMemory( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_CHANNEL_OPEN_VQE				f_pVqeConfig,
				IN		tPOCT6100_CHANNEL_OPEN					f_pChannelOpen,
				IN		UINT16									f_usChanIndex,
				IN		UINT16									f_usEchoMemIndex,
				IN		BOOL									f_fClearPlayoutPointers,
				IN		BOOL									f_fModifyOnly );

UINT32 Oct6100ApiWriteVqeAfMemory( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_CHANNEL_OPEN_VQE				f_pVqeConfig,
				IN		tPOCT6100_CHANNEL_OPEN					f_pChannelOpen,
				IN		UINT16									f_usChanIndex,
				IN		UINT16									f_usEchoMemIndex,
				IN		BOOL									f_fClearPlayoutPointers,
				IN		BOOL									f_fModifyOnly );

UINT32 Oct6100ApiWriteEchoMemory( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_CHANNEL_OPEN_TDM				f_pTdmConfig,
				IN		tPOCT6100_CHANNEL_OPEN					f_pChannelOpen,
				IN		UINT16									f_usEchoIndex,
				IN		UINT16									f_usRinRoutTsiIndex,
				IN		UINT16									f_usSinSoutTsiIndex );

UINT32 Oct6100ApiUpdateOpenStruct( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_CHANNEL_MODIFY				f_pChanModify,
				IN OUT	tPOCT6100_CHANNEL_OPEN					f_pChanOpen,
				IN		tPOCT6100_API_CHANNEL					f_pChanEntry );





UINT32 Oct6100ApiRetrieveNlpConfDword( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_API_CHANNEL					f_pChanEntry,
				IN		UINT32									f_ulAddress,
				OUT		PUINT32									f_pulConfigDword );

UINT32 Oct6100ApiSaveNlpConfDword( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_API_CHANNEL					f_pChanEntry,
				IN		UINT32									f_ulAddress,
				IN		UINT32									f_ulConfigDword );



UINT32 Oct6100ApiWriteDebugChanMemory( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_CHANNEL_OPEN_TDM				f_pTdmConfig,
				IN		tPOCT6100_CHANNEL_OPEN_VQE				f_pVqeConfig,
				IN		tPOCT6100_CHANNEL_OPEN					f_pChannelOpen,
				IN		UINT16									f_usChanIndex,
				IN		UINT16									f_usEchoMemIndex,
				IN		UINT16									f_usRinRoutTsiIndex,
				IN		UINT16									f_usSinSoutTsiIndex );

UINT32 Oct6100ApiDebugChannelOpen( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance );

UINT32 Oct6100ApiDebugChannelClose( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance );

UINT32 Oct6100ApiEnableChannelRecordingSer(
				IN		tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT	tPOCT6100_ENABLE_CHANNEL_RECORDING		f_pChannelRecord );

UINT32 Oct6100ApiDisableChannelRecordingSer(
				IN		tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT	tPOCT6100_DISABLE_CHANNEL_RECORDING		f_pChannelRecord );

UINT32 Oct6100ApiMutePorts( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		UINT16									f_usEchoIndex,
				IN		UINT16									f_usRinTsstIndex,
				IN		UINT16									f_usSinTsstIndex,
				IN		BOOL									f_fCheckBridgeIndex );

UINT32 Oct6100ApiSetChannelLevelControl(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_CHANNEL_OPEN_VQE				f_pVqeConfig,
				IN		UINT16									f_usChanIndex,
				IN		UINT16									f_usEchoMemIndex,
				IN		BOOL									f_fClearAlcHlcStatusBit );

UINT32 Oct6100ApiSetChannelTailConfiguration(
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_CHANNEL_OPEN_VQE				f_pVqeConfig,
				IN		UINT16									f_usChanIndex,
				IN		UINT16									f_usEchoMemIndex,
				IN		BOOL									f_fModifyOnly );

UINT32 Oct6100ChannelMuteSer( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_CHANNEL_MUTE					f_pChannelMute );

UINT32 Oct6100ApiAssertChannelMuteParams(	
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance, 
				IN		tPOCT6100_CHANNEL_MUTE					f_pChannelMute, 
				OUT		PUINT16									f_pusChanIndex,
				OUT		PUINT16									f_pusPorts );

UINT32 Oct6100ChannelUnMuteSer( 
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		tPOCT6100_CHANNEL_UNMUTE				f_pChannelUnMute );

UINT32 Oct6100ApiAssertChannelUnMuteParams(	
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance, 
				IN		tPOCT6100_CHANNEL_UNMUTE				f_pChannelUnMute, 
				OUT		PUINT16									f_pusChanIndex,
				OUT		PUINT16									f_pusPorts );

UINT32 Oct6100ApiMuteSinWithFeatures(
				IN		tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		UINT16									f_usChanIndex,
				IN		BOOL									f_fEnableSinWithFeatures );

UINT32 Oct6100ApiMuteChannelPorts(	
				IN OUT	tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN		UINT16									f_usChanIndex,
				IN		UINT16									f_usPortMask,
				IN		BOOL									f_fMute );

INT32 Oct6100ApiOctFloatToDbEnergyByte(
				IN	UINT8 x );

INT32 Oct6100ApiOctFloatToDbEnergyHalf(
				IN	UINT16 x );

UINT16 Oct6100ApiDbAmpHalfToOctFloat(
				IN	INT32 x );

#endif /* __OCT6100_CHANNEL_PRIV_H__ */
