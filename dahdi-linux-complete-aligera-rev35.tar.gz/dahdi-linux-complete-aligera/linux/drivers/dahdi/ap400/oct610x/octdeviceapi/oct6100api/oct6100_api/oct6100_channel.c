/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

File: oct6100_channel.c

    Copyright (c) 2001-2017 Octasic Inc. All rights reserved.
    
Description: 

	This file contains functions used to open, modify and close echo 
	cancellation channels.

This source code is Octasic Confidential. Use of and access to this code 
is covered by the Octasic Device Enabling Software License Agreement. 
Acknowledgement of the Octasic Device Enabling Software License was 
required for access to this code. A copy was also provided with the release.

$Octasic_Release: OCT610xAPI-01.04.08 $

$Octasic_Revision: 529 $

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/


/*****************************  INCLUDE FILES  *******************************/

#include "octdef.h"

#include "oct6100api/oct6100_defines.h"
#include "oct6100api/oct6100_errors.h"
#include "oct6100api/oct6100_apiud.h"

#include "apilib/octapi_llman.h"

#include "oct6100api/oct6100_tlv_inst.h"
#include "oct6100api/oct6100_chip_open_inst.h"
#include "oct6100api/oct6100_chip_stats_inst.h"
#include "oct6100api/oct6100_interrupts_inst.h"
#include "oct6100api/oct6100_remote_debug_inst.h"
#include "oct6100api/oct6100_debug_inst.h"
#include "oct6100api/oct6100_api_inst.h"
#include "oct6100api/oct6100_mixer_inst.h"



#include "oct6100api/oct6100_tsst_inst.h"
#include "oct6100api/oct6100_channel_inst.h"

#include "oct6100api/oct6100_interrupts_pub.h"
#include "oct6100api/oct6100_chip_open_pub.h"




#include "oct6100api/oct6100_channel_pub.h"
#include "oct6100api/oct6100_debug_pub.h"

#include "oct6100_chip_open_priv.h"
#include "oct6100_miscellaneous_priv.h"
#include "oct6100_memory_priv.h"
#include "oct6100_tsst_priv.h"
#include "oct6100_mixer_priv.h"



#include "oct6100_channel_priv.h"
#include "oct6100_debug_priv.h"


/****************************  PUBLIC FUNCTIONS  ****************************/

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ChannelOpen

Description:    This function opens a echo cancellation channel. An echo cancellation
				channel is constituted of two voice stream (RIN/ROUT and SIN/SOUT), and
				an echo cancelling core.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.

f_pChannelOpen			Pointer to echo channel open structure.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ChannelOpenDef(
				IN OUT tPOCT6100_CHANNEL_OPEN			f_pChannelOpen )
{
	f_pChannelOpen->pulChannelHndl			= NULL;
	f_pChannelOpen->ulUserChanId			= cOCT6100_INVALID_VALUE;
	f_pChannelOpen->ulEchoOperationMode		= cOCT6100_ECHO_OP_MODE_POWER_DOWN;
	f_pChannelOpen->fEnableToneDisabler		= FALSE;


	/* VQE configuration.*/
	f_pChannelOpen->VqeConfig.fSinDcOffsetRemoval = TRUE;
	f_pChannelOpen->VqeConfig.fRinDcOffsetRemoval = TRUE;
	f_pChannelOpen->VqeConfig.fRinLevelControl	= FALSE;
	f_pChannelOpen->VqeConfig.lRinLevelControlGainDb = 0;
	f_pChannelOpen->VqeConfig.fSoutLevelControl = FALSE;
	f_pChannelOpen->VqeConfig.lSoutLevelControlGainDb = 0;
	f_pChannelOpen->VqeConfig.fRinAutomaticLevelControl	= FALSE;
	f_pChannelOpen->VqeConfig.lRinAutomaticLevelControlTargetDb = -20;
	f_pChannelOpen->VqeConfig.fSoutAutomaticLevelControl = FALSE;
	f_pChannelOpen->VqeConfig.lSoutAutomaticLevelControlTargetDb = -20;
	f_pChannelOpen->VqeConfig.fRinHighLevelCompensation = FALSE;
	f_pChannelOpen->VqeConfig.lRinHighLevelCompensationThresholdDb = -10;
	f_pChannelOpen->VqeConfig.fSoutAdaptiveNoiseReduction = FALSE;

	f_pChannelOpen->VqeConfig.ulComfortNoiseMode = cOCT6100_COMFORT_NOISE_NORMAL;
	f_pChannelOpen->VqeConfig.fEnableNlp = TRUE;
	f_pChannelOpen->VqeConfig.fEnableTailDisplacement = FALSE;
	f_pChannelOpen->VqeConfig.ulTailDisplacement = cOCT6100_AUTO_SELECT_TAIL;
	f_pChannelOpen->VqeConfig.ulTailLength = cOCT6100_AUTO_SELECT_TAIL;

	f_pChannelOpen->VqeConfig.fDtmfToneRemoval = FALSE;

	f_pChannelOpen->VqeConfig.fAcousticEcho = FALSE;
	f_pChannelOpen->VqeConfig.lDefaultErlDb = -6;
	f_pChannelOpen->VqeConfig.ulAecTailLength = 128;
	f_pChannelOpen->VqeConfig.lAecDefaultErlDb = 0;
	f_pChannelOpen->VqeConfig.ulNonLinearityBehaviorA = 1;
	f_pChannelOpen->VqeConfig.ulNonLinearityBehaviorB = 0;	
	f_pChannelOpen->VqeConfig.ulDoubleTalkBehavior = cOCT6100_DOUBLE_TALK_BEH_NORMAL;
	f_pChannelOpen->VqeConfig.ulSoutAutomaticListenerEnhancementGainDb = 0;
	f_pChannelOpen->VqeConfig.ulSoutNaturalListenerEnhancementGainDb = 0;
	f_pChannelOpen->VqeConfig.fSoutNaturalListenerEnhancement = FALSE;
	f_pChannelOpen->VqeConfig.fRoutNoiseReduction = FALSE;
	f_pChannelOpen->VqeConfig.lRoutNoiseReductionLevelGainDb = -18;
	f_pChannelOpen->VqeConfig.fEnablePlayout = TRUE;
	f_pChannelOpen->VqeConfig.lAnrSnrEnhancementDb = -18;
	f_pChannelOpen->VqeConfig.ulAnrVoiceNoiseSegregation = 6;
	f_pChannelOpen->VqeConfig.ulToneDisablerVqeActivationDelay = 300;
	f_pChannelOpen->VqeConfig.fEnableMusicProtection = FALSE;
	/* Older images have idle code detection hard-coded to enabled. */
	f_pChannelOpen->VqeConfig.fIdleCodeDetection = TRUE;

	/* TDM configuration.*/


	f_pChannelOpen->TdmConfig.ulRinTimeslot = cOCT6100_UNASSIGNED;
	f_pChannelOpen->TdmConfig.ulRinStream = cOCT6100_UNASSIGNED;
	f_pChannelOpen->TdmConfig.ulRinPcmLaw = cOCT6100_PCM_U_LAW;

	f_pChannelOpen->TdmConfig.ulSinTimeslot = cOCT6100_UNASSIGNED;
	f_pChannelOpen->TdmConfig.ulSinStream = cOCT6100_UNASSIGNED;
	f_pChannelOpen->TdmConfig.ulSinPcmLaw = cOCT6100_PCM_U_LAW;

	f_pChannelOpen->TdmConfig.ulRoutTimeslot = cOCT6100_UNASSIGNED;
	f_pChannelOpen->TdmConfig.ulRoutStream = cOCT6100_UNASSIGNED;
	f_pChannelOpen->TdmConfig.ulRoutPcmLaw = cOCT6100_PCM_U_LAW;

	f_pChannelOpen->TdmConfig.ulSoutTimeslot = cOCT6100_UNASSIGNED;
	f_pChannelOpen->TdmConfig.ulSoutStream = cOCT6100_UNASSIGNED;
	f_pChannelOpen->TdmConfig.ulSoutPcmLaw = cOCT6100_PCM_U_LAW;




	return cOCT6100_ERR_OK;
}

UINT32 Oct6100ChannelOpen(
				IN tPOCT6100_INSTANCE_API				f_pApiInstance,
				IN OUT tPOCT6100_CHANNEL_OPEN			f_pChannelOpen )
{
	tOCT6100_SEIZE_SERIALIZE_OBJECT		SeizeSerObj;
	tOCT6100_RELEASE_SERIALIZE_OBJECT	ReleaseSerObj;
	UINT32								ulSerRes = cOCT6100_ERR_OK;
	UINT32								ulFncRes = cOCT6100_ERR_OK;

	/* Set the process context of the serialize structure.*/
	SeizeSerObj.pProcessContext = f_pApiInstance->pProcessContext;
	ReleaseSerObj.pProcessContext = f_pApiInstance->pProcessContext;

	/* Seize all list semaphores needed by this function. */
	SeizeSerObj.ulSerialObjHndl = f_pApiInstance->ulApiSerObj;
	SeizeSerObj.ulTryTimeMs = cOCT6100_WAIT_INFINITELY;
	ulSerRes = Oct6100UserSeizeSerializeObject( &SeizeSerObj );
	if ( ulSerRes == cOCT6100_ERR_OK )
	{
		/* Call the serialized function. */
		ulFncRes = Oct6100ChannelOpenSer( f_pApiInstance, f_pChannelOpen );
	}
	else
	{
		return ulSerRes;
	}

	/* Release the seized semaphores. */
	ReleaseSerObj.ulSerialObjHndl = f_pApiInstance->ulApiSerObj;
	ulSerRes = Oct6100UserReleaseSerializeObject( &ReleaseSerObj );

	/* If an error occured then return the error code. */
	if ( ulSerRes != cOCT6100_ERR_OK )
		return ulSerRes;
	if ( ulFncRes != cOCT6100_ERR_OK )
		return ulFncRes;

	return cOCT6100_ERR_OK;
}


/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ChannelClose

Description:    This function closes an echo canceller channel

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.

f_pChannelClose			Pointer to channel close structure.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ChannelCloseDef(
				IN OUT tPOCT6100_CHANNEL_CLOSE		f_pChannelClose )
{
	f_pChannelClose->ulChannelHndl = cOCT6100_INVALID_HANDLE;
	
	return cOCT6100_ERR_OK;
}

UINT32 Oct6100ChannelClose(
				IN tPOCT6100_INSTANCE_API				f_pApiInstance,
				IN tPOCT6100_CHANNEL_CLOSE			f_pChannelClose )
{
	tOCT6100_SEIZE_SERIALIZE_OBJECT		SeizeSerObj;
	tOCT6100_RELEASE_SERIALIZE_OBJECT	ReleaseSerObj;
	UINT32								ulSerRes = cOCT6100_ERR_OK;
	UINT32								ulFncRes = cOCT6100_ERR_OK;

	/* Set the process context of the serialize structure.*/
	SeizeSerObj.pProcessContext = f_pApiInstance->pProcessContext;
	ReleaseSerObj.pProcessContext = f_pApiInstance->pProcessContext;

	/* Seize all list semaphores needed by this function. */
	SeizeSerObj.ulSerialObjHndl = f_pApiInstance->ulApiSerObj;
	SeizeSerObj.ulTryTimeMs = cOCT6100_WAIT_INFINITELY;

	ulSerRes = Oct6100UserSeizeSerializeObject( &SeizeSerObj );
	if ( ulSerRes == cOCT6100_ERR_OK )
	{
		/* Call the serialized function. */
		ulFncRes = Oct6100ChannelCloseSer( f_pApiInstance, f_pChannelClose );
	}
	else
	{
		return ulSerRes;
	}

	/* Release the seized semaphores. */
	ReleaseSerObj.ulSerialObjHndl = f_pApiInstance->ulApiSerObj;
	ulSerRes = Oct6100UserReleaseSerializeObject( &ReleaseSerObj );

	/* If an error occured then return the error code. */
	if ( ulSerRes != cOCT6100_ERR_OK )
		return ulSerRes;
	if ( ulFncRes != cOCT6100_ERR_OK )
		return ulFncRes;

	return cOCT6100_ERR_OK;
}


/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ChannelModify

Description:    This function will modify the parameter of an echo channel. If 
				the call to this channel allows the channel to go from power down
				to enable, the API will activate it.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance				Pointer to API instance. This memory is used to keep the
							present state of the chip and all its resources.

f_pChannelModify			Pointer to echo channel change structure.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ChannelModifyDef(
				IN OUT tPOCT6100_CHANNEL_MODIFY			f_pChannelModify )
{
	f_pChannelModify->ulChannelHndl = cOCT6100_INVALID_HANDLE;
	f_pChannelModify->ulUserChanId = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->ulEchoOperationMode = cOCT6100_KEEP_PREVIOUS_SETTING;
	
	f_pChannelModify->fEnableToneDisabler = cOCT6100_KEEP_PREVIOUS_SETTING;

	f_pChannelModify->fApplyToAllChannels = FALSE;




	f_pChannelModify->fTdmConfigModified = FALSE;
	f_pChannelModify->fVqeConfigModified = FALSE;


	/* VQE config. */
	f_pChannelModify->VqeConfig.fSinDcOffsetRemoval = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.fRinDcOffsetRemoval = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.fRinLevelControl = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.lRinLevelControlGainDb = (INT32)cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.fSoutLevelControl = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.lSoutLevelControlGainDb = (INT32)cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.fRinAutomaticLevelControl = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.lRinAutomaticLevelControlTargetDb = (INT32)cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.fSoutAutomaticLevelControl = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.lSoutAutomaticLevelControlTargetDb = (INT32)cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.fRinHighLevelCompensation = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.lRinHighLevelCompensationThresholdDb = (INT32)cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.fSoutAdaptiveNoiseReduction = cOCT6100_KEEP_PREVIOUS_SETTING;

	f_pChannelModify->VqeConfig.ulComfortNoiseMode = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.fEnableNlp = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.fEnableTailDisplacement = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.ulTailDisplacement = cOCT6100_KEEP_PREVIOUS_SETTING;

	f_pChannelModify->VqeConfig.fDtmfToneRemoval = cOCT6100_KEEP_PREVIOUS_SETTING;

	f_pChannelModify->VqeConfig.fAcousticEcho = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.lDefaultErlDb = (INT32)cOCT6100_KEEP_PREVIOUS_SETTING; 
	f_pChannelModify->VqeConfig.ulAecTailLength = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.lAecDefaultErlDb = (INT32)cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.ulNonLinearityBehaviorA = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.ulNonLinearityBehaviorB = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.ulDoubleTalkBehavior = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.ulSoutAutomaticListenerEnhancementGainDb = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.ulSoutNaturalListenerEnhancementGainDb = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.fSoutNaturalListenerEnhancement = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.fRoutNoiseReduction = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.lRoutNoiseReductionLevelGainDb = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.fEnablePlayout = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.lAnrSnrEnhancementDb = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.ulAnrVoiceNoiseSegregation = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.ulToneDisablerVqeActivationDelay = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.fEnableMusicProtection = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->VqeConfig.fIdleCodeDetection = cOCT6100_KEEP_PREVIOUS_SETTING;

	/* TDM config. */


	f_pChannelModify->TdmConfig.ulRinTimeslot = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->TdmConfig.ulRinStream = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->TdmConfig.ulRinPcmLaw = cOCT6100_KEEP_PREVIOUS_SETTING;

	f_pChannelModify->TdmConfig.ulSinTimeslot = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->TdmConfig.ulSinStream = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->TdmConfig.ulSinPcmLaw = cOCT6100_KEEP_PREVIOUS_SETTING;

	f_pChannelModify->TdmConfig.ulRoutTimeslot = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->TdmConfig.ulRoutStream = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->TdmConfig.ulRoutPcmLaw = cOCT6100_KEEP_PREVIOUS_SETTING;

	f_pChannelModify->TdmConfig.ulSoutTimeslot = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->TdmConfig.ulSoutStream = cOCT6100_KEEP_PREVIOUS_SETTING;
	f_pChannelModify->TdmConfig.ulSoutPcmLaw = cOCT6100_KEEP_PREVIOUS_SETTING;




	return cOCT6100_ERR_OK;
}

UINT32 Oct6100ChannelModify(
				IN tPOCT6100_INSTANCE_API		f_pApiInstance,
				IN OUT tPOCT6100_CHANNEL_MODIFY	f_pChannelModify )
{
	tOCT6100_SEIZE_SERIALIZE_OBJECT		SeizeSerObj;
	tOCT6100_RELEASE_SERIALIZE_OBJECT	ReleaseSerObj;
	UINT32								ulSerRes = cOCT6100_ERR_OK;
	UINT32								ulFncRes = cOCT6100_ERR_OK;

	/* Set the process context of the serialize structure.*/
	SeizeSerObj.pProcessContext = f_pApiInstance->pProcessContext;
	ReleaseSerObj.pProcessContext = f_pApiInstance->pProcessContext;

	/* Seize all list semaphores needed by this function. */
	SeizeSerObj.ulSerialObjHndl = f_pApiInstance->ulApiSerObj;
	SeizeSerObj.ulTryTimeMs = cOCT6100_WAIT_INFINITELY;
	ulSerRes = Oct6100UserSeizeSerializeObject( &SeizeSerObj );
	if ( ulSerRes == cOCT6100_ERR_OK )
	{
		/* Check the apply to all channels flag first. */
		if ( f_pChannelModify->fApplyToAllChannels != TRUE &&
			f_pChannelModify->fApplyToAllChannels != FALSE )
			return cOCT6100_ERR_CHANNEL_APPLY_TO_ALL_CHANNELS;

		/* Check if must apply modification to all channels. */
		if ( f_pChannelModify->fApplyToAllChannels == TRUE )
		{
			tPOCT6100_API_CHANNEL	pChanEntry;
			UINT16					usChanIndex;

			/* Loop through all channels and look for the opened ones. */
			for ( usChanIndex = 0; usChanIndex < f_pApiInstance->pSharedInfo->ChipConfig.usMaxChannels; usChanIndex++ )
			{
				mOCT6100_GET_CHANNEL_ENTRY_PNT( f_pApiInstance->pSharedInfo, pChanEntry, usChanIndex );

				/* Check if this one is opened. */
				if ( pChanEntry->fReserved == TRUE )
				{
					/* Channel is opened.  Form handle and call actual modify function. */
					f_pChannelModify->ulChannelHndl = cOCT6100_HNDL_TAG_CHANNEL | ( pChanEntry->byEntryOpenCnt << cOCT6100_ENTRY_OPEN_CNT_SHIFT ) | usChanIndex;

					/* Call the serialized function. */
					ulFncRes = Oct6100ChannelModifySer( f_pApiInstance, f_pChannelModify );
					if ( ulFncRes != cOCT6100_ERR_OK )
						break;
				}
			}
		}
		else /* if ( f_pChannelModify->fApplyToAllChannels == FALSE ) */
		{
			/* Call the serialized function. */
			ulFncRes = Oct6100ChannelModifySer( f_pApiInstance, f_pChannelModify );
		}
	}
	else
	{
		return ulSerRes;
	}

	/* Release the seized semaphores. */
	ReleaseSerObj.ulSerialObjHndl = f_pApiInstance->ulApiSerObj;
	ulSerRes = Oct6100UserReleaseSerializeObject( &ReleaseSerObj );

	/* If an error occured then return the error code. */
	if ( ulSerRes != cOCT6100_ERR_OK )
		return ulSerRes;
	if ( ulFncRes != cOCT6100_ERR_OK )
		return ulFncRes;

	return cOCT6100_ERR_OK;
}






/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ChannelGetStats

Description:    This function retrieves all the config and stats related to the channel
				designated by ulChannelHndl.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.

f_pChannelStats			Pointer to a tOCT6100_CHANNEL_STATS structure.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ChannelGetStatsDef(
				IN OUT tPOCT6100_CHANNEL_STATS			f_pChannelStats )
{
	f_pChannelStats->fResetStats = FALSE;

	f_pChannelStats->ulChannelHndl = cOCT6100_INVALID_HANDLE;
	f_pChannelStats->ulUserChanId = cOCT6100_INVALID_STAT;
	f_pChannelStats->ulEchoOperationMode = cOCT6100_INVALID_STAT;
	f_pChannelStats->fEnableToneDisabler = FALSE;
	f_pChannelStats->ulMutePortsMask = cOCT6100_CHANNEL_MUTE_PORT_NONE;


	/* VQE configuration.*/
	f_pChannelStats->VqeConfig.fEnableNlp = FALSE;
	f_pChannelStats->VqeConfig.fEnableTailDisplacement = FALSE;
	f_pChannelStats->VqeConfig.ulTailDisplacement = cOCT6100_INVALID_STAT;
	f_pChannelStats->VqeConfig.ulTailLength = cOCT6100_INVALID_STAT;

	f_pChannelStats->VqeConfig.fSinDcOffsetRemoval = FALSE;
	f_pChannelStats->VqeConfig.fRinDcOffsetRemoval = FALSE;
	f_pChannelStats->VqeConfig.fRinLevelControl = FALSE;
	f_pChannelStats->VqeConfig.fSoutLevelControl = FALSE;
	f_pChannelStats->VqeConfig.fRinAutomaticLevelControl = FALSE;
	f_pChannelStats->VqeConfig.fSoutAutomaticLevelControl = FALSE;
	f_pChannelStats->VqeConfig.fRinHighLevelCompensation = FALSE;
	f_pChannelStats->VqeConfig.fAcousticEcho = FALSE;
	f_pChannelStats->VqeConfig.fSoutAdaptiveNoiseReduction = FALSE;
	f_pChannelStats->VqeConfig.fDtmfToneRemoval = FALSE;


	
	f_pChannelStats->VqeConfig.ulComfortNoiseMode = cOCT6100_INVALID_STAT;
	f_pChannelStats->VqeConfig.ulNonLinearityBehaviorA = cOCT6100_INVALID_STAT;
	f_pChannelStats->VqeConfig.ulNonLinearityBehaviorB = cOCT6100_INVALID_STAT;
	f_pChannelStats->VqeConfig.ulDoubleTalkBehavior = cOCT6100_INVALID_STAT;
	f_pChannelStats->VqeConfig.lRinLevelControlGainDb = cOCT6100_INVALID_SIGNED_STAT;
	f_pChannelStats->VqeConfig.lSoutLevelControlGainDb = cOCT6100_INVALID_SIGNED_STAT;
	f_pChannelStats->VqeConfig.lRinAutomaticLevelControlTargetDb = cOCT6100_INVALID_SIGNED_STAT;
	f_pChannelStats->VqeConfig.lSoutAutomaticLevelControlTargetDb = cOCT6100_INVALID_SIGNED_STAT;
	f_pChannelStats->VqeConfig.lRinHighLevelCompensationThresholdDb = cOCT6100_INVALID_SIGNED_STAT;
	f_pChannelStats->VqeConfig.lDefaultErlDb = cOCT6100_INVALID_SIGNED_STAT;
	f_pChannelStats->VqeConfig.lAecDefaultErlDb = cOCT6100_INVALID_SIGNED_STAT;
	f_pChannelStats->VqeConfig.ulAecTailLength = cOCT6100_INVALID_STAT;
	f_pChannelStats->VqeConfig.ulSoutAutomaticListenerEnhancementGainDb = cOCT6100_INVALID_STAT;
	f_pChannelStats->VqeConfig.ulSoutNaturalListenerEnhancementGainDb = cOCT6100_INVALID_STAT;
	f_pChannelStats->VqeConfig.fSoutNaturalListenerEnhancement = FALSE;
	f_pChannelStats->VqeConfig.fRoutNoiseReduction = FALSE;
	f_pChannelStats->VqeConfig.lRoutNoiseReductionLevelGainDb = cOCT6100_INVALID_SIGNED_STAT;
	f_pChannelStats->VqeConfig.fEnablePlayout = TRUE;
	f_pChannelStats->VqeConfig.lAnrSnrEnhancementDb = cOCT6100_INVALID_SIGNED_STAT;
	f_pChannelStats->VqeConfig.ulAnrVoiceNoiseSegregation = cOCT6100_INVALID_STAT;
	f_pChannelStats->VqeConfig.ulToneDisablerVqeActivationDelay = cOCT6100_INVALID_STAT;
	f_pChannelStats->VqeConfig.fEnableMusicProtection = FALSE;
	f_pChannelStats->VqeConfig.fIdleCodeDetection = FALSE;



	/* TDM configuration.*/

	


	f_pChannelStats->TdmConfig.ulRinTimeslot = cOCT6100_INVALID_STAT;
	f_pChannelStats->TdmConfig.ulRinStream = cOCT6100_INVALID_STAT;
	f_pChannelStats->TdmConfig.ulRinPcmLaw = cOCT6100_INVALID_STAT;

	f_pChannelStats->TdmConfig.ulSinTimeslot = cOCT6100_INVALID_STAT;
	f_pChannelStats->TdmConfig.ulSinStream = cOCT6100_INVALID_STAT;
	f_pChannelStats->TdmConfig.ulSinPcmLaw = cOCT6100_INVALID_STAT;

	f_pChannelStats->TdmConfig.ulRoutTimeslot = cOCT6100_INVALID_STAT;
	f_pChannelStats->TdmConfig.ulRoutStream = cOCT6100_INVALID_STAT;
	f_pChannelStats->TdmConfig.ulRoutPcmLaw = cOCT6100_INVALID_STAT;
	

	
	f_pChannelStats->TdmConfig.ulSoutTimeslot = cOCT6100_INVALID_STAT;
	f_pChannelStats->TdmConfig.ulSoutStream = cOCT6100_INVALID_STAT;
	f_pChannelStats->TdmConfig.ulSoutPcmLaw = cOCT6100_INVALID_STAT;


	



	f_pChannelStats->ulNumEchoPathChanges = cOCT6100_INVALID_STAT;
	f_pChannelStats->ulToneDisablerStatus = cOCT6100_INVALID_STAT;
	f_pChannelStats->fEchoCancellerConverged = FALSE;
	f_pChannelStats->fSinVoiceDetected = FALSE;
	f_pChannelStats->lCurrentERL  = cOCT6100_INVALID_SIGNED_STAT;
	f_pChannelStats->lCurrentERLE = cOCT6100_INVALID_SIGNED_STAT;
	f_pChannelStats->ulCurrentEchoDelay = cOCT6100_INVALID_STAT;
	
	f_pChannelStats->lMaxERL  = cOCT6100_INVALID_SIGNED_STAT;
	f_pChannelStats->lMaxERLE = cOCT6100_INVALID_SIGNED_STAT;
	f_pChannelStats->ulMaxEchoDelay = cOCT6100_INVALID_STAT;
	
	f_pChannelStats->lRinLevel = cOCT6100_INVALID_SIGNED_STAT;
	f_pChannelStats->lSinLevel = cOCT6100_INVALID_SIGNED_STAT;
	f_pChannelStats->lRinAppliedGain = cOCT6100_INVALID_SIGNED_STAT;
	f_pChannelStats->lSoutAppliedGain = cOCT6100_INVALID_SIGNED_STAT;
	f_pChannelStats->lComfortNoiseLevel = cOCT6100_INVALID_SIGNED_STAT;
	


	return cOCT6100_ERR_OK;
}

UINT32 Oct6100ChannelGetStats(
				IN tPOCT6100_INSTANCE_API				f_pApiInstance,
				IN OUT tPOCT6100_CHANNEL_STATS			f_pChannelStats )
{
	tOCT6100_SEIZE_SERIALIZE_OBJECT		SeizeSerObj;
	tOCT6100_RELEASE_SERIALIZE_OBJECT	ReleaseSerObj;
	UINT32								ulSerRes = cOCT6100_ERR_OK;
	UINT32								ulFncRes = cOCT6100_ERR_OK;

	/* Set the process context of the serialize structure.*/
	SeizeSerObj.pProcessContext = f_pApiInstance->pProcessContext;
	ReleaseSerObj.pProcessContext = f_pApiInstance->pProcessContext;

	/* Seize all list semaphores needed by this function. */
	SeizeSerObj.ulSerialObjHndl = f_pApiInstance->ulApiSerObj;
	SeizeSerObj.ulTryTimeMs = cOCT6100_WAIT_INFINITELY;
	ulSerRes = Oct6100UserSeizeSerializeObject( &SeizeSerObj );
	if ( ulSerRes == cOCT6100_ERR_OK )
	{
		/* Call the serialized function. */
		ulFncRes = Oct6100ApiChannelGetStatsSer( f_pApiInstance, f_pChannelStats );
	}
	else
	{
		return ulSerRes;
	}

	/* Release the seized semaphores. */
	ReleaseSerObj.ulSerialObjHndl = f_pApiInstance->ulApiSerObj;
	ulSerRes = Oct6100UserReleaseSerializeObject( &ReleaseSerObj );

	/* If an error occured then return the error code. */
	if ( ulSerRes != cOCT6100_ERR_OK )
		return ulSerRes;
	if ( ulFncRes != cOCT6100_ERR_OK )
		return ulFncRes;

	return cOCT6100_ERR_OK;
}


/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ChannelMute

Description:    This function mutes some or all of the ports designated by 
				ulChannelHndl.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.

f_pChannelMute			Pointer to a tPOCT6100_CHANNEL_MUTE structure.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ChannelMuteDef(
				IN OUT tPOCT6100_CHANNEL_MUTE			f_pChannelMute )
{
	f_pChannelMute->ulChannelHndl = cOCT6100_INVALID_HANDLE;
	f_pChannelMute->ulPortMask = cOCT6100_CHANNEL_MUTE_PORT_NONE;

	return cOCT6100_ERR_OK;
}

UINT32 Oct6100ChannelMute(
				IN tPOCT6100_INSTANCE_API				f_pApiInstance,
				IN OUT tPOCT6100_CHANNEL_MUTE			f_pChannelMute )
{
	tOCT6100_SEIZE_SERIALIZE_OBJECT		SeizeSerObj;
	tOCT6100_RELEASE_SERIALIZE_OBJECT	ReleaseSerObj;
	UINT32								ulSerRes = cOCT6100_ERR_OK;
	UINT32								ulFncRes = cOCT6100_ERR_OK;

	/* Set the process context of the serialize structure.*/
	SeizeSerObj.pProcessContext = f_pApiInstance->pProcessContext;
	ReleaseSerObj.pProcessContext = f_pApiInstance->pProcessContext;

	/* Seize all list semaphores needed by this function. */
	SeizeSerObj.ulSerialObjHndl = f_pApiInstance->ulApiSerObj;
	SeizeSerObj.ulTryTimeMs = cOCT6100_WAIT_INFINITELY;
	ulSerRes = Oct6100UserSeizeSerializeObject( &SeizeSerObj );
	if ( ulSerRes == cOCT6100_ERR_OK )
	{
		/* Call the serialized function. */
		ulFncRes = Oct6100ChannelMuteSer( f_pApiInstance, f_pChannelMute );
	}
	else
	{
		return ulSerRes;
	}

	/* Release the seized semaphores. */
	ReleaseSerObj.ulSerialObjHndl = f_pApiInstance->ulApiSerObj;
	ulSerRes = Oct6100UserReleaseSerializeObject( &ReleaseSerObj );

	/* If an error occured then return the error code. */
	if ( ulSerRes != cOCT6100_ERR_OK )
		return ulSerRes;
	if ( ulFncRes != cOCT6100_ERR_OK )
		return ulFncRes;

	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ChannelUnMute

Description:    This function unmutes some or all of the ports designated by 
				ulChannelHndl.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.

f_pChannelUnMute		Pointer to a tPOCT6100_CHANNEL_UNMUTE structure.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ChannelUnMuteDef(
				IN OUT tPOCT6100_CHANNEL_UNMUTE			f_pChannelUnMute )
{
	f_pChannelUnMute->ulChannelHndl = cOCT6100_INVALID_HANDLE;
	f_pChannelUnMute->ulPortMask = cOCT6100_CHANNEL_MUTE_PORT_NONE;

	return cOCT6100_ERR_OK;
}

UINT32 Oct6100ChannelUnMute(
				IN tPOCT6100_INSTANCE_API				f_pApiInstance,
				IN OUT tPOCT6100_CHANNEL_UNMUTE			f_pChannelUnMute )
{
	tOCT6100_SEIZE_SERIALIZE_OBJECT		SeizeSerObj;
	tOCT6100_RELEASE_SERIALIZE_OBJECT	ReleaseSerObj;
	UINT32								ulSerRes = cOCT6100_ERR_OK;
	UINT32								ulFncRes = cOCT6100_ERR_OK;

	/* Set the process context of the serialize structure.*/
	SeizeSerObj.pProcessContext = f_pApiInstance->pProcessContext;
	ReleaseSerObj.pProcessContext = f_pApiInstance->pProcessContext;

	/* Seize all list semaphores needed by this function. */
	SeizeSerObj.ulSerialObjHndl = f_pApiInstance->ulApiSerObj;
	SeizeSerObj.ulTryTimeMs = cOCT6100_WAIT_INFINITELY;
	ulSerRes = Oct6100UserSeizeSerializeObject( &SeizeSerObj );
	if ( ulSerRes == cOCT6100_ERR_OK )
	{
		/* Call the serialized function. */
		ulFncRes = Oct6100ChannelUnMuteSer( f_pApiInstance, f_pChannelUnMute );
	}
	else
	{
		return ulSerRes;
	}

	/* Release the seized semaphores. */
	ReleaseSerObj.ulSerialObjHndl = f_pApiInstance->ulApiSerObj;
	ulSerRes = Oct6100UserReleaseSerializeObject( &ReleaseSerObj );

	/* If an error occured then return the error code. */
	if ( ulSerRes != cOCT6100_ERR_OK )
		return ulSerRes;
	if ( ulFncRes != cOCT6100_ERR_OK )
		return ulFncRes;

	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiEnableChannelRecording

Description:    Enable the recording channel

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.

f_pChannelRecord		Pointer to a tOCT6100_ENABLE_CHANNEL_RECORDING structure.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiEnableChannelRecordingDef(
				IN OUT tPOCT6100_ENABLE_CHANNEL_RECORDING	f_pChannelRecord )
{
	f_pChannelRecord->pulChannelHndlConflict = NULL;
	return cOCT6100_ERR_OK;
}

UINT32 Oct6100ApiEnableChannelRecording(
				IN tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT tPOCT6100_ENABLE_CHANNEL_RECORDING	f_pChannelRecord )
{
	tOCT6100_SEIZE_SERIALIZE_OBJECT		SeizeSerObj;
	tOCT6100_RELEASE_SERIALIZE_OBJECT	ReleaseSerObj;
	UINT32								ulSerRes = cOCT6100_ERR_OK;
	UINT32								ulFncRes = cOCT6100_ERR_OK;

	/* Set the process context of the serialize structure.*/
	SeizeSerObj.pProcessContext = f_pApiInstance->pProcessContext;
	ReleaseSerObj.pProcessContext = f_pApiInstance->pProcessContext;

	/* Seize all list semaphores needed by this function. */
	SeizeSerObj.ulSerialObjHndl = f_pApiInstance->ulApiSerObj;
	SeizeSerObj.ulTryTimeMs = cOCT6100_WAIT_INFINITELY;
	ulSerRes = Oct6100UserSeizeSerializeObject( &SeizeSerObj );
	if ( ulSerRes == cOCT6100_ERR_OK )
	{
		/* Call the serialized function. */
		ulFncRes = Oct6100ApiEnableChannelRecordingSer( f_pApiInstance, f_pChannelRecord );
	}
	else
	{
		return ulSerRes;
	}

	/* Release the seized semaphores. */
	ReleaseSerObj.ulSerialObjHndl = f_pApiInstance->ulApiSerObj;
	ulSerRes = Oct6100UserReleaseSerializeObject( &ReleaseSerObj );

	/* If an error occured then return the error code. */
	if ( ulSerRes != cOCT6100_ERR_OK )
		return ulSerRes;
	if ( ulFncRes != cOCT6100_ERR_OK )
		return ulFncRes;

	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiDisableChannelRecording

Description:    Disables the recording channel

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.

f_pChannelRecord		Pointer to a tOCT6100_DISABLE_CHANNEL_RECORDING structure.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiDisableChannelRecordingDef(
				IN OUT tPOCT6100_DISABLE_CHANNEL_RECORDING	f_pChannelRecord )
{
	f_pChannelRecord->ulUnused = 0;
	return cOCT6100_ERR_OK;
}

UINT32 Oct6100ApiDisableChannelRecording(
				IN tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT tPOCT6100_DISABLE_CHANNEL_RECORDING	f_pChannelRecord )
{
	tOCT6100_SEIZE_SERIALIZE_OBJECT		SeizeSerObj;
	tOCT6100_RELEASE_SERIALIZE_OBJECT	ReleaseSerObj;
	UINT32								ulSerRes = cOCT6100_ERR_OK;
	UINT32								ulFncRes = cOCT6100_ERR_OK;

	/* Set the process context of the serialize structure.*/
	SeizeSerObj.pProcessContext = f_pApiInstance->pProcessContext;
	ReleaseSerObj.pProcessContext = f_pApiInstance->pProcessContext;

	/* Seize all list semaphores needed by this function. */
	SeizeSerObj.ulSerialObjHndl = f_pApiInstance->ulApiSerObj;
	SeizeSerObj.ulTryTimeMs = cOCT6100_WAIT_INFINITELY;
	ulSerRes = Oct6100UserSeizeSerializeObject( &SeizeSerObj );
	if ( ulSerRes == cOCT6100_ERR_OK )
	{
		/* Call the serialized function. */
		ulFncRes = Oct6100ApiDisableChannelRecordingSer( f_pApiInstance, f_pChannelRecord );
	}
	else
	{
		return ulSerRes;
	}

	/* Release the seized semaphores. */
	ReleaseSerObj.ulSerialObjHndl = f_pApiInstance->ulApiSerObj;
	ulSerRes = Oct6100UserReleaseSerializeObject( &ReleaseSerObj );

	/* If an error occured then return the error code. */
	if ( ulSerRes != cOCT6100_ERR_OK )
		return ulSerRes;
	if ( ulFncRes != cOCT6100_ERR_OK )
		return ulFncRes;

	return cOCT6100_ERR_OK;
}

/****************************  PRIVATE FUNCTIONS  ****************************/

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiGetChannelsEchoSwSizes

Description:    Gets the sizes of all portions of the API instance pertinent
				to the management of the ECHO memory.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pOpenChip				Pointer to chip configuration struct.
f_pInstSizes			Pointer to struct containing instance sizes.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiGetChannelsEchoSwSizes(
				IN	tPOCT6100_CHIP_OPEN				f_pOpenChip,
				OUT	tPOCT6100_API_INSTANCE_SIZES	f_pInstSizes )
{
	UINT32	ulTempVar;
	UINT32	ulResult;
	UINT32	ulMaxChannels;

	ulMaxChannels = f_pOpenChip->ulMaxChannels;

	if ( f_pOpenChip->fEnableChannelRecording == TRUE && ulMaxChannels != 672 )
		ulMaxChannels++;

	/* Determine the amount of memory required for the API echo channel list.*/
	f_pInstSizes->ulChannelList			= ulMaxChannels * sizeof( tOCT6100_API_CHANNEL );	/* Add one for the record channel.*/

	if ( ulMaxChannels > 0 )
	{
		/* Calculate memory needed for ECHO memory allocation */
		ulResult = OctapiLlmAllocGetSize( ulMaxChannels, &f_pInstSizes->ulChannelAlloc );
		if ( ulResult != cOCT6100_ERR_OK  )
			return cOCT6100_ERR_FATAL_0;
	}
	else
	{
		f_pInstSizes->ulChannelAlloc = 0;
	}


	mOCT6100_ROUND_MEMORY_SIZE( f_pInstSizes->ulChannelList, ulTempVar )
	mOCT6100_ROUND_MEMORY_SIZE( f_pInstSizes->ulChannelAlloc, ulTempVar )

	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiChannelsEchoSwInit

Description:    Initializes all elements of the instance structure associated
				to the ECHO memory.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiChannelsEchoSwInit(
				IN tPOCT6100_INSTANCE_API			f_pApiInstance )
{
	tPOCT6100_API_CHANNEL			pChannelsEchoList;

	tPOCT6100_SHARED_INFO			pSharedInfo;
	UINT16	usMaxChannels;
	PVOID	pEchoChanAlloc;

	UINT32	ulResult;

	/* Get local pointer to shared portion of the API instance. */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	/* Initialize the ECHO channel API list.*/
	usMaxChannels = pSharedInfo->ChipConfig.usMaxChannels;

	/* Add a channel to initialize if the recording is activated. */
	if ( pSharedInfo->ChipConfig.fEnableChannelRecording == TRUE )
		usMaxChannels++;

	/* Set all entries in the ADCPM channel list to unused. */
	mOCT6100_GET_CHANNEL_LIST_PNT( pSharedInfo, pChannelsEchoList );
	
	/* Initialize the API ECHO channels allocation software to "all free". */
	if ( usMaxChannels > 0 )
	{
		/* Clear the memory */
		Oct6100UserMemSet( pChannelsEchoList, 0x00, sizeof(tOCT6100_API_CHANNEL) * usMaxChannels );

		mOCT6100_GET_CHANNEL_ALLOC_PNT( pSharedInfo, pEchoChanAlloc )
		
		ulResult = OctapiLlmAllocInit( &pEchoChanAlloc, usMaxChannels );
		if ( ulResult != cOCT6100_ERR_OK  )
			return cOCT6100_ERR_FATAL_1;
	}



	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ChannelOpenSer

Description:    Opens a echo cancellation channel.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.

f_pChannelOpen			Pointer to channel configuration structure.  Then handle
						identifying the buffer in all future function calls is
						returned in this structure.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ChannelOpenSer(
				IN tPOCT6100_INSTANCE_API			f_pApiInstance,
				IN OUT tPOCT6100_CHANNEL_OPEN		f_pChannelOpen )
{
	tOCT6100_API_ECHO_CHAN_INDEX		ChannelIndexConf;
	UINT32	ulResult;

	/* Check the user's configuration of the echo cancellation channel for errors. */
	ulResult = Oct6100ApiCheckChannelParams( f_pApiInstance, f_pChannelOpen, &ChannelIndexConf );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/* Reserve all resources needed by the echo cancellation channel. */
	ulResult = Oct6100ApiReserveChannelResources( f_pApiInstance, f_pChannelOpen, &ChannelIndexConf );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/* Write all necessary structures to activate the echo cancellation channel. */
	ulResult = Oct6100ApiWriteChannelStructs( f_pApiInstance, f_pChannelOpen, &ChannelIndexConf );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/* Update the new echo cancellation channels's entry in the ECHO channel list. */
	ulResult = Oct6100ApiUpdateChannelEntry( f_pApiInstance, f_pChannelOpen, &ChannelIndexConf );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiCheckChannelParams

Description:    Checks the user's echo cancellation channel open configuration for errors.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.

f_pChannelOpen			Pointer to echo cancellation channel open configuration structure.
f_pChanIndexConf		Pointer to a structure used to store the multiple resources indexes.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiCheckChannelParams(
				IN tPOCT6100_INSTANCE_API				f_pApiInstance,
				IN tPOCT6100_CHANNEL_OPEN				f_pChannelOpen,
				OUT tPOCT6100_API_ECHO_CHAN_INDEX		f_pChanIndexConf )
{
	tPOCT6100_CHANNEL_OPEN_TDM		pTdmConfig;
	tPOCT6100_CHANNEL_OPEN_VQE		pVqeConfig;

	UINT32	ulResult;

	/* Dereference the configuration structure for clearer code and faster access.*/
	pTdmConfig	 = &f_pChannelOpen->TdmConfig;
	pVqeConfig	 = &f_pChannelOpen->VqeConfig;


	/* Check for errors. */
	if ( f_pApiInstance->pSharedInfo->ChipConfig.usMaxChannels == 0 )
		return cOCT6100_ERR_CHANNEL_DISABLED;

	if ( f_pChannelOpen->pulChannelHndl == NULL )
		return cOCT6100_ERR_CHANNEL_INVALID_HANDLE;

	if ( f_pChannelOpen->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_NORMAL &&
		 f_pChannelOpen->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_HT_FREEZE &&
		 f_pChannelOpen->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_HT_RESET &&
		 f_pChannelOpen->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_POWER_DOWN &&
		 f_pChannelOpen->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_EXTERNAL &&
		 f_pChannelOpen->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_SPEECH_RECOGNITION &&
		 f_pChannelOpen->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_NO_ECHO )
		return cOCT6100_ERR_CHANNEL_ECHO_OP_MODE;

	/* Check the 2100Hz echo disabling configuration.*/
	if ( f_pChannelOpen->fEnableToneDisabler != TRUE && 
		 f_pChannelOpen->fEnableToneDisabler != FALSE  )
		return cOCT6100_ERR_CHANNEL_TONE_DISABLER_ENABLE;
	




	/*==============================================================================*/
	/* Check the TDM configuration parameters.*/

	ulResult = Oct6100ApiCheckTdmConfig( f_pApiInstance, pTdmConfig );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	/*==============================================================================*/


	/*==============================================================================*/
	/* Now validate the VQE parameters */

	ulResult = Oct6100ApiCheckVqeConfig( f_pApiInstance, pVqeConfig, f_pChannelOpen->fEnableToneDisabler );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	/* Verify if the echo operation mode selected can be applied. */
	if ( ( f_pChannelOpen->ulEchoOperationMode == cOCT6100_ECHO_OP_MODE_NO_ECHO )
		&& ( pVqeConfig->fEnableNlp == FALSE ) )
		return cOCT6100_ERR_CHANNEL_ECHO_OP_MODE_NLP_REQUIRED;
	
	if ( ( f_pChannelOpen->ulEchoOperationMode == cOCT6100_ECHO_OP_MODE_SPEECH_RECOGNITION )
		&& ( pVqeConfig->fEnableNlp == FALSE ) )
		return cOCT6100_ERR_CHANNEL_ECHO_OP_MODE_NLP_REQUIRED;

	/* Comfort noise must be activated for speech recognition mode to work. */
	if ( ( f_pChannelOpen->ulEchoOperationMode == cOCT6100_ECHO_OP_MODE_SPEECH_RECOGNITION )
		&& ( pVqeConfig->ulComfortNoiseMode == cOCT6100_COMFORT_NOISE_OFF ) )
		return cOCT6100_ERR_CHANNEL_COMFORT_NOISE_REQUIRED;

	/*==============================================================================*/



	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiReserveChannelResources

Description:    Reserves all resources needed for the new channel.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.
	
f_pChannelOpen			Pointer to echo cancellation channel configuration structure.
f_pulChannelIndex		Allocated entry in ECHO channel list.
f_pChanIndexConf		Pointer to a structure used to store the multiple resources indexes.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiReserveChannelResources(	
				IN  tPOCT6100_INSTANCE_API				f_pApiInstance,
				IN  tPOCT6100_CHANNEL_OPEN				f_pChannelOpen,
				OUT tPOCT6100_API_ECHO_CHAN_INDEX		f_pChanIndexConf )
{
	tPOCT6100_SHARED_INFO			pSharedInfo;
	tPOCT6100_CHANNEL_OPEN_TDM		pTdmConfig;


	UINT32	ulResult;
	UINT32	ulTempVar;
	UINT32	ulFreeMixerEventCnt;

	BOOL	fRinTsstEntry = FALSE;
	BOOL	fSinTsstEntry = FALSE;
	BOOL	fRoutTsstEntry = FALSE;
	BOOL	fSoutTsstEntry = FALSE;

	BOOL	fRinRoutTsiMemEntry = FALSE;
	BOOL	fSinSoutTsiMemEntry = FALSE;

	BOOL	fEchoChanEntry = FALSE;

	PUINT16	pusRinRoutConversionMemIndex = NULL;
	PUINT16	pusSinSoutConversionMemIndex = NULL;
	BOOL	fRinRoutConversionMemEntry = FALSE;
	BOOL	fSinSoutConversionMemEntry = FALSE;


	
	/* Obtain local pointer to shared portion of instance. */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	/* Obtain a local pointer to the configuration structures.*/
	pTdmConfig		= &f_pChannelOpen->TdmConfig;


	/*===============================================================================*/
	/* Reserve Echo and TSI entries. */

	ulResult = Oct6100ApiReserveEchoEntry( f_pApiInstance, 
										   &f_pChanIndexConf->usEchoChanIndex );
	if ( ulResult == cOCT6100_ERR_OK )
	{
		fEchoChanEntry = TRUE;

		/* Set the echo, encoder and decoder memory indexes.*/
		f_pChanIndexConf->usEchoMemIndex = f_pChanIndexConf->usEchoChanIndex;
		
		/* Reserve an entry for the RIN/ROUT tsi chariot memory. */
		ulResult = Oct6100ApiReserveTsiMemEntry( f_pApiInstance, 
												 &f_pChanIndexConf->usRinRoutTsiMemIndex );
		if ( ulResult == cOCT6100_ERR_OK )
		{
			fRinRoutTsiMemEntry = TRUE;

			/* Reserve an entry for the SIN/SOUT tsi chariot memory. */
			ulResult = Oct6100ApiReserveTsiMemEntry( f_pApiInstance, 
													 &f_pChanIndexConf->usSinSoutTsiMemIndex );
			if ( ulResult == cOCT6100_ERR_OK )
			{
				fSinSoutTsiMemEntry = TRUE;

				
				/* Reserve a conversion memory block if law conversion is required. */
				if ( pTdmConfig->ulRinPcmLaw != pTdmConfig->ulRoutPcmLaw )
				{
					pusRinRoutConversionMemIndex = &f_pChanIndexConf->usRinRoutConversionMemIndex;
				}

				if ( pTdmConfig->ulSinPcmLaw != pTdmConfig->ulSoutPcmLaw )
				{
					pusSinSoutConversionMemIndex = &f_pChanIndexConf->usSinSoutConversionMemIndex;
				}

				/* Reserve the conversion memories. */
				if ( pusRinRoutConversionMemIndex != NULL )
				{
					/* Reserve a conversion memory for the Rin/Rout stream. */
					ulResult = Oct6100ApiReserveConversionMemEntry( f_pApiInstance, 
																	pusRinRoutConversionMemIndex );
					if ( ulResult == cOCT6100_ERR_OK )
					{
						fRinRoutConversionMemEntry = TRUE;
					}
				}
				else
				{
					/* No conversion memory reserved.*/
					f_pChanIndexConf->usRinRoutConversionMemIndex = cOCT6100_INVALID_INDEX;
				}

				if ( ( pusSinSoutConversionMemIndex != NULL ) && 
					 ( ulResult == cOCT6100_ERR_OK ) )
				{
					/* Reserve a conversion memory for the Sin/Sout stream. */
					ulResult = Oct6100ApiReserveConversionMemEntry( f_pApiInstance, 
																	pusSinSoutConversionMemIndex );
					if ( ulResult == cOCT6100_ERR_OK )
					{
						fSinSoutConversionMemEntry = TRUE;
					}
				}
				else
				{
					/* No conversion memory reserved.*/
					f_pChanIndexConf->usSinSoutConversionMemIndex = cOCT6100_INVALID_INDEX;
				}


			}
			else
			{
				/* Return an error other then a Fatal.*/
				ulResult = cOCT6100_ERR_CHANNEL_OUT_OF_TSI_MEMORY;
			}
		}
		else
		{
			/* Return an error other then a Fatal.*/
			ulResult = cOCT6100_ERR_CHANNEL_OUT_OF_TSI_MEMORY;
		}
	}

	/*===============================================================================*/

	/*===============================================================================*/
	/* Now reserve the TSST entries if required.*/

	/* Reserve the Rin TSST entry */	
	if ( (ulResult == cOCT6100_ERR_OK ) &&
		 (pTdmConfig->ulRinTimeslot != cOCT6100_UNASSIGNED && 
		  pTdmConfig->ulRinStream != cOCT6100_UNASSIGNED) )
	{
		ulResult = Oct6100ApiReserveTsst( f_pApiInstance, 
										  pTdmConfig->ulRinTimeslot, 
										  pTdmConfig->ulRinStream, 

										  cOCT6100_INPUT_TSST,
										  &f_pChanIndexConf->usRinTsstIndex, 
										  NULL );
		if ( ulResult == cOCT6100_ERR_OK )
			fRinTsstEntry = TRUE;
	}
	else
	{
		f_pChanIndexConf->usRinTsstIndex = cOCT6100_INVALID_INDEX;
	}

		
	if ( (ulResult == cOCT6100_ERR_OK ) &&
		 (pTdmConfig->ulSinTimeslot != cOCT6100_UNASSIGNED && 
		  pTdmConfig->ulSinStream != cOCT6100_UNASSIGNED) )
	{
		/* Reserve the Sin TSST entry.*/
		ulResult = Oct6100ApiReserveTsst( f_pApiInstance, 
										  pTdmConfig->ulSinTimeslot, 
										  pTdmConfig->ulSinStream, 

										  cOCT6100_INPUT_TSST,
										  &f_pChanIndexConf->usSinTsstIndex, 
										  NULL );
		if ( ulResult == cOCT6100_ERR_OK )
			fSinTsstEntry = TRUE;
	}
	else 
	{
		f_pChanIndexConf->usSinTsstIndex = cOCT6100_INVALID_INDEX;
	}

	if ( (ulResult == cOCT6100_ERR_OK ) &&
		 (pTdmConfig->ulRoutTimeslot != cOCT6100_UNASSIGNED && 
		  pTdmConfig->ulRoutStream != cOCT6100_UNASSIGNED) )
	{
		/* Reserve the Rout TSST entry.*/
		ulResult = Oct6100ApiReserveTsst( f_pApiInstance, 
										  pTdmConfig->ulRoutTimeslot, 
										  pTdmConfig->ulRoutStream, 

										  cOCT6100_OUTPUT_TSST,
										  &f_pChanIndexConf->usRoutTsstIndex, 
										  NULL );
		if ( ulResult == cOCT6100_ERR_OK )
			fRoutTsstEntry = TRUE;
	}
	else
	{
		f_pChanIndexConf->usRoutTsstIndex = cOCT6100_INVALID_INDEX;
	}

				
	if ( (ulResult == cOCT6100_ERR_OK ) &&
		 (pTdmConfig->ulSoutTimeslot != cOCT6100_UNASSIGNED && 
		  pTdmConfig->ulSoutStream != cOCT6100_UNASSIGNED) )
	{
		/* Reserve the Sout TSST entry.*/
		ulResult = Oct6100ApiReserveTsst( f_pApiInstance, 
										  pTdmConfig->ulSoutTimeslot, 
										  pTdmConfig->ulSoutStream, 

										  cOCT6100_OUTPUT_TSST,
										  &f_pChanIndexConf->usSoutTsstIndex, 
										  NULL );
		if ( ulResult == cOCT6100_ERR_OK )
			fSoutTsstEntry = TRUE;
	}
	else 
	{
		f_pChanIndexConf->usSoutTsstIndex = cOCT6100_INVALID_INDEX;
	}

	/*===============================================================================*/
	

	/*===============================================================================*/
	/* Check if there are a couple of mixer events available for us. */

	if ( ulResult == cOCT6100_ERR_OK )
	{
		UINT32 ulMixerEventCntNeeded = 0;

		/* Calculate how many mixer events are needed. */
		if ( f_pChanIndexConf->usRinTsstIndex == cOCT6100_INVALID_INDEX )
			ulMixerEventCntNeeded++;

		if ( f_pChanIndexConf->usSinTsstIndex == cOCT6100_INVALID_INDEX )
			ulMixerEventCntNeeded++;

		/* If at least 1 mixer event is needed, check if those are available. */
		if ( ulMixerEventCntNeeded != 0 )
		{
			ulResult = Oct6100ApiGetFreeMixerEventCnt( f_pApiInstance, &ulFreeMixerEventCnt );
			if ( ulResult == cOCT6100_ERR_OK )
			{
				/* The API might need more mixer events if the ports have to be muted. */
				/* Check if these are available. */
				if ( ulFreeMixerEventCnt < ulMixerEventCntNeeded )
				{
					ulResult = cOCT6100_ERR_CHANNEL_OUT_OF_MIXER_EVENTS;
				}
			}
		}
	}

	/*===============================================================================*/


	/*===============================================================================*/
	/* Release the resources if something went wrong */		
	if ( ulResult != cOCT6100_ERR_OK  )
	{
		/*===============================================================================*/
		/* Release the previously reserved resources .*/
		if( fRinTsstEntry == TRUE )
		{
			ulTempVar = Oct6100ApiReleaseTsst( f_pApiInstance,  
											   pTdmConfig->ulRinTimeslot,
											   pTdmConfig->ulRinStream,

											   cOCT6100_INPUT_TSST,
											   cOCT6100_INVALID_INDEX );
			if ( ulTempVar != cOCT6100_ERR_OK )
				return ulTempVar;
		}

		if( fSinTsstEntry == TRUE )
		{
			ulTempVar = Oct6100ApiReleaseTsst( f_pApiInstance,  
											   pTdmConfig->ulSinTimeslot,
											   pTdmConfig->ulSinStream,

											   cOCT6100_INPUT_TSST,
											   cOCT6100_INVALID_INDEX );
			if ( ulTempVar != cOCT6100_ERR_OK )
				return ulTempVar;
		}

		if( fRoutTsstEntry == TRUE )
		{
			ulTempVar = Oct6100ApiReleaseTsst( f_pApiInstance,  
											   pTdmConfig->ulRoutTimeslot,
											   pTdmConfig->ulRoutStream,

											   cOCT6100_OUTPUT_TSST,
											   cOCT6100_INVALID_INDEX );
			if ( ulTempVar != cOCT6100_ERR_OK )
				return ulTempVar;
		}

		if( fSoutTsstEntry == TRUE )
		{
			ulTempVar = Oct6100ApiReleaseTsst( f_pApiInstance, 
											   pTdmConfig->ulSoutTimeslot,
											   pTdmConfig->ulSoutStream,

											   cOCT6100_OUTPUT_TSST,
											   cOCT6100_INVALID_INDEX );
			if ( ulTempVar != cOCT6100_ERR_OK )
				return ulTempVar;
		}

		if( fRinRoutTsiMemEntry == TRUE )
		{
			ulTempVar = Oct6100ApiReleaseTsiMemEntry( f_pApiInstance, 
													  f_pChanIndexConf->usRinRoutTsiMemIndex );
			if ( ulTempVar != cOCT6100_ERR_OK )
				return ulTempVar;
		}

		if( fSinSoutTsiMemEntry == TRUE )
		{
			ulTempVar = Oct6100ApiReleaseTsiMemEntry( f_pApiInstance, 
													  f_pChanIndexConf->usSinSoutTsiMemIndex );
			if ( ulTempVar != cOCT6100_ERR_OK )
				return ulTempVar;
		}

		/*===============================================================================*/

		/*===============================================================================*/
		/* Release the previously reserved echo resources .*/
		if( fEchoChanEntry == TRUE )
		{
			ulTempVar = Oct6100ApiReleaseEchoEntry( f_pApiInstance, 
													f_pChanIndexConf->usEchoChanIndex );
			if ( ulTempVar != cOCT6100_ERR_OK )
				return ulTempVar;
		}

		/*===============================================================================*/
	


		/*===============================================================================*/
		/* Release the conversion resources. */
		if( fRinRoutConversionMemEntry == TRUE )
		{
			ulTempVar = Oct6100ApiReleaseConversionMemEntry( f_pApiInstance, 
															f_pChanIndexConf->usRinRoutConversionMemIndex );
			if ( ulTempVar != cOCT6100_ERR_OK )
				return ulTempVar;
		}

		if( fSinSoutConversionMemEntry == TRUE )
		{
			ulTempVar = Oct6100ApiReleaseConversionMemEntry( f_pApiInstance, 
															f_pChanIndexConf->usSinSoutConversionMemIndex );
			if ( ulTempVar != cOCT6100_ERR_OK )
				return ulTempVar;
		}

		/*===============================================================================*/
		
		return ulResult;
	}

	return cOCT6100_ERR_OK;
}


/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiWriteChannelStructs

Description:    Performs all the required structure writes to configure the
				new echo cancellation channel.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.
	
f_pChannelOpen			Pointer to echo cancellation channel configuration structure.
f_pChanIndexConf		Pointer to a structure used to store the multiple resources indexes.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiWriteChannelStructs(
				IN tPOCT6100_INSTANCE_API			f_pApiInstance,
				IN tPOCT6100_CHANNEL_OPEN			f_pChannelOpen,
				OUT tPOCT6100_API_ECHO_CHAN_INDEX	f_pChanIndexConf )
{
	tPOCT6100_SHARED_INFO			pSharedInfo;
	tPOCT6100_CHANNEL_OPEN_TDM		pTdmConfig;
	tOCT6100_WRITE_PARAMS			WriteParams;
	tPOCT6100_API_CHANNEL			pChanEntry;
	UINT32	ulResult;
	UINT32	ulDwordAddress;
	UINT32	ulDwordData;



	/* Obtain local pointer to shared portion of instance. */
	pSharedInfo = f_pApiInstance->pSharedInfo;
	
	/* Obtain a local pointer to the TDM configuration structure.*/
	pTdmConfig = &f_pChannelOpen->TdmConfig;

	WriteParams.pProcessContext = f_pApiInstance->pProcessContext;

	WriteParams.ulUserChipId = pSharedInfo->ChipConfig.ulUserChipId;

	mOCT6100_GET_CHANNEL_ENTRY_PNT( f_pApiInstance->pSharedInfo, pChanEntry, f_pChanIndexConf->usEchoChanIndex );

	/*==============================================================================*/
	/* Configure the Input Tsst control memory.*/
	
	/* Set the RIN Tsst control entry.*/
	if ( f_pChanIndexConf->usRinTsstIndex != cOCT6100_INVALID_INDEX )
	{
		ulResult = Oct6100ApiWriteInputTsstControlMemory( f_pApiInstance,
														  f_pChanIndexConf->usRinTsstIndex,
														  f_pChanIndexConf->usRinRoutTsiMemIndex,
														  pTdmConfig->ulRinPcmLaw );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;
	}

	/* Set the SIN Tsst control entry.*/
	if ( f_pChanIndexConf->usSinTsstIndex != cOCT6100_INVALID_INDEX )
	{
		ulResult = Oct6100ApiWriteInputTsstControlMemory( f_pApiInstance,
														  f_pChanIndexConf->usSinTsstIndex,
														  f_pChanIndexConf->usSinSoutTsiMemIndex,
														  pTdmConfig->ulSinPcmLaw );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;
	}

	/*==============================================================================*/


	/*==============================================================================*/
	/* Configure the conversion control memory if law conversion is required. */

	if( f_pChanIndexConf->usRinRoutConversionMemIndex != cOCT6100_INVALID_INDEX )
	{
		ulResult = Oct6100ApiWriteLawConversionMemory( 
												f_pApiInstance,
												f_pChanIndexConf->usRinRoutConversionMemIndex,
												f_pChanIndexConf->usRinRoutTsiMemIndex,
												f_pChannelOpen->TdmConfig.ulRoutPcmLaw,
												TRUE );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;
	}

	if( f_pChanIndexConf->usSinSoutConversionMemIndex != cOCT6100_INVALID_INDEX )
	{
		ulResult = Oct6100ApiWriteLawConversionMemory( 
												f_pApiInstance,
												f_pChanIndexConf->usSinSoutConversionMemIndex,
												f_pChanIndexConf->usSinSoutTsiMemIndex,
												f_pChannelOpen->TdmConfig.ulSoutPcmLaw,
												FALSE );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;
	}

	
	/*==============================================================================*/
	/* Clearing the tone events bit vector */

	ulDwordAddress  = pSharedInfo->MemoryMap.ulChanMainMemBase + ( f_pChanIndexConf->usEchoChanIndex * pSharedInfo->MemoryMap.ulChanMainMemSize );
	ulDwordAddress += cOCT6100_CH_MAIN_TONE_EVENT_OFFSET;
	ulDwordData = 0x00000000;

	ulResult = Oct6100ApiWriteDword( f_pApiInstance, ulDwordAddress, ulDwordData );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	ulDwordAddress += 4;

	ulResult = Oct6100ApiWriteDword( f_pApiInstance, ulDwordAddress, ulDwordData );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/*==============================================================================*/

	
	/*==============================================================================*/
	/*	Write the VQE memory */
	
	ulResult = Oct6100ApiWriteVqeMemory( f_pApiInstance,
										  &f_pChannelOpen->VqeConfig,
										  f_pChannelOpen,
										  f_pChanIndexConf->usEchoChanIndex,	
										  f_pChanIndexConf->usEchoMemIndex,
										  TRUE,
										  FALSE );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	/*==============================================================================*/

	/*==============================================================================*/
	/*	Write the echo memory */

	ulResult = Oct6100ApiWriteEchoMemory( f_pApiInstance,
										  pTdmConfig,
										  f_pChannelOpen,
										  f_pChanIndexConf->usEchoMemIndex,
										  f_pChanIndexConf->usRinRoutTsiMemIndex,
										  f_pChanIndexConf->usSinSoutTsiMemIndex );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	/*==============================================================================*/



	/*==============================================================================*/
	/*	Mute channel if required, this is done on a port basis */

	/* Initialize the silence indexes to invalid for now. */
	pChanEntry->usRinSilenceEventIndex = cOCT6100_INVALID_INDEX;
	pChanEntry->usSinSilenceEventIndex = cOCT6100_INVALID_INDEX;

	/* Set the TSI memory indexes. */
	pChanEntry->usRinRoutTsiMemIndex  = f_pChanIndexConf->usRinRoutTsiMemIndex;
	pChanEntry->usSinSoutTsiMemIndex  = f_pChanIndexConf->usSinSoutTsiMemIndex;

	ulResult = Oct6100ApiMutePorts( f_pApiInstance,
									f_pChanIndexConf->usEchoChanIndex,
									f_pChanIndexConf->usRinTsstIndex,
									f_pChanIndexConf->usSinTsstIndex,
									FALSE );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;
	
	/*==============================================================================*/





	/*==============================================================================*/
	/* Configure the Output Tsst control memory.*/
	
	/* Set the ROUT Tsst control entry.*/
	if ( f_pChanIndexConf->usRoutTsstIndex != cOCT6100_INVALID_INDEX )
	{
		ulResult = Oct6100ApiWriteOutputTsstControlMemory( f_pApiInstance,
														   f_pChanIndexConf->usRoutTsstIndex,

														   f_pChanIndexConf->usRinRoutTsiMemIndex );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;
	}

	/* Set the SOUT Tsst control entry.*/
	if ( f_pChanIndexConf->usSoutTsstIndex != cOCT6100_INVALID_INDEX )
	{
		ulResult = Oct6100ApiWriteOutputTsstControlMemory( f_pApiInstance,
														   f_pChanIndexConf->usSoutTsstIndex,

														   f_pChanIndexConf->usSinSoutTsiMemIndex );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;
	}

	/*==============================================================================*/

	return cOCT6100_ERR_OK;
}



/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiUpdateChannelEntry

Description:    Updates the new channel in the ECHO channel list.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

f_pChannelOpen			Pointer to echo cancellation channel configuration structure.
f_pChanIndexConf		Pointer to a structure used to store the multiple resources indexes.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiUpdateChannelEntry(
				IN tPOCT6100_INSTANCE_API			f_pApiInstance,
				IN tPOCT6100_CHANNEL_OPEN			f_pChannelOpen,
				OUT tPOCT6100_API_ECHO_CHAN_INDEX	f_pChanIndexConf )
{
	tPOCT6100_API_CHANNEL			pChanEntry;
	tPOCT6100_CHANNEL_OPEN_TDM		pTdmConfig;
	tPOCT6100_CHANNEL_OPEN_VQE		pVqeConfig;


	/* Obtain a pointer to the config structures of the tPOCT6100_CHANNEL_OPEN structure. */
	pTdmConfig   = &f_pChannelOpen->TdmConfig;
	pVqeConfig   = &f_pChannelOpen->VqeConfig;


	/* Obtain a pointer to the new buffer's list entry. */
	mOCT6100_GET_CHANNEL_ENTRY_PNT( f_pApiInstance->pSharedInfo, pChanEntry, f_pChanIndexConf->usEchoChanIndex )

	
	/*=======================================================================*/
	/* Update num active channel stats. */
	if ( f_pChannelOpen->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_POWER_DOWN )
	{		
		f_pApiInstance->pSharedInfo->MiscVars.ulNumActiveChannels++;
	}
	/*=======================================================================*/


	/*=======================================================================*/
	/* Copy the channel's configuration and allocated resources. */
	pChanEntry->ulUserChanId = f_pChannelOpen->ulUserChanId;
	pChanEntry->byEchoOperationMode = (UINT8)( f_pChannelOpen->ulEchoOperationMode & 0xFF );
	pChanEntry->fEnableToneDisabler = (UINT8)( f_pChannelOpen->fEnableToneDisabler & 0xFF );


	/* Save the VQE configuration.*/
	pChanEntry->VqeConfig.byComfortNoiseMode = (UINT8)( pVqeConfig->ulComfortNoiseMode & 0xFF );
	pChanEntry->VqeConfig.fEnableNlp = (UINT8)( pVqeConfig->fEnableNlp & 0xFF );
	pChanEntry->VqeConfig.fEnableTailDisplacement = (UINT8)( pVqeConfig->fEnableTailDisplacement );
	pChanEntry->VqeConfig.usTailDisplacement = (UINT16)( pVqeConfig->ulTailDisplacement & 0xFFFF );
	pChanEntry->VqeConfig.usTailLength = (UINT16)( pVqeConfig->ulTailLength & 0xFFFF );

	pChanEntry->VqeConfig.fSinDcOffsetRemoval = (UINT8)( pVqeConfig->fSinDcOffsetRemoval & 0xFF );
	pChanEntry->VqeConfig.fRinDcOffsetRemoval = (UINT8)( pVqeConfig->fRinDcOffsetRemoval & 0xFF );
	pChanEntry->VqeConfig.fRinLevelControl = (UINT8)( pVqeConfig->fRinLevelControl & 0xFF );
	pChanEntry->VqeConfig.chRinLevelControlGainDb = (OCT_INT8)( pVqeConfig->lRinLevelControlGainDb & 0xFF );
	pChanEntry->VqeConfig.fSoutLevelControl = (UINT8)( pVqeConfig->fSoutLevelControl & 0xFF );
	pChanEntry->VqeConfig.chSoutLevelControlGainDb = (OCT_INT8)( pVqeConfig->lSoutLevelControlGainDb & 0xFF );
	pChanEntry->VqeConfig.fRinAutomaticLevelControl = (UINT8)( pVqeConfig->fRinAutomaticLevelControl & 0xFF );
	pChanEntry->VqeConfig.chRinAutomaticLevelControlTargetDb = (OCT_INT8)( pVqeConfig->lRinAutomaticLevelControlTargetDb & 0xFF );
	pChanEntry->VqeConfig.fSoutAutomaticLevelControl = (UINT8)( pVqeConfig->fSoutAutomaticLevelControl & 0xFF );
	pChanEntry->VqeConfig.chSoutAutomaticLevelControlTargetDb = (OCT_INT8)( pVqeConfig->lSoutAutomaticLevelControlTargetDb & 0xFF );
	pChanEntry->VqeConfig.fRinHighLevelCompensation = (UINT8)( pVqeConfig->fRinHighLevelCompensation & 0xFF );
	pChanEntry->VqeConfig.chRinHighLevelCompensationThresholdDb = (OCT_INT8)( pVqeConfig->lRinHighLevelCompensationThresholdDb & 0xFF );
	pChanEntry->VqeConfig.fSoutAdaptiveNoiseReduction = (UINT8)( pVqeConfig->fSoutAdaptiveNoiseReduction & 0xFF );


	pChanEntry->VqeConfig.fAcousticEcho		= (UINT8)( pVqeConfig->fAcousticEcho & 0xFF );

	pChanEntry->VqeConfig.fDtmfToneRemoval	= (UINT8)( pVqeConfig->fDtmfToneRemoval & 0xFF );

	pChanEntry->VqeConfig.chDefaultErlDb	= (OCT_INT8)( pVqeConfig->lDefaultErlDb & 0xFF );
	pChanEntry->VqeConfig.chAecDefaultErlDb	= (OCT_INT8)( pVqeConfig->lAecDefaultErlDb & 0xFF );
	pChanEntry->VqeConfig.usAecTailLength = (UINT16)( pVqeConfig->ulAecTailLength & 0xFFFF );
	pChanEntry->VqeConfig.byNonLinearityBehaviorA = (UINT8)( pVqeConfig->ulNonLinearityBehaviorA & 0xFF );
	pChanEntry->VqeConfig.byNonLinearityBehaviorB = (UINT8)( pVqeConfig->ulNonLinearityBehaviorB & 0xFF );
	pChanEntry->VqeConfig.byDoubleTalkBehavior = (UINT8)( pVqeConfig->ulDoubleTalkBehavior & 0xFF );
	pChanEntry->VqeConfig.chAnrSnrEnhancementDb	= (OCT_INT8)( pVqeConfig->lAnrSnrEnhancementDb & 0xFF );
	pChanEntry->VqeConfig.byAnrVoiceNoiseSegregation = (UINT8)( pVqeConfig->ulAnrVoiceNoiseSegregation & 0xFF );
	pChanEntry->VqeConfig.usToneDisablerVqeActivationDelay = (UINT16)( pVqeConfig->ulToneDisablerVqeActivationDelay & 0xFFFF );

	pChanEntry->VqeConfig.bySoutAutomaticListenerEnhancementGainDb = (UINT8)( pVqeConfig->ulSoutAutomaticListenerEnhancementGainDb & 0xFF );
	pChanEntry->VqeConfig.bySoutNaturalListenerEnhancementGainDb = (UINT8)( pVqeConfig->ulSoutNaturalListenerEnhancementGainDb & 0xFF );
	pChanEntry->VqeConfig.fSoutNaturalListenerEnhancement = (UINT8)( pVqeConfig->fSoutNaturalListenerEnhancement & 0xFF );
	pChanEntry->VqeConfig.fRoutNoiseReduction = (UINT8)( pVqeConfig->fRoutNoiseReduction & 0xFF );
	pChanEntry->VqeConfig.fEnablePlayout = (UINT8)( pVqeConfig->fEnablePlayout & 0xFF );
	pChanEntry->VqeConfig.chRoutNoiseReductionLevelGainDb = (OCT_INT8) (pVqeConfig->lRoutNoiseReductionLevelGainDb & 0xFF);
	pChanEntry->VqeConfig.fEnableMusicProtection = (UINT8)( pVqeConfig->fEnableMusicProtection & 0xFF );
	pChanEntry->VqeConfig.fIdleCodeDetection = (UINT8)( pVqeConfig->fIdleCodeDetection & 0xFF );


	
	/* Save the RIN settings.*/
	pChanEntry->TdmConfig.byRinPcmLaw = (UINT8)( pTdmConfig->ulRinPcmLaw & 0xFF );
	pChanEntry->TdmConfig.usRinTimeslot = (UINT16)( pTdmConfig->ulRinTimeslot & 0xFFFF );
	pChanEntry->TdmConfig.usRinStream = (UINT16)( pTdmConfig->ulRinStream & 0xFFFF );
	
	/* Save the SIN settings.*/
	pChanEntry->TdmConfig.bySinPcmLaw = (UINT8)( pTdmConfig->ulSinPcmLaw & 0xFF );
	pChanEntry->TdmConfig.usSinTimeslot = (UINT16)( pTdmConfig->ulSinTimeslot & 0xFFFF );
	pChanEntry->TdmConfig.usSinStream = (UINT16)( pTdmConfig->ulSinStream & 0xFFFF );

	/* Save the ROUT settings.*/
	pChanEntry->TdmConfig.byRoutPcmLaw = (UINT8)( pTdmConfig->ulRoutPcmLaw & 0xFF );
	pChanEntry->TdmConfig.usRoutTimeslot = (UINT16)( pTdmConfig->ulRoutTimeslot & 0xFFFF );
	pChanEntry->TdmConfig.usRoutStream = (UINT16)( pTdmConfig->ulRoutStream & 0xFFFF );



	/* Save the SOUT settings.*/
	pChanEntry->TdmConfig.bySoutPcmLaw = (UINT8)( pTdmConfig->ulSoutPcmLaw & 0xFF );
	pChanEntry->TdmConfig.usSoutTimeslot = (UINT16)( pTdmConfig->ulSoutTimeslot & 0xFFFF );
	pChanEntry->TdmConfig.usSoutStream = (UINT16)( pTdmConfig->ulSoutStream & 0xFFFF );






	/*=======================================================================*/

	/*=======================================================================*/
	/* Store hardware related information.*/
	pChanEntry->usRinRoutTsiMemIndex  = f_pChanIndexConf->usRinRoutTsiMemIndex;
	pChanEntry->usSinSoutTsiMemIndex  = f_pChanIndexConf->usSinSoutTsiMemIndex;
	pChanEntry->usExtraSinTsiMemIndex = cOCT6100_INVALID_INDEX;
	pChanEntry->usExtraRinTsiMemIndex = cOCT6100_INVALID_INDEX;



	pChanEntry->usRinRoutConversionMemIndex = f_pChanIndexConf->usRinRoutConversionMemIndex;
	pChanEntry->usSinSoutConversionMemIndex = f_pChanIndexConf->usSinSoutConversionMemIndex;


	


	pChanEntry->usEchoMemIndex = f_pChanIndexConf->usEchoMemIndex;

	pChanEntry->usRinTsstIndex = f_pChanIndexConf->usRinTsstIndex;
	pChanEntry->usSinTsstIndex = f_pChanIndexConf->usSinTsstIndex;
	pChanEntry->usRoutTsstIndex = f_pChanIndexConf->usRoutTsstIndex;
	pChanEntry->usSoutTsstIndex = f_pChanIndexConf->usSoutTsstIndex;

	pChanEntry->usSinCopyEventIndex		= cOCT6100_INVALID_INDEX;
	pChanEntry->usSoutCopyEventIndex	= cOCT6100_INVALID_INDEX;

	/* Nothing muted for now. */
	pChanEntry->usMutedPorts			= cOCT6100_CHANNEL_MUTE_PORT_NONE;





	/* Initialize the bidirectional flag.*/
	pChanEntry->fBiDirChannel = FALSE;

	/*=======================================================================*/
	/* Init some of the stats.*/

	pChanEntry->sMaxERL						= cOCT6100_INVALID_SIGNED_STAT_W;
	pChanEntry->sMaxERLE					= cOCT6100_INVALID_SIGNED_STAT_W;
	pChanEntry->usMaxEchoDelay				= cOCT6100_INVALID_STAT_W;
	pChanEntry->usNumEchoPathChangesOfst	= 0;

	/*=======================================================================*/



	/*=======================================================================*/
	
	/* Form handle returned to user. */
	*f_pChannelOpen->pulChannelHndl = cOCT6100_HNDL_TAG_CHANNEL | (pChanEntry->byEntryOpenCnt << cOCT6100_ENTRY_OPEN_CNT_SHIFT) | f_pChanIndexConf->usEchoChanIndex;

	/* Finally, mark the channel as open. */
	pChanEntry->fReserved = TRUE;
	pChanEntry->usExtraSinTsiDependencyCnt = 0;
	
	/* Increment the number of channel open.*/
	f_pApiInstance->pSharedInfo->ChipStats.usNumberChannels++;

	/*=======================================================================*/


	return cOCT6100_ERR_OK;
}






/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ChannelCloseSer

Description:    Closes a echo cancellation channel.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.

f_pChannelClose			Pointer to echo cancellation channel close structure.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ChannelCloseSer(
				IN tPOCT6100_INSTANCE_API				f_pApiInstance,
				IN tPOCT6100_CHANNEL_CLOSE				f_pChannelClose )
{
	UINT16	usChannelIndex;


	UINT32	ulResult;

	/* Verify that all the parameters given match the state of the API. */
	ulResult = Oct6100ApiAssertChannelParams( f_pApiInstance, 
											  f_pChannelClose, 

											  &usChannelIndex );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/* Release all resources associated to the echo cancellation channel. */
	ulResult = Oct6100ApiInvalidateChannelStructs( f_pApiInstance, 

												   usChannelIndex );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/* Release all resources associated to the echo cancellation channel. */
	ulResult = Oct6100ApiReleaseChannelResources( f_pApiInstance, usChannelIndex );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/* Invalidate the handle.*/
	f_pChannelClose->ulChannelHndl = cOCT6100_INVALID_HANDLE;

	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiAssertChannelParams

Description:    Validate the handle given by the user and verify the state of 
				the channel about to be closed.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.

f_pChannelClose			Pointer to echo cancellation channel close structure.
f_pulFpgaChanIndex		Pointer to the FPGA channel index associated to this channel.
f_pusChanIndex			Pointer to the index of the channel within the API instance.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiAssertChannelParams( 
				IN		tPOCT6100_INSTANCE_API				f_pApiInstance,
				IN		tPOCT6100_CHANNEL_CLOSE				f_pChannelClose,

				IN OUT	PUINT16								f_pusChanIndex )
{
	tPOCT6100_SHARED_INFO			pSharedInfo;
	tPOCT6100_API_CHANNEL			pChanEntry;
	UINT32							ulEntryOpenCnt;

	/* Get local pointer(s). */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	/* Check the provided handle. */
	if ( (f_pChannelClose->ulChannelHndl & cOCT6100_HNDL_TAG_MASK) != cOCT6100_HNDL_TAG_CHANNEL )
		return cOCT6100_ERR_CHANNEL_INVALID_HANDLE;

	*f_pusChanIndex = (UINT16)( f_pChannelClose->ulChannelHndl & cOCT6100_HNDL_INDEX_MASK );
	if ( *f_pusChanIndex  >= pSharedInfo->ChipConfig.usMaxChannels )
		return cOCT6100_ERR_CHANNEL_INVALID_HANDLE;

	/*=======================================================================*/
	/* Get a pointer to the channel's list entry. */

	mOCT6100_GET_CHANNEL_ENTRY_PNT( pSharedInfo, pChanEntry, *f_pusChanIndex  )

	/* Extract the entry open count from the provided handle. */
	ulEntryOpenCnt = ( f_pChannelClose->ulChannelHndl >> cOCT6100_ENTRY_OPEN_CNT_SHIFT) & cOCT6100_ENTRY_OPEN_CNT_MASK;

	/* Check for errors. */
	if ( pChanEntry->fReserved != TRUE )
		return cOCT6100_ERR_CHANNEL_NOT_OPEN;
	if ( ulEntryOpenCnt != pChanEntry->byEntryOpenCnt )
		return cOCT6100_ERR_CHANNEL_INVALID_HANDLE;
	if ( pChanEntry->fBiDirChannel == TRUE )
		return cOCT6100_ERR_CHANNEL_PART_OF_BIDIR_CHANNEL;

	/*=======================================================================*/
	




	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiInvalidateChannelStructs

Description:    Closes a echo cancellation channel.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.

f_ulFpgaChanIndex		Index of the channel within the SCN_PLC FPGA.
f_usChanIndex			Index of the channel within the API instance.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiInvalidateChannelStructs( 
				IN		tPOCT6100_INSTANCE_API				f_pApiInstance,

				IN		UINT16								f_usChanIndex )
{
	tPOCT6100_API_CHANNEL			pChanEntry;
	tPOCT6100_API_CHANNEL_TDM		pTdmConfig;

	tPOCT6100_SHARED_INFO			pSharedInfo;
	tOCT6100_WRITE_PARAMS			WriteParams;
	tOCT6100_WRITE_SMEAR_PARAMS		SmearParams;
	UINT32							ulResult;

	
	/* Obtain local pointer to shared portion of instance. */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	mOCT6100_GET_CHANNEL_ENTRY_PNT( pSharedInfo, pChanEntry, f_usChanIndex );
	
	/* Obtain local pointer to the TDM configuration of the channel */
	pTdmConfig = &pChanEntry->TdmConfig;

	WriteParams.pProcessContext = f_pApiInstance->pProcessContext;

	WriteParams.ulUserChipId = pSharedInfo->ChipConfig.ulUserChipId;

	SmearParams.pProcessContext = f_pApiInstance->pProcessContext;

	SmearParams.ulUserChipId = pSharedInfo->ChipConfig.ulUserChipId;
	
	/* If this channel is currently debugged, automatically close the debug channel. */
	if ( ( pSharedInfo->ChipConfig.fEnableChannelRecording == TRUE || pSharedInfo->ChipConfig.fAllowDynamicRecording == TRUE )
		&& ( pSharedInfo->DebugInfo.usCurrentDebugChanIndex == f_usChanIndex ) )
	{
		tOCT6100_DEBUG_SELECT_CHANNEL	SelectDebugChan;

		/* Ensure forward compatibility. */
		Oct6100DebugSelectChannelDef( &SelectDebugChan );

		/* Set the hot channel to an invalid handle to disable recording. */
		SelectDebugChan.ulChannelHndl = cOCT6100_INVALID_HANDLE;

		/* Call the serialized fonction. */
		ulResult = Oct6100DebugSelectChannelSer( f_pApiInstance, &SelectDebugChan, FALSE );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;
	}

	/* Deactivate the TSST control memory if used. */
	
	/* RIN port.*/
	if ( pTdmConfig->usRinTimeslot != cOCT6100_UNASSIGNED )
	{
		/* Deactivate the TSST entry.*/
		WriteParams.ulWriteAddress = cOCT6100_TSST_CONTROL_MEM_BASE + ( pChanEntry->usRinTsstIndex * cOCT6100_TSST_CONTROL_MEM_ENTRY_SIZE );
		WriteParams.usWriteData  = 0x0000;

		mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
		if ( ulResult != cOCT6100_ERR_OK  )
			return ulResult;
	}

	/* SIN port.*/
	if ( pTdmConfig->usSinTimeslot != cOCT6100_UNASSIGNED )
	{
		/* Deactivate the TSST entry.*/
		WriteParams.ulWriteAddress = cOCT6100_TSST_CONTROL_MEM_BASE + ( pChanEntry->usSinTsstIndex  * cOCT6100_TSST_CONTROL_MEM_ENTRY_SIZE );
		WriteParams.usWriteData  = 0x0000;

		mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
		if ( ulResult != cOCT6100_ERR_OK  )
			return ulResult;
	}
	
	/*=======================================================================*/
	/* ROUT port.*/
	
	if ( pTdmConfig->usRoutTimeslot != cOCT6100_UNASSIGNED )
	{
		/* Deactivate the TSST entry.*/
		WriteParams.ulWriteAddress = cOCT6100_TSST_CONTROL_MEM_BASE + ( pChanEntry->usRoutTsstIndex  * cOCT6100_TSST_CONTROL_MEM_ENTRY_SIZE );
		WriteParams.usWriteData  = 0x0000;

		mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
		if ( ulResult != cOCT6100_ERR_OK  )
			return ulResult;
	}


	/*=======================================================================*/
	
	/*=======================================================================*/
	/* SOUT port.*/

	if ( pTdmConfig->usSoutTimeslot != cOCT6100_UNASSIGNED )
	{
		/* Deactivate the TSST entry.*/
		WriteParams.ulWriteAddress = cOCT6100_TSST_CONTROL_MEM_BASE + ( pChanEntry->usSoutTsstIndex  * cOCT6100_TSST_CONTROL_MEM_ENTRY_SIZE );
		WriteParams.usWriteData  = 0x0000;

		mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
		if ( ulResult != cOCT6100_ERR_OK  )
			return ulResult;
	}


		/*=======================================================================*/

	
	/*------------------------------------------------------------------------------*/
	/* Deactivate the ECHO control memory entry.*/
	
	/* Set the input Echo control entry to unused.*/
	WriteParams.ulWriteAddress  = cOCT6100_ECHO_CONTROL_MEM_BASE + ( pChanEntry->usEchoMemIndex * cOCT6100_ECHO_CONTROL_MEM_ENTRY_SIZE );
	WriteParams.usWriteData = 0x85FF;	/* TSI index 1535 reserved for power-down mode */

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	WriteParams.ulWriteAddress += 2;
	WriteParams.usWriteData = 0xC5FF;	/* TSI index 1535 reserved for power-down mode */

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;
	/*------------------------------------------------------------------------------*/

	/*------------------------------------------------------------------------------*/
	/* Deactivate the conversion control memories if used. */
	
	if ( pChanEntry->usRinRoutConversionMemIndex != cOCT6100_INVALID_INDEX )
	{
		/* Rin/Rout stream conversion memory was used */
		ulResult = Oct6100ApiClearConversionMemory( f_pApiInstance, pChanEntry->usRinRoutConversionMemIndex );
		if ( ulResult != cOCT6100_ERR_OK  )
			return ulResult;
	}
	
	if ( pChanEntry->usSinSoutConversionMemIndex != cOCT6100_INVALID_INDEX )
	{
		/* Sin/Sout stream conversion memory was used */
		ulResult = Oct6100ApiClearConversionMemory( f_pApiInstance, pChanEntry->usSinSoutConversionMemIndex );
		if ( ulResult != cOCT6100_ERR_OK  )
			return ulResult;
	}

	/*------------------------------------------------------------------------------*/


	/*------------------------------------------------------------------------------*/
	/* Clear the silence copy events if they were created. */

	/* Unmute the Rin port if it was muted. */
	if ( pChanEntry->usRinSilenceEventIndex != cOCT6100_INVALID_INDEX )
	{
		/* Remove the event from the list.*/
		ulResult = Oct6100ApiMixerEventRemove(	f_pApiInstance,
												pChanEntry->usRinSilenceEventIndex,
												cOCT6100_EVENT_TYPE_SOUT_COPY );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;

		ulResult = Oct6100ApiReleaseMixerEventEntry( f_pApiInstance, pChanEntry->usRinSilenceEventIndex );
		if ( ulResult != cOCT6100_ERR_OK  )
			return cOCT6100_ERR_FATAL_DF;

		pChanEntry->usRinSilenceEventIndex = cOCT6100_INVALID_INDEX;
	}

	/* Unmute the Sin port if it was muted. */
	if ( pChanEntry->usSinSilenceEventIndex != cOCT6100_INVALID_INDEX )
	{
		/* Remove the event from the list.*/
		ulResult = Oct6100ApiMixerEventRemove(	f_pApiInstance,
												pChanEntry->usSinSilenceEventIndex,
												cOCT6100_EVENT_TYPE_SOUT_COPY );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;

		ulResult = Oct6100ApiReleaseMixerEventEntry( f_pApiInstance, pChanEntry->usSinSilenceEventIndex );
		if ( ulResult != cOCT6100_ERR_OK  )
			return cOCT6100_ERR_FATAL_E0;

		pChanEntry->usSinSilenceEventIndex = cOCT6100_INVALID_INDEX;
	}

	/*------------------------------------------------------------------------------*/









	/*------------------------------------------------------------------------------*/
	/* Reset PGSP */

	WriteParams.ulWriteAddress = cOCT6100_CHANNEL_ROOT_BASE + ( pChanEntry->usEchoMemIndex * cOCT6100_CHANNEL_ROOT_SIZE ) + pSharedInfo->MemoryMap.ulChanRootConfOfst;
	WriteParams.usWriteData = 0x0800;

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult; 

	/*------------------------------------------------------------------------------*/

	/*------------------------------------------------------------------------------*/
	/* Clear the mute with feature bit. */

	if ( ( pChanEntry->usMutedPorts & cOCT6100_CHANNEL_MUTE_PORT_SIN_WITH_FEATURES ) != 0x0 )
	{
		ulResult = Oct6100ApiMuteSinWithFeatures( f_pApiInstance, f_usChanIndex, FALSE );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;
	}

	/*------------------------------------------------------------------------------*/

	/*------------------------------------------------------------------------------*/
	/* Clear the VQE memory. */

	SmearParams.ulWriteAddress = cOCT6100_CHANNEL_ROOT_BASE + ( pChanEntry->usEchoMemIndex * cOCT6100_CHANNEL_ROOT_SIZE ) + pSharedInfo->MemoryMap.ulChanRootConfOfst + 0x20;
	SmearParams.usWriteData = 0x0000;
	SmearParams.ulWriteLength = 2;

	mOCT6100_DRIVER_WRITE_SMEAR_API( SmearParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/*------------------------------------------------------------------------------*/
	/*------------------------------------------------------------------------------*/
	/* Clear the NLP memory. */

	SmearParams.ulWriteAddress = cOCT6100_CHANNEL_ROOT_BASE + ( pChanEntry->usEchoMemIndex * cOCT6100_CHANNEL_ROOT_SIZE ) + pSharedInfo->MemoryMap.ulChanRootConfOfst + 0x28;
	SmearParams.usWriteData = 0x0000;
	SmearParams.ulWriteLength = 2;

	mOCT6100_DRIVER_WRITE_SMEAR_API( SmearParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/*------------------------------------------------------------------------------*/
	/* Clear the AF information memory. */

	SmearParams.ulWriteAddress = pSharedInfo->MemoryMap.ulChanMainMemBase + ( pChanEntry->usEchoMemIndex * f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainMemSize ) + f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainIoMemOfst;
	SmearParams.usWriteData = 0x0000;
	SmearParams.ulWriteLength = 12;

	mOCT6100_DRIVER_WRITE_SMEAR_API( SmearParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;
	
	/*Reset ALC status*/
	WriteParams.ulWriteAddress = pSharedInfo->MemoryMap.ulChanMainMemBase + ( pChanEntry->usEchoMemIndex * f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainMemSize ) + f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainIoMemOfst + 0x3A;
	WriteParams.usWriteData = 0x0000;

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult; 
	
	/*------------------------------------------------------------------------------*/

	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiReleaseChannelResources

Description:	Release and clear the API entry associated to the echo cancellation channel.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.

f_usChannelIndex		Index of the echo cancellation channel in the API list.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiReleaseChannelResources( 
				IN  tPOCT6100_INSTANCE_API				f_pApiInstance,
				IN	UINT16								f_usChannelIndex )
{
	tPOCT6100_SHARED_INFO		pSharedInfo;
	tPOCT6100_API_CHANNEL		pChanEntry;
	tPOCT6100_API_CHANNEL_TDM	pTdmConfig;

	UINT32	ulResult;


	/* Obtain local pointer to shared portion of instance. */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	mOCT6100_GET_CHANNEL_ENTRY_PNT( pSharedInfo, pChanEntry, f_usChannelIndex );

	/*=======================================================================*/
	/* Update num active channel stats. */
	if ( pChanEntry->byEchoOperationMode != cOCT6100_ECHO_OP_MODE_POWER_DOWN )
	{		
		f_pApiInstance->pSharedInfo->MiscVars.ulNumActiveChannels--;
	}
	/*=======================================================================*/

	/* Obtain local pointer to the TDM configurationof the channel */
	pTdmConfig = &pChanEntry->TdmConfig;

	/* Release the two TSI chariot memory entries.*/
	ulResult = Oct6100ApiReleaseTsiMemEntry( f_pApiInstance, pChanEntry->usRinRoutTsiMemIndex );
	if ( ulResult != cOCT6100_ERR_OK  )
		return cOCT6100_ERR_FATAL_2;

	ulResult = Oct6100ApiReleaseTsiMemEntry( f_pApiInstance, pChanEntry->usSinSoutTsiMemIndex );
	if ( ulResult != cOCT6100_ERR_OK  )
		return cOCT6100_ERR_FATAL_3;

	/* Now release the ECHO channel and control memory entries.*/
	ulResult = Oct6100ApiReleaseEchoEntry( f_pApiInstance, f_usChannelIndex );
	if ( ulResult != cOCT6100_ERR_OK  )
		return cOCT6100_ERR_FATAL_4;

	/* Release the conversion resources.*/
	if ( pChanEntry->usRinRoutConversionMemIndex != cOCT6100_INVALID_INDEX )
	{
		ulResult = Oct6100ApiReleaseConversionMemEntry( f_pApiInstance, pChanEntry->usRinRoutConversionMemIndex );
		if ( ulResult != cOCT6100_ERR_OK  )
			return cOCT6100_ERR_FATAL_B9;

		pChanEntry->usRinRoutConversionMemIndex = cOCT6100_INVALID_INDEX;
	}

	if ( pChanEntry->usSinSoutConversionMemIndex != cOCT6100_INVALID_INDEX )
	{
		ulResult = Oct6100ApiReleaseConversionMemEntry( f_pApiInstance, pChanEntry->usSinSoutConversionMemIndex );
		if ( ulResult != cOCT6100_ERR_OK  )
			return cOCT6100_ERR_FATAL_BA;

		pChanEntry->usSinSoutConversionMemIndex = cOCT6100_INVALID_INDEX;
	}

	/*=========================================================================*/
	/* Release the TSST control memory entries if any were reserved.*/
	if ( pTdmConfig->usRinTimeslot != cOCT6100_UNASSIGNED)
	{
		ulResult = Oct6100ApiReleaseTsst( f_pApiInstance, 
										  pTdmConfig->usRinTimeslot,
										  pTdmConfig->usRinStream,

										  cOCT6100_INPUT_TSST,
										  cOCT6100_INVALID_INDEX );
		if ( ulResult != cOCT6100_ERR_OK  )
			return cOCT6100_ERR_FATAL_5;
	}

	if ( pTdmConfig->usSinTimeslot != cOCT6100_UNASSIGNED)
	{
		ulResult = Oct6100ApiReleaseTsst( f_pApiInstance, 
										  pTdmConfig->usSinTimeslot,
										  pTdmConfig->usSinStream,

										  cOCT6100_INPUT_TSST,
										  cOCT6100_INVALID_INDEX );
		if ( ulResult != cOCT6100_ERR_OK  )
			return cOCT6100_ERR_FATAL_6;
	}

	/*=======================================================================*/
	/* Release all the TSSTs associated to the ROUT port of this channel. */
	if ( pTdmConfig->usRoutTimeslot != cOCT6100_UNASSIGNED)
	{
		ulResult = Oct6100ApiReleaseTsst( f_pApiInstance, 
										  pTdmConfig->usRoutTimeslot,
										  pTdmConfig->usRoutStream,

										  cOCT6100_OUTPUT_TSST,
										  cOCT6100_INVALID_INDEX );
		if ( ulResult != cOCT6100_ERR_OK  )
			return cOCT6100_ERR_FATAL_7;
	}



	/*=======================================================================*/

	
	/*=======================================================================*/
	/* Release all the TSSTs associated to the SOUT port of this channel. */
	if ( pTdmConfig->usSoutTimeslot != cOCT6100_UNASSIGNED)
	{
		ulResult = Oct6100ApiReleaseTsst( f_pApiInstance, 
										  pTdmConfig->usSoutTimeslot,
										  pTdmConfig->usSoutStream,

										  cOCT6100_OUTPUT_TSST,
										  cOCT6100_INVALID_INDEX );
		if ( ulResult != cOCT6100_ERR_OK  )
			return cOCT6100_ERR_FATAL_9;
	}


	/*=======================================================================*/







	/*=======================================================================*/
	/* Update the channel's list entry. */

	/* Clear the NLP dword array. */
	Oct6100UserMemSet( pChanEntry->aulNlpConfDword, 0, sizeof( pChanEntry->aulNlpConfDword ) );

	/* Clear the echo operation mode. */
	pChanEntry->byEchoOperationMode = cOCT6100_ECHO_OP_MODE_POWER_DOWN;

	/* Mark the channel as closed. */
	pChanEntry->fReserved = FALSE;
	pChanEntry->byEntryOpenCnt++;

	/* Reset the port, the bridge and BidirInfo */
	pChanEntry->usMutedPorts = cOCT6100_CHANNEL_MUTE_PORT_NONE;
	pChanEntry->fBiDirChannel = FALSE;

	
	/* Decrement the number of channel open.*/
	f_pApiInstance->pSharedInfo->ChipStats.usNumberChannels--;

	/*=======================================================================*/

	return cOCT6100_ERR_OK;

}



/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ChannelModifySer

Description:    Modify an echo cancellation channel.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.

f_pChannelModify		Pointer to channel configuration structure.  The handle
						identifying the buffer in all future function calls is
						returned in this structure.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ChannelModifySer(
				IN		tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT	tPOCT6100_CHANNEL_MODIFY				f_pChannelModify )
{
	UINT16	usChanIndex;
	UINT32	ulResult;
	UINT16	usNewRinTsstIndex;
	UINT16	usNewSinTsstIndex;
	UINT16	usNewRoutTsstIndex;
	UINT16	usNewSoutTsstIndex;

	tOCT6100_CHANNEL_OPEN	TempChanOpen;

	/* Check the user's configuration of the echo cancellation channel for errors. */
	ulResult = Oct6100ApiCheckChannelModify( f_pApiInstance, 
											 f_pChannelModify, 
											 &TempChanOpen, 

											 &usChanIndex );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/* Reserve all resources needed by the echo cancellation channel. */
	ulResult = Oct6100ApiModifyChannelResources( f_pApiInstance, 
												 f_pChannelModify, 
												 usChanIndex, 
												 &usNewRinTsstIndex, 
												 &usNewSinTsstIndex, 
												 &usNewRoutTsstIndex, 
												 &usNewSoutTsstIndex );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/* Write all necessary structures to activate the echo cancellation channel. */
	ulResult = Oct6100ApiModifyChannelStructs( f_pApiInstance, 
											   f_pChannelModify, 
											   &TempChanOpen, 
											   usChanIndex, 

											   usNewRinTsstIndex, 
											   usNewSinTsstIndex, 
											   usNewRoutTsstIndex, 
											   usNewSoutTsstIndex );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/* Update the new echo cancellation channels's entry in the ECHO channel list. */
	ulResult = Oct6100ApiModifyChannelEntry( f_pApiInstance, 
											 f_pChannelModify, 
											 &TempChanOpen, 
											 usChanIndex,  

											 usNewRinTsstIndex, 
											 usNewSinTsstIndex, 
											 usNewRoutTsstIndex, 
											 usNewSoutTsstIndex  );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiCheckChannelModify

Description:    Checks the user's echo cancellation channel modify structure for errors.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.

f_pChannelModify		Pointer to echo cancellation channel modify structure.
f_pTempChanOpen			Pointer to a channel open structure.
f_pusNewPhasingTsstIndex	Pointer to a new phasing TSST index within the API instance.
f_pusChanIndex			Pointer to the channel index within the API instance channel list

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiCheckChannelModify(
				IN		tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT	tPOCT6100_CHANNEL_MODIFY				f_pChannelModify,
				IN		tPOCT6100_CHANNEL_OPEN					f_pTempChanOpen,

				OUT		PUINT16									f_pusChanIndex )
{
	tPOCT6100_API_CHANNEL		pChanEntry;
	UINT32	ulResult;
	UINT32	ulEntryOpenCnt;


	/* Check the provided handle. */
	if ( (f_pChannelModify->ulChannelHndl & cOCT6100_HNDL_TAG_MASK) != cOCT6100_HNDL_TAG_CHANNEL )
		return cOCT6100_ERR_CHANNEL_INVALID_HANDLE;

	*f_pusChanIndex = (UINT16)( f_pChannelModify->ulChannelHndl & cOCT6100_HNDL_INDEX_MASK );
	if ( *f_pusChanIndex >= f_pApiInstance->pSharedInfo->ChipConfig.usMaxChannels )
		return cOCT6100_ERR_CHANNEL_INVALID_HANDLE;

	/*=======================================================================*/
	/* Get a pointer to the channel's list entry. */

	mOCT6100_GET_CHANNEL_ENTRY_PNT( f_pApiInstance->pSharedInfo, pChanEntry, *f_pusChanIndex )

	/* Extract the entry open count from the provided handle. */
	ulEntryOpenCnt = ( f_pChannelModify->ulChannelHndl >> cOCT6100_ENTRY_OPEN_CNT_SHIFT) & cOCT6100_ENTRY_OPEN_CNT_MASK;

	/* Check for errors. */
	if ( pChanEntry->fReserved != TRUE )
		return cOCT6100_ERR_CHANNEL_NOT_OPEN;
	if ( ulEntryOpenCnt != pChanEntry->byEntryOpenCnt )
		return cOCT6100_ERR_CHANNEL_INVALID_HANDLE;

	/*=======================================================================*/


	/*=======================================================================*/
	/* Check the general modify parameters. */
	
	if ( f_pChannelModify->ulEchoOperationMode != cOCT6100_KEEP_PREVIOUS_SETTING &&
		 f_pChannelModify->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_NORMAL &&
		 f_pChannelModify->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_HT_FREEZE &&
		 f_pChannelModify->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_HT_RESET &&
		 f_pChannelModify->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_POWER_DOWN &&
		 f_pChannelModify->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_EXTERNAL &&
		 f_pChannelModify->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_SPEECH_RECOGNITION &&
		 f_pChannelModify->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_NO_ECHO )
		return cOCT6100_ERR_CHANNEL_ECHO_OP_MODE;

	/* Check the 2100Hz echo disabling configuration.*/
	if ( f_pChannelModify->fEnableToneDisabler != cOCT6100_KEEP_PREVIOUS_SETTING &&
		 f_pChannelModify->fEnableToneDisabler != TRUE && 
		 f_pChannelModify->fEnableToneDisabler != FALSE )
		return cOCT6100_ERR_CHANNEL_TONE_DISABLER_ENABLE;







	if ( f_pChannelModify->fVqeConfigModified != TRUE && 
		 f_pChannelModify->fVqeConfigModified != FALSE )
		return cOCT6100_ERR_CHANNEL_MODIFY_VQE_CONFIG;

	if ( f_pChannelModify->fTdmConfigModified != TRUE && 
		 f_pChannelModify->fTdmConfigModified != FALSE )
		return cOCT6100_ERR_CHANNEL_MODIFY_TDM_CONFIG;

	/*=======================================================================*/

	/*=======================================================================*/
	/* Verify if any law change was requested. If so reprogram all structures.*/

	if (( f_pChannelModify->fTdmConfigModified == TRUE ) &&
		( f_pChannelModify->TdmConfig.ulRinPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING ||
		  f_pChannelModify->TdmConfig.ulSinPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING ||
		  f_pChannelModify->TdmConfig.ulRoutPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING ||
		  f_pChannelModify->TdmConfig.ulSoutPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING ))
	{
		f_pChannelModify->fVqeConfigModified = TRUE;

	}
	/*=======================================================================*/
	
	ulResult = Oct6100ApiUpdateOpenStruct( f_pApiInstance, f_pChannelModify, f_pTempChanOpen, pChanEntry );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	/* All further check will now be performed using the TempOpenChan structure in order
	   to reuse the checks written for the open channel structure.*/
	


	/* Check the TDM config.*/
	if ( f_pChannelModify->fTdmConfigModified == TRUE )
	{
		tPOCT6100_CHANNEL_MODIFY_TDM		pModifyTdm;
		tPOCT6100_CHANNEL_OPEN_TDM			pOpenTdm;

		pModifyTdm = &f_pChannelModify->TdmConfig;
		pOpenTdm = &f_pTempChanOpen->TdmConfig;

		ulResult = Oct6100ApiCheckTdmConfig( f_pApiInstance,
											 pOpenTdm );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;

		/* Check if that Stream and Timeslot values are valid.*/
		
		/* Check the RIN port.*/
		if ( f_pChannelModify->TdmConfig.ulRinStream == cOCT6100_KEEP_PREVIOUS_SETTING &&
			f_pChannelModify->TdmConfig.ulRinTimeslot != cOCT6100_KEEP_PREVIOUS_SETTING )
			return cOCT6100_ERR_CHANNEL_RIN_TIMESLOT;

		if ( f_pChannelModify->TdmConfig.ulRinStream != cOCT6100_KEEP_PREVIOUS_SETTING &&
			f_pChannelModify->TdmConfig.ulRinTimeslot == cOCT6100_KEEP_PREVIOUS_SETTING )
			return cOCT6100_ERR_CHANNEL_RIN_STREAM;
		 


		/* Check the SIN port.*/
		if ( f_pChannelModify->TdmConfig.ulSinStream == cOCT6100_KEEP_PREVIOUS_SETTING &&
			f_pChannelModify->TdmConfig.ulSinTimeslot != cOCT6100_KEEP_PREVIOUS_SETTING )
			return cOCT6100_ERR_CHANNEL_SIN_TIMESLOT;

		if ( f_pChannelModify->TdmConfig.ulSinStream != cOCT6100_KEEP_PREVIOUS_SETTING &&
			f_pChannelModify->TdmConfig.ulSinTimeslot == cOCT6100_KEEP_PREVIOUS_SETTING )
			return cOCT6100_ERR_CHANNEL_SIN_STREAM;

		/* Check the ROUT port.*/
		if ( f_pChannelModify->TdmConfig.ulRoutStream == cOCT6100_KEEP_PREVIOUS_SETTING &&
			f_pChannelModify->TdmConfig.ulRoutTimeslot != cOCT6100_KEEP_PREVIOUS_SETTING )
			return cOCT6100_ERR_CHANNEL_ROUT_TIMESLOT;

		if ( f_pChannelModify->TdmConfig.ulRoutStream != cOCT6100_KEEP_PREVIOUS_SETTING &&
			f_pChannelModify->TdmConfig.ulRoutTimeslot == cOCT6100_KEEP_PREVIOUS_SETTING )
			return cOCT6100_ERR_CHANNEL_ROUT_STREAM;

		/* Check the SOUT port.*/
		if ( f_pChannelModify->TdmConfig.ulSoutStream == cOCT6100_KEEP_PREVIOUS_SETTING &&
			f_pChannelModify->TdmConfig.ulSoutTimeslot != cOCT6100_KEEP_PREVIOUS_SETTING )
			return cOCT6100_ERR_CHANNEL_SOUT_TIMESLOT;

		if ( f_pChannelModify->TdmConfig.ulSoutStream != cOCT6100_KEEP_PREVIOUS_SETTING &&
			f_pChannelModify->TdmConfig.ulSoutTimeslot == cOCT6100_KEEP_PREVIOUS_SETTING )
			return cOCT6100_ERR_CHANNEL_SOUT_STREAM;

		/* Verify if the channel is currently part of a bidirectional channel, and if */
		/* so perform the required checks. */
		if ( pChanEntry->fBiDirChannel == TRUE )
		{
			/* Check the ports that must remain unassigned.*/
			if ( f_pTempChanOpen->TdmConfig.ulRinTimeslot != cOCT6100_UNASSIGNED )
				return cOCT6100_ERR_CHANNEL_RIN_TIMESLOT;
			if ( f_pTempChanOpen->TdmConfig.ulSoutTimeslot != cOCT6100_UNASSIGNED )
				return cOCT6100_ERR_CHANNEL_SOUT_TIMESLOT;
			
			/* Check that no PCM law change is requested.*/
			if ( f_pTempChanOpen->TdmConfig.ulRinPcmLaw != f_pTempChanOpen->TdmConfig.ulRoutPcmLaw )
				return cOCT6100_ERR_CHANNEL_RIN_ROUT_LAW_CONVERSION;
			if ( f_pTempChanOpen->TdmConfig.ulSinPcmLaw != f_pTempChanOpen->TdmConfig.ulSoutPcmLaw )
				return cOCT6100_ERR_CHANNEL_SIN_SOUT_LAW_CONVERSION;
		}




	}

	/* Check the VQE config.*/
	if ( f_pChannelModify->fVqeConfigModified == TRUE )
	{
		ulResult = Oct6100ApiCheckVqeConfig( f_pApiInstance,
											 &f_pTempChanOpen->VqeConfig,
											 f_pTempChanOpen->fEnableToneDisabler );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;
	}

	/* Verify if the echo operation mode selected can be applied. */
	if ( ( f_pTempChanOpen->ulEchoOperationMode == cOCT6100_ECHO_OP_MODE_NO_ECHO )
		&& ( f_pTempChanOpen->VqeConfig.fEnableNlp == FALSE ) )
		return cOCT6100_ERR_CHANNEL_ECHO_OP_MODE_NLP_REQUIRED;
	
	if ( ( f_pTempChanOpen->ulEchoOperationMode == cOCT6100_ECHO_OP_MODE_SPEECH_RECOGNITION )
		&& ( f_pTempChanOpen->VqeConfig.fEnableNlp == FALSE ) )
		return cOCT6100_ERR_CHANNEL_ECHO_OP_MODE_NLP_REQUIRED;

	/* Comfort noise must be activated for speech recognition mode to work. */
	if ( ( f_pTempChanOpen->ulEchoOperationMode == cOCT6100_ECHO_OP_MODE_SPEECH_RECOGNITION )
		&& ( f_pTempChanOpen->VqeConfig.ulComfortNoiseMode == cOCT6100_COMFORT_NOISE_OFF ) )
		return cOCT6100_ERR_CHANNEL_COMFORT_NOISE_REQUIRED;


	/*=======================================================================*/

	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiModifyChannelResources

Description:    Reserves any new resources needed for the channel
-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.
	
f_pChannelModify		Pointer to echo cancellation channel configuration structure.
f_usChanIndex			Allocated entry in ECHO channel list.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiModifyChannelResources(	
				IN  tPOCT6100_INSTANCE_API				f_pApiInstance,
				IN  tPOCT6100_CHANNEL_MODIFY			f_pChannelModify,
				IN	UINT16								f_usChanIndex,
				OUT	PUINT16								f_pusNewRinTsstIndex,
				OUT	PUINT16								f_pusNewSinTsstIndex,
				OUT	PUINT16								f_pusNewRoutTsstIndex,
				OUT	PUINT16								f_pusNewSoutTsstIndex )
{
	tPOCT6100_API_CHANNEL			pChanEntry;
	tPOCT6100_SHARED_INFO			pSharedInfo;

	tPOCT6100_API_CHANNEL_TDM		pApiTdmConf;
	tPOCT6100_CHANNEL_MODIFY_TDM	pModifyTdmConf;

	UINT32	ulResult = cOCT6100_ERR_OK;
	UINT32	ulTempVar = cOCT6100_ERR_OK;
	UINT32	ulFreeMixerEventCnt;
	
	BOOL	fRinReleased = FALSE;
	BOOL	fSinReleased = FALSE;
	BOOL	fRoutReleased = FALSE;
	BOOL	fSoutReleased = FALSE;

	BOOL	fRinReserved = FALSE;
	BOOL	fSinReserved = FALSE;
	BOOL	fRoutReserved = FALSE;
	BOOL	fSoutReserved = FALSE;

	BOOL	fReserveRin = FALSE;
	BOOL	fReserveSin = FALSE;
	BOOL	fReserveRout = FALSE;
	BOOL	fReserveSout = FALSE;

	BOOL	fRinRoutConversionMemReserved = FALSE;
	BOOL	fSinSoutConversionMemReserved = FALSE;

	BOOL	fRinRoutLawConversionModify	= FALSE;
	BOOL	fSinSoutLawConversionModify	= FALSE;
	UINT32	ulNewRinPcmLaw = cOCT6100_INVALID_PCM_LAW;
	UINT32	ulNewRoutPcmLaw = cOCT6100_INVALID_PCM_LAW;
	UINT32	ulNewSinPcmLaw = cOCT6100_INVALID_PCM_LAW;
	UINT32	ulNewSoutPcmLaw	= cOCT6100_INVALID_PCM_LAW;


	/* Obtain local pointer to shared portion of instance. */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	/* Obtain local pointer to the TDM configuration structure of the tPOCT6100_CHANNEL_MODIFY structure. */
	pModifyTdmConf   = &f_pChannelModify->TdmConfig;

	/*=======================================================================*/
	/* Get a pointer to the channel's list entry. */
	mOCT6100_GET_CHANNEL_ENTRY_PNT( pSharedInfo, pChanEntry, f_usChanIndex )

	/* Obtain local pointer to the TDM configuration structure of the tPOCT6100_API_CHANNEL structure. */
	pApiTdmConf   = &pChanEntry->TdmConfig;

	/*===============================================================================*/
	/* Modify TSST resources if required.*/
	if ( f_pChannelModify->fTdmConfigModified == TRUE )
	{
		/* First release any entry that need to be released.*/
		if ( ( pModifyTdmConf->ulRinTimeslot != cOCT6100_KEEP_PREVIOUS_SETTING )

			)
		{
			if ( pChanEntry->usRinTsstIndex != cOCT6100_INVALID_INDEX )
			{
				/* Release the previously reserved entry.*/
				ulResult = Oct6100ApiReleaseTsst( f_pApiInstance, 
												  pChanEntry->TdmConfig.usRinTimeslot,
												  pChanEntry->TdmConfig.usRinStream, 

												  cOCT6100_INPUT_TSST,
												  cOCT6100_INVALID_INDEX );
				if ( ulResult == cOCT6100_ERR_OK  )
				{
					fRinReleased = TRUE;
				}
			}

			fReserveRin = TRUE;
		}

		/* Release SIN port.*/
		if ( ( ulResult == cOCT6100_ERR_OK ) 
			&& ( ( pModifyTdmConf->ulSinTimeslot != cOCT6100_KEEP_PREVIOUS_SETTING )

				) )
		{
			if ( pChanEntry->usSinTsstIndex != cOCT6100_INVALID_INDEX )
			{
				/* Release the previously reserved entry.*/
				ulResult = Oct6100ApiReleaseTsst( f_pApiInstance, 
												  pChanEntry->TdmConfig.usSinTimeslot,
												  pChanEntry->TdmConfig.usSinStream, 

												  cOCT6100_INPUT_TSST,
												  cOCT6100_INVALID_INDEX );
				if ( ulResult == cOCT6100_ERR_OK  )
				{
					fSinReleased = TRUE;
				}
			}

			fReserveSin = TRUE;
		}

		/* Release ROUT port.*/
		if ( ( ulResult == cOCT6100_ERR_OK ) 
			&& ( ( pModifyTdmConf->ulRoutTimeslot != cOCT6100_KEEP_PREVIOUS_SETTING )

				) )
		{
			if ( pChanEntry->usRoutTsstIndex != cOCT6100_INVALID_INDEX )
			{
				/* Release the previously reserved entry.*/
				ulResult = Oct6100ApiReleaseTsst( f_pApiInstance,
												  pChanEntry->TdmConfig.usRoutTimeslot,
												  pChanEntry->TdmConfig.usRoutStream, 

												  cOCT6100_OUTPUT_TSST,
												  cOCT6100_INVALID_INDEX );
				if ( ulResult == cOCT6100_ERR_OK  )
				{
					fRoutReleased = TRUE;
				}
			}

			fReserveRout = TRUE;
		}

		/* Release the SOUT port.*/
		if ( ( ulResult == cOCT6100_ERR_OK ) 
			&& ( ( pModifyTdmConf->ulSoutTimeslot != cOCT6100_KEEP_PREVIOUS_SETTING )

				) )
		{
			if ( pChanEntry->usSoutTsstIndex != cOCT6100_INVALID_INDEX )
			{
				/* Release the previously reserved entry.*/
				ulResult = Oct6100ApiReleaseTsst( f_pApiInstance, 
												  pChanEntry->TdmConfig.usSoutTimeslot,
												  pChanEntry->TdmConfig.usSoutStream, 

												  cOCT6100_OUTPUT_TSST,
												  cOCT6100_INVALID_INDEX );
				if ( ulResult == cOCT6100_ERR_OK  )
				{
					fSoutReleased = TRUE;
				}
			}

			fReserveSout = TRUE;
		}

		/* Now reserve any new entry required.*/
		
		/* Modify RIN port.*/
		if ( ( fReserveRin == TRUE ) && ( ulResult == cOCT6100_ERR_OK ) )
		{
			if ( pModifyTdmConf->ulRinTimeslot != cOCT6100_UNASSIGNED )
			{

				{
					/* Reserve the new TSST.*/
					ulResult = Oct6100ApiReserveTsst( f_pApiInstance, 
												  pModifyTdmConf->ulRinTimeslot, 
												  pModifyTdmConf->ulRinStream, 

	  											  cOCT6100_INPUT_TSST,
												  f_pusNewRinTsstIndex, 
												  NULL );
					if ( ulResult == cOCT6100_ERR_OK  )
					{
						fRinReserved = TRUE;
					}
				}
			}
			else
			{
				*f_pusNewRinTsstIndex = cOCT6100_INVALID_INDEX;
			}
		}
		else
		{
			*f_pusNewRinTsstIndex = cOCT6100_INVALID_INDEX;
		}

		/* Modify SIN port.*/
		if ( ( fReserveSin == TRUE ) && ( ulResult == cOCT6100_ERR_OK ) )
		{
			if ( pModifyTdmConf->ulSinTimeslot != cOCT6100_UNASSIGNED )
			{

				{
					/* Reserve the new TSST.*/
					ulResult = Oct6100ApiReserveTsst( f_pApiInstance, 
												  pModifyTdmConf->ulSinTimeslot, 
												  pModifyTdmConf->ulSinStream, 

	  											  cOCT6100_INPUT_TSST,
												  f_pusNewSinTsstIndex, 
												  NULL );
					if ( ulResult == cOCT6100_ERR_OK )
					{
						fSinReserved = TRUE;
					}
				}
			}
			else
			{
				*f_pusNewSinTsstIndex = cOCT6100_INVALID_INDEX;
			}
		}
		else
		{
			*f_pusNewSinTsstIndex = cOCT6100_INVALID_INDEX;
		}

		/* Modify ROUT port.*/
		if ( ( fReserveRout == TRUE ) && ( ulResult == cOCT6100_ERR_OK ) )
		{
			if ( pModifyTdmConf->ulRoutTimeslot != cOCT6100_UNASSIGNED )
			{

				{
					/* Reserve the new TSST.*/
					ulResult = Oct6100ApiReserveTsst( f_pApiInstance, 
												  pModifyTdmConf->ulRoutTimeslot, 
												  pModifyTdmConf->ulRoutStream, 

	  											  cOCT6100_OUTPUT_TSST,
												  f_pusNewRoutTsstIndex, 
												  NULL );
					if ( ulResult == cOCT6100_ERR_OK  )
					{
						fRoutReserved = TRUE;
					}
				}
			}
			else
			{
				*f_pusNewRoutTsstIndex = cOCT6100_INVALID_INDEX;
			}
		}
		else
		{
			*f_pusNewRoutTsstIndex = cOCT6100_INVALID_INDEX;
		}

		/* Modify SOUT port.*/
		if ( ( fReserveSout == TRUE ) && ( ulResult == cOCT6100_ERR_OK ) )
		{
			if ( pModifyTdmConf->ulSoutTimeslot != cOCT6100_UNASSIGNED )
			{

				{
					/* Reserve the new TSST.*/
					ulResult = Oct6100ApiReserveTsst( f_pApiInstance, 
												  pModifyTdmConf->ulSoutTimeslot, 
												  pModifyTdmConf->ulSoutStream, 

	  											  cOCT6100_OUTPUT_TSST,
												  f_pusNewSoutTsstIndex, 
												  NULL );
					if ( ulResult == cOCT6100_ERR_OK  )
					{
						fSoutReserved = TRUE;
					}
				}
			}
			else
			{
				*f_pusNewSoutTsstIndex = cOCT6100_INVALID_INDEX;
			}
		}
		else
		{
			*f_pusNewSoutTsstIndex = cOCT6100_INVALID_INDEX;
		}

		/* Check if PCM law parameters have changed.  If they did, flag a conversion memory change. */

		/* Rin/Rout stream */
		if ( ulResult == cOCT6100_ERR_OK 
			&& ( pModifyTdmConf->ulRinPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING 
				|| pModifyTdmConf->ulRoutPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING ) )
		{
			if ( pModifyTdmConf->ulRinPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING )
			{
				ulNewRinPcmLaw = pModifyTdmConf->ulRinPcmLaw;
			}
			else
			{
				ulNewRinPcmLaw = pApiTdmConf->byRinPcmLaw;
			}

			if ( pModifyTdmConf->ulRoutPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING )
			{
				ulNewRoutPcmLaw = pModifyTdmConf->ulRoutPcmLaw;
			}
			else
			{
				ulNewRoutPcmLaw = pApiTdmConf->byRoutPcmLaw;
			}

			/* Check if must reprogram law conversion memory */
			if ( ulNewRinPcmLaw != ulNewRoutPcmLaw )
			{
				fRinRoutLawConversionModify = TRUE;
			}
		}

		/* Sin/Sout stream */
		if ( ulResult == cOCT6100_ERR_OK 
			&& ( pModifyTdmConf->ulSinPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING 
				|| pModifyTdmConf->ulSoutPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING )
			&& pChanEntry->usSinSoutConversionMemIndex == cOCT6100_INVALID_INDEX )
		{
			if ( pModifyTdmConf->ulSinPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING )
			{
				ulNewSinPcmLaw = pModifyTdmConf->ulSinPcmLaw;
			}
			else
			{
				ulNewSinPcmLaw = pApiTdmConf->bySinPcmLaw;
			}

			if ( pModifyTdmConf->ulSoutPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING )
			{
				ulNewSoutPcmLaw = pModifyTdmConf->ulSoutPcmLaw;
			}
			else
			{
				ulNewSoutPcmLaw = pApiTdmConf->bySoutPcmLaw;
			}

			/* Check if must reprogram law conversion memory */
			if ( ulNewSinPcmLaw != ulNewSoutPcmLaw )
			{
				fSinSoutLawConversionModify = TRUE;
			}
		}
	}

	/* Check if conversion memories must be reserved for law conversion */
	if ( ( ulResult == cOCT6100_ERR_OK )
		&& ( fRinRoutLawConversionModify == TRUE )
		&& ( pChanEntry->usRinRoutConversionMemIndex == cOCT6100_INVALID_INDEX ) )
	{
		/* The memory was not reserved, proceed. */
		ulResult = Oct6100ApiReserveConversionMemEntry( f_pApiInstance, &pChanEntry->usRinRoutConversionMemIndex );
		if ( ulResult == cOCT6100_ERR_OK  )
		{
			fRinRoutConversionMemReserved = TRUE;
		}
	}

	if ( ( ulResult == cOCT6100_ERR_OK )
		&& ( fSinSoutLawConversionModify == TRUE )
		&& ( pChanEntry->usSinSoutConversionMemIndex == cOCT6100_INVALID_INDEX ) )
	{
		/* The memory was not reserved, proceed. */
		ulResult = Oct6100ApiReserveConversionMemEntry( f_pApiInstance, &pChanEntry->usSinSoutConversionMemIndex );
		if ( ulResult == cOCT6100_ERR_OK  )
		{
			fSinSoutConversionMemReserved = TRUE;
		}
	}


	/*===============================================================================*/
	/* Check if there are a couple of mixer events available for us. */

	if ( ulResult == cOCT6100_ERR_OK )
	{
		/* No mixer is needed if the TDM config has not been modified */
		if ( f_pChannelModify->fTdmConfigModified == TRUE )
		{		
			UINT32 ulMixerEventCntNeeded = 0;

			/* Calculate how many mixer events are needed. */

			{
				/* If the channel is in bidir mode, do not create the Rin silence event!!! */
				if ( pChanEntry->fBiDirChannel == FALSE )
				{
					if ( ( *f_pusNewRinTsstIndex == cOCT6100_INVALID_INDEX )
						&& ( pChanEntry->usRinSilenceEventIndex == cOCT6100_INVALID_INDEX ) )
						ulMixerEventCntNeeded++;
				}
			}

			if ( ( *f_pusNewSinTsstIndex == cOCT6100_INVALID_INDEX )
				&& ( pChanEntry->usSinSilenceEventIndex == cOCT6100_INVALID_INDEX ) )
			{
				ulMixerEventCntNeeded++;
			}

			/* If at least 1 mixer event is needed, check if those are available. */
			if ( ulMixerEventCntNeeded != 0 )
			{
				ulResult = Oct6100ApiGetFreeMixerEventCnt( f_pApiInstance, &ulFreeMixerEventCnt );
				if ( ulResult == cOCT6100_ERR_OK )
				{
					/* The API might need more mixer events if the ports have to be muted. */
					/* Check if these are available. */
					if ( ulFreeMixerEventCnt < ulMixerEventCntNeeded )
					{
						ulResult = cOCT6100_ERR_CHANNEL_OUT_OF_MIXER_EVENTS;
					}
				}
			}
		}
	}

	/*===============================================================================*/

	/* Verify if an error occured. */
	if ( ulResult != cOCT6100_ERR_OK )
	{
		/* Release any resources newly reserved.*/
		if ( fRinReserved == TRUE )
		{
			ulTempVar = Oct6100ApiReleaseTsst( f_pApiInstance, 
											  pModifyTdmConf->ulRinTimeslot,
											  pModifyTdmConf->ulRinStream, 

											  cOCT6100_INPUT_TSST,
											  cOCT6100_INVALID_INDEX );
			if ( ulTempVar != cOCT6100_ERR_OK )
				return ulTempVar;
		}

		/* For the SIN port.*/
		if ( fSinReserved == TRUE )
		{
			ulTempVar = Oct6100ApiReleaseTsst( f_pApiInstance, 
											  pModifyTdmConf->ulSinTimeslot,
											  pModifyTdmConf->ulSinStream, 

											  cOCT6100_INPUT_TSST,
											  cOCT6100_INVALID_INDEX );
			if ( ulTempVar != cOCT6100_ERR_OK )
				return ulTempVar;
		}

		/* For the ROUT port.*/
		if ( fRoutReserved == TRUE )
		{
			ulTempVar = Oct6100ApiReleaseTsst( f_pApiInstance, 
											  pModifyTdmConf->ulRoutTimeslot,
											  pModifyTdmConf->ulRoutStream, 

											  cOCT6100_OUTPUT_TSST,
											  cOCT6100_INVALID_INDEX );
			if ( ulTempVar != cOCT6100_ERR_OK )
				return ulTempVar;
		}

		/* For the SOUT port.*/
		if ( fSoutReserved == TRUE )
		{
			ulTempVar = Oct6100ApiReleaseTsst( f_pApiInstance, 
											  pModifyTdmConf->ulSoutTimeslot,
											  pModifyTdmConf->ulSoutStream, 

											  cOCT6100_OUTPUT_TSST,
											  cOCT6100_INVALID_INDEX );
			if ( ulTempVar != cOCT6100_ERR_OK )
				return ulTempVar;
		}

		/* Now make sure any resources released gets reserved back again.*/

		/* For the RIN port.*/
		if ( fRinReleased == TRUE )
		{
			/* Reserve the new TSST.*/
			ulTempVar = Oct6100ApiReserveTsst( f_pApiInstance, 
											  pChanEntry->TdmConfig.usRinTimeslot, 
											  pChanEntry->TdmConfig.usRinStream, 

	  										  cOCT6100_INPUT_TSST,
											  &pChanEntry->usRinTsstIndex, 
											  NULL );
			if ( ulTempVar != cOCT6100_ERR_OK )
				return ulTempVar;
		}

		/* For the SIN port.*/
		if ( fSinReleased == TRUE )
		{
			/* Reserve the new TSST.*/
			ulTempVar = Oct6100ApiReserveTsst( f_pApiInstance, 
											  pChanEntry->TdmConfig.usSinTimeslot, 
											  pChanEntry->TdmConfig.usSinStream, 

	  										  cOCT6100_INPUT_TSST,
											  &pChanEntry->usSinTsstIndex, 
											  NULL );
			if ( ulTempVar != cOCT6100_ERR_OK )
				return ulTempVar;
		}

		/* For the ROUT port.*/
		if ( fRoutReleased == TRUE )
		{
			/* Reserve the new TSST.*/
			ulTempVar = Oct6100ApiReserveTsst( f_pApiInstance, 
											  pChanEntry->TdmConfig.usRoutTimeslot, 
											  pChanEntry->TdmConfig.usRoutStream, 

	  										  cOCT6100_OUTPUT_TSST,
											  &pChanEntry->usRoutTsstIndex, 
											  NULL );
			if ( ulTempVar != cOCT6100_ERR_OK )
				return ulTempVar;
		}

		/* For the SOUT port.*/
		if ( fSoutReleased == TRUE )
		{
			/* Reserve the new TSST.*/
			ulTempVar = Oct6100ApiReserveTsst( f_pApiInstance, 
											  pChanEntry->TdmConfig.usSoutTimeslot, 
											  pChanEntry->TdmConfig.usSoutStream, 

	  										  cOCT6100_OUTPUT_TSST,
											  &pChanEntry->usSoutTsstIndex, 
											  NULL );
			if ( ulTempVar != cOCT6100_ERR_OK )
				return ulTempVar;
		}

		/* Release the conversion memories if they were reserved.*/
		if ( fRinRoutConversionMemReserved == TRUE )
		{
			ulTempVar = Oct6100ApiReleaseConversionMemEntry( f_pApiInstance, 
													    pChanEntry->usRinRoutConversionMemIndex );
			if ( ulTempVar != cOCT6100_ERR_OK )
				return ulTempVar;
		}

		if ( fSinSoutConversionMemReserved == TRUE )
		{
			ulTempVar = Oct6100ApiReleaseConversionMemEntry( f_pApiInstance, 
													    pChanEntry->usSinSoutConversionMemIndex );
			if ( ulTempVar != cOCT6100_ERR_OK )
				return ulTempVar;
		}
		
		/* Now return the error.*/
		return ulResult;
	}

	return cOCT6100_ERR_OK;
}


/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiModifyChannelStructs

Description:    Performs all the required structure writes to configure the
				echo cancellation channel based on the new modifications.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance				Pointer to API instance. This memory is used to keep the
							present state of the chip and all its resources.
					
f_pChannelModify			Pointer to echo cancellation channel configuration structure.
f_pChannelOpen				Pointer to a structure used to store the multiple resources indexes.
f_usChanIndex				Index of the channel within the API's channel list.
f_usNewPhasingTsstIndex		Index of the new phasing TSST.
f_pfSinSoutCodecActive		Pointer to the state of the SIN/SOUT codec.
f_pfRinRoutCodecActive		Pointer to the state of the RIN/ROUT codec.
f_usNewRinTsstIndex			New RIN TSST memory index.
f_usNewSinTsstIndex			New SIN TSST memory index.
f_usNewRoutTsstIndex		New ROUT TSST memory index.
f_usNewSoutTsstIndex		New SOUT TSST memory index.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiModifyChannelStructs(
				IN	tPOCT6100_INSTANCE_API			f_pApiInstance,
				IN	tPOCT6100_CHANNEL_MODIFY		f_pChannelModify, 
				IN	tPOCT6100_CHANNEL_OPEN			f_pChannelOpen, 
				IN	UINT16							f_usChanIndex,

				IN	UINT16							f_usNewRinTsstIndex,
				IN	UINT16							f_usNewSinTsstIndex,
				IN	UINT16							f_usNewRoutTsstIndex,
				IN	UINT16							f_usNewSoutTsstIndex )
{
	tPOCT6100_API_CHANNEL		pChanEntry;
	tPOCT6100_SHARED_INFO	pSharedInfo;
	tOCT6100_READ_PARAMS	ReadParams;
	tOCT6100_WRITE_PARAMS	WriteParams;

	tPOCT6100_API_CHANNEL_TDM	pApiTdmConf;
	tPOCT6100_API_CHANNEL_VQE	pApiVqeConf;

	UINT32	ulResult;
	UINT16	usReadData;

	UINT16	usSinTsstIndex;
	UINT16	usRinTsstIndex;






	UINT32	ulNewRinPcmLaw = cOCT6100_INVALID_PCM_LAW;
	UINT32	ulNewRoutPcmLaw = cOCT6100_INVALID_PCM_LAW;
	UINT32	ulNewSinPcmLaw = cOCT6100_INVALID_PCM_LAW;
	UINT32	ulNewSoutPcmLaw = cOCT6100_INVALID_PCM_LAW;

	/* Obtain local pointer to shared portion of instance. */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	WriteParams.pProcessContext = f_pApiInstance->pProcessContext;

	WriteParams.ulUserChipId = pSharedInfo->ChipConfig.ulUserChipId;

	ReadParams.pProcessContext = f_pApiInstance->pProcessContext;

	ReadParams.ulUserChipId = pSharedInfo->ChipConfig.ulUserChipId;
	ReadParams.pusReadData = &usReadData;

	/*=======================================================================*/
	/* Get a pointer to the channel's list entry. */
	mOCT6100_GET_CHANNEL_ENTRY_PNT( pSharedInfo, pChanEntry, f_usChanIndex )

	/* Obtain local pointer to the configuration structures of the tPOCT6100_API_CHANNEL structure. */

	pApiTdmConf   = &pChanEntry->TdmConfig;
	pApiVqeConf   = &pChanEntry->VqeConfig;

	/*=======================================================================*/
	/* Init the RIN and SIN TSST index */
	
	usRinTsstIndex = pChanEntry->usRinTsstIndex;
	usSinTsstIndex = pChanEntry->usSinTsstIndex;


	/*==============================================================================*/
	/* Clear the TSST that will be release.*/

	if ( f_pChannelModify->fTdmConfigModified == TRUE )	
	{
		/* Modify RIN port.*/
		if ( f_pChannelModify->TdmConfig.ulRinTimeslot != cOCT6100_KEEP_PREVIOUS_SETTING )
		{
			if ( pChanEntry->usRinTsstIndex != cOCT6100_INVALID_INDEX )
			{
				/* Clear the previous entry  */
				WriteParams.ulWriteAddress = cOCT6100_TSST_CONTROL_MEM_BASE + ( (pChanEntry->usRinTsstIndex & cOCT6100_TSST_INDEX_MASK) * cOCT6100_TSST_CONTROL_MEM_ENTRY_SIZE );
				WriteParams.usWriteData  = 0x0000;

				mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
				if ( ulResult != cOCT6100_ERR_OK  )
					return ulResult;
			}
		}

		/* Modify SIN port.*/
		if ( f_pChannelModify->TdmConfig.ulSinTimeslot != cOCT6100_KEEP_PREVIOUS_SETTING )
		{
			if ( pChanEntry->usSinTsstIndex != cOCT6100_INVALID_INDEX )
			{
				/* Clear the previous entry  */
				WriteParams.ulWriteAddress = cOCT6100_TSST_CONTROL_MEM_BASE + ( (pChanEntry->usSinTsstIndex & cOCT6100_TSST_INDEX_MASK) * cOCT6100_TSST_CONTROL_MEM_ENTRY_SIZE );
				WriteParams.usWriteData  = 0x0000;

				mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
				if ( ulResult != cOCT6100_ERR_OK  )
					return ulResult;
			}
		}

		/* Modify ROUT port.*/
		if ( f_pChannelModify->TdmConfig.ulRoutTimeslot != cOCT6100_KEEP_PREVIOUS_SETTING )
		{
			if ( pChanEntry->usRoutTsstIndex != cOCT6100_INVALID_INDEX )
			{
				/* Clear the previous entry  */
				WriteParams.ulWriteAddress = cOCT6100_TSST_CONTROL_MEM_BASE + ( (pChanEntry->usRoutTsstIndex & cOCT6100_TSST_INDEX_MASK) * cOCT6100_TSST_CONTROL_MEM_ENTRY_SIZE );
				WriteParams.usWriteData  = 0x0000;

				mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
				if ( ulResult != cOCT6100_ERR_OK  )
					return ulResult;
			}
		}

		/* Modify SOUT port.*/
		if ( f_pChannelModify->TdmConfig.ulSoutTimeslot != cOCT6100_KEEP_PREVIOUS_SETTING)
		{
			if ( pChanEntry->usSoutTsstIndex != cOCT6100_INVALID_INDEX )
			{
				/* Clear the previous entry  */
				WriteParams.ulWriteAddress = cOCT6100_TSST_CONTROL_MEM_BASE + ( (pChanEntry->usSoutTsstIndex & cOCT6100_TSST_INDEX_MASK) * cOCT6100_TSST_CONTROL_MEM_ENTRY_SIZE );
				WriteParams.usWriteData  = 0x0000;

				mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
				if ( ulResult != cOCT6100_ERR_OK  )
					return ulResult;
			}
		}
	}
	/*==============================================================================*/

	
	/*==============================================================================*/
	/* Now, Configure the Tsst control memory.*/

	if ( f_pChannelModify->fTdmConfigModified == TRUE )	
	{
		/* Modify RIN port.*/
		if ( f_pChannelModify->TdmConfig.ulRinTimeslot != cOCT6100_KEEP_PREVIOUS_SETTING )
		{
			usRinTsstIndex = f_usNewRinTsstIndex;

			if ( f_usNewRinTsstIndex != cOCT6100_INVALID_INDEX )
			{
				if ( pChanEntry->usExtraRinTsiMemIndex != cOCT6100_INVALID_INDEX )
				{
					ulResult = Oct6100ApiWriteInputTsstControlMemory( f_pApiInstance,
																	  f_usNewRinTsstIndex,
																	  pChanEntry->usExtraRinTsiMemIndex,
																	  f_pChannelOpen->TdmConfig.ulRinPcmLaw );
					if ( ulResult != cOCT6100_ERR_OK  )
						return ulResult;
				}
				else
				{
					ulResult = Oct6100ApiWriteInputTsstControlMemory( f_pApiInstance,
																	  f_usNewRinTsstIndex,
																	  pChanEntry->usRinRoutTsiMemIndex,
																	  f_pChannelOpen->TdmConfig.ulRinPcmLaw );
					if ( ulResult != cOCT6100_ERR_OK  )
						return ulResult;
				}
			}
		}
		if ( f_pChannelModify->TdmConfig.ulRinTimeslot == cOCT6100_KEEP_PREVIOUS_SETTING &&
			 f_pChannelModify->TdmConfig.ulRinPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING )
		{
			if ( pChanEntry->usExtraRinTsiMemIndex != cOCT6100_INVALID_INDEX )
			{
				if ( pChanEntry->usRinTsstIndex != cOCT6100_INVALID_INDEX )
				{
					ulResult = Oct6100ApiWriteInputTsstControlMemory( f_pApiInstance,
																	  pChanEntry->usRinTsstIndex,
																	  pChanEntry->usExtraRinTsiMemIndex,
																	  f_pChannelOpen->TdmConfig.ulRinPcmLaw );
					if ( ulResult != cOCT6100_ERR_OK  )
						return ulResult;
				}
			}
			else
			{
				if ( pChanEntry->usRinTsstIndex != cOCT6100_INVALID_INDEX )
				{
					ulResult = Oct6100ApiWriteInputTsstControlMemory( f_pApiInstance,
																	  pChanEntry->usRinTsstIndex,
																	  pChanEntry->usRinRoutTsiMemIndex,
																	  f_pChannelOpen->TdmConfig.ulRinPcmLaw );
					if ( ulResult != cOCT6100_ERR_OK  )
						return ulResult;
				}
			}
		}

		/* Modify SIN port.*/
		if ( f_pChannelModify->TdmConfig.ulSinTimeslot != cOCT6100_KEEP_PREVIOUS_SETTING )
		{
			usSinTsstIndex = f_usNewSinTsstIndex;

			if ( f_usNewSinTsstIndex != cOCT6100_INVALID_INDEX )
			{
				if ( pChanEntry->usExtraSinTsiMemIndex != cOCT6100_INVALID_INDEX )
				{
					/* Write the new entry now.*/
					ulResult = Oct6100ApiWriteInputTsstControlMemory( f_pApiInstance,
																	  f_usNewSinTsstIndex,
																	  pChanEntry->usExtraSinTsiMemIndex,
																	  f_pChannelOpen->TdmConfig.ulSinPcmLaw );
					if ( ulResult != cOCT6100_ERR_OK  )
						return ulResult;
				}
				else
				{
					/* Write the new entry now.*/
					ulResult = Oct6100ApiWriteInputTsstControlMemory( f_pApiInstance,
																	  f_usNewSinTsstIndex,
																	  pChanEntry->usSinSoutTsiMemIndex,
																	  f_pChannelOpen->TdmConfig.ulSinPcmLaw );
					if ( ulResult != cOCT6100_ERR_OK  )
						return ulResult;
				}
			}
		}
		if ( f_pChannelModify->TdmConfig.ulSinTimeslot == cOCT6100_KEEP_PREVIOUS_SETTING &&
			 f_pChannelModify->TdmConfig.ulSinPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING )
		{
			if ( pChanEntry->usExtraSinTsiMemIndex != cOCT6100_INVALID_INDEX )
			{
				if ( pChanEntry->usSinTsstIndex != cOCT6100_INVALID_INDEX )
				{
					ulResult = Oct6100ApiWriteInputTsstControlMemory( f_pApiInstance,
																	  pChanEntry->usSinTsstIndex ,
																	  pChanEntry->usExtraSinTsiMemIndex,
																	  f_pChannelOpen->TdmConfig.ulSinPcmLaw );
					if ( ulResult != cOCT6100_ERR_OK  )
						return ulResult;
				}
			}
			else
			{
				if ( pChanEntry->usSinTsstIndex != cOCT6100_INVALID_INDEX )
				{
					ulResult = Oct6100ApiWriteInputTsstControlMemory( f_pApiInstance,
																	  pChanEntry->usSinTsstIndex ,
																	  pChanEntry->usSinSoutTsiMemIndex,
																	  f_pChannelOpen->TdmConfig.ulSinPcmLaw );
					if ( ulResult != cOCT6100_ERR_OK  )
						return ulResult;
				}
			}
		}

		/* Modify ROUT port.*/
		if ( ( f_pChannelModify->TdmConfig.ulRoutTimeslot != cOCT6100_KEEP_PREVIOUS_SETTING )

			)
		{
			if ( f_usNewRoutTsstIndex != cOCT6100_INVALID_INDEX )
			{

				{
					/* If this output port is not muted. */
					if ( ( pChanEntry->usMutedPorts & cOCT6100_CHANNEL_MUTE_PORT_ROUT ) == 0x0 )
					{
						/* Write the new entry now.*/
						ulResult = Oct6100ApiWriteOutputTsstControlMemory( f_pApiInstance,
																   f_usNewRoutTsstIndex,

																   pChanEntry->usRinRoutTsiMemIndex );
						if ( ulResult != cOCT6100_ERR_OK  )
							return ulResult;
					}
				}
			}
		}

		/* Modify SOUT port.*/
		if ( ( f_pChannelModify->TdmConfig.ulSoutTimeslot != cOCT6100_KEEP_PREVIOUS_SETTING )

			)
		{
			if ( f_usNewSoutTsstIndex != cOCT6100_INVALID_INDEX )
			{

				{
					/* If this output port is not muted. */
					if ( ( pChanEntry->usMutedPorts & cOCT6100_CHANNEL_MUTE_PORT_SOUT ) == 0x0 )
					{
						/* Write the new entry now.*/
						ulResult = Oct6100ApiWriteOutputTsstControlMemory( f_pApiInstance,
																   f_usNewSoutTsstIndex,

																   pChanEntry->usSinSoutTsiMemIndex );

						if ( ulResult != cOCT6100_ERR_OK  )
							return ulResult;
					}
				}
			}
		}

		/* Check if the conversion memory was reserved. */

		/* Rin/Rout stream */
		if ( pChanEntry->usRinRoutConversionMemIndex != cOCT6100_INVALID_INDEX
			&& ( f_pChannelModify->TdmConfig.ulRinPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING 
			|| f_pChannelModify->TdmConfig.ulRoutPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING ) )
		{
			if ( f_pChannelModify->TdmConfig.ulRinPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING )
			{
				ulNewRinPcmLaw = f_pChannelModify->TdmConfig.ulRinPcmLaw;
			}
			else
			{
				ulNewRinPcmLaw = pApiTdmConf->byRinPcmLaw;
			}

			if ( f_pChannelModify->TdmConfig.ulRoutPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING )
			{
				ulNewRoutPcmLaw = f_pChannelModify->TdmConfig.ulRoutPcmLaw;
			}
			else
			{
				ulNewRoutPcmLaw = pApiTdmConf->byRoutPcmLaw;
			}

			/* Check if must reprogram law conversion memory */
			if ( ( ulNewRinPcmLaw != ulNewRoutPcmLaw )
				&& ( f_pChannelOpen->TdmConfig.ulRinStream != cOCT6100_UNASSIGNED ) 
				&& ( f_pChannelOpen->TdmConfig.ulRoutStream != cOCT6100_UNASSIGNED ) )
			{
				ulResult = Oct6100ApiWriteLawConversionMemory( 
										f_pApiInstance,
										pChanEntry->usRinRoutConversionMemIndex,
										pChanEntry->usRinRoutTsiMemIndex,
										ulNewRoutPcmLaw,
										TRUE );
				if ( ulResult != cOCT6100_ERR_OK  )
					return ulResult;				
			}
			else
			{
				ulResult = Oct6100ApiClearConversionMemory( 
										f_pApiInstance,
										pChanEntry->usRinRoutConversionMemIndex );
				if ( ulResult != cOCT6100_ERR_OK  )
					return ulResult;				
			}
		}

		/* Sin/Sout stream */
		if ( pChanEntry->usSinSoutConversionMemIndex != cOCT6100_INVALID_INDEX
			&& ( f_pChannelModify->TdmConfig.ulSinPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING 
				|| f_pChannelModify->TdmConfig.ulSoutPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING ) )
		{
			if ( f_pChannelModify->TdmConfig.ulSinPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING )
			{
				ulNewSinPcmLaw = f_pChannelModify->TdmConfig.ulSinPcmLaw;
			}
			else
			{
				ulNewSinPcmLaw = pApiTdmConf->bySinPcmLaw;
			}

			if ( f_pChannelModify->TdmConfig.ulSoutPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING )
			{
				ulNewSoutPcmLaw = f_pChannelModify->TdmConfig.ulSoutPcmLaw;
			}
			else
			{
				ulNewSoutPcmLaw = pApiTdmConf->bySoutPcmLaw;
			}

			/* Check if must reprogram law conversion memory */
			if ( ( ulNewSinPcmLaw != ulNewSoutPcmLaw )
				&& ( f_pChannelOpen->TdmConfig.ulSinStream != cOCT6100_UNASSIGNED ) 
				&& ( f_pChannelOpen->TdmConfig.ulSoutStream != cOCT6100_UNASSIGNED ) )
			{
				ulResult = Oct6100ApiWriteLawConversionMemory( 
										f_pApiInstance,
										pChanEntry->usSinSoutConversionMemIndex,
										pChanEntry->usSinSoutTsiMemIndex,
										ulNewSoutPcmLaw,
										FALSE );
				if ( ulResult != cOCT6100_ERR_OK  )
					return ulResult;	
			}
			else
			{
				ulResult = Oct6100ApiClearConversionMemory( 
										f_pApiInstance,
										pChanEntry->usSinSoutConversionMemIndex );
				if ( ulResult != cOCT6100_ERR_OK  )
					return ulResult;		
			}
		}


	}

	/*==============================================================================*/






	
	/*==============================================================================*/
	/* Modify the VQE parameter if required.*/

	if ( ( f_pChannelModify->fVqeConfigModified == TRUE )
		|| ( (UINT8)f_pChannelOpen->ulEchoOperationMode != pChanEntry->byEchoOperationMode )
		|| ( f_pChannelOpen->fEnableToneDisabler != pChanEntry->fEnableToneDisabler ) )
	{
		ulResult = Oct6100ApiWriteVqeMemory( f_pApiInstance,
											  &f_pChannelOpen->VqeConfig,
											  f_pChannelOpen,
											  f_usChanIndex,
											  pChanEntry->usEchoMemIndex,
											  FALSE,
											  TRUE );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;
	}

	/*==============================================================================*/
	/* Modify the Echo memory if required.*/
	if ( f_pChannelModify->fEnableToneDisabler		 != cOCT6100_KEEP_PREVIOUS_SETTING ||
		 f_pChannelModify->ulEchoOperationMode       != cOCT6100_KEEP_PREVIOUS_SETTING ||
		 f_pChannelModify->TdmConfig.ulRinPcmLaw	 != cOCT6100_KEEP_PREVIOUS_SETTING ||
		 f_pChannelModify->TdmConfig.ulSinPcmLaw	 != cOCT6100_KEEP_PREVIOUS_SETTING ||
		 f_pChannelModify->TdmConfig.ulRoutPcmLaw	 != cOCT6100_KEEP_PREVIOUS_SETTING ||
		 f_pChannelModify->TdmConfig.ulSoutPcmLaw	 != cOCT6100_KEEP_PREVIOUS_SETTING )
	{
		ulResult = Oct6100ApiWriteEchoMemory( f_pApiInstance,
											  &f_pChannelOpen->TdmConfig,
											  f_pChannelOpen,
											  pChanEntry->usEchoMemIndex,
											  pChanEntry->usRinRoutTsiMemIndex,
											  pChanEntry->usSinSoutTsiMemIndex );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;
		

	}

	/*==============================================================================*/
	/* Modify the Mixer events if law changes are requested. */
	
	if ( pChanEntry->usSinCopyEventIndex != cOCT6100_INVALID_INDEX && 
		 f_pChannelModify->TdmConfig.ulSinPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING )
	{
		ReadParams.ulReadAddress = cOCT6100_MIXER_CONTROL_MEM_BASE + ( pChanEntry->usSinCopyEventIndex * cOCT6100_MIXER_CONTROL_MEM_ENTRY_SIZE );

		mOCT6100_DRIVER_READ_API( ReadParams, ulResult );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;

		/* Modify the value according to the new law.*/
		if ( f_pChannelModify->TdmConfig.ulSinPcmLaw == cOCT6100_PCM_A_LAW )
			WriteParams.usWriteData = (UINT16)( usReadData | ( f_pChannelModify->TdmConfig.ulSinPcmLaw << cOCT6100_MIXER_CONTROL_MEM_LAW_OFFSET ));
		else
			WriteParams.usWriteData = (UINT16)( usReadData & (~( f_pChannelModify->TdmConfig.ulSinPcmLaw << cOCT6100_MIXER_CONTROL_MEM_LAW_OFFSET )));

		/* Write back the new value.*/
		WriteParams.ulWriteAddress = ReadParams.ulReadAddress;

		mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;
	}

	if ( pChanEntry->usSoutCopyEventIndex != cOCT6100_INVALID_INDEX && 
		 f_pChannelModify->TdmConfig.ulSoutPcmLaw != cOCT6100_KEEP_PREVIOUS_SETTING )
	{
		ReadParams.ulReadAddress = cOCT6100_MIXER_CONTROL_MEM_BASE + ( pChanEntry->usSoutCopyEventIndex * cOCT6100_MIXER_CONTROL_MEM_ENTRY_SIZE );

		mOCT6100_DRIVER_READ_API( ReadParams, ulResult );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;

		/* Modify the value according to the new law.*/
		if ( f_pChannelModify->TdmConfig.ulSoutPcmLaw == cOCT6100_PCM_A_LAW )
			WriteParams.usWriteData = (UINT16)( usReadData | ( f_pChannelModify->TdmConfig.ulSoutPcmLaw << cOCT6100_MIXER_CONTROL_MEM_LAW_OFFSET ));
		else
			WriteParams.usWriteData = (UINT16)( usReadData & (~( f_pChannelModify->TdmConfig.ulSoutPcmLaw << cOCT6100_MIXER_CONTROL_MEM_LAW_OFFSET )));

		/* Write back the new value.*/
		WriteParams.ulWriteAddress = ReadParams.ulReadAddress;

		mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;
	}

	/*==============================================================================*/
	/*	Mute channel if required, this is done on a port basis */
	
	ulResult = Oct6100ApiMutePorts( f_pApiInstance,
									f_usChanIndex,
									usRinTsstIndex,
									usSinTsstIndex,
									TRUE );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	/*==============================================================================*/





	return cOCT6100_ERR_OK;
}



/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiModifyChannelEntry

Description:    Updates the channel structure in the ECHO channel list.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance				Pointer to API instance. This memory is used to keep
							the present state of the chip and all its resources.

f_pChannelModify			Pointer to echo cancellation channel modify structure.
f_pChannelOpen				Pointer to echo cancellation channel configuration structure.
f_usChanIndex				Index of the channel within the API's channel list.
f_usNewPhasingTsstIndex		Index of the new phasing TSST.
f_fSinSoutCodecActive		State of the SIN/SOUT codec.
f_fRinRoutCodecActive		State of the RIN/ROUT codec.
f_usNewRinTsstIndex			New RIN TSST memory index.
f_usNewSinTsstIndex			New SIN TSST memory index.
f_usNewRoutTsstIndex		New ROUT TSST memory index.
f_usNewSoutTsstIndex		New SOUT TSST memory index.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiModifyChannelEntry(
				IN tPOCT6100_INSTANCE_API			f_pApiInstance,
				IN tPOCT6100_CHANNEL_MODIFY			f_pChannelModify,
				IN tPOCT6100_CHANNEL_OPEN			f_pChannelOpen,
				IN UINT16							f_usChanIndex,

				IN UINT16							f_usNewRinTsstIndex,
				IN UINT16							f_usNewSinTsstIndex,
				IN UINT16							f_usNewRoutTsstIndex,
				IN UINT16							f_usNewSoutTsstIndex )
{
	tPOCT6100_SHARED_INFO		pSharedInfo;
	tPOCT6100_API_CHANNEL		pChanEntry;

	tPOCT6100_API_CHANNEL_TDM	pApiTdmConf;
	tPOCT6100_API_CHANNEL_VQE	pApiVqeConf;

	/* Obtain local pointer to shared portion of instance. */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	/*=======================================================================*/
	/* Get a pointer to the channel's list entry. */
	mOCT6100_GET_CHANNEL_ENTRY_PNT( pSharedInfo, pChanEntry, f_usChanIndex )

	/* Obtain local pointer to the configuration structures of the tPOCT6100_API_CHANNEL structure. */

	pApiTdmConf   = &pChanEntry->TdmConfig;
	pApiVqeConf   = &pChanEntry->VqeConfig;

	/*=======================================================================*/
	/* Update num active channel stats. */
	{
		UINT8	byOpenEchoMode;

		byOpenEchoMode = (UINT8)( f_pChannelOpen->ulEchoOperationMode & 0xFF );

		if ( pChanEntry->byEchoOperationMode != byOpenEchoMode )
		{
			if ( pChanEntry->byEchoOperationMode == cOCT6100_ECHO_OP_MODE_POWER_DOWN )
			{				
				f_pApiInstance->pSharedInfo->MiscVars.ulNumActiveChannels++;
			}
			else if ( byOpenEchoMode == cOCT6100_ECHO_OP_MODE_POWER_DOWN )
			{			
				f_pApiInstance->pSharedInfo->MiscVars.ulNumActiveChannels--;
			}
		}
	}
	/*=======================================================================*/

	/*=======================================================================*/
	/* Copy the channel's general configuration. */

	pChanEntry->ulUserChanId = f_pChannelOpen->ulUserChanId;
	pChanEntry->byEchoOperationMode = (UINT8)( f_pChannelOpen->ulEchoOperationMode & 0xFF );
	pChanEntry->fEnableToneDisabler = (UINT8)( f_pChannelOpen->fEnableToneDisabler & 0xFF );



	/*=======================================================================*/
	/* Copy the channel's TDM configuration of all the modified fields. */

	if ( f_pChannelModify->fTdmConfigModified == TRUE )
	{
		pApiTdmConf->byRinPcmLaw = (UINT8)( f_pChannelOpen->TdmConfig.ulRinPcmLaw & 0xFF );
		pApiTdmConf->bySinPcmLaw = (UINT8)( f_pChannelOpen->TdmConfig.ulSinPcmLaw & 0xFF );
		pApiTdmConf->byRoutPcmLaw = (UINT8)( f_pChannelOpen->TdmConfig.ulRoutPcmLaw & 0xFF );
		pApiTdmConf->bySoutPcmLaw = (UINT8)( f_pChannelOpen->TdmConfig.ulSoutPcmLaw & 0xFF );



		if ( f_pChannelModify->TdmConfig.ulRinTimeslot != cOCT6100_KEEP_PREVIOUS_SETTING ) 
		{
			if ( f_usNewRinTsstIndex != cOCT6100_INVALID_INDEX )
			{
				pApiTdmConf->usRinStream	= (UINT16)( f_pChannelOpen->TdmConfig.ulRinStream & 0xFFFF );
				pApiTdmConf->usRinTimeslot	= (UINT16)( f_pChannelOpen->TdmConfig.ulRinTimeslot & 0xFFFF );
				pChanEntry->usRinTsstIndex	= f_usNewRinTsstIndex;
			}
			else /* f_ulNewRinTsstIndex != cOCT6100_INVALID_INDEX */
			{
				pApiTdmConf->usRinStream	= cOCT6100_UNASSIGNED;
				pApiTdmConf->usRinTimeslot	= cOCT6100_UNASSIGNED;
				pChanEntry->usRinTsstIndex	= cOCT6100_INVALID_INDEX;
			}
		}

		if ( f_pChannelModify->TdmConfig.ulSinTimeslot != cOCT6100_KEEP_PREVIOUS_SETTING ) 
		{
			if ( f_usNewSinTsstIndex != cOCT6100_INVALID_INDEX )
			{
				pApiTdmConf->usSinStream	= (UINT16)( f_pChannelOpen->TdmConfig.ulSinStream & 0xFFFF );
				pApiTdmConf->usSinTimeslot	= (UINT16)( f_pChannelOpen->TdmConfig.ulSinTimeslot & 0xFFFF );
				pChanEntry->usSinTsstIndex	= f_usNewSinTsstIndex;
			}
			else /* f_ulNewSinTsstIndex != cOCT6100_INVALID_INDEX */
			{
				pApiTdmConf->usSinStream	= cOCT6100_UNASSIGNED;
				pApiTdmConf->usSinTimeslot	= cOCT6100_UNASSIGNED;
				pChanEntry->usSinTsstIndex	= cOCT6100_INVALID_INDEX;
			}
		}

		if ( f_pChannelModify->TdmConfig.ulRoutTimeslot != cOCT6100_KEEP_PREVIOUS_SETTING ) 
		{
			if ( f_usNewRoutTsstIndex != cOCT6100_INVALID_INDEX )
			{
				pApiTdmConf->usRoutStream	= (UINT16)( f_pChannelOpen->TdmConfig.ulRoutStream & 0xFFFF );
				pApiTdmConf->usRoutTimeslot	= (UINT16)( f_pChannelOpen->TdmConfig.ulRoutTimeslot & 0xFFFF );
				pChanEntry->usRoutTsstIndex	= f_usNewRoutTsstIndex;
			}
			else /* f_ulNewRoutTsstIndex != cOCT6100_INVALID_INDEX */
			{
				pApiTdmConf->usRoutStream	= cOCT6100_UNASSIGNED;
				pApiTdmConf->usRoutTimeslot	= cOCT6100_UNASSIGNED;
				pChanEntry->usRoutTsstIndex	= cOCT6100_INVALID_INDEX;
			}
		}

		if ( f_pChannelModify->TdmConfig.ulSoutTimeslot != cOCT6100_KEEP_PREVIOUS_SETTING ) 
		{
			if ( f_usNewSoutTsstIndex != cOCT6100_INVALID_INDEX )
			{
				pApiTdmConf->usSoutStream	= (UINT16)( f_pChannelOpen->TdmConfig.ulSoutStream & 0xFFFF );
				pApiTdmConf->usSoutTimeslot	= (UINT16)( f_pChannelOpen->TdmConfig.ulSoutTimeslot & 0xFFFF );
				pChanEntry->usSoutTsstIndex	= f_usNewSoutTsstIndex;
			}
			else /* f_ulNewSoutTsstIndex != cOCT6100_INVALID_INDEX */
			{
				pApiTdmConf->usSoutStream	= cOCT6100_UNASSIGNED;
				pApiTdmConf->usSoutTimeslot	= cOCT6100_UNASSIGNED;
				pChanEntry->usSoutTsstIndex	= cOCT6100_INVALID_INDEX;
			}
		}
	}
	
	/*=======================================================================*/
	/* Copy the channel's VQE configuration of all the modified fields. */

	if ( f_pChannelModify->fVqeConfigModified == TRUE )
	{
		pApiVqeConf->fEnableNlp									= (UINT8)( f_pChannelOpen->VqeConfig.fEnableNlp & 0xFF );
		pApiVqeConf->byComfortNoiseMode							= (UINT8)( f_pChannelOpen->VqeConfig.ulComfortNoiseMode & 0xFF );
		pApiVqeConf->fSinDcOffsetRemoval						= (UINT8)( f_pChannelOpen->VqeConfig.fSinDcOffsetRemoval & 0xFF );
		pApiVqeConf->fRinDcOffsetRemoval						= (UINT8)( f_pChannelOpen->VqeConfig.fRinDcOffsetRemoval & 0xFF );
		pApiVqeConf->fRinLevelControl							= (UINT8)( f_pChannelOpen->VqeConfig.fRinLevelControl & 0xFF );
		pApiVqeConf->fSoutLevelControl							= (UINT8)( f_pChannelOpen->VqeConfig.fSoutLevelControl & 0xFF );
		pApiVqeConf->fRinAutomaticLevelControl					= (UINT8)( f_pChannelOpen->VqeConfig.fRinAutomaticLevelControl & 0xFF );
		pApiVqeConf->fSoutAutomaticLevelControl					= (UINT8)( f_pChannelOpen->VqeConfig.fSoutAutomaticLevelControl & 0xFF );
		pApiVqeConf->fRinHighLevelCompensation					= (UINT8)( f_pChannelOpen->VqeConfig.fRinHighLevelCompensation & 0xFF );

		pApiVqeConf->fSoutAdaptiveNoiseReduction				= (UINT8)( f_pChannelOpen->VqeConfig.fSoutAdaptiveNoiseReduction & 0xFF );

		pApiVqeConf->chRinLevelControlGainDb					= (OCT_INT8)( f_pChannelOpen->VqeConfig.lRinLevelControlGainDb & 0xFF );
		pApiVqeConf->chSoutLevelControlGainDb					= (OCT_INT8)( f_pChannelOpen->VqeConfig.lSoutLevelControlGainDb & 0xFF );
		pApiVqeConf->chRinAutomaticLevelControlTargetDb			= (OCT_INT8)( f_pChannelOpen->VqeConfig.lRinAutomaticLevelControlTargetDb & 0xFF );
		pApiVqeConf->chSoutAutomaticLevelControlTargetDb		= (OCT_INT8)( f_pChannelOpen->VqeConfig.lSoutAutomaticLevelControlTargetDb & 0xFF );
		pApiVqeConf->chRinHighLevelCompensationThresholdDb		= (OCT_INT8)( f_pChannelOpen->VqeConfig.lRinHighLevelCompensationThresholdDb & 0xFF );
		pApiVqeConf->fEnableTailDisplacement					= (UINT8)( f_pChannelOpen->VqeConfig.fEnableTailDisplacement & 0xFF );
		pApiVqeConf->usTailDisplacement							= (UINT16)( f_pChannelOpen->VqeConfig.ulTailDisplacement & 0xFFFF );
		pApiVqeConf->usTailLength								= (UINT16)( f_pChannelOpen->VqeConfig.ulTailLength & 0xFFFF );
		pApiVqeConf->fAcousticEcho								= (UINT8)( f_pChannelOpen->VqeConfig.fAcousticEcho & 0xFF );
		pApiVqeConf->fDtmfToneRemoval							= (UINT8)( f_pChannelOpen->VqeConfig.fDtmfToneRemoval & 0xFF );

		pApiVqeConf->chDefaultErlDb								= (OCT_INT8)( f_pChannelOpen->VqeConfig.lDefaultErlDb & 0xFF );
		pApiVqeConf->chAecDefaultErlDb							= (OCT_INT8)( f_pChannelOpen->VqeConfig.lAecDefaultErlDb & 0xFF );
		pApiVqeConf->usAecTailLength							= (UINT16)( f_pChannelOpen->VqeConfig.ulAecTailLength & 0xFFFF );
		pApiVqeConf->chAnrSnrEnhancementDb						= (OCT_INT8)( f_pChannelOpen->VqeConfig.lAnrSnrEnhancementDb & 0xFF );
		pApiVqeConf->byAnrVoiceNoiseSegregation					= (UINT8)( f_pChannelOpen->VqeConfig.ulAnrVoiceNoiseSegregation & 0xFF );
		pApiVqeConf->usToneDisablerVqeActivationDelay			= (UINT16)( f_pChannelOpen->VqeConfig.ulToneDisablerVqeActivationDelay & 0xFFFF );
		pApiVqeConf->byNonLinearityBehaviorA					= (UINT8)( f_pChannelOpen->VqeConfig.ulNonLinearityBehaviorA & 0xFF );
		pApiVqeConf->byNonLinearityBehaviorB					= (UINT8)( f_pChannelOpen->VqeConfig.ulNonLinearityBehaviorB & 0xFF );
		pApiVqeConf->byDoubleTalkBehavior						= (UINT8)( f_pChannelOpen->VqeConfig.ulDoubleTalkBehavior & 0xFF );
		pApiVqeConf->bySoutAutomaticListenerEnhancementGainDb	= (UINT8)( f_pChannelOpen->VqeConfig.ulSoutAutomaticListenerEnhancementGainDb & 0xFF );
		pApiVqeConf->bySoutNaturalListenerEnhancementGainDb		= (UINT8)( f_pChannelOpen->VqeConfig.ulSoutNaturalListenerEnhancementGainDb & 0xFF );
		pApiVqeConf->fSoutNaturalListenerEnhancement			= (UINT8)( f_pChannelOpen->VqeConfig.fSoutNaturalListenerEnhancement & 0xFF );
		pApiVqeConf->fRoutNoiseReduction						= (UINT8)( f_pChannelOpen->VqeConfig.fRoutNoiseReduction & 0xFF );
		pApiVqeConf->chRoutNoiseReductionLevelGainDb			= (OCT_INT8)( f_pChannelOpen->VqeConfig.lRoutNoiseReductionLevelGainDb & 0xFF );

		pApiVqeConf->fEnablePlayout								= (UINT8)( f_pChannelOpen->VqeConfig.fEnablePlayout & 0xFF );

		pApiVqeConf->fEnableMusicProtection						= (UINT8)( f_pChannelOpen->VqeConfig.fEnableMusicProtection & 0xFF );
		pApiVqeConf->fIdleCodeDetection							= (UINT8)( f_pChannelOpen->VqeConfig.fIdleCodeDetection & 0xFF );
	}





	return cOCT6100_ERR_OK;
}


















/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiChannelGetStatsSer

Description:    Serialized function that returns all the stats of the specified
				channel.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.

f_pChannelStats			Pointer to a channel stats structure.
\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiChannelGetStatsSer(
				IN  tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN  tPOCT6100_CHANNEL_STATS					f_pChannelStats )
{
	tOCT6100_READ_PARAMS		ReadParams;
	tOCT6100_READ_BURST_PARAMS	BurstParams;
	tPOCT6100_API_CHANNEL		pChanEntry;
	tPOCT6100_SHARED_INFO		pSharedInfo;

	UINT32	ulEntryOpenCnt;

	UINT32	ulBaseAddress;
	UINT32	ulFeatureBytesOffset;
	UINT32	ulFeatureBitOffset;
	UINT32	ulFeatureFieldLength;
	UINT32	ulTempData;
	UINT32	ulMask;
	UINT16	usChanIndex;
	UINT16	ausReadData[ 32 ];

	BYTE	byRinEnergyRaw;
	BYTE	bySinEnergyRaw;
	BYTE	bySoutEnergyRaw;
	INT32	lSoutEnergyIndB;
	BYTE	byCnEnergyRaw;
	UINT16	usEchoDelayInFrames;
	UINT16	usErlRaw;

	UINT32	ulResult;
	UINT16	usReadData;

	/* Get local pointer to shared portion of instance. */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	BurstParams.pProcessContext = f_pApiInstance->pProcessContext;

	BurstParams.ulUserChipId = f_pApiInstance->pSharedInfo->ChipConfig.ulUserChipId;
	BurstParams.pusReadData = ausReadData;
		
	ReadParams.pProcessContext = f_pApiInstance->pProcessContext;

	ReadParams.ulUserChipId = f_pApiInstance->pSharedInfo->ChipConfig.ulUserChipId;
	ReadParams.pusReadData = &usReadData;

	/* Check the reset stats flag.*/
	if ( f_pChannelStats->fResetStats != TRUE && f_pChannelStats->fResetStats != FALSE )
		return cOCT6100_ERR_CHANNEL_STATS_RESET;

	/* Check the provided handle. */
	if ( cOCT6100_HNDL_TAG_CHANNEL != (f_pChannelStats->ulChannelHndl & cOCT6100_HNDL_TAG_MASK) )
		return cOCT6100_ERR_CHANNEL_INVALID_HANDLE;

	usChanIndex = (UINT16)( f_pChannelStats->ulChannelHndl & cOCT6100_HNDL_INDEX_MASK );
	if ( usChanIndex >= f_pApiInstance->pSharedInfo->ChipConfig.usMaxChannels )
		return cOCT6100_ERR_CHANNEL_INVALID_HANDLE;

	/*=======================================================================*/
	/* Get a pointer to the channel's list entry. */

	mOCT6100_GET_CHANNEL_ENTRY_PNT( f_pApiInstance->pSharedInfo, pChanEntry, usChanIndex )

	/* Extract the entry open count from the provided handle. */
	ulEntryOpenCnt = ( f_pChannelStats->ulChannelHndl >> cOCT6100_ENTRY_OPEN_CNT_SHIFT) & cOCT6100_ENTRY_OPEN_CNT_MASK;

	/* Check for errors. */
	if ( pChanEntry->fReserved != TRUE )
		return cOCT6100_ERR_CHANNEL_NOT_OPEN;
	if ( ulEntryOpenCnt != pChanEntry->byEntryOpenCnt )
		return cOCT6100_ERR_CHANNEL_INVALID_HANDLE;

	/*=======================================================================*/
	


	/* Copy the general configuration.*/
	f_pChannelStats->ulUserChanId = pChanEntry->ulUserChanId;
	f_pChannelStats->ulEchoOperationMode = pChanEntry->byEchoOperationMode;
	f_pChannelStats->fEnableToneDisabler = pChanEntry->fEnableToneDisabler;
	f_pChannelStats->ulMutePortsMask = pChanEntry->usMutedPorts;



	
	/* Copy the TDM configuration.*/



	f_pChannelStats->TdmConfig.ulSinTimeslot = pChanEntry->TdmConfig.usSinTimeslot;
	f_pChannelStats->TdmConfig.ulSinStream = pChanEntry->TdmConfig.usSinStream;
	f_pChannelStats->TdmConfig.ulSinPcmLaw = pChanEntry->TdmConfig.bySinPcmLaw;


	f_pChannelStats->TdmConfig.ulSoutTimeslot = pChanEntry->TdmConfig.usSoutTimeslot;
	f_pChannelStats->TdmConfig.ulSoutStream = pChanEntry->TdmConfig.usSoutStream;
	f_pChannelStats->TdmConfig.ulSoutPcmLaw = pChanEntry->TdmConfig.bySoutPcmLaw;


		

	f_pChannelStats->TdmConfig.ulRinTimeslot = pChanEntry->TdmConfig.usRinTimeslot;
	f_pChannelStats->TdmConfig.ulRinStream = pChanEntry->TdmConfig.usRinStream;
	f_pChannelStats->TdmConfig.ulRinPcmLaw = pChanEntry->TdmConfig.byRinPcmLaw;


	f_pChannelStats->TdmConfig.ulRoutTimeslot = pChanEntry->TdmConfig.usRoutTimeslot;
	f_pChannelStats->TdmConfig.ulRoutStream = pChanEntry->TdmConfig.usRoutStream;
	f_pChannelStats->TdmConfig.ulRoutPcmLaw = pChanEntry->TdmConfig.byRoutPcmLaw;




	/* Copy the VQE configuration.*/
	f_pChannelStats->VqeConfig.fEnableNlp = pChanEntry->VqeConfig.fEnableNlp;
	f_pChannelStats->VqeConfig.ulComfortNoiseMode = pChanEntry->VqeConfig.byComfortNoiseMode;
	f_pChannelStats->VqeConfig.fEnableTailDisplacement = pChanEntry->VqeConfig.fEnableTailDisplacement;
	if ( pChanEntry->VqeConfig.usTailDisplacement != cOCT6100_AUTO_SELECT_TAIL )
		f_pChannelStats->VqeConfig.ulTailDisplacement = pChanEntry->VqeConfig.usTailDisplacement;
	else
		f_pChannelStats->VqeConfig.ulTailDisplacement = f_pApiInstance->pSharedInfo->ChipConfig.usTailDisplacement;

	if ( pChanEntry->VqeConfig.usTailLength != cOCT6100_AUTO_SELECT_TAIL )
		f_pChannelStats->VqeConfig.ulTailLength = pChanEntry->VqeConfig.usTailLength;
	else
		f_pChannelStats->VqeConfig.ulTailLength = f_pApiInstance->pSharedInfo->ImageInfo.usMaxTailLength;
	


	f_pChannelStats->VqeConfig.fSinDcOffsetRemoval = pChanEntry->VqeConfig.fSinDcOffsetRemoval;
	f_pChannelStats->VqeConfig.fRinDcOffsetRemoval = pChanEntry->VqeConfig.fRinDcOffsetRemoval;
	f_pChannelStats->VqeConfig.fRinLevelControl = pChanEntry->VqeConfig.fRinLevelControl;
	f_pChannelStats->VqeConfig.fSoutLevelControl = pChanEntry->VqeConfig.fSoutLevelControl;
	f_pChannelStats->VqeConfig.fRinAutomaticLevelControl = pChanEntry->VqeConfig.fRinAutomaticLevelControl;
	f_pChannelStats->VqeConfig.fSoutAutomaticLevelControl = pChanEntry->VqeConfig.fSoutAutomaticLevelControl;
	f_pChannelStats->VqeConfig.fRinHighLevelCompensation = pChanEntry->VqeConfig.fRinHighLevelCompensation;
	f_pChannelStats->VqeConfig.fSoutAdaptiveNoiseReduction = pChanEntry->VqeConfig.fSoutAdaptiveNoiseReduction;

	f_pChannelStats->VqeConfig.lRinLevelControlGainDb	= pChanEntry->VqeConfig.chRinLevelControlGainDb;
	f_pChannelStats->VqeConfig.lSoutLevelControlGainDb	= pChanEntry->VqeConfig.chSoutLevelControlGainDb;
	f_pChannelStats->VqeConfig.lRinAutomaticLevelControlTargetDb	= pChanEntry->VqeConfig.chRinAutomaticLevelControlTargetDb;
	f_pChannelStats->VqeConfig.lSoutAutomaticLevelControlTargetDb	= pChanEntry->VqeConfig.chSoutAutomaticLevelControlTargetDb;
	f_pChannelStats->VqeConfig.lRinHighLevelCompensationThresholdDb	= pChanEntry->VqeConfig.chRinHighLevelCompensationThresholdDb;
	f_pChannelStats->VqeConfig.fAcousticEcho			= pChanEntry->VqeConfig.fAcousticEcho;
	f_pChannelStats->VqeConfig.fDtmfToneRemoval			= pChanEntry->VqeConfig.fDtmfToneRemoval;

	f_pChannelStats->VqeConfig.lDefaultErlDb							= pChanEntry->VqeConfig.chDefaultErlDb;
	f_pChannelStats->VqeConfig.lAecDefaultErlDb							= pChanEntry->VqeConfig.chAecDefaultErlDb;
	f_pChannelStats->VqeConfig.ulAecTailLength							= pChanEntry->VqeConfig.usAecTailLength;
	f_pChannelStats->VqeConfig.lAnrSnrEnhancementDb						= pChanEntry->VqeConfig.chAnrSnrEnhancementDb;
	f_pChannelStats->VqeConfig.ulAnrVoiceNoiseSegregation				= pChanEntry->VqeConfig.byAnrVoiceNoiseSegregation;
	f_pChannelStats->VqeConfig.ulToneDisablerVqeActivationDelay			= pChanEntry->VqeConfig.usToneDisablerVqeActivationDelay;
	f_pChannelStats->VqeConfig.ulNonLinearityBehaviorA					= pChanEntry->VqeConfig.byNonLinearityBehaviorA;
	f_pChannelStats->VqeConfig.ulNonLinearityBehaviorB					= pChanEntry->VqeConfig.byNonLinearityBehaviorB;
	f_pChannelStats->VqeConfig.ulDoubleTalkBehavior						= pChanEntry->VqeConfig.byDoubleTalkBehavior;
	f_pChannelStats->VqeConfig.ulSoutAutomaticListenerEnhancementGainDb	= pChanEntry->VqeConfig.bySoutAutomaticListenerEnhancementGainDb;
	f_pChannelStats->VqeConfig.ulSoutNaturalListenerEnhancementGainDb	= pChanEntry->VqeConfig.bySoutNaturalListenerEnhancementGainDb;
	f_pChannelStats->VqeConfig.fSoutNaturalListenerEnhancement			= pChanEntry->VqeConfig.fSoutNaturalListenerEnhancement;
	f_pChannelStats->VqeConfig.fRoutNoiseReduction						= pChanEntry->VqeConfig.fRoutNoiseReduction;
	f_pChannelStats->VqeConfig.lRoutNoiseReductionLevelGainDb			= pChanEntry->VqeConfig.chRoutNoiseReductionLevelGainDb;

	f_pChannelStats->VqeConfig.fEnablePlayout								= pChanEntry->VqeConfig.fEnablePlayout;

	f_pChannelStats->VqeConfig.fEnableMusicProtection					= pChanEntry->VqeConfig.fEnableMusicProtection;
	f_pChannelStats->VqeConfig.fIdleCodeDetection						= pChanEntry->VqeConfig.fIdleCodeDetection;
	



	/* Reset the stats and exit if the reset flag is set.*/
	if ( f_pChannelStats->fResetStats == TRUE )
	{
		pChanEntry->sMaxERLE = cOCT6100_INVALID_SIGNED_STAT_W;
		pChanEntry->sMaxERL = cOCT6100_INVALID_SIGNED_STAT_W;
		pChanEntry->usMaxEchoDelay = cOCT6100_INVALID_STAT_W;
	}
	
	/*---------------------------------------------------------------------*/
	/* Update the API internal stats.*/

	BurstParams.ulReadAddress  = f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainMemBase + (usChanIndex * f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainMemSize );
	BurstParams.ulReadAddress += f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainIoMemOfst + f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainIoStatsOfst;
	BurstParams.ulReadLength = f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainIoStatsSize / 2;	/* Length in words.*/

	mOCT6100_DRIVER_READ_BURST_API( BurstParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;
	
	/* Check if the energy stat are found in the new memory location. */
	if ( ( pSharedInfo->ImageInfo.fRinEnergyStat == TRUE )
		&& ( pSharedInfo->ImageInfo.fSoutEnergyStat == TRUE ) )
	{
		ulFeatureBytesOffset = f_pApiInstance->pSharedInfo->MemoryMap.RinEnergyStatFieldOfst.usDwordOffset * 4;
		ulFeatureBitOffset	 = f_pApiInstance->pSharedInfo->MemoryMap.RinEnergyStatFieldOfst.byBitOffset;
		ulFeatureFieldLength = f_pApiInstance->pSharedInfo->MemoryMap.RinEnergyStatFieldOfst.byFieldSize;

		ReadParams.ulReadAddress = f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainMemBase + (usChanIndex * f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainMemSize );
		ReadParams.ulReadAddress += f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainIoMemOfst + ulFeatureBytesOffset;

		/* Optimize this access by only reading the word we are interested in. */
		if ( ulFeatureBitOffset < 16 )
			ReadParams.ulReadAddress += 2;

		/* Must read in memory directly since this value is changed by hardware */
		mOCT6100_DRIVER_READ_API( ReadParams, ulResult );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;

		/* Move data at correct position according to what was read. */
		if ( ulFeatureBitOffset < 16 )
			ulTempData = usReadData;
		else
			ulTempData = usReadData << 16;

		/* Clear previous value set in the feature field. */
		mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

		ulTempData &= ulMask;

		/* Shift to get value. */
		ulTempData = ulTempData >> ulFeatureBitOffset;

		/* Overwrite value read the old way. */
		ausReadData[ 0 ] &= 0x00FF;
		ausReadData[ 0 ] |= (UINT16)( ( ulTempData << 8 ) & 0xFF00 );

		ulFeatureBytesOffset = f_pApiInstance->pSharedInfo->MemoryMap.SoutEnergyStatFieldOfst.usDwordOffset * 4;
		ulFeatureBitOffset	 = f_pApiInstance->pSharedInfo->MemoryMap.SoutEnergyStatFieldOfst.byBitOffset;
		ulFeatureFieldLength = f_pApiInstance->pSharedInfo->MemoryMap.SoutEnergyStatFieldOfst.byFieldSize;

		ReadParams.ulReadAddress = f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainMemBase + (usChanIndex * f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainMemSize );
		ReadParams.ulReadAddress += f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainIoMemOfst + ulFeatureBytesOffset;

		/* Optimize this access by only reading the word we are interested in. */
		if ( ulFeatureBitOffset < 16 )
			ReadParams.ulReadAddress += 2;

		/* Must read in memory directly since this value is changed by hardware */
		mOCT6100_DRIVER_READ_API( ReadParams, ulResult );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;

		/* Move data at correct position according to what was read. */
		if ( ulFeatureBitOffset < 16 )
			ulTempData = usReadData;
		else
			ulTempData = usReadData << 16;

		/* Clear previous value set in the feature field. */
		mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

		ulTempData &= ulMask;

		/* Shift to get value. */
		ulTempData = ulTempData >> ulFeatureBitOffset;

		/* Overwrite value read the old way. */
		ausReadData[ 1 ] &= 0x00FF;
		ausReadData[ 1 ] |= (UINT16)( ( ulTempData << 8 ) & 0xFF00 );
	}

	byRinEnergyRaw  = (BYTE)(( ausReadData[ 0 ] >> 8 ) & 0xFF);
	bySinEnergyRaw  = (BYTE)(( ausReadData[ 0 ] >> 0 ) & 0xFF);
	bySoutEnergyRaw = (BYTE)(( ausReadData[ 1 ] >> 8 ) & 0xFF);
	byCnEnergyRaw   = (BYTE)(( ausReadData[ 5 ] >> 8 ) & 0xFF);

	usEchoDelayInFrames		= (UINT16)(ausReadData[ 4 ]);
	usErlRaw				= ausReadData[ 2 ];

	pChanEntry->byToneDisablerStatus = (UINT8)(( ausReadData[ 5 ] >> 0 ) & 0xFF);
	if ( f_pChannelStats->fResetStats == TRUE )
	{
		pChanEntry->usNumEchoPathChangesOfst = (UINT16)(ausReadData[ 3 ]);
		pChanEntry->usNumEchoPathChanges = 0;
	}
	else /* if ( f_pChannelStats->fResetStats == FALSE ) */
	{
		pChanEntry->usNumEchoPathChanges = (UINT16)( ausReadData[ 3 ] - pChanEntry->usNumEchoPathChangesOfst );
	}

	pChanEntry->sComfortNoiseLevel  = (INT16)( Oct6100ApiOctFloatToDbEnergyByte( byCnEnergyRaw ) & 0xFFFF );
	pChanEntry->sComfortNoiseLevel -= 12;
	pChanEntry->sRinLevel  = (INT16)( Oct6100ApiOctFloatToDbEnergyByte( byRinEnergyRaw ) & 0xFFFF );
	pChanEntry->sRinLevel -= 12;
	pChanEntry->sSinLevel = (INT16)( Oct6100ApiOctFloatToDbEnergyByte( bySinEnergyRaw ) & 0xFFFF );
	pChanEntry->sSinLevel -= 12;
	lSoutEnergyIndB        = Oct6100ApiOctFloatToDbEnergyByte( bySoutEnergyRaw );
	lSoutEnergyIndB		  -= 12;
	
	/* Process some stats only if the channel is converged.*/
	if ( ( usEchoDelayInFrames != cOCT6100_INVALID_ECHO_DELAY ) 
		&& ( pChanEntry->byEchoOperationMode != cOCT6100_ECHO_OP_MODE_POWER_DOWN ) 
		&& ( pChanEntry->byEchoOperationMode != cOCT6100_ECHO_OP_MODE_HT_RESET ) )
	{
		/* Update the current ERL. */
		pChanEntry->sCurrentERL				= (INT16)( Oct6100ApiOctFloatToDbEnergyHalf( usErlRaw ) & 0xFFFF );
		pChanEntry->sCurrentERLE			= (INT16)( ( lSoutEnergyIndB - pChanEntry->sSinLevel ) & 0xFFFF );
		pChanEntry->usCurrentEchoDelay		= (UINT16)( usEchoDelayInFrames / 8 );	/* To convert in msec.*/

		/* Update the max value if required.*/
		if ( pChanEntry->usCurrentEchoDelay > pChanEntry->usMaxEchoDelay || 
			 pChanEntry->usMaxEchoDelay == cOCT6100_INVALID_STAT_W )
		{
			pChanEntry->usMaxEchoDelay = pChanEntry->usCurrentEchoDelay;
		}

		if ( pChanEntry->sCurrentERL > pChanEntry->sMaxERL ||
			 pChanEntry->sMaxERL == cOCT6100_INVALID_SIGNED_STAT_W )
		{
			pChanEntry->sMaxERL = pChanEntry->sCurrentERL;
		}

		if ( pChanEntry->sCurrentERLE > pChanEntry->sMaxERLE ||
			 pChanEntry->sMaxERLE == cOCT6100_INVALID_SIGNED_STAT_W )
		{
			pChanEntry->sMaxERLE = pChanEntry->sCurrentERLE;
		}
	}
	else
	{
		pChanEntry->sCurrentERLE		= cOCT6100_INVALID_SIGNED_STAT_W;
		pChanEntry->sCurrentERL			= cOCT6100_INVALID_SIGNED_STAT_W;
		pChanEntry->usCurrentEchoDelay	= cOCT6100_INVALID_STAT_W;
	}

	if ( f_pApiInstance->pSharedInfo->ImageInfo.fRinAppliedGainStat == TRUE )
	{
		/* Calculate base address for auto level control + high level compensation configuration. */
		ulBaseAddress = f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainMemBase + ( usChanIndex * f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainMemSize ) + f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainIoMemOfst;
			
		ulFeatureBytesOffset = f_pApiInstance->pSharedInfo->MemoryMap.RinAppliedGainStatOfst.usDwordOffset * 4;
		ulFeatureBitOffset	 = f_pApiInstance->pSharedInfo->MemoryMap.RinAppliedGainStatOfst.byBitOffset;
		ulFeatureFieldLength = f_pApiInstance->pSharedInfo->MemoryMap.RinAppliedGainStatOfst.byFieldSize;

		ReadParams.ulReadAddress = ulBaseAddress + ulFeatureBytesOffset;

		/* Optimize this access by only reading the word we are interested in. */
		if ( ulFeatureBitOffset < 16 )
			ReadParams.ulReadAddress += 2;

		/* Must read in memory directly since this value is changed by hardware */
		mOCT6100_DRIVER_READ_API( ReadParams, ulResult )
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;

		/* Move data at correct position according to what was read. */
		if ( ulFeatureBitOffset < 16 )
			ulTempData = usReadData;
		else
			ulTempData = usReadData << 16;

		/* Clear previous value set in the feature field.*/
		mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

		ulTempData &= ulMask;

		/* Shift to get value. */
		ulTempData = ulTempData >> ulFeatureBitOffset;
		
		pChanEntry->sRinAppliedGain = (INT16)( 2 * (INT16)( Oct6100ApiOctFloatToDbEnergyHalf( (UINT16)( ulTempData & 0xFFFF ) ) & 0xFFFF ) );
	}

	if ( f_pApiInstance->pSharedInfo->ImageInfo.fSoutAppliedGainStat == TRUE )
	{
		/* Calculate base address for auto level control + high level compensation configuration. */
		ulBaseAddress = f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainMemBase + ( usChanIndex * f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainMemSize ) + f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainIoMemOfst;
			
		ulFeatureBytesOffset = f_pApiInstance->pSharedInfo->MemoryMap.SoutAppliedGainStatOfst.usDwordOffset * 4;
		ulFeatureBitOffset	 = f_pApiInstance->pSharedInfo->MemoryMap.SoutAppliedGainStatOfst.byBitOffset;
		ulFeatureFieldLength = f_pApiInstance->pSharedInfo->MemoryMap.SoutAppliedGainStatOfst.byFieldSize;

		ReadParams.ulReadAddress = ulBaseAddress + ulFeatureBytesOffset;

		/* Optimize this access by only reading the word we are interested in. */
		if ( ulFeatureBitOffset < 16 )
			ReadParams.ulReadAddress += 2;

		/* Must read in memory directly since this value is changed by hardware */
		mOCT6100_DRIVER_READ_API( ReadParams, ulResult )
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;

		/* Move data at correct position according to what was read. */
		if ( ulFeatureBitOffset < 16 )
			ulTempData = usReadData;
		else
			ulTempData = usReadData << 16;

		/* Clear previous value set in the feature field. */
		mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

		ulTempData &= ulMask;

		/* Shift to get value. */
		ulTempData = ulTempData >> ulFeatureBitOffset;
		
		pChanEntry->sSoutAppliedGain = (INT16)( 2 * (INT16)( Oct6100ApiOctFloatToDbEnergyHalf( (UINT16)( ulTempData & 0xFFFF ) ) & 0xFFFF ) );
	}

	/*---------------------------------------------------------------------*/
	/* Return the real stats.*/

	f_pChannelStats->ulNumEchoPathChanges = pChanEntry->usNumEchoPathChanges;
	if ( usEchoDelayInFrames != cOCT6100_INVALID_ECHO_DELAY )
	{
		f_pChannelStats->fEchoCancellerConverged = TRUE;
	}
	else
	{
		f_pChannelStats->fEchoCancellerConverged = FALSE;
	}
	if ( pChanEntry->sCurrentERL == cOCT6100_INVALID_SIGNED_STAT_W )
		f_pChannelStats->lCurrentERL = cOCT6100_INVALID_SIGNED_STAT;
	else
		f_pChannelStats->lCurrentERL = pChanEntry->sCurrentERL;

	if ( pChanEntry->sMaxERL == cOCT6100_INVALID_SIGNED_STAT_W )
		f_pChannelStats->lMaxERL = cOCT6100_INVALID_SIGNED_STAT;
	else
		f_pChannelStats->lMaxERL = pChanEntry->sMaxERL;

	if ( pChanEntry->usMaxEchoDelay == cOCT6100_INVALID_STAT_W )
		f_pChannelStats->ulMaxEchoDelay = cOCT6100_INVALID_STAT;
	else
		f_pChannelStats->ulMaxEchoDelay = pChanEntry->usMaxEchoDelay;

	if ( pChanEntry->sRinLevel == cOCT6100_INVALID_SIGNED_STAT_W )
		f_pChannelStats->lRinLevel = cOCT6100_INVALID_SIGNED_STAT;
	else
		f_pChannelStats->lRinLevel = pChanEntry->sRinLevel;

	if ( pSharedInfo->ImageInfo.fSinLevel == TRUE )
	{
		if ( pChanEntry->sSinLevel == cOCT6100_INVALID_SIGNED_STAT_W )
			f_pChannelStats->lSinLevel = cOCT6100_INVALID_SIGNED_STAT;
		else
			f_pChannelStats->lSinLevel = pChanEntry->sSinLevel;
	}
	else /* if ( pSharedInfo->ImageInfo.fSinLevel != TRUE ) */
	{
		/* SIN level is not supported in this image. */
		f_pChannelStats->lSinLevel = cOCT6100_INVALID_SIGNED_STAT;
	}

	f_pChannelStats->lRinAppliedGain = pChanEntry->VqeConfig.chRinLevelControlGainDb;
	if ( ( f_pApiInstance->pSharedInfo->ImageInfo.fRinAppliedGainStat == TRUE )
		&& ( ( pChanEntry->VqeConfig.fRinAutomaticLevelControl == TRUE )
		|| ( pChanEntry->VqeConfig.fRinHighLevelCompensation == TRUE ) ) )
	{
		f_pChannelStats->lRinAppliedGain = pChanEntry->sRinAppliedGain;
	}

	f_pChannelStats->lSoutAppliedGain = pChanEntry->VqeConfig.chSoutLevelControlGainDb;
	if ( ( f_pApiInstance->pSharedInfo->ImageInfo.fSoutAppliedGainStat == TRUE )
		&& ( pChanEntry->VqeConfig.fSoutAutomaticLevelControl == TRUE ) )
	{
		f_pChannelStats->lSoutAppliedGain = pChanEntry->sSoutAppliedGain;
	}

	if ( pChanEntry->usCurrentEchoDelay == cOCT6100_INVALID_STAT_W )
		f_pChannelStats->ulCurrentEchoDelay	= cOCT6100_INVALID_STAT;
	else
		f_pChannelStats->ulCurrentEchoDelay	= pChanEntry->usCurrentEchoDelay;

	if ( pSharedInfo->ImageInfo.fSinLevel == TRUE )
	{
		if ( pChanEntry->sCurrentERLE == cOCT6100_INVALID_SIGNED_STAT_W )
			f_pChannelStats->lCurrentERLE = cOCT6100_INVALID_SIGNED_STAT;
		else
			f_pChannelStats->lCurrentERLE = pChanEntry->sCurrentERLE;
	}
	else /* if ( pSharedInfo->ImageInfo.fSinLevel != TRUE ) */
	{
		f_pChannelStats->lCurrentERLE = cOCT6100_INVALID_SIGNED_STAT;
	}

	if ( pSharedInfo->ImageInfo.fSinLevel == TRUE )
	{
		if ( pChanEntry->sMaxERLE == cOCT6100_INVALID_SIGNED_STAT_W )
			f_pChannelStats->lMaxERLE = cOCT6100_INVALID_SIGNED_STAT;
		else
			f_pChannelStats->lMaxERLE = pChanEntry->sMaxERLE;
	}
	else /* if ( pSharedInfo->ImageInfo.fSinLevel != TRUE ) */
	{
		f_pChannelStats->lMaxERLE = cOCT6100_INVALID_SIGNED_STAT;
	}

	f_pChannelStats->lComfortNoiseLevel		= pChanEntry->sComfortNoiseLevel;
	f_pChannelStats->ulToneDisablerStatus   = pChanEntry->byToneDisablerStatus;

	if ( f_pApiInstance->pSharedInfo->ImageInfo.fSinVoiceDetectedStat == TRUE )
	{
		UINT32 ulVoiceDetectedBytesOfst	= f_pApiInstance->pSharedInfo->MemoryMap.SinVoiceDetectedStatOfst.usDwordOffset * 4;
		UINT32 ulVoiceDetectedBitOfst	= f_pApiInstance->pSharedInfo->MemoryMap.SinVoiceDetectedStatOfst.byBitOffset;
		UINT32 ulVoiceDetectedFieldSize	= f_pApiInstance->pSharedInfo->MemoryMap.SinVoiceDetectedStatOfst.byFieldSize;

		/* Set the channel root base address.*/
		UINT32 ulChannelRootBaseAddress = cOCT6100_CHANNEL_ROOT_BASE + ( usChanIndex * cOCT6100_CHANNEL_ROOT_SIZE ) + f_pApiInstance->pSharedInfo->MemoryMap.ulChanRootConfOfst;

		ReadParams.ulReadAddress = ulChannelRootBaseAddress + ulVoiceDetectedBytesOfst;

		/* Optimize this access by only reading the word we are interested in. */
		if ( ulVoiceDetectedBitOfst < 16 )
			ReadParams.ulReadAddress += 2;

		/* Must read in memory directly since this value is changed by hardware */
		mOCT6100_DRIVER_READ_API( ReadParams, ulResult )
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;

		/* Move data at correct position according to what was read. */
		if ( ulVoiceDetectedBitOfst < 16 )
			ulTempData = usReadData;
		else
			ulTempData = usReadData << 16;

		mOCT6100_CREATE_FEATURE_MASK( ulVoiceDetectedFieldSize, ulVoiceDetectedBitOfst, &ulMask );
		
		if ( ( ulTempData & ulMask ) != 0x0 )
			f_pChannelStats->fSinVoiceDetected = TRUE;
		else
			f_pChannelStats->fSinVoiceDetected = FALSE;
	}
	
	/*---------------------------------------------------------------------*/

	return cOCT6100_ERR_OK;
}	


/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiReserveEchoEntry

Description:    Reserves one of the echo channel API entry.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

f_pusEchoIndex			Resulting index reserved in the echo channel list.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiReserveEchoEntry(
				IN	tPOCT6100_INSTANCE_API		f_pApiInstance,
				OUT	PUINT16						f_pusEchoIndex )
{
	tPOCT6100_SHARED_INFO		pSharedInfo;
	PVOID	pEchoAlloc;
	UINT32	ulResult;
	UINT32	ulEchoIndex;

	/* Get local pointer to shared portion of instance. */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	mOCT6100_GET_CHANNEL_ALLOC_PNT( pSharedInfo, pEchoAlloc )
	
	ulResult = OctapiLlmAllocAlloc( pEchoAlloc, &ulEchoIndex );
	if ( ulResult != cOCT6100_ERR_OK  )
	{
		if ( ulResult == OCTAPI_LLM_NO_STRUCTURES_LEFT )
			return cOCT6100_ERR_CHANNEL_ALL_CHANNELS_ARE_OPENED;
		else
			return cOCT6100_ERR_FATAL_11;
	}

	*f_pusEchoIndex = (UINT16)( ulEchoIndex & 0xFFFF );

	return cOCT6100_ERR_OK;
}


/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiReleaseEchoEntry

Description:    Releases the specified ECHO channel API entry.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

f_usEchoIndex			Index reserved in the echo channel list.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiReleaseEchoEntry(
				IN	tPOCT6100_INSTANCE_API		f_pApiInstance,
				IN	UINT16						f_usEchoIndex )
{
	tPOCT6100_SHARED_INFO		pSharedInfo;
	PVOID	pEchoAlloc;
	UINT32	ulResult;

	/* Get local pointer to shared portion of instance. */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	mOCT6100_GET_CHANNEL_ALLOC_PNT( pSharedInfo, pEchoAlloc )
	
	ulResult = OctapiLlmAllocDealloc( pEchoAlloc, f_usEchoIndex );
	if ( ulResult != cOCT6100_ERR_OK  )
	{
		return cOCT6100_ERR_FATAL_12;
	}

	return cOCT6100_ERR_OK;
}






/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiCheckTdmConfig

Description:    This function will check the validity of the TDM config parameter
				of an Open TDM config structure.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

f_pTdmConfig			TDM config of the channel.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiCheckTdmConfig( 
				IN	tPOCT6100_INSTANCE_API			f_pApiInstance,
				IN	tPOCT6100_CHANNEL_OPEN_TDM		f_pTdmConfig )
{
	UINT32	ulResult;

	/*==============================================================================*/
	/* Check the TDM configuration parameters.*/

	/* Check the validity of the timeslot and Stream only if it is defined.*/
	if ( f_pTdmConfig->ulRinTimeslot != cOCT6100_UNASSIGNED || 
		 f_pTdmConfig->ulRinStream != cOCT6100_UNASSIGNED )
	{


		/* Check the RIN TDM streams, timeslots component for errors.*/
		ulResult = Oct6100ApiValidateTsst( f_pApiInstance, 

										   f_pTdmConfig->ulRinTimeslot, 
										   f_pTdmConfig->ulRinStream,
										   cOCT6100_INPUT_TSST );
		if ( ulResult != cOCT6100_ERR_OK  )
		{
			if ( ulResult == cOCT6100_ERR_TSST_TIMESLOT )
			{
				return cOCT6100_ERR_CHANNEL_RIN_TIMESLOT;
			}
			else if ( ulResult == cOCT6100_ERR_TSST_STREAM )
			{
				return cOCT6100_ERR_CHANNEL_RIN_STREAM;
			}
			else
			{
				return ulResult;
			}
		}
	}

	/* Check the validity of the timeslot and Stream only if it is defined.*/
	if ( f_pTdmConfig->ulRoutTimeslot != cOCT6100_UNASSIGNED || 
		 f_pTdmConfig->ulRoutStream != cOCT6100_UNASSIGNED )
	{


		/* Check the ROUT TDM streams, timeslots component for errors.*/
		ulResult = Oct6100ApiValidateTsst( f_pApiInstance, 

										   f_pTdmConfig->ulRoutTimeslot, 
										   f_pTdmConfig->ulRoutStream,
										   cOCT6100_OUTPUT_TSST );
		if ( ulResult != cOCT6100_ERR_OK  )
		{
			if ( ulResult == cOCT6100_ERR_TSST_TIMESLOT )
			{
				return cOCT6100_ERR_CHANNEL_ROUT_TIMESLOT;
			}
			else if ( ulResult == cOCT6100_ERR_TSST_STREAM )
			{
				return cOCT6100_ERR_CHANNEL_ROUT_STREAM;
			}
			else
			{
				return ulResult;
			}
		}
	}

	/* Check the validity of the timeslot and Stream only if it is defined.*/
	if ( f_pTdmConfig->ulSinTimeslot != cOCT6100_UNASSIGNED || 
		 f_pTdmConfig->ulSinStream != cOCT6100_UNASSIGNED )
	{


		/* Check the SIN TDM streams, timeslots component for errors.*/
		ulResult = Oct6100ApiValidateTsst( f_pApiInstance,

										   f_pTdmConfig->ulSinTimeslot, 
										   f_pTdmConfig->ulSinStream,
										   cOCT6100_INPUT_TSST );
		if ( ulResult != cOCT6100_ERR_OK  )
		{
			if ( ulResult == cOCT6100_ERR_TSST_TIMESLOT )
			{
				return cOCT6100_ERR_CHANNEL_SIN_TIMESLOT;
			}
			else if ( ulResult == cOCT6100_ERR_TSST_STREAM )
			{
				return cOCT6100_ERR_CHANNEL_SIN_STREAM;
			}
			else
			{
				return ulResult;
			}
		}
	}

	/* Check the validity of the timeslot and Stream only if it is defined.*/
	if ( f_pTdmConfig->ulSoutTimeslot != cOCT6100_UNASSIGNED || 
		 f_pTdmConfig->ulSoutStream != cOCT6100_UNASSIGNED )
	{


		/* Check the ROUT TDM streams, timeslots component for errors.*/
		ulResult = Oct6100ApiValidateTsst( f_pApiInstance, 

										   f_pTdmConfig->ulSoutTimeslot, 
										   f_pTdmConfig->ulSoutStream,
										   cOCT6100_OUTPUT_TSST );
		if ( ulResult != cOCT6100_ERR_OK  )
		{
			if ( ulResult == cOCT6100_ERR_TSST_TIMESLOT )
			{
				return cOCT6100_ERR_CHANNEL_SOUT_TIMESLOT;
			}
			else if ( ulResult == cOCT6100_ERR_TSST_STREAM )
			{
				return cOCT6100_ERR_CHANNEL_SOUT_STREAM;
			}
			else
			{
				return ulResult;
			}
		}
	}	
	
	/* Check the PCM law parameters.*/
	if ( f_pTdmConfig->ulRinPcmLaw != cOCT6100_PCM_U_LAW && 
		 f_pTdmConfig->ulRinPcmLaw != cOCT6100_PCM_A_LAW )
		return cOCT6100_ERR_CHANNEL_RIN_PCM_LAW;

	if ( f_pTdmConfig->ulSinPcmLaw != cOCT6100_PCM_U_LAW && 
		 f_pTdmConfig->ulSinPcmLaw != cOCT6100_PCM_A_LAW )
		return cOCT6100_ERR_CHANNEL_SIN_PCM_LAW;

	if ( f_pTdmConfig->ulRoutPcmLaw != cOCT6100_PCM_U_LAW && 
		 f_pTdmConfig->ulRoutPcmLaw != cOCT6100_PCM_A_LAW )
		return cOCT6100_ERR_CHANNEL_ROUT_PCM_LAW;

	if ( f_pTdmConfig->ulSoutPcmLaw != cOCT6100_PCM_U_LAW && 
		 f_pTdmConfig->ulSoutPcmLaw != cOCT6100_PCM_A_LAW )
		return cOCT6100_ERR_CHANNEL_SOUT_PCM_LAW;
	
	/*==============================================================================*/



	return cOCT6100_ERR_OK;
}


/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiCheckVqeConfig

Description:    This function will check the validity of the VQE config parameter
				of an Open VQE config structure.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

f_pVqeConfig			VQE config of the channel.
f_fEnableToneDisabler	Whether the tone disabler is active or not.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiCheckVqeConfig( 
				IN OUT	tPOCT6100_INSTANCE_API			f_pApiInstance,
				IN		tPOCT6100_CHANNEL_OPEN_VQE		f_pVqeConfig,
				IN		BOOL							f_fEnableToneDisabler )
{
	tPOCT6100_API_IMAGE_INFO		pImageInfo;

	pImageInfo = &f_pApiInstance->pSharedInfo->ImageInfo;

	if ( f_pVqeConfig->fEnableNlp != TRUE && f_pVqeConfig->fEnableNlp != FALSE )
		return cOCT6100_ERR_CHANNEL_ENABLE_NLP;

	if ( f_pVqeConfig->fEnableNlp == TRUE && pImageInfo->fNlpControl == FALSE )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_NLP_CONTROL;
	


	/* Check the comfort noise mode.*/
	if ( f_pVqeConfig->ulComfortNoiseMode != cOCT6100_COMFORT_NOISE_OFF && pImageInfo->fComfortNoise == FALSE )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_BKG_NOISE_FREEZE;

	if ( f_pVqeConfig->ulComfortNoiseMode != cOCT6100_COMFORT_NOISE_NORMAL && 
		 f_pVqeConfig->ulComfortNoiseMode != cOCT6100_COMFORT_NOISE_EXTENDED &&
		 f_pVqeConfig->ulComfortNoiseMode != cOCT6100_COMFORT_NOISE_FAST_LATCH &&
		 f_pVqeConfig->ulComfortNoiseMode != cOCT6100_COMFORT_NOISE_OFF )
		return cOCT6100_ERR_CHANNEL_COMFORT_NOISE_MODE;

	/* Check the DC offset removal.*/
	if ( f_pVqeConfig->fSinDcOffsetRemoval != TRUE && f_pVqeConfig->fSinDcOffsetRemoval != FALSE )
		return cOCT6100_ERR_CHANNEL_SIN_DC_OFFSET_REM;

	if ( f_pVqeConfig->fSinDcOffsetRemoval == TRUE && pImageInfo->fSinDcOffsetRemoval == FALSE )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_SIN_DC_OFFSET_REM;

	if ( f_pVqeConfig->fRinDcOffsetRemoval != TRUE && f_pVqeConfig->fRinDcOffsetRemoval != FALSE )
		return cOCT6100_ERR_CHANNEL_RIN_DC_OFFSET_REM;

	if ( f_pVqeConfig->fRinDcOffsetRemoval == TRUE && pImageInfo->fRinDcOffsetRemoval == FALSE )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_RIN_DC_OFFSET_REM;

	/* Check the Level control.*/
	if ( f_pVqeConfig->fRinLevelControl != TRUE && f_pVqeConfig->fRinLevelControl != FALSE )
		return cOCT6100_ERR_CHANNEL_RIN_LEVEL_CONTROL;

	if ( f_pVqeConfig->fSoutLevelControl != TRUE && f_pVqeConfig->fSoutLevelControl != FALSE )
		return cOCT6100_ERR_CHANNEL_SOUT_LEVEL_CONTROL;

	if ( ( f_pVqeConfig->lRinLevelControlGainDb < -24 ) || ( f_pVqeConfig->lRinLevelControlGainDb >  24 ) )
		return cOCT6100_ERR_CHANNEL_RIN_LEVEL_CONTROL_GAIN;

	if ( ( f_pVqeConfig->lSoutLevelControlGainDb < -24 ) || ( f_pVqeConfig->lSoutLevelControlGainDb >  24 ) )
		return cOCT6100_ERR_CHANNEL_SOUT_LEVEL_CONTROL_GAIN;

	if ( ( f_pVqeConfig->fRinAutomaticLevelControl != TRUE ) && ( f_pVqeConfig->fRinAutomaticLevelControl != FALSE ) )
		return cOCT6100_ERR_CHANNEL_RIN_AUTO_LEVEL_CONTROL;

	if ( ( f_pVqeConfig->fRinHighLevelCompensation != TRUE ) && ( f_pVqeConfig->fRinHighLevelCompensation != FALSE ) )
		return cOCT6100_ERR_CHANNEL_RIN_HIGH_LEVEL_COMP;

	if ( ( f_pVqeConfig->fRinAutomaticLevelControl == TRUE ) && ( pImageInfo->fRinAutoLevelControl == FALSE ) ) 
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_RIN_AUTO_LC;

	if ( ( f_pVqeConfig->fRinHighLevelCompensation == TRUE ) && ( pImageInfo->fRinHighLevelCompensation == FALSE ) )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_RIN_HIGH_LEVEL_COMP;

	if ( f_pVqeConfig->fRinAutomaticLevelControl == TRUE )
	{
		if ( f_pVqeConfig->fRinLevelControl == TRUE )
			return cOCT6100_ERR_CHANNEL_RIN_AUTO_LEVEL_MANUAL;

		if ( f_pVqeConfig->fRinHighLevelCompensation == TRUE )
			return cOCT6100_ERR_CHANNEL_RIN_AUTO_LEVEL_HIGH_LEVEL_COMP;

		if ( ( f_pVqeConfig->lRinAutomaticLevelControlTargetDb < -40 || f_pVqeConfig->lRinAutomaticLevelControlTargetDb > 0 ) )
			return cOCT6100_ERR_CHANNEL_RIN_AUTO_LEVEL_CONTROL_TARGET;
	}

	if ( f_pVqeConfig->fRinHighLevelCompensation == TRUE )
	{
		if ( f_pVqeConfig->fRinLevelControl == TRUE )
			return cOCT6100_ERR_CHANNEL_RIN_HIGH_LEVEL_COMP_MANUAL;

		if ( ( f_pVqeConfig->lRinHighLevelCompensationThresholdDb < -40 || f_pVqeConfig->lRinHighLevelCompensationThresholdDb > 0 ) )
			return cOCT6100_ERR_CHANNEL_RIN_HIGH_LEVEL_COMP_THRESHOLD;
	}

	if ( f_pVqeConfig->fSoutAutomaticLevelControl != TRUE && f_pVqeConfig->fSoutAutomaticLevelControl != FALSE )
		return cOCT6100_ERR_CHANNEL_SOUT_AUTO_LEVEL_CONTROL;

	if ( ( f_pVqeConfig->fSoutAutomaticLevelControl == TRUE ) && ( pImageInfo->fSoutAutoLevelControl == FALSE ) ) 
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_SOUT_AUTO_LC;

	if ( f_pVqeConfig->fSoutAutomaticLevelControl == TRUE )
	{
		if ( f_pVqeConfig->fSoutLevelControl == TRUE )
			return cOCT6100_ERR_CHANNEL_SOUT_AUTO_LEVEL_MANUAL;

		if ( ( f_pVqeConfig->lSoutAutomaticLevelControlTargetDb < -40 || f_pVqeConfig->lSoutAutomaticLevelControlTargetDb > 0 ) )
			return cOCT6100_ERR_CHANNEL_SOUT_AUTO_LEVEL_CONTROL_TARGET;
	}

	if ( f_pVqeConfig->fSoutAdaptiveNoiseReduction != TRUE && 
		 f_pVqeConfig->fSoutAdaptiveNoiseReduction != FALSE )
		return cOCT6100_ERR_CHANNEL_SOUT_ADAPT_NOISE_REDUCTION;

	if ( f_pVqeConfig->fSoutAdaptiveNoiseReduction == TRUE && pImageInfo->fAdaptiveNoiseReduction == FALSE )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_ANR;



	/* Validate the DTMF tone removal parameter.*/
	if ( f_pVqeConfig->fDtmfToneRemoval != TRUE && f_pVqeConfig->fDtmfToneRemoval != FALSE )
		return cOCT6100_ERR_CHANNEL_TONE_REMOVAL;

	if ( f_pVqeConfig->fDtmfToneRemoval == TRUE && pImageInfo->fToneRemoval == FALSE )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_TONE_REMOVAL;



	/* Check the Tail displacement enable.*/
	if ( f_pVqeConfig->fEnableTailDisplacement != TRUE && f_pVqeConfig->fEnableTailDisplacement != FALSE )
		return cOCT6100_ERR_CHANNEL_ENABLE_TAIL_DISPLACEMENT;

	if ( f_pVqeConfig->fEnableTailDisplacement == TRUE && pImageInfo->fTailDisplacement == FALSE )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_TAIL_DISPLACEMENT;

	/* Check the Tail displacement value.*/
	if ( f_pVqeConfig->fEnableTailDisplacement == TRUE )
	{
		if ( f_pVqeConfig->ulTailDisplacement != cOCT6100_AUTO_SELECT_TAIL )
		{
			/* Check if this feature is supported by the image. */
			if ( pImageInfo->fPerChannelTailDisplacement == FALSE )
				return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_PER_CHAN_TAIL;

			/* Check that this value is not greater then what the image supports. */
			if ( f_pVqeConfig->ulTailDisplacement > pImageInfo->usMaxTailDisplacement )
				return cOCT6100_ERR_CHANNEL_TAIL_DISPLACEMENT_INVALID;
		}
	}

	/* Check the tail length value. */
	if ( f_pVqeConfig->ulTailLength != cOCT6100_AUTO_SELECT_TAIL )
	{
		/* Check if this feature is supported by the image. */
		if ( ( pImageInfo->fPerChannelTailLength == FALSE )
			&& ( (UINT16)( f_pVqeConfig->ulTailLength & 0xFFFF ) != pImageInfo->usMaxTailLength ) )
			return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_TAIL_LENGTH;

		if ( ( f_pVqeConfig->ulTailLength < 32 ) || ( f_pVqeConfig->ulTailLength > 128 ) 
			|| ( ( f_pVqeConfig->ulTailLength % 4 ) != 0x0 ) )
			return cOCT6100_ERR_CHANNEL_TAIL_LENGTH;

		/* Check if the requested tail length is supported by the chip. */
		if ( f_pVqeConfig->ulTailLength > pImageInfo->usMaxTailLength )
			return cOCT6100_ERR_CHANNEL_TAIL_LENGTH_INVALID;
	}

	/* Validate the acoustic echo cancellation parameter.*/
	if ( f_pVqeConfig->fAcousticEcho != TRUE && f_pVqeConfig->fAcousticEcho != FALSE )
		return cOCT6100_ERR_CHANNEL_ACOUSTIC_ECHO;

	if ( f_pVqeConfig->fAcousticEcho == TRUE && pImageInfo->fAcousticEcho == FALSE )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_ACOUSTIC_ECHO;

	if ( f_pVqeConfig->fAcousticEcho == TRUE )
	{
		/* Check if acoustic echo tail length configuration is supported in the image. */
		if ( ( f_pVqeConfig->ulAecTailLength != 128 ) && ( pImageInfo->fAecTailLength == FALSE ) )
			return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_ACOUSTIC_ECHO_TAIL_LENGTH;

		/* Check the requested acoustic echo tail length. */
		if ( ( f_pVqeConfig->ulAecTailLength != 128 )
			&& ( f_pVqeConfig->ulAecTailLength != 256 ) 
			&& ( f_pVqeConfig->ulAecTailLength != 512 )
			&& ( f_pVqeConfig->ulAecTailLength != 1024 ) )
			return cOCT6100_ERR_CHANNEL_ACOUSTIC_ECHO_TAIL_LENGTH;

		if ( f_pVqeConfig->fEnableTailDisplacement == TRUE )
		{
			UINT32 ulTailSum;

			/* Start with requested tail displacement. */
			if ( f_pVqeConfig->ulTailDisplacement == cOCT6100_AUTO_SELECT_TAIL )
			{
				ulTailSum = f_pApiInstance->pSharedInfo->ChipConfig.usTailDisplacement;
			}
			else
			{
				ulTailSum = f_pVqeConfig->ulTailDisplacement;
			}

			/* Add requested tail length. */
			if ( f_pVqeConfig->ulTailLength == cOCT6100_AUTO_SELECT_TAIL )
			{
				ulTailSum += f_pApiInstance->pSharedInfo->ImageInfo.usMaxTailLength;
			}
			else
			{
				ulTailSum += f_pVqeConfig->ulTailLength;
			}

			/* The tail sum must be smaller then the requested AEC tail length. */
			if ( ulTailSum > f_pVqeConfig->ulAecTailLength )
				return cOCT6100_ERR_CHANNEL_ACOUSTIC_ECHO_TAIL_SUM;
		}
	}
	
	/* Validate the Default ERL parameter.*/
	if ( f_pVqeConfig->lDefaultErlDb != -6 && pImageInfo->fDefaultErl == FALSE )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_DEFAULT_ERL;

	if ( ( f_pVqeConfig->lDefaultErlDb != 0 ) && 
		( f_pVqeConfig->lDefaultErlDb != -3 ) && 
		( f_pVqeConfig->lDefaultErlDb != -6 ) &&
		( f_pVqeConfig->lDefaultErlDb != -9 ) &&
		( f_pVqeConfig->lDefaultErlDb != -12 ) &&
		( f_pVqeConfig->lDefaultErlDb != -15 ) &&
		( f_pVqeConfig->lDefaultErlDb != -18 ) &&
		( f_pVqeConfig->lDefaultErlDb != -21 ) &&
		( f_pVqeConfig->lDefaultErlDb != -24 ) &&
		( f_pVqeConfig->lDefaultErlDb != -27 ) &&
		( f_pVqeConfig->lDefaultErlDb != -30 ) )
		return cOCT6100_ERR_CHANNEL_DEFAULT_ERL;

	/* Validate the Default AEC ERL parameter.*/
	if ( f_pVqeConfig->lAecDefaultErlDb != 0 && pImageInfo->fAecDefaultErl == FALSE )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_AEC_DEFAULT_ERL;

	if ( ( f_pVqeConfig->lAecDefaultErlDb != 0 ) && 
		 ( f_pVqeConfig->lAecDefaultErlDb != -3 ) && 
		 ( f_pVqeConfig->lAecDefaultErlDb != -6 ) &&
		 ( f_pVqeConfig->lAecDefaultErlDb != -9 ) &&
		 ( f_pVqeConfig->lAecDefaultErlDb != -12 ) && 
		 ( f_pVqeConfig->lAecDefaultErlDb != -15 ) &&
		 ( f_pVqeConfig->lAecDefaultErlDb != -18 ) && 
		 ( f_pVqeConfig->lAecDefaultErlDb != -21 ) && 
		 ( f_pVqeConfig->lAecDefaultErlDb != -24 ) &&
		 ( f_pVqeConfig->lAecDefaultErlDb != -27 ) && 
		 ( f_pVqeConfig->lAecDefaultErlDb != -30 ) )
		return cOCT6100_ERR_CHANNEL_AEC_DEFAULT_ERL;

	/* Validate the non-linearity A parameter.*/
	if ( f_pVqeConfig->ulNonLinearityBehaviorA != 1 && pImageInfo->fNonLinearityBehaviorA == FALSE )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_DOUBLE_TALK;

	if ( f_pVqeConfig->ulNonLinearityBehaviorA >= 14 )
		return cOCT6100_ERR_CHANNEL_DOUBLE_TALK;

	/* Validate the non-linearity B parameter.*/
	if ( f_pVqeConfig->ulNonLinearityBehaviorB != 0 && pImageInfo->fNonLinearityBehaviorB == FALSE )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_NON_LINEARITY_B;

	if ( f_pVqeConfig->ulNonLinearityBehaviorB >= 9 )
		return cOCT6100_ERR_CHANNEL_NON_LINEARITY_B;

	/* Check if configuring the double talk behavior is supported in the firmware. */
	if ( f_pVqeConfig->ulDoubleTalkBehavior != cOCT6100_DOUBLE_TALK_BEH_NORMAL && pImageInfo->fDoubleTalkBehavior == FALSE )
		return cOCT6100_ERR_NOT_SUPPORTED_DOUBLE_TALK_BEHAVIOR_MODE;
	
	/* Validate the double talk behavior mode parameter. */
	if ( f_pVqeConfig->ulDoubleTalkBehavior != cOCT6100_DOUBLE_TALK_BEH_NORMAL && f_pVqeConfig->ulDoubleTalkBehavior != cOCT6100_DOUBLE_TALK_BEH_LESS_AGGRESSIVE )
		return cOCT6100_ERR_CHANNEL_DOUBLE_TALK_MODE;

	/* Validate the Sout automatic listener enhancement ratio. */
	if ( f_pVqeConfig->ulSoutAutomaticListenerEnhancementGainDb != 0 && pImageInfo->fListenerEnhancement == FALSE )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_ALE;

	if ( f_pVqeConfig->ulSoutAutomaticListenerEnhancementGainDb > 30 )
		return cOCT6100_ERR_CHANNEL_ALE_RATIO;

	/* Validate the Sout natural listener enhancement ratio. */
	if ( f_pVqeConfig->fSoutNaturalListenerEnhancement != TRUE && f_pVqeConfig->fSoutNaturalListenerEnhancement != FALSE )
		return cOCT6100_ERR_CHANNEL_NLE_FLAG;

	if ( f_pVqeConfig->fSoutNaturalListenerEnhancement == TRUE && pImageInfo->fListenerEnhancement == FALSE )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_NLE;

	if ( f_pVqeConfig->fSoutNaturalListenerEnhancement == TRUE )
	{
		if ( f_pVqeConfig->ulSoutNaturalListenerEnhancementGainDb > 30 )
			return cOCT6100_ERR_CHANNEL_NLE_RATIO;
	}

	/* Both ALE and NLE cannot be activated simultaneously. */
	if ( ( f_pVqeConfig->ulSoutAutomaticListenerEnhancementGainDb != 0 )
		&& ( f_pVqeConfig->fSoutNaturalListenerEnhancement == TRUE ) )
		return cOCT6100_ERR_CHANNEL_ALE_NLE_SIMULTANEOUSLY;
	
	/* Validate Rout noise reduction. */
	if ( f_pVqeConfig->fRoutNoiseReduction != TRUE && f_pVqeConfig->fRoutNoiseReduction != FALSE )
		return cOCT6100_ERR_CHANNEL_ROUT_NOISE_REDUCTION;

	/* Check if Rout noise reduction is supported. */
	if ( f_pVqeConfig->fRoutNoiseReduction == TRUE && pImageInfo->fRoutNoiseReduction == FALSE )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_ROUT_NR;

	/* Check if parameters are valid. */
	if ( f_pVqeConfig->fEnablePlayout != TRUE && f_pVqeConfig->fEnablePlayout != FALSE )
		return cOCT6100_ERR_CHANNEL_ENABLE_PLAYOUT;
	if ( f_pVqeConfig->fEnablePlayout == FALSE && pImageInfo->fPerChannelPlayoutControl == FALSE )
		return cOCT6100_ERR_NOT_SUPPORTED_DISABLE_PLAYOUT;

	if ( f_pVqeConfig->fEnablePlayout == TRUE && f_pVqeConfig->fRoutNoiseReduction == TRUE && pImageInfo->fPerChannelPlayoutControl == TRUE)
		return cOCT6100_ERR_NOT_SUPPORTED_ENABLE_PLAYOUT_AND_ROUT_NOISE_REDUCTION;

	/*Check if noise reduction level gain is supported*/
	if ( ( pImageInfo->fRoutNoiseReductionLevel == FALSE ) && ( f_pVqeConfig->lRoutNoiseReductionLevelGainDb != -18 ) )
		 return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_ROUT_NOISE_REDUCTION_GAIN;
	
	if ( ( f_pVqeConfig->lRoutNoiseReductionLevelGainDb != 0 ) && 
		( f_pVqeConfig->lRoutNoiseReductionLevelGainDb != -6 ) && 
		( f_pVqeConfig->lRoutNoiseReductionLevelGainDb != -12 ) &&
		( f_pVqeConfig->lRoutNoiseReductionLevelGainDb != -18 ) )
	
		return cOCT6100_ERR_CHANNEL_ROUT_NOISE_REDUCTION_GAIN;

	/* Check if ANR SNRE is supported. */
	if ( ( f_pVqeConfig->lAnrSnrEnhancementDb != -18 ) && ( pImageInfo->fAnrSnrEnhancement == FALSE ) )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_ANR_SNR_ENHANCEMENT;

	/* Validate Sout ANR SNR enhancement. */
	if ( ( f_pVqeConfig->lAnrSnrEnhancementDb != -9 )
		&& ( f_pVqeConfig->lAnrSnrEnhancementDb != -12 ) 
		&& ( f_pVqeConfig->lAnrSnrEnhancementDb != -15 )
		&& ( f_pVqeConfig->lAnrSnrEnhancementDb != -18 )
		&& ( f_pVqeConfig->lAnrSnrEnhancementDb != -21 )
		&& ( f_pVqeConfig->lAnrSnrEnhancementDb != -24 )
		&& ( f_pVqeConfig->lAnrSnrEnhancementDb != -27 )
		&& ( f_pVqeConfig->lAnrSnrEnhancementDb != -30 ) )
		return cOCT6100_ERR_CHANNEL_ANR_SNR_ENHANCEMENT;
	
	/* Validate ANR voice-noise segregation. */
	if ( f_pVqeConfig->ulAnrVoiceNoiseSegregation > 15 )
		return cOCT6100_ERR_CHANNEL_ANR_SEGREGATION;

	/* Check if ANR VN segregation is supported. */
	if ( ( f_pVqeConfig->ulAnrVoiceNoiseSegregation != 6 ) && ( pImageInfo->fAnrVoiceNoiseSegregation == FALSE ) )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_ANR_SEGREGATION;

	/* Check if the loaded image supports tone disabler VQE activation delay. */
	if ( ( f_pVqeConfig->ulToneDisablerVqeActivationDelay != 300 )
		&& ( pImageInfo->fToneDisablerVqeActivationDelay == FALSE ) )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_TONE_DISABLER_ACTIVATION_DELAY;

	/* Check if the specified tone disabler VQE activation delay is correct. */
	if ( ( f_pVqeConfig->ulToneDisablerVqeActivationDelay < 300 )
		|| ( ( ( f_pVqeConfig->ulToneDisablerVqeActivationDelay - 300 ) % 512 ) != 0 ) )
		return cOCT6100_ERR_CHANNEL_TONE_DISABLER_ACTIVATION_DELAY;

	/* Check the enable music protection flag. */
	if ( ( f_pVqeConfig->fEnableMusicProtection != TRUE ) && ( f_pVqeConfig->fEnableMusicProtection != FALSE ) )
		return cOCT6100_ERR_CHANNEL_ENABLE_MUSIC_PROTECTION;

	/* The music protection module can only be activated if the image supports it. */
	if ( ( f_pVqeConfig->fEnableMusicProtection == TRUE ) &&
		( pImageInfo->fMusicProtection == FALSE ) )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_MUSIC_PROTECTION;

	/* Check the enable idle code detection flag. */
	if ( ( f_pVqeConfig->fIdleCodeDetection != TRUE ) && ( f_pVqeConfig->fIdleCodeDetection != FALSE ) )
		return cOCT6100_ERR_CHANNEL_IDLE_CODE_DETECTION;

	/* The idle code detection module can only be activated if the image supports it. */
	if ( ( f_pVqeConfig->fIdleCodeDetection == TRUE ) && ( pImageInfo->fIdleCodeDetection == FALSE ) )
		return cOCT6100_ERR_NOT_SUPPORTED_IDLE_CODE_DETECTION;

	/* The idle code detection module can be disabled only if idle code detection configuration */
	/* is supported in the image. */
	if ( pImageInfo->fIdleCodeDetection == TRUE )
	{
		if ( ( f_pVqeConfig->fIdleCodeDetection == FALSE ) && ( pImageInfo->fIdleCodeDetectionConfiguration == FALSE ) )
			return cOCT6100_ERR_NOT_SUPPORTED_IDLE_CODE_DETECTION_CONFIG;
	}

	return cOCT6100_ERR_OK;
}



/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiWriteInputTsstControlMemory

Description:    This function configure a TSST control memory entry in internal memory.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

f_usTsstIndex			TSST index within the TSST control memory.
f_usTsiMemIndex			TSI index within the TSI chariot memory.
f_ulTsstInputLaw		PCM law of the input TSST.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiWriteInputTsstControlMemory( 
				IN	tPOCT6100_INSTANCE_API			f_pApiInstance,
				IN	UINT16							f_usTsstIndex,
				IN	UINT16							f_usTsiMemIndex,
				IN	UINT32							f_ulTsstInputLaw )
{
	tOCT6100_WRITE_PARAMS			WriteParams;
	UINT32							ulResult;

	WriteParams.pProcessContext = f_pApiInstance->pProcessContext;

	WriteParams.ulUserChipId = f_pApiInstance->pSharedInfo->ChipConfig.ulUserChipId;

	WriteParams.ulWriteAddress = cOCT6100_TSST_CONTROL_MEM_BASE + ( (f_usTsstIndex & cOCT6100_TSST_INDEX_MASK) * cOCT6100_TSST_CONTROL_MEM_ENTRY_SIZE );
	
	WriteParams.usWriteData  = cOCT6100_TSST_CONTROL_MEM_INPUT_TSST;
	WriteParams.usWriteData |= f_usTsiMemIndex & cOCT6100_TSST_CONTROL_MEM_TSI_MEM_MASK;

	/* Set the PCM law.*/
	WriteParams.usWriteData |= f_ulTsstInputLaw << cOCT6100_TSST_CONTROL_MEM_PCM_LAW_OFFSET;

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	return cOCT6100_ERR_OK;
}



/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiWriteOutputTsstControlMemory

Description:    This function configure a TSST control memory entry in internal memory.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiWriteOutputTsstControlMemory( 
				IN	tPOCT6100_INSTANCE_API			f_pApiInstance,
				IN	UINT16							f_usTsstIndex,

				IN	UINT16							f_usTsiMemIndex )
{
	tOCT6100_WRITE_PARAMS			WriteParams;
	UINT32							ulResult;

	WriteParams.pProcessContext = f_pApiInstance->pProcessContext;

	WriteParams.ulUserChipId = f_pApiInstance->pSharedInfo->ChipConfig.ulUserChipId;

	WriteParams.ulWriteAddress = cOCT6100_TSST_CONTROL_MEM_BASE + ( (f_usTsstIndex & cOCT6100_TSST_INDEX_MASK) * cOCT6100_TSST_CONTROL_MEM_ENTRY_SIZE );
	
	WriteParams.usWriteData  = cOCT6100_TSST_CONTROL_MEM_OUTPUT_TSST;

	WriteParams.usWriteData |= f_usTsiMemIndex & cOCT6100_TSST_CONTROL_MEM_TSI_MEM_MASK;

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	return cOCT6100_ERR_OK;
}



/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiWriteLawConversionMemory

Description:    This function configure a conversion memory entry in internal 
				memory for law conversion.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance				Pointer to API instance. This memory is used to keep
							the present state of the chip and all its resources.

f_usConversionMemIndex		Index of the conversion block within the conversion memory.
f_usTsiMemIndex				TSI index within the TSI chariot memory.
f_ulPcmLaw					PCM law of the encoded samples.
f_fRinRoutStream			Flag indicating if we are programming the Rin/Rout 
							stream or not.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiWriteLawConversionMemory( 
				IN	tPOCT6100_INSTANCE_API			f_pApiInstance,
				IN	UINT16							f_usConversionMemIndex,
				IN	UINT16							f_usTsiMemIndex,
				IN	UINT32							f_ulPcmLaw,
				IN	UINT32							f_fRinRoutStream )
{
	tOCT6100_WRITE_PARAMS			WriteParams;
	UINT32							ulResult;

	WriteParams.pProcessContext = f_pApiInstance->pProcessContext;

	WriteParams.ulUserChipId = f_pApiInstance->pSharedInfo->ChipConfig.ulUserChipId;

	/*==============================================================================*/
	/* Conversion Control Base */
	WriteParams.ulWriteAddress = cOCT6100_CONVERSION_CONTROL_MEM_BASE + ( f_usConversionMemIndex * cOCT6100_CONVERSION_CONTROL_MEM_ENTRY_SIZE );
	
	/* When we are programming the Rin/Rout stream, we consider the conversion memory as */
	/* a decoder, as opposed to the Sin/Sout stream, which is an encoder. */
	if ( f_fRinRoutStream == TRUE )
	{
		WriteParams.usWriteData  = cOCT6100_CONVERSION_CONTROL_MEM_DECODER;
		WriteParams.usWriteData |= 0x8 << cOCT6100_CONVERSION_CONTROL_MEM_COMP_OFFSET;
	}
	else /* f_fRinRoutStream == FALSE */
	{
		WriteParams.usWriteData  = cOCT6100_CONVERSION_CONTROL_MEM_ENCODER;
		if ( f_ulPcmLaw == cOCT6100_PCM_U_LAW )
		{
			WriteParams.usWriteData |= 0x4 << cOCT6100_CONVERSION_CONTROL_MEM_COMP_OFFSET;
		}
		else /* ulPcmLaw  == cOCT6100_PCM_A_LAW */
		{
			WriteParams.usWriteData |= 0x5 << cOCT6100_CONVERSION_CONTROL_MEM_COMP_OFFSET;
		}
	}
	WriteParams.usWriteData |= f_usTsiMemIndex & cOCT6100_TSST_CONTROL_MEM_TSI_MEM_MASK;

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;
	
	/*==============================================================================*/
	/* Conversion Control Base + 2 */
	WriteParams.ulWriteAddress += 2;

	if ( f_fRinRoutStream == TRUE )
	{
		/* Default to u-law */
		WriteParams.usWriteData = 0;
		if ( f_ulPcmLaw == cOCT6100_PCM_A_LAW )
		{
			/* Set A-law bit */
			WriteParams.usWriteData |= 0x1 << cOCT6100_CONVERSION_CONTROL_MEM_LAW_OFFSET;
		}
	}
	else /* f_fRinRoutStream == FALSE */
	{
		/* No phasing */
		WriteParams.usWriteData = 0x1 << 10;
	}

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/*==============================================================================*/
	/* Conversion Control Base + 4 */
	WriteParams.ulWriteAddress += 2;
		
	/* Set the reset mode */
	WriteParams.usWriteData	= cOCT6100_CONVERSION_CONTROL_MEM_RST_ON_NEXT_FR;

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/*==============================================================================*/
	/* Conversion Control Base + 6 */
	WriteParams.ulWriteAddress += 2;
		
	/* Activate this entry */
	WriteParams.usWriteData	= cOCT6100_CONVERSION_CONTROL_MEM_ACTIVATE_ENTRY;

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/*==============================================================================*/
	return cOCT6100_ERR_OK;
}



/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiClearConversionMemory

Description:    This function clears a conversion memory entry in internal 
				memory.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep 
						the present state of the chip and all its resources.

f_usConversionMemIndex	Index of the block within the conversion memory.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiClearConversionMemory( 
				IN	tPOCT6100_INSTANCE_API			f_pApiInstance,
				IN	UINT16							f_usConversionMemIndex )
{
	tOCT6100_WRITE_PARAMS		WriteParams;
	tOCT6100_READ_PARAMS		ReadParams;
	UINT32						ulResult;
	UINT32						ulBaseAddress;
	UINT16						usReadData;

	WriteParams.pProcessContext = f_pApiInstance->pProcessContext;

	WriteParams.ulUserChipId = f_pApiInstance->pSharedInfo->ChipConfig.ulUserChipId;
	WriteParams.usWriteData = 0;

	ReadParams.pProcessContext = f_pApiInstance->pProcessContext;

	ReadParams.ulUserChipId = f_pApiInstance->pSharedInfo->ChipConfig.ulUserChipId;
	ReadParams.pusReadData = &usReadData;

	/*==============================================================================*/
	/* Clear the entry */
	ulBaseAddress = cOCT6100_CONVERSION_CONTROL_MEM_BASE + ( f_usConversionMemIndex * cOCT6100_CONVERSION_CONTROL_MEM_ENTRY_SIZE );
	/* The "activate" bit at offset +6 must be cleared first. */
	WriteParams.ulWriteAddress = ulBaseAddress + 6;

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;
	
	/* Read at 0x200 to make sure there is no corruption on channel 0. */
	ReadParams.ulReadAddress = 0x200;
	mOCT6100_DRIVER_READ_API( ReadParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;	

	/* Then clear the rest of the structure. */
	WriteParams.ulWriteAddress = ulBaseAddress + 4;

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	WriteParams.ulWriteAddress = ulBaseAddress + 2;

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	WriteParams.ulWriteAddress = ulBaseAddress;

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;
	
	/*==============================================================================*/
	
	return cOCT6100_ERR_OK;
}


/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiWriteVqeMemory

Description:    This function configure an echo memory entry in internal memory and
				external memory.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance				Pointer to API instance. This memory is used to keep
							the present state of the chip and all its resources.

f_pVqeConfig				Pointer to a VQE config structure.
f_pChannelOpen				Pointer to a channel configuration structure.
f_usChanIndex				Index of the echo channel in the API instance.
f_usEchoMemIndex			Index of the echo channel within the SSPX memory.
f_fClearPlayoutPointers		Flag indicating if the playout pointer should be cleared.
f_fModifyOnly				Flag indicating if the configuration should be
							modified only.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiWriteVqeMemory( 
				IN	tPOCT6100_INSTANCE_API			f_pApiInstance,
				IN	tPOCT6100_CHANNEL_OPEN_VQE		f_pVqeConfig,
				IN	tPOCT6100_CHANNEL_OPEN			f_pChannelOpen,
				IN	UINT16							f_usChanIndex,
				IN	UINT16							f_usEchoMemIndex,
				IN	BOOL							f_fClearPlayoutPointers,
				IN	BOOL							f_fModifyOnly )
{
	UINT32	ulResult;

	/* Write the NLP software configuration structure. */
	ulResult = Oct6100ApiWriteVqeNlpMemory(
							f_pApiInstance,
							f_pVqeConfig,
							f_pChannelOpen,
							f_usChanIndex,
							f_usEchoMemIndex,
							f_fClearPlayoutPointers,
							f_fModifyOnly );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	/* Write the AF software configuration structure. */
	ulResult = Oct6100ApiWriteVqeAfMemory(
							f_pApiInstance,
							f_pVqeConfig,
							f_pChannelOpen,
							f_usChanIndex,
							f_usEchoMemIndex,
							f_fClearPlayoutPointers,
							f_fModifyOnly );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiWriteVqeNlpMemory

Description:    This function configures the NLP related VQE features of an 
				echo channel.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance				Pointer to API instance. This memory is used to keep
							the present state of the chip and all its resources.

f_pVqeConfig				Pointer to a VQE config structure.
f_pChannelOpen				Pointer to a channel configuration structure.
f_usChanIndex				Index of the echo channel in the API instance.
f_usEchoMemIndex			Index of the echo channel within the SSPX memory.
f_fClearPlayoutPointers		Flag indicating if the playout pointer should be cleared.
f_fModifyOnly				Flag indicating if the configuration should be
							modified only.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiWriteVqeNlpMemory( 
				IN	tPOCT6100_INSTANCE_API			f_pApiInstance,
				IN	tPOCT6100_CHANNEL_OPEN_VQE		f_pVqeConfig,
				IN	tPOCT6100_CHANNEL_OPEN			f_pChannelOpen,
				IN	UINT16							f_usChanIndex,
				IN	UINT16							f_usEchoMemIndex,
				IN	BOOL							f_fClearPlayoutPointers,
				IN	BOOL							f_fModifyOnly )
{
	tPOCT6100_API_CHANNEL			pChanEntry;
	tPOCT6100_SHARED_INFO			pSharedInfo;
	tOCT6100_WRITE_PARAMS			WriteParams;

	UINT32							ulResult;
	UINT32							ulTempData;
	UINT32							ulNlpConfigBaseAddress;
	UINT32							ulFeatureBytesOffset;
	UINT32							ulFeatureBitOffset;
	UINT32							ulFeatureFieldLength;
	UINT32							ulMask;
	UINT16							usTempData;
	BOOL							fEchoOperationModeChanged;
	
	pSharedInfo = f_pApiInstance->pSharedInfo;

	WriteParams.pProcessContext = f_pApiInstance->pProcessContext;

	WriteParams.ulUserChipId = pSharedInfo->ChipConfig.ulUserChipId;

	/* Obtain a pointer to the new buffer's list entry. */
	mOCT6100_GET_CHANNEL_ENTRY_PNT( pSharedInfo, pChanEntry, f_usChanIndex );

	/*==============================================================================*/
	/*	Configure the CPU NLP configuration of the channel feature by feature.*/

	ulNlpConfigBaseAddress = cOCT6100_CHANNEL_ROOT_BASE + ( f_usEchoMemIndex * cOCT6100_CHANNEL_ROOT_SIZE ) + pSharedInfo->MemoryMap.ulChanRootConfOfst;
	
	/* Set initial value to zero.*/
	ulTempData = 0;

	/* Configure Adaptive Noise Reduction.*/
	if ( pSharedInfo->ImageInfo.fAdaptiveNoiseReduction == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE ) 
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( ( f_pVqeConfig->fSoutAdaptiveNoiseReduction != pChanEntry->VqeConfig.fSoutAdaptiveNoiseReduction ) 

					) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.AdaptiveNoiseReductionOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.AdaptiveNoiseReductionOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.AdaptiveNoiseReductionOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulNlpConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData, 
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;
			
			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);

			/* Set adaptive noise reduction on the SOUT port.*/
			ulTempData |= ( ( (UINT32)f_pVqeConfig->fSoutAdaptiveNoiseReduction ) << ulFeatureBitOffset );



			/* First read the DWORD where the field is located. */
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}

	/* Configure Rout Noise Reduction. */
	if ( pSharedInfo->ImageInfo.fRoutNoiseReduction == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( f_pVqeConfig->fRoutNoiseReduction != pChanEntry->VqeConfig.fRoutNoiseReduction ) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.RinAnrOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.RinAnrOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.RinAnrOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulNlpConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;
			
			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);

			/* Set noise reduction on the Rout port. */
			ulTempData |= ( ( (UINT32)f_pVqeConfig->fRoutNoiseReduction ) << ulFeatureBitOffset );

			/* Write the new DWORD where the field is located. */
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}
	if (pSharedInfo->ImageInfo.fRoutNoiseReductionLevel == TRUE)
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( (f_pVqeConfig->lRoutNoiseReductionLevelGainDb != pChanEntry->VqeConfig.chRoutNoiseReductionLevelGainDb ) 
				   ||( f_pVqeConfig->fRoutNoiseReduction != pChanEntry->VqeConfig.fRoutNoiseReduction ) ) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.RinAnrValOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.RinAnrValOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.RinAnrValOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulNlpConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;
			
			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);

			if (f_pVqeConfig->fRoutNoiseReduction == TRUE)
			{
				switch( f_pVqeConfig->lRoutNoiseReductionLevelGainDb)
				{
				case  0:	ulTempData |= ( 0 << ulFeatureBitOffset );
					break;
				case -6:	ulTempData |= ( 1 << ulFeatureBitOffset );
					break;
				case -12:	ulTempData |= ( 2 << ulFeatureBitOffset );
					break;
				case -18:	ulTempData |= ( 3 << ulFeatureBitOffset );
					break;
				default:	ulTempData |= ( 0 << ulFeatureBitOffset );
					break;
				}
			}
			else 
				ulTempData |= ( 0 << ulFeatureBitOffset );

			/* Write the new DWORD where the field is located. */
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}

	}

	/* Per channel playout configuration control. */
	if ( pSharedInfo->ImageInfo.fPerChannelPlayoutControl == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( f_pVqeConfig->fEnablePlayout != pChanEntry->VqeConfig.fEnablePlayout ) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.PerChannelPlayoutControlFieldOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.PerChannelPlayoutControlFieldOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.PerChannelPlayoutControlFieldOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											&ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);
			ulTempData |= (UINT32)f_pVqeConfig->fEnablePlayout << ulFeatureBitOffset;

			/* Write the new DWORD where the field is located. */
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}

	/* Configure Sout ANR SNR enhancement. */
	if ( pSharedInfo->ImageInfo.fAnrSnrEnhancement == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( f_pVqeConfig->lAnrSnrEnhancementDb != pChanEntry->VqeConfig.chAnrSnrEnhancementDb ) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.AnrSnrEnhancementOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.AnrSnrEnhancementOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.AnrSnrEnhancementOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulNlpConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;
			
			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);

			/* Set ANR SNR enhancement on the Sout port. */
			switch( f_pVqeConfig->lAnrSnrEnhancementDb )
			{
			case -9:	ulTempData |= ( 7 << ulFeatureBitOffset );
				break;
			case -12:	ulTempData |= ( 6 << ulFeatureBitOffset );
				break;
			case -15:	ulTempData |= ( 5 << ulFeatureBitOffset );
				break;
			case -21:	ulTempData |= ( 3 << ulFeatureBitOffset );
				break;
			case -24:	ulTempData |= ( 2 << ulFeatureBitOffset );
				break;
			case -27:	ulTempData |= ( 1 << ulFeatureBitOffset );
				break;
			case -30:	ulTempData |= ( 0 << ulFeatureBitOffset );
				break;
			default:	ulTempData |= ( 4 << ulFeatureBitOffset );
				/* -18 */
				break;
			}

			/* Write the new DWORD where the field is located. */
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}

	/* Configure Sout ANR voice-noise segregation. */
	if ( pSharedInfo->ImageInfo.fAnrVoiceNoiseSegregation == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( f_pVqeConfig->ulAnrVoiceNoiseSegregation != pChanEntry->VqeConfig.byAnrVoiceNoiseSegregation ) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.AnrVoiceNoiseSegregationOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.AnrVoiceNoiseSegregationOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.AnrVoiceNoiseSegregationOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulNlpConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;
			
			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);

			/* Set ANR voice-noise segregation on the Sout port. */
			ulTempData |= ( ( (UINT32)f_pVqeConfig->ulAnrVoiceNoiseSegregation ) << ulFeatureBitOffset );

			/* Write the new DWORD where the field is located. */
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}

	/* Configure the tone disabler VQE activation delay. */
	if ( pSharedInfo->ImageInfo.fToneDisablerVqeActivationDelay == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( ( f_pVqeConfig->ulToneDisablerVqeActivationDelay != pChanEntry->VqeConfig.usToneDisablerVqeActivationDelay ) 
					|| ( f_pChannelOpen->fEnableToneDisabler != pChanEntry->fEnableToneDisabler ) ) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.ToneDisablerVqeActivationDelayOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.ToneDisablerVqeActivationDelayOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.ToneDisablerVqeActivationDelayOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulNlpConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;
			
			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);

			/* Set the tone disabler VQE activation delay.  The VQE activation delay */
			/* is only set if the tone disabler is activated. */
			if ( f_pChannelOpen->fEnableToneDisabler == TRUE )
				ulTempData |= ( ( (UINT32)( ( f_pVqeConfig->ulToneDisablerVqeActivationDelay - 300 ) / 512 ) ) << ulFeatureBitOffset );
			else
				ulTempData |= ( 0 ) << ulFeatureBitOffset;

			/* Write the new DWORD where the field is located. */
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}


	
	/* Set the DC removal on RIN ports.*/
	if ( pSharedInfo->ImageInfo.fRinDcOffsetRemoval == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( f_pVqeConfig->fRinDcOffsetRemoval != pChanEntry->VqeConfig.fRinDcOffsetRemoval ) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.RinDcOffsetRemovalOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.RinDcOffsetRemovalOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.RinDcOffsetRemovalOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulNlpConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData, 
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);

			/* Set adaptive noise reduction on the SOUT port.*/
			ulTempData |= ( ( (UINT32)f_pVqeConfig->fRinDcOffsetRemoval ) << ulFeatureBitOffset );

			/* The write the new DWORD where the field is located.*/
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}

	/* Set the DC removal on SIN ports.*/
	if ( pSharedInfo->ImageInfo.fSinDcOffsetRemoval == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( f_pVqeConfig->fSinDcOffsetRemoval != pChanEntry->VqeConfig.fSinDcOffsetRemoval ) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.SinDcOffsetRemovalOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.SinDcOffsetRemovalOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.SinDcOffsetRemovalOfst.byFieldSize;

			/* First read the DWORD where the field is located.*/
			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulNlpConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);

			/* Set adaptive noise reduction on the SOUT port.*/
			ulTempData |= ( ( (UINT32)f_pVqeConfig->fSinDcOffsetRemoval ) << ulFeatureBitOffset );

			/* Save the DWORD where the field is located.*/
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}

	/* Set the level control. */
	if ( ( pChanEntry->byEchoOperationMode != f_pChannelOpen->ulEchoOperationMode )
		&& ( f_pChannelOpen->ulEchoOperationMode == cOCT6100_ECHO_OP_MODE_NORMAL ) )
		fEchoOperationModeChanged = TRUE;
	else
		fEchoOperationModeChanged = FALSE;

	/* If opening the channel, all level control configuration must be written. */
	if ( f_fModifyOnly == FALSE )
		fEchoOperationModeChanged = TRUE;
	ulResult = Oct6100ApiSetChannelLevelControl( f_pApiInstance, 
												 f_pVqeConfig, 
												 f_usChanIndex,
												 f_usEchoMemIndex,
												 fEchoOperationModeChanged );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	/* Set the background noise freeze.*/
	if ( pSharedInfo->ImageInfo.fComfortNoise == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( f_pVqeConfig->ulComfortNoiseMode != pChanEntry->VqeConfig.byComfortNoiseMode ) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.ComfortNoiseModeOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.ComfortNoiseModeOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.ComfortNoiseModeOfst.byFieldSize;

			/* First read the DWORD where the field is located.*/
			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulNlpConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);
			ulTempData |= ( f_pVqeConfig->ulComfortNoiseMode << ulFeatureBitOffset );

			/* Save the new DWORD where the field is located. */
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}

	/* Set the state of the NLP */
	if ( pSharedInfo->ImageInfo.fNlpControl == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( f_pVqeConfig->fEnableNlp != pChanEntry->VqeConfig.fEnableNlp ) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.NlpControlFieldOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.NlpControlFieldOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.NlpControlFieldOfst.byFieldSize;

			/* First read the DWORD where the field is located.*/
			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulNlpConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);

			if ( f_pVqeConfig->fEnableNlp == FALSE )
				ulTempData |= 0x1 << ulFeatureBitOffset;

			/* Save the new DWORD where the field is located.*/
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;
		}
	}

	/* Set the tail configuration. */
	ulResult = Oct6100ApiSetChannelTailConfiguration(
												f_pApiInstance,
												f_pVqeConfig,
												f_usChanIndex,
												f_usEchoMemIndex,
												f_fModifyOnly );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	/* Set the Default ERL. */
	if ( ( pSharedInfo->ImageInfo.fDefaultErl == TRUE ) && ( f_pVqeConfig->fAcousticEcho == FALSE ) )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( ( f_pVqeConfig->lDefaultErlDb != pChanEntry->VqeConfig.chDefaultErlDb ) 
					|| ( f_pChannelOpen->ulEchoOperationMode != pChanEntry->byEchoOperationMode ) 
					|| ( f_pVqeConfig->fAcousticEcho != pChanEntry->VqeConfig.fAcousticEcho ) ) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.DefaultErlFieldOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.DefaultErlFieldOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.DefaultErlFieldOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulNlpConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);

			/* Convert the DB value to octasic's float format. (In energy) */
			if ( ( f_pChannelOpen->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_NO_ECHO )
				&& ( f_pChannelOpen->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_SPEECH_RECOGNITION ) )
			{
				usTempData = Oct6100ApiDbAmpHalfToOctFloat( 2 * f_pVqeConfig->lDefaultErlDb );
			}
			else
			{
				/* Clear the defautl ERL when using the no echo cancellation operation mode. */
				usTempData = 0x0;
			}

			if ( ulFeatureFieldLength < 16 )
				usTempData = (UINT16)( usTempData >> ( 16 - ulFeatureFieldLength ) );

			ulTempData |= ( usTempData << ulFeatureBitOffset );

			/* Save the new DWORD where the field is located.*/
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}

	/* Set the Acoustic echo control.*/
	if ( pSharedInfo->ImageInfo.fAcousticEcho == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( f_pVqeConfig->fAcousticEcho != pChanEntry->VqeConfig.fAcousticEcho ) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.AecFieldOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.AecFieldOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.AecFieldOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulNlpConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field. */
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);
			ulTempData |= ( ( (UINT32)f_pVqeConfig->fAcousticEcho ) << ulFeatureBitOffset );

			/* Then save the new DWORD where the field is located. */
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}

	/* Set the Acoustic Echo Default ERL. */
	if ( ( pSharedInfo->ImageInfo.fAecDefaultErl == TRUE ) && ( f_pVqeConfig->fAcousticEcho == TRUE ) )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( ( f_pVqeConfig->lAecDefaultErlDb != pChanEntry->VqeConfig.chAecDefaultErlDb ) 
					|| ( f_pVqeConfig->fAcousticEcho != pChanEntry->VqeConfig.fAcousticEcho ) ) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.AecDefaultErlFieldOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.AecDefaultErlFieldOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.AecDefaultErlFieldOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulNlpConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field. */
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);
			
			if ( ( f_pChannelOpen->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_NO_ECHO )
				&& ( f_pChannelOpen->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_SPEECH_RECOGNITION ) )
			{
				/* Convert the DB value to octasic's float format. (In energy) */
				usTempData = Oct6100ApiDbAmpHalfToOctFloat( 2 * f_pVqeConfig->lAecDefaultErlDb );
			}
			else
			{
				/* Clear the AEC defautl ERL when using the no echo cancellation operation mode. */
				usTempData = 0x0;
			}

			if ( ulFeatureFieldLength < 16 )
				usTempData = (UINT16)( usTempData >> ( 16 - ulFeatureFieldLength ) );

			ulTempData |= ( usTempData << ulFeatureBitOffset );

			/* Then save the DWORD where the field is located. */
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}

	/* Set the DTMF tone removal bit.*/
	if ( pSharedInfo->ImageInfo.fToneRemoval == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( f_pVqeConfig->fDtmfToneRemoval != pChanEntry->VqeConfig.fDtmfToneRemoval ) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.ToneRemovalFieldOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.ToneRemovalFieldOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.ToneRemovalFieldOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulNlpConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);
			ulTempData |= ( ( (UINT32)f_pVqeConfig->fDtmfToneRemoval ) << ulFeatureBitOffset );

			/* First read the DWORD where the field is located.*/
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}



	/* Set the non-linear behavior A.*/
	if ( pSharedInfo->ImageInfo.fNonLinearityBehaviorA == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( ( f_pVqeConfig->ulNonLinearityBehaviorA != pChanEntry->VqeConfig.byNonLinearityBehaviorA ) 
					|| ( f_pChannelOpen->ulEchoOperationMode != pChanEntry->byEchoOperationMode ) ) ) )
		{
			UINT16	ausLookupTable[ 14 ] = { 0x3663, 0x3908, 0x399C, 0x3A47, 0x3B06, 0x3B99, 0x3C47, 0x3D02, 0x3D99, 0x3E47, 0x3F00, 0x3F99, 0x4042, 0x4100 };
			
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.PcmLeakFieldOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.PcmLeakFieldOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.PcmLeakFieldOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulNlpConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);
			
			/* Check if some bits of the filed are shared with another field (RNR) */
			usTempData = ausLookupTable[ f_pVqeConfig->ulNonLinearityBehaviorA ];
			if ( ulFeatureFieldLength != 16 )
				usTempData = (UINT16)( usTempData >> ( 16 - ulFeatureFieldLength ) );

			if ( ( f_pChannelOpen->ulEchoOperationMode == cOCT6100_ECHO_OP_MODE_NO_ECHO )
				|| ( f_pChannelOpen->ulEchoOperationMode == cOCT6100_ECHO_OP_MODE_SPEECH_RECOGNITION ) )
				ulTempData |= ( 0x0 << ulFeatureBitOffset );
			else
				ulTempData |= ( usTempData << ulFeatureBitOffset );

			/* Then save the DWORD where the field is located.*/
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;
		}
	}
	


	/*==============================================================================*/
	/* Write the 2100 Hz Echo Disabling mode */

	/* Check if the configuration has been changed. */
	if ( ( f_fModifyOnly == FALSE )
		|| ( ( f_fModifyOnly == TRUE ) 
			&& ( f_pChannelOpen->fEnableToneDisabler != pChanEntry->fEnableToneDisabler ) ) )
	{
		ulFeatureBytesOffset = pSharedInfo->MemoryMap.ToneDisablerControlOfst.usDwordOffset * 4;
		ulFeatureBitOffset	 = pSharedInfo->MemoryMap.ToneDisablerControlOfst.byBitOffset;
		ulFeatureFieldLength = pSharedInfo->MemoryMap.ToneDisablerControlOfst.byFieldSize;

		/* First read the DWORD where the field is located.*/
		mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											&ulTempData,
											ulResult );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;

		/* Clear previous value set in the feature field.*/
		mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

		ulTempData &= (~ulMask);
		
		/* This is a disable bit, so it must be set only if the enable flag is set to false. */
		if ( f_pChannelOpen->fEnableToneDisabler == FALSE )
			ulTempData |= 0x1 << ulFeatureBitOffset;

		/* Save the DWORD where the field is located. */
		mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
										pChanEntry,
										ulNlpConfigBaseAddress + ulFeatureBytesOffset,
										ulTempData,
										ulResult );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;	
	}
	/*==============================================================================*/


	/*==============================================================================*/
	/* Write the Nlp Trivial enable flag. */

	/* Check if the configuration has been changed. */
	if ( ( f_fModifyOnly == FALSE )
		|| ( ( f_fModifyOnly == TRUE ) 
			&& ( 

				( f_pChannelOpen->ulEchoOperationMode != pChanEntry->byEchoOperationMode ) ) ) )
	{
		ulFeatureBytesOffset = pSharedInfo->MemoryMap.NlpTrivialFieldOfst.usDwordOffset * 4;
		ulFeatureBitOffset	 = pSharedInfo->MemoryMap.NlpTrivialFieldOfst.byBitOffset;
		ulFeatureFieldLength = pSharedInfo->MemoryMap.NlpTrivialFieldOfst.byFieldSize;

		/* First read the DWORD where the field is located.*/
		mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											&ulTempData,
											ulResult );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;

		/* Clear previous value set in the feature field.*/
		mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

		ulTempData &= (~ulMask);
		if ( ( f_pChannelOpen->ulEchoOperationMode == cOCT6100_ECHO_OP_MODE_NO_ECHO )
			|| ( f_pChannelOpen->ulEchoOperationMode == cOCT6100_ECHO_OP_MODE_SPEECH_RECOGNITION ) )
		{
			ulTempData |= TRUE << ulFeatureBitOffset;
		}


		/* Then write the DWORD where the field is located. */
		mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
										pChanEntry,
										ulNlpConfigBaseAddress + ulFeatureBytesOffset,
										ulTempData,
										ulResult );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;	
	}
	/*==============================================================================*/


	/*==============================================================================*/
	/* Set the double talk behavior mode. */
	if ( pSharedInfo->ImageInfo.fDoubleTalkBehaviorFieldOfst == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( f_pVqeConfig->ulDoubleTalkBehavior != pChanEntry->VqeConfig.byDoubleTalkBehavior ) ) )
		{
			/* The field is located in the CPURO structure. */
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.DoubleTalkBehaviorFieldOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.DoubleTalkBehaviorFieldOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.DoubleTalkBehaviorFieldOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulNlpConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData, 
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);
			ulTempData |= (f_pVqeConfig->ulDoubleTalkBehavior  << ulFeatureBitOffset );

			/* Then save the DWORD where the field is located.*/
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}			
	}
	/*==============================================================================*/


	/*==============================================================================*/
	/* Set the music protection enable. */
	if ( ( pSharedInfo->ImageInfo.fMusicProtection == TRUE )
		&& ( pSharedInfo->ImageInfo.fMusicProtectionConfiguration == TRUE ) )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( f_pVqeConfig->fEnableMusicProtection != pChanEntry->VqeConfig.fEnableMusicProtection ) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.MusicProtectionFieldOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.MusicProtectionFieldOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.MusicProtectionFieldOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulNlpConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData, 
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);
			if ( f_pVqeConfig->fEnableMusicProtection == TRUE )
				ulTempData |= ( 1 << ulFeatureBitOffset );

			/* Then save the DWORD where the field is located.*/
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}
	/*==============================================================================*/

	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiWriteVqeAfMemory

Description:    This function configures the AF related VQE features of an 
				echo channel.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance				Pointer to API instance. This memory is used to keep
							the present state of the chip and all its resources.

f_pVqeConfig				Pointer to a VQE config structure.
f_pChannelOpen				Pointer to a channel configuration structure.
f_usChanIndex				Index of the echo channel in the API instance.
f_usEchoMemIndex			Index of the echo channel within the SSPX memory.
f_fClearPlayoutPointers		Flag indicating if the playout pointer should be cleared.
f_fModifyOnly				Flag indicating if the configuration should be
							modified only.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiWriteVqeAfMemory( 
				IN	tPOCT6100_INSTANCE_API			f_pApiInstance,
				IN	tPOCT6100_CHANNEL_OPEN_VQE		f_pVqeConfig,
				IN	tPOCT6100_CHANNEL_OPEN			f_pChannelOpen,
				IN	UINT16							f_usChanIndex,
				IN	UINT16							f_usEchoMemIndex,
				IN	BOOL							f_fClearPlayoutPointers,
				IN	BOOL							f_fModifyOnly )
{
	tPOCT6100_API_CHANNEL			pChanEntry;
	tPOCT6100_SHARED_INFO			pSharedInfo;
	tOCT6100_WRITE_PARAMS			WriteParams;
	UINT32							ulResult;
	UINT32							ulTempData;
	UINT32							ulAfConfigBaseAddress;
	UINT32							ulFeatureBytesOffset;
	UINT32							ulFeatureBitOffset;
	UINT32							ulFeatureFieldLength;
	UINT32							ulMask;
	UINT16							usTempData;
	
	pSharedInfo = f_pApiInstance->pSharedInfo;

	WriteParams.pProcessContext = f_pApiInstance->pProcessContext;

	WriteParams.ulUserChipId = pSharedInfo->ChipConfig.ulUserChipId;

	/* Obtain a pointer to the new buffer's list entry. */
	mOCT6100_GET_CHANNEL_ENTRY_PNT( pSharedInfo, pChanEntry, f_usChanIndex );

	/*==============================================================================*/
	/*	Write the AF CPU configuration of the channel feature by feature.*/

	/* Calculate AF CPU configuration base address. */
	ulAfConfigBaseAddress = pSharedInfo->MemoryMap.ulChanMainMemBase + ( f_usEchoMemIndex * pSharedInfo->MemoryMap.ulChanMainMemSize ) + f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainIoMemOfst;
	
	/* Set initial value to zero.*/
	ulTempData = 0;

	/*==============================================================================*/
	/* Program the Maximum echo point within the Main channel memory.*/
	if ( pSharedInfo->ImageInfo.fMaxEchoPoint == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( ( f_pVqeConfig->lDefaultErlDb != pChanEntry->VqeConfig.chDefaultErlDb ) 
					|| ( f_pChannelOpen->ulEchoOperationMode != pChanEntry->byEchoOperationMode ) ) ) )
		{
			/* Write the echo tail length */
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.ChanMainIoMaxEchoPointOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.ChanMainIoMaxEchoPointOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.ChanMainIoMaxEchoPointOfst.byFieldSize;

			/* First read the DWORD where the field is located.*/
			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulAfConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);

			/* Convert the DB value to octasic's float format.*/
			if ( f_pChannelOpen->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_NO_ECHO )
			{
				usTempData = Oct6100ApiDbAmpHalfToOctFloat( 2 * f_pVqeConfig->lDefaultErlDb );
			}
			else
			{
				/* Clear max echo point.  No echo cancellation here. */
				usTempData = 0x0;
			}

			if ( ulFeatureFieldLength < 16 )
				usTempData = (UINT16)( usTempData >> ( 16 - ulFeatureFieldLength ) );

			ulTempData |= usTempData << ulFeatureBitOffset;

			/* First read the DWORD where the field is located.*/
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulAfConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}
	/*==============================================================================*/


	/*==============================================================================*/
	/* Set the non-linear behavior B.*/
	if ( pSharedInfo->ImageInfo.fNonLinearityBehaviorB == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( f_pVqeConfig->ulNonLinearityBehaviorB != pChanEntry->VqeConfig.byNonLinearityBehaviorB ) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.NlpConvCapFieldOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.NlpConvCapFieldOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.NlpConvCapFieldOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulAfConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData, 
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);
			ulTempData |= (f_pVqeConfig->ulNonLinearityBehaviorB  << ulFeatureBitOffset );

			/* Then save the DWORD where the field is located.*/
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulAfConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}
	/*==============================================================================*/

	
	/*==============================================================================*/
	/* Set the listener enhancement feature. */
	if ( pSharedInfo->ImageInfo.fListenerEnhancement == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( ( f_pVqeConfig->ulSoutAutomaticListenerEnhancementGainDb != pChanEntry->VqeConfig.bySoutAutomaticListenerEnhancementGainDb ) 
					|| ( f_pVqeConfig->fSoutNaturalListenerEnhancement != pChanEntry->VqeConfig.fSoutNaturalListenerEnhancement ) 
					|| ( f_pVqeConfig->ulSoutNaturalListenerEnhancementGainDb != pChanEntry->VqeConfig.bySoutNaturalListenerEnhancementGainDb ) ) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.AdaptiveAleOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.AdaptiveAleOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.AdaptiveAleOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulAfConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );
			
			ulTempData &= (~ulMask);

			if ( f_pVqeConfig->ulSoutAutomaticListenerEnhancementGainDb != 0 )
			{
				UINT32 ulGainDb;

				ulGainDb = f_pVqeConfig->ulSoutAutomaticListenerEnhancementGainDb / 3;

				/* Round up. */
				if ( ( f_pVqeConfig->ulSoutAutomaticListenerEnhancementGainDb % 3 ) != 0x0 )
					ulGainDb ++;

				ulTempData |= ( ulGainDb << ulFeatureBitOffset );
			}
			else if ( f_pVqeConfig->fSoutNaturalListenerEnhancement != 0 )
			{
				UINT32 ulGainDb;

				ulGainDb = f_pVqeConfig->ulSoutNaturalListenerEnhancementGainDb / 3;

				/* Round up. */
				if ( ( f_pVqeConfig->ulSoutNaturalListenerEnhancementGainDb % 3 ) != 0x0 )
					ulGainDb ++;

				ulTempData |= ( ( 0x80 | ulGainDb ) << ulFeatureBitOffset );
			}

			/* Now write the DWORD where the field is located containing the new configuration. */
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulAfConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}
	/*==============================================================================*/


	/*==============================================================================*/
	/* Set the idle code detection enable. */
	if ( ( pSharedInfo->ImageInfo.fIdleCodeDetection == TRUE )
		&& ( pSharedInfo->ImageInfo.fIdleCodeDetectionConfiguration == TRUE ) )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( f_pVqeConfig->fIdleCodeDetection != pChanEntry->VqeConfig.fIdleCodeDetection ) ) )
		{
			/* Calculate base address in the AF software configuration. */
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.IdleCodeDetectionFieldOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.IdleCodeDetectionFieldOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.IdleCodeDetectionFieldOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulAfConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData, 
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);
			if ( f_pVqeConfig->fIdleCodeDetection == FALSE )
				ulTempData |= ( 1 << ulFeatureBitOffset );

			/* Then save the DWORD where the field is located.*/
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulAfConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}
	/*==============================================================================*/


	/*==============================================================================*/
	/* Set the AFT control field. */
	if ( pSharedInfo->ImageInfo.fAftControl == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( f_pChannelOpen->ulEchoOperationMode != pChanEntry->byEchoOperationMode ) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.AftControlOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.AftControlOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.AftControlOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulAfConfigBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);
			
			/* If the operation mode is no echo, set the field such that echo cancellation is disabled. */
			if ( f_pChannelOpen->ulEchoOperationMode == cOCT6100_ECHO_OP_MODE_NO_ECHO )
			{
				ulTempData |= ( 0x1234 << ulFeatureBitOffset );
			}
			else if ( f_pChannelOpen->ulEchoOperationMode == cOCT6100_ECHO_OP_MODE_SPEECH_RECOGNITION )
			{
				/* For clarity. */
				ulTempData |= ( 0x0 << ulFeatureBitOffset );
			}

			/* Then save the DWORD where the field is located.*/
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulAfConfigBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}
	/*==============================================================================*/

	return cOCT6100_ERR_OK;
}




/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiWriteEchoMemory

Description:    This function configure an echo memory entry in internal memory.and
				external memory.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

f_pTdmConfig			Pointer to a TDM config structure.
f_pChannelOpen			Pointer to a channel configuration structure.
f_usEchoIndex			Echo channel index within the SSPX memory.
f_usRinRoutTsiIndex		RIN/ROUT TSI index within the TSI chariot memory
f_usSinSoutTsiIndex		SIN/SOUT TSI index within the TSI chariot memory

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiWriteEchoMemory( 
				IN	tPOCT6100_INSTANCE_API			f_pApiInstance,
				IN	tPOCT6100_CHANNEL_OPEN_TDM		f_pTdmConfig,
				IN	tPOCT6100_CHANNEL_OPEN			f_pChannelOpen,
				IN	UINT16							f_usEchoIndex,
				IN	UINT16							f_usRinRoutTsiIndex,
				IN	UINT16							f_usSinSoutTsiIndex )

{
	tPOCT6100_SHARED_INFO		pSharedInfo;
	tOCT6100_WRITE_PARAMS		WriteParams;
	UINT32						ulResult;
	UINT32						ulTempData;
	UINT32						ulBaseAddress;
	UINT32						ulRinPcmLaw;
	UINT32						ulRoutPcmLaw;
	UINT32						ulSinPcmLaw;
	UINT32						ulSoutPcmLaw;

	pSharedInfo = f_pApiInstance->pSharedInfo;

	WriteParams.pProcessContext = f_pApiInstance->pProcessContext;

	WriteParams.ulUserChipId = pSharedInfo->ChipConfig.ulUserChipId;

	ulRinPcmLaw		= f_pChannelOpen->TdmConfig.ulRoutPcmLaw;
	ulRoutPcmLaw	= f_pChannelOpen->TdmConfig.ulRoutPcmLaw;
	ulSinPcmLaw		= f_pChannelOpen->TdmConfig.ulSinPcmLaw;
	ulSoutPcmLaw	= f_pChannelOpen->TdmConfig.ulSinPcmLaw;

	/*==============================================================================*/
	/*	Configure the Global Static Configuration of the channel.*/

	ulBaseAddress = cOCT6100_CHANNEL_ROOT_BASE + ( f_usEchoIndex * cOCT6100_CHANNEL_ROOT_SIZE ) + cOCT6100_CHANNEL_ROOT_GLOBAL_CONF_OFFSET;

	/* Set the PGSP context base address. */
	ulTempData = pSharedInfo->MemoryMap.ulChanMainMemBase + ( f_usEchoIndex * pSharedInfo->MemoryMap.ulChanMainMemSize ) + cOCT6100_CH_MAIN_PGSP_CONTEXT_OFFSET;
	
	WriteParams.ulWriteAddress = ulBaseAddress + cOCT6100_GSC_PGSP_CONTEXT_BASE_ADD_OFFSET;
	WriteParams.usWriteData = (UINT16)( ulTempData >> 16 );

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	WriteParams.ulWriteAddress += 2;
	WriteParams.usWriteData = (UINT16)( ulTempData & 0xFFFF );

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/* Set the PGSP init context base address. */
	ulTempData = ( cOCT6100_IMAGE_FILE_BASE + 0x200 ) & 0x07FFFFFF;
	
	WriteParams.ulWriteAddress = ulBaseAddress + cOCT6100_GSC_PGSP_INIT_CONTEXT_BASE_ADD_OFFSET;
	WriteParams.usWriteData = (UINT16)( ulTempData >> 16 );

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	WriteParams.ulWriteAddress += 2;
	WriteParams.usWriteData = (UINT16)( ulTempData & 0xFFFF );

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;
	
	/* Set the RIN circular buffer base address. */
	ulTempData  = ( pSharedInfo->MemoryMap.ulChanMainMemBase + ( f_usEchoIndex * pSharedInfo->MemoryMap.ulChanMainMemSize ) + pSharedInfo->MemoryMap.ulChanMainRinCBMemOfst) & 0x07FFFF00;
	ulTempData |= ( ulRoutPcmLaw << cOCT6100_GSC_BUFFER_LAW_OFFSET );
	
	/* Set the circular buffer size.*/
	if (( pSharedInfo->MemoryMap.ulChanMainRinCBMemSize & 0xFFFF00FF ) != 0 )
		return cOCT6100_ERR_CHANNEL_INVALID_RIN_CB_SIZE;
	ulTempData |= pSharedInfo->MemoryMap.ulChanMainRinCBMemSize >> 8;
		
	WriteParams.ulWriteAddress = ulBaseAddress + cOCT6100_GSC_RIN_CIRC_BUFFER_BASE_ADD_OFFSET;
	WriteParams.usWriteData = (UINT16)( ulTempData >> 16 );

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	WriteParams.ulWriteAddress += 2;
	WriteParams.usWriteData = (UINT16)( ulTempData & 0xFFFF );

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/* Set the SIN circular buffer base address. */
	ulTempData  = ( pSharedInfo->MemoryMap.ulChanMainMemBase + ( f_usEchoIndex * pSharedInfo->MemoryMap.ulChanMainMemSize ) + pSharedInfo->MemoryMap.ulChanMainSinCBMemOfst) & 0x07FFFF00;
	ulTempData |= ( ulSinPcmLaw << cOCT6100_GSC_BUFFER_LAW_OFFSET );

	WriteParams.ulWriteAddress = ulBaseAddress + cOCT6100_GSC_SIN_CIRC_BUFFER_BASE_ADD_OFFSET;
	WriteParams.usWriteData = (UINT16)( ulTempData >> 16 );

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	WriteParams.ulWriteAddress += 2;
	WriteParams.usWriteData = (UINT16)( ulTempData & 0xFFFF );

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/* Set the SOUT circular buffer base address. */
	ulTempData  = ( pSharedInfo->MemoryMap.ulChanMainMemBase + ( f_usEchoIndex * pSharedInfo->MemoryMap.ulChanMainMemSize ) + pSharedInfo->MemoryMap.ulChanMainSoutCBMemOfst ) & 0x07FFFF00;
	ulTempData |= ( ulSoutPcmLaw << cOCT6100_GSC_BUFFER_LAW_OFFSET );

	WriteParams.ulWriteAddress = ulBaseAddress + cOCT6100_GSC_SOUT_CIRC_BUFFER_BASE_ADD_OFFSET;
	WriteParams.usWriteData = (UINT16)( ulTempData >> 16 );

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	WriteParams.ulWriteAddress += 2;
	WriteParams.usWriteData = (UINT16)( ulTempData & 0xFFFF );

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/*==============================================================================*/

	
	/*==============================================================================*/
	/*	ECHO SSPX Memory configuration.*/
	
	WriteParams.ulWriteAddress  = cOCT6100_ECHO_CONTROL_MEM_BASE + ( f_usEchoIndex * cOCT6100_ECHO_CONTROL_MEM_ENTRY_SIZE );

	/* ECHO memory BASE + 2 */
	WriteParams.ulWriteAddress += 2;
	WriteParams.usWriteData = 0x0000;

	/* Set the echo control field.*/
	if ( ( ( pSharedInfo->IntrptManage.fAfBistFailedOnBoot == TRUE ) 

			)

		)
	{
		/* Keep the AF in reset, or in power-down. */
		if ( f_pChannelOpen->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_POWER_DOWN )
			WriteParams.usWriteData |= cOCT6100_ECHO_OP_MODE_HT_RESET << cOCT6100_ECHO_CONTROL_MEM_AF_CONTROL;
		else
			WriteParams.usWriteData |= cOCT6100_ECHO_OP_MODE_POWER_DOWN << cOCT6100_ECHO_CONTROL_MEM_AF_CONTROL;
	}
	else
	{
		if ( ( f_pChannelOpen->ulEchoOperationMode == cOCT6100_ECHO_OP_MODE_NO_ECHO )
			|| ( f_pChannelOpen->ulEchoOperationMode == cOCT6100_ECHO_OP_MODE_SPEECH_RECOGNITION ) )
		{
			/* Temporally set echo mode in reset */
			WriteParams.usWriteData |= cOCT6100_ECHO_OP_MODE_HT_RESET << cOCT6100_ECHO_CONTROL_MEM_AF_CONTROL;

			/* Set the SIN/SOUT law.*/
			WriteParams.usWriteData |= ulSinPcmLaw << cOCT6100_ECHO_CONTROL_MEM_INPUT_LAW_OFFSET;
			WriteParams.usWriteData |= ulSoutPcmLaw << cOCT6100_ECHO_CONTROL_MEM_OUTPUT_LAW_OFFSET;

			/* Set the TSI chariot memory field.*/
			WriteParams.usWriteData |= f_usSinSoutTsiIndex & cOCT6100_ECHO_CONTROL_MEM_TSI_MEM_MASK; 			
			
			mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
			if ( ulResult != cOCT6100_ERR_OK  )
				return ulResult;

			WriteParams.usWriteData = 0x0000;

			WriteParams.usWriteData |= cOCT6100_ECHO_OP_MODE_NORMAL << cOCT6100_ECHO_CONTROL_MEM_AF_CONTROL;
		}
		else if ( f_pChannelOpen->ulEchoOperationMode != cOCT6100_ECHO_OP_MODE_EXTERNAL )
		{
			WriteParams.usWriteData |= f_pChannelOpen->ulEchoOperationMode << cOCT6100_ECHO_CONTROL_MEM_AF_CONTROL;
		}
	}
	
	/* Set the SIN/SOUT law.*/
	WriteParams.usWriteData |= ulSinPcmLaw << cOCT6100_ECHO_CONTROL_MEM_INPUT_LAW_OFFSET;
	WriteParams.usWriteData |= ulSoutPcmLaw << cOCT6100_ECHO_CONTROL_MEM_OUTPUT_LAW_OFFSET;

	/* Set the TSI chariot memory field.*/
	WriteParams.usWriteData |= f_usSinSoutTsiIndex & cOCT6100_ECHO_CONTROL_MEM_TSI_MEM_MASK; 

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/* ECHO memory BASE */
	WriteParams.ulWriteAddress -= 2;
	WriteParams.usWriteData  = cOCT6100_ECHO_CONTROL_MEM_ACTIVATE_ENTRY;

	/* Set the RIN/ROUT law.*/
	WriteParams.usWriteData |= ulRinPcmLaw << cOCT6100_ECHO_CONTROL_MEM_INPUT_LAW_OFFSET;
	WriteParams.usWriteData |= ulRoutPcmLaw << cOCT6100_ECHO_CONTROL_MEM_OUTPUT_LAW_OFFSET;

	/* Set the RIN external echo control bit.*/
	if ( f_pChannelOpen->ulEchoOperationMode == cOCT6100_ECHO_OP_MODE_EXTERNAL )
		WriteParams.usWriteData |= cOCT6100_ECHO_CONTROL_MEM_EXTERNAL_AF_CTRL;

	/* Set the TSI chariot memory field.*/
	WriteParams.usWriteData |= f_usRinRoutTsiIndex & cOCT6100_ECHO_CONTROL_MEM_TSI_MEM_MASK; 

	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK  )
		return ulResult;

	/*==============================================================================*/

	return cOCT6100_ERR_OK;
}


/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiUpdateOpenStruct

Description:    This function will copy the new parameter from the modify structure 
				into a channel open structure to be processed later by the same path 
				as the channel open function.  
				If a parameter is set to keep previous, it's current value will be 
				extracted from the channel entry in the API.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------

IN		f_pApiInstance				Pointer to an API instance structure.
IN		f_pChanModify			Pointer to a channel modify structure.
IN OUT	f_pChanOpen				Pointer to a channel open structure.
IN		f_pChanEntry			Pointer to an API channel structure.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiUpdateOpenStruct( 
				IN		tPOCT6100_INSTANCE_API			f_pApiInstance,
				IN		tPOCT6100_CHANNEL_MODIFY		f_pChanModify,
				IN OUT	tPOCT6100_CHANNEL_OPEN			f_pChanOpen,
				IN		tPOCT6100_API_CHANNEL			f_pChanEntry )
{
	
	/* Check the generic Echo parameters.*/
	if ( f_pChanModify->ulEchoOperationMode == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->ulEchoOperationMode = f_pChanEntry->byEchoOperationMode;
	else
		f_pChanOpen->ulEchoOperationMode = f_pChanModify->ulEchoOperationMode;


	if ( f_pChanModify->fEnableToneDisabler == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->fEnableToneDisabler = f_pChanEntry->fEnableToneDisabler;
	else
		f_pChanOpen->fEnableToneDisabler = f_pChanModify->fEnableToneDisabler;


	if ( f_pChanModify->ulUserChanId == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->ulUserChanId = f_pChanEntry->ulUserChanId;
	else
		f_pChanOpen->ulUserChanId = f_pChanModify->ulUserChanId;


	
	/*======================================================================*/
	/* Now update the TDM config.*/
	/* Rin PCM LAW */
	if ( f_pChanModify->TdmConfig.ulRinPcmLaw == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->TdmConfig.ulRinPcmLaw = f_pChanEntry->TdmConfig.byRinPcmLaw;
	else
		f_pChanOpen->TdmConfig.ulRinPcmLaw = f_pChanModify->TdmConfig.ulRinPcmLaw;
	
	/* Sin PCM LAW */
	if ( f_pChanModify->TdmConfig.ulSinPcmLaw == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->TdmConfig.ulSinPcmLaw = f_pChanEntry->TdmConfig.bySinPcmLaw;
	else
		f_pChanOpen->TdmConfig.ulSinPcmLaw = f_pChanModify->TdmConfig.ulSinPcmLaw;
	
	/* Rout PCM LAW */
	if ( f_pChanModify->TdmConfig.ulRoutPcmLaw == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->TdmConfig.ulRoutPcmLaw = f_pChanEntry->TdmConfig.byRoutPcmLaw;
	else
		f_pChanOpen->TdmConfig.ulRoutPcmLaw = f_pChanModify->TdmConfig.ulRoutPcmLaw;

	/* Sout PCM LAW */
	if ( f_pChanModify->TdmConfig.ulSoutPcmLaw == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->TdmConfig.ulSoutPcmLaw = f_pChanEntry->TdmConfig.bySoutPcmLaw;
	else
		f_pChanOpen->TdmConfig.ulSoutPcmLaw = f_pChanModify->TdmConfig.ulSoutPcmLaw;


	/* Rin Timeslot */
	if ( f_pChanModify->TdmConfig.ulRinTimeslot == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->TdmConfig.ulRinTimeslot = f_pChanEntry->TdmConfig.usRinTimeslot;
	else
		f_pChanOpen->TdmConfig.ulRinTimeslot = f_pChanModify->TdmConfig.ulRinTimeslot;
	
	/* Rin Stream */
	if ( f_pChanModify->TdmConfig.ulRinStream == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->TdmConfig.ulRinStream = f_pChanEntry->TdmConfig.usRinStream;
	else
		f_pChanOpen->TdmConfig.ulRinStream = f_pChanModify->TdmConfig.ulRinStream;




	/* Sin Timeslot */
	if ( f_pChanModify->TdmConfig.ulSinTimeslot == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->TdmConfig.ulSinTimeslot = f_pChanEntry->TdmConfig.usSinTimeslot;
	else
		f_pChanOpen->TdmConfig.ulSinTimeslot = f_pChanModify->TdmConfig.ulSinTimeslot;
	
	/* Sin Stream */
	if ( f_pChanModify->TdmConfig.ulSinStream == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->TdmConfig.ulSinStream = f_pChanEntry->TdmConfig.usSinStream;
	else
		f_pChanOpen->TdmConfig.ulSinStream = f_pChanModify->TdmConfig.ulSinStream;




	/* Rout Timeslot */
	if ( f_pChanModify->TdmConfig.ulRoutTimeslot == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->TdmConfig.ulRoutTimeslot = f_pChanEntry->TdmConfig.usRoutTimeslot;
	else
		f_pChanOpen->TdmConfig.ulRoutTimeslot = f_pChanModify->TdmConfig.ulRoutTimeslot;
	
	/* Rout Stream */
	if ( f_pChanModify->TdmConfig.ulRoutStream == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->TdmConfig.ulRoutStream = f_pChanEntry->TdmConfig.usRoutStream;
	else
		f_pChanOpen->TdmConfig.ulRoutStream = f_pChanModify->TdmConfig.ulRoutStream;




	/* Sout Timeslot */
	if ( f_pChanModify->TdmConfig.ulSoutTimeslot == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->TdmConfig.ulSoutTimeslot = f_pChanEntry->TdmConfig.usSoutTimeslot;
	else
		f_pChanOpen->TdmConfig.ulSoutTimeslot = f_pChanModify->TdmConfig.ulSoutTimeslot;
	
	/* Sout Stream */
	if ( f_pChanModify->TdmConfig.ulSoutStream == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->TdmConfig.ulSoutStream = f_pChanEntry->TdmConfig.usSoutStream;
	else
		f_pChanOpen->TdmConfig.ulSoutStream = f_pChanModify->TdmConfig.ulSoutStream;



	/*======================================================================*/
	
	/*======================================================================*/
	/* Now update the VQE config.*/
	
	if ( f_pChanModify->VqeConfig.ulComfortNoiseMode == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.ulComfortNoiseMode = f_pChanEntry->VqeConfig.byComfortNoiseMode;
	else
		f_pChanOpen->VqeConfig.ulComfortNoiseMode = f_pChanModify->VqeConfig.ulComfortNoiseMode;

	if ( f_pChanModify->VqeConfig.fEnableNlp == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.fEnableNlp = f_pChanEntry->VqeConfig.fEnableNlp;
	else
		f_pChanOpen->VqeConfig.fEnableNlp = f_pChanModify->VqeConfig.fEnableNlp;
	
	if ( f_pChanModify->VqeConfig.fEnableTailDisplacement == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.fEnableTailDisplacement = f_pChanEntry->VqeConfig.fEnableTailDisplacement;
	else
		f_pChanOpen->VqeConfig.fEnableTailDisplacement = f_pChanModify->VqeConfig.fEnableTailDisplacement;

	if ( f_pChanModify->VqeConfig.ulTailDisplacement == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.ulTailDisplacement = f_pChanEntry->VqeConfig.usTailDisplacement;
	else
		f_pChanOpen->VqeConfig.ulTailDisplacement = f_pChanModify->VqeConfig.ulTailDisplacement;

	/* Tail length cannot be modifed. */
	f_pChanOpen->VqeConfig.ulTailLength = f_pChanEntry->VqeConfig.usTailLength;


	
	if ( f_pChanModify->VqeConfig.fRinDcOffsetRemoval == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.fRinDcOffsetRemoval = f_pChanEntry->VqeConfig.fRinDcOffsetRemoval;
	else
		f_pChanOpen->VqeConfig.fRinDcOffsetRemoval = f_pChanModify->VqeConfig.fRinDcOffsetRemoval;
	

	if ( f_pChanModify->VqeConfig.fRinLevelControl == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.fRinLevelControl = f_pChanEntry->VqeConfig.fRinLevelControl;
	else
		f_pChanOpen->VqeConfig.fRinLevelControl = f_pChanModify->VqeConfig.fRinLevelControl;


	if ( f_pChanModify->VqeConfig.fRinAutomaticLevelControl == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.fRinAutomaticLevelControl = f_pChanEntry->VqeConfig.fRinAutomaticLevelControl;
	else
		f_pChanOpen->VqeConfig.fRinAutomaticLevelControl = f_pChanModify->VqeConfig.fRinAutomaticLevelControl;


	if ( f_pChanModify->VqeConfig.fRinHighLevelCompensation == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.fRinHighLevelCompensation = f_pChanEntry->VqeConfig.fRinHighLevelCompensation;
	else
		f_pChanOpen->VqeConfig.fRinHighLevelCompensation = f_pChanModify->VqeConfig.fRinHighLevelCompensation;


	if ( f_pChanModify->VqeConfig.lRinHighLevelCompensationThresholdDb == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.lRinHighLevelCompensationThresholdDb = f_pChanEntry->VqeConfig.chRinHighLevelCompensationThresholdDb;
	else
		f_pChanOpen->VqeConfig.lRinHighLevelCompensationThresholdDb = f_pChanModify->VqeConfig.lRinHighLevelCompensationThresholdDb;

	
	if ( f_pChanModify->VqeConfig.fSinDcOffsetRemoval == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.fSinDcOffsetRemoval = f_pChanEntry->VqeConfig.fSinDcOffsetRemoval;
	else
		f_pChanOpen->VqeConfig.fSinDcOffsetRemoval = f_pChanModify->VqeConfig.fSinDcOffsetRemoval;
	

	if ( f_pChanModify->VqeConfig.fSoutAdaptiveNoiseReduction == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.fSoutAdaptiveNoiseReduction = f_pChanEntry->VqeConfig.fSoutAdaptiveNoiseReduction;
	else
		f_pChanOpen->VqeConfig.fSoutAdaptiveNoiseReduction = f_pChanModify->VqeConfig.fSoutAdaptiveNoiseReduction;

	

	

	if ( f_pChanModify->VqeConfig.fSoutLevelControl == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.fSoutLevelControl = f_pChanEntry->VqeConfig.fSoutLevelControl;
	else
		f_pChanOpen->VqeConfig.fSoutLevelControl = f_pChanModify->VqeConfig.fSoutLevelControl;


	if ( f_pChanModify->VqeConfig.fSoutAutomaticLevelControl == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.fSoutAutomaticLevelControl = f_pChanEntry->VqeConfig.fSoutAutomaticLevelControl;
	else
		f_pChanOpen->VqeConfig.fSoutAutomaticLevelControl = f_pChanModify->VqeConfig.fSoutAutomaticLevelControl;


	if ( f_pChanModify->VqeConfig.lRinLevelControlGainDb == ( (INT32)cOCT6100_KEEP_PREVIOUS_SETTING ) )
		f_pChanOpen->VqeConfig.lRinLevelControlGainDb = f_pChanEntry->VqeConfig.chRinLevelControlGainDb;
	else
		f_pChanOpen->VqeConfig.lRinLevelControlGainDb = f_pChanModify->VqeConfig.lRinLevelControlGainDb;
	

	if ( f_pChanModify->VqeConfig.lSoutLevelControlGainDb == ( (INT32)cOCT6100_KEEP_PREVIOUS_SETTING ) )
		f_pChanOpen->VqeConfig.lSoutLevelControlGainDb = f_pChanEntry->VqeConfig.chSoutLevelControlGainDb;
	else
		f_pChanOpen->VqeConfig.lSoutLevelControlGainDb = f_pChanModify->VqeConfig.lSoutLevelControlGainDb;


	if ( f_pChanModify->VqeConfig.lRinAutomaticLevelControlTargetDb == ( (INT32)cOCT6100_KEEP_PREVIOUS_SETTING ) )
		f_pChanOpen->VqeConfig.lRinAutomaticLevelControlTargetDb = f_pChanEntry->VqeConfig.chRinAutomaticLevelControlTargetDb;
	else
		f_pChanOpen->VqeConfig.lRinAutomaticLevelControlTargetDb = f_pChanModify->VqeConfig.lRinAutomaticLevelControlTargetDb;
	

	if ( f_pChanModify->VqeConfig.lSoutAutomaticLevelControlTargetDb == ( (INT32)cOCT6100_KEEP_PREVIOUS_SETTING ) )
		f_pChanOpen->VqeConfig.lSoutAutomaticLevelControlTargetDb = f_pChanEntry->VqeConfig.chSoutAutomaticLevelControlTargetDb;
	else
		f_pChanOpen->VqeConfig.lSoutAutomaticLevelControlTargetDb = f_pChanModify->VqeConfig.lSoutAutomaticLevelControlTargetDb;


	if ( f_pChanModify->VqeConfig.lDefaultErlDb == ( (INT32)cOCT6100_KEEP_PREVIOUS_SETTING ) )
		f_pChanOpen->VqeConfig.lDefaultErlDb = f_pChanEntry->VqeConfig.chDefaultErlDb;
	else
		f_pChanOpen->VqeConfig.lDefaultErlDb = f_pChanModify->VqeConfig.lDefaultErlDb;


	if ( f_pChanModify->VqeConfig.lAecDefaultErlDb == ( (INT32)cOCT6100_KEEP_PREVIOUS_SETTING ) )
		f_pChanOpen->VqeConfig.lAecDefaultErlDb = f_pChanEntry->VqeConfig.chAecDefaultErlDb;
	else
		f_pChanOpen->VqeConfig.lAecDefaultErlDb = f_pChanModify->VqeConfig.lAecDefaultErlDb;


	if ( f_pChanModify->VqeConfig.ulAecTailLength == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.ulAecTailLength = f_pChanEntry->VqeConfig.usAecTailLength;
	else
		f_pChanOpen->VqeConfig.ulAecTailLength = f_pChanModify->VqeConfig.ulAecTailLength;


	if ( f_pChanModify->VqeConfig.fAcousticEcho == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.fAcousticEcho = f_pChanEntry->VqeConfig.fAcousticEcho;
	else
		f_pChanOpen->VqeConfig.fAcousticEcho = f_pChanModify->VqeConfig.fAcousticEcho;


	if ( f_pChanModify->VqeConfig.fDtmfToneRemoval == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.fDtmfToneRemoval = f_pChanEntry->VqeConfig.fDtmfToneRemoval;
	else
		f_pChanOpen->VqeConfig.fDtmfToneRemoval = f_pChanModify->VqeConfig.fDtmfToneRemoval;





	if ( f_pChanModify->VqeConfig.ulNonLinearityBehaviorA == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.ulNonLinearityBehaviorA = f_pChanEntry->VqeConfig.byNonLinearityBehaviorA;
	else
		f_pChanOpen->VqeConfig.ulNonLinearityBehaviorA = f_pChanModify->VqeConfig.ulNonLinearityBehaviorA;


	if ( f_pChanModify->VqeConfig.ulNonLinearityBehaviorB == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.ulNonLinearityBehaviorB = f_pChanEntry->VqeConfig.byNonLinearityBehaviorB;
	else
		f_pChanOpen->VqeConfig.ulNonLinearityBehaviorB = f_pChanModify->VqeConfig.ulNonLinearityBehaviorB;


	if ( f_pChanModify->VqeConfig.ulDoubleTalkBehavior == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.ulDoubleTalkBehavior = f_pChanEntry->VqeConfig.byDoubleTalkBehavior;
	else
		f_pChanOpen->VqeConfig.ulDoubleTalkBehavior = f_pChanModify->VqeConfig.ulDoubleTalkBehavior;


	if ( f_pChanModify->VqeConfig.ulSoutAutomaticListenerEnhancementGainDb == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.ulSoutAutomaticListenerEnhancementGainDb = f_pChanEntry->VqeConfig.bySoutAutomaticListenerEnhancementGainDb;
	else
		f_pChanOpen->VqeConfig.ulSoutAutomaticListenerEnhancementGainDb = f_pChanModify->VqeConfig.ulSoutAutomaticListenerEnhancementGainDb;


	if ( f_pChanModify->VqeConfig.ulSoutNaturalListenerEnhancementGainDb == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.ulSoutNaturalListenerEnhancementGainDb = f_pChanEntry->VqeConfig.bySoutNaturalListenerEnhancementGainDb;
	else
		f_pChanOpen->VqeConfig.ulSoutNaturalListenerEnhancementGainDb = f_pChanModify->VqeConfig.ulSoutNaturalListenerEnhancementGainDb;


	if ( f_pChanModify->VqeConfig.fSoutNaturalListenerEnhancement == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.fSoutNaturalListenerEnhancement = f_pChanEntry->VqeConfig.fSoutNaturalListenerEnhancement;
	else
		f_pChanOpen->VqeConfig.fSoutNaturalListenerEnhancement = f_pChanModify->VqeConfig.fSoutNaturalListenerEnhancement;


	if ( f_pChanModify->VqeConfig.fRoutNoiseReduction == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.fRoutNoiseReduction = f_pChanEntry->VqeConfig.fRoutNoiseReduction;
	else
		f_pChanOpen->VqeConfig.fRoutNoiseReduction = f_pChanModify->VqeConfig.fRoutNoiseReduction;

	if ( f_pChanModify->VqeConfig.lRoutNoiseReductionLevelGainDb == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.lRoutNoiseReductionLevelGainDb = f_pChanEntry->VqeConfig.chRoutNoiseReductionLevelGainDb;
	else
		f_pChanOpen->VqeConfig.lRoutNoiseReductionLevelGainDb = f_pChanModify->VqeConfig.lRoutNoiseReductionLevelGainDb;


	if ( f_pChanModify->VqeConfig.lAnrSnrEnhancementDb == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.lAnrSnrEnhancementDb = f_pChanEntry->VqeConfig.chAnrSnrEnhancementDb;
	else
		f_pChanOpen->VqeConfig.lAnrSnrEnhancementDb = f_pChanModify->VqeConfig.lAnrSnrEnhancementDb;


	if ( f_pChanModify->VqeConfig.ulAnrVoiceNoiseSegregation == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.ulAnrVoiceNoiseSegregation = f_pChanEntry->VqeConfig.byAnrVoiceNoiseSegregation;
	else
		f_pChanOpen->VqeConfig.ulAnrVoiceNoiseSegregation = f_pChanModify->VqeConfig.ulAnrVoiceNoiseSegregation;


	if ( f_pChanModify->VqeConfig.ulToneDisablerVqeActivationDelay == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.ulToneDisablerVqeActivationDelay = f_pChanEntry->VqeConfig.usToneDisablerVqeActivationDelay;
	else
		f_pChanOpen->VqeConfig.ulToneDisablerVqeActivationDelay = f_pChanModify->VqeConfig.ulToneDisablerVqeActivationDelay;


	if ( f_pChanModify->VqeConfig.fEnableMusicProtection == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.fEnableMusicProtection = f_pChanEntry->VqeConfig.fEnableMusicProtection;
	else
		f_pChanOpen->VqeConfig.fEnableMusicProtection = f_pChanModify->VqeConfig.fEnableMusicProtection;


	if ( f_pChanModify->VqeConfig.fIdleCodeDetection == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.fIdleCodeDetection = f_pChanEntry->VqeConfig.fIdleCodeDetection;
	else
		f_pChanOpen->VqeConfig.fIdleCodeDetection = f_pChanModify->VqeConfig.fIdleCodeDetection;

	if ( f_pChanModify->VqeConfig.fEnablePlayout == cOCT6100_KEEP_PREVIOUS_SETTING )
		f_pChanOpen->VqeConfig.fEnablePlayout = f_pChanEntry->VqeConfig.fEnablePlayout;
	else
		f_pChanOpen->VqeConfig.fEnablePlayout = f_pChanModify->VqeConfig.fEnablePlayout;

	/*======================================================================*/



	/*======================================================================*/

	return cOCT6100_ERR_OK;
}







/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiRetrieveNlpConfDword

Description:    This function is used by the API to store on a per channel basis
				the various confguration DWORD from the device. The API performs 
				less read to the chip that way since it is always in synch with the 
				chip.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

f_pChanEntry			Pointer to an API channel structure..
f_ulAddress				Address that needs to be modified..
f_pulConfigDword		Pointer to the content stored in the API located at the
						desired address.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32	Oct6100ApiRetrieveNlpConfDword( 
									   
				IN		tPOCT6100_INSTANCE_API				f_pApiInstance,
				IN		tPOCT6100_API_CHANNEL				f_pChanEntry,
				IN		UINT32								f_ulAddress,
				OUT		PUINT32								f_pulConfigDword )
{
	UINT32	ulResult;
	UINT32	ulFirstEmptyIndex = 0xFFFFFFFF;
	UINT32	i;

	/* Search for the Dword.*/
	for ( i = 0; i < cOCT6100_MAX_NLP_CONF_DWORD; i++ )
	{
		if ( ( ulFirstEmptyIndex == 0xFFFFFFFF ) && ( f_pChanEntry->aulNlpConfDword[ i ][ 0 ] == 0x0 ) )
			ulFirstEmptyIndex = i;
		
		if ( f_pChanEntry->aulNlpConfDword[ i ][ 0 ] == f_ulAddress )
		{
			/* We found the matching Dword.*/
			*f_pulConfigDword = f_pChanEntry->aulNlpConfDword[ i ][ 1 ];
			return cOCT6100_ERR_OK;
		}
	}

	if ( i == cOCT6100_MAX_NLP_CONF_DWORD && ulFirstEmptyIndex == 0xFFFFFFFF )
		return cOCT6100_ERR_FATAL_8E;

	/* We did not found any entry, let's create a new entry.*/
	f_pChanEntry->aulNlpConfDword[ ulFirstEmptyIndex ][ 0 ] = f_ulAddress;


	/* Read the DWORD where the field is located.*/
	ulResult = Oct6100ApiReadDword( f_pApiInstance,
									f_ulAddress,
									f_pulConfigDword );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	return cOCT6100_ERR_OK;
}


/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiSaveNlpConfDword

Description:    This function stores a configuration Dword within an API channel
				structure and then writes it into the chip.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

f_pChanEntry			Pointer to an API channel structure..
f_ulAddress				Address that needs to be modified..
f_pulConfigDword		content to be stored in the API located at the
						desired address.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32	Oct6100ApiSaveNlpConfDword( 
									   
				IN		tPOCT6100_INSTANCE_API				f_pApiInstance,
				IN		tPOCT6100_API_CHANNEL				f_pChanEntry,
				IN		UINT32								f_ulAddress,
				IN		UINT32								f_ulConfigDword )
{
	UINT32	ulResult;
	UINT32	i;

	/* Search for the Dword.*/
	for ( i = 0; i < cOCT6100_MAX_NLP_CONF_DWORD; i++ )
	{

		if ( f_pChanEntry->aulNlpConfDword[ i ][ 0 ] == f_ulAddress )
		{
			/* We found the matching Dword.*/
			f_pChanEntry->aulNlpConfDword[ i ][ 1 ] = f_ulConfigDword;
			break;
		}
	}

	if ( i == cOCT6100_MAX_NLP_CONF_DWORD )
		return cOCT6100_ERR_FATAL_8F;


	/* Write the config DWORD.*/
	ulResult = Oct6100ApiWriteDword( f_pApiInstance,
									f_ulAddress,
									f_ulConfigDword );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;
	
	return cOCT6100_ERR_OK;
}



INT32 Oct6100ApiOctFloatToDbEnergyByte(UINT8 x)
{
	INT32	lResult;

	lResult = Oct6100ApiOctFloatToDbEnergyHalf( (UINT16)(x << 8) );
	return lResult;
}

INT32 Oct6100ApiOctFloatToDbEnergyHalf(UINT16 x)
{
	INT32 y;
	UINT16 m;

	y = (((x >> 8) & 0x7F) - 0x41) * 3;

	m = (UINT16)((x & 0x00E0) >> 5);
	if (m < 2) y += 0;
	else if (m < 5) y += 1;
	else y += 2;

	return y;
}

UINT16 Oct6100ApiDbAmpHalfToOctFloat(INT32 x)
{
	INT32 db_div6;
	INT32 db_mod6;
	UINT16 rval;
	INT32 x_unsigned;

	if(x < 0)
	{
		x_unsigned = -x;
	}
	else
	{
		x_unsigned = x;
	}

	db_div6 = x_unsigned / 6;
	db_mod6 = x_unsigned % 6;

	if(x < 0)
	{
		if(db_mod6 == 0)
		{
			/* Change nothing! */
			db_div6 = -db_div6;
		}
		else
		{
			/* When we are negative, round down, and then adjust modulo. For example, if
			 x is -1, then db_div6 is 0 and db_mod6 is 1. We adjust so db_div6 = -1 and
			 db_mod6 = 5, which gives the correct adjustment. */
			db_div6 = -db_div6-1;
			db_mod6 = 6 - db_mod6;
		}
	}

	rval = (UINT16)(0x4100 + db_div6 * 0x100);

	if(db_mod6 == 0)
	{
		rval += 0x0000;
	}
	else if(db_mod6 == 1)
	{
		rval += 0x0020;
	}		
	else if(db_mod6 == 2)
	{
		rval += 0x0040;
	}		
	else if(db_mod6 == 3)
	{
		rval += 0x0070;
	}		
	else if(db_mod6 == 4)
	{
		rval += 0x0090;
	}		
	else /* if(db_mod6 == 5) */
	{
		rval += 0x00D0;
	}

	return rval;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiWriteDebugChanMemory

Description:    This function configure a debug channel echo memory entry 
				in internal memory.and external memory.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

f_pTdmConfig			Pointer to a TDM configuration structure.
f_pVqeConfig			Pointer to a VQE configuration structure.
f_pChannelOpen			Pointer to a channel configuration structure.
f_usChanIndex			Index of the echo channel in the API instance.
f_usEchoMemIndex		Index of the echo channel within the SSPX memory.
f_usRinRoutTsiIndex		RIN/ROUT TSI index within the TSI chariot memory.
f_usSinSoutTsiIndex		SIN/SOUT TSI index within the TSI chariot memory.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiWriteDebugChanMemory( 
				IN	tPOCT6100_INSTANCE_API			f_pApiInstance,
				IN	tPOCT6100_CHANNEL_OPEN_TDM		f_pTdmConfig,
				IN	tPOCT6100_CHANNEL_OPEN_VQE		f_pVqeConfig,
				IN	tPOCT6100_CHANNEL_OPEN			f_pChannelOpen,
				IN	UINT16							f_usChanIndex,
				IN	UINT16							f_usEchoMemIndex,
				IN	UINT16							f_usRinRoutTsiIndex,
				IN	UINT16							f_usSinSoutTsiIndex )
{
	tPOCT6100_SHARED_INFO	pSharedInfo;
	UINT32					ulResult;

	/* Obtain pointer to local portion of the instance. */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	/*==============================================================================*/
	/* Write the VQE configuration of the debug channel. */

	ulResult = Oct6100ApiWriteVqeMemory( 
										f_pApiInstance, 
										f_pVqeConfig, 
										f_pChannelOpen, 
										f_usChanIndex,
										f_usEchoMemIndex,
										TRUE, 
										FALSE );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;	

	/*==============================================================================*/


	/*==============================================================================*/

	/* Write the echo memory configuration of the debug channel. */
	ulResult = Oct6100ApiWriteEchoMemory(
										f_pApiInstance,
										f_pTdmConfig,
										f_pChannelOpen,
										f_usEchoMemIndex,
										f_usRinRoutTsiIndex,
										f_usSinSoutTsiIndex );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;	

	/*==============================================================================*/

	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiDebugChannelOpen

Description:    Internal function used to open a debug channel.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance				Pointer to API instance. This memory is used to keep
							the present state of the chip and all its resources.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32	Oct6100ApiDebugChannelOpen( 
					IN	tPOCT6100_INSTANCE_API f_pApiInstance )
{
	tPOCT6100_SHARED_INFO		pSharedInfo;
	tOCT6100_CHANNEL_OPEN		TempChanOpen;
	
	UINT32	ulResult;
	UINT16	usChanIndex;
	UINT16	usDummyEchoIndex;

	pSharedInfo = f_pApiInstance->pSharedInfo;

	/* Let's program the channel memory.*/
	Oct6100ChannelOpenDef( &TempChanOpen );
	
	TempChanOpen.ulEchoOperationMode = cOCT6100_ECHO_OP_MODE_HT_RESET;	/* Activate the channel in reset.*/
	TempChanOpen.VqeConfig.fEnableNlp = FALSE;
	TempChanOpen.VqeConfig.ulComfortNoiseMode = cOCT6100_COMFORT_NOISE_NORMAL;
	TempChanOpen.VqeConfig.fSinDcOffsetRemoval = FALSE;
	TempChanOpen.VqeConfig.fRinDcOffsetRemoval = FALSE;
	TempChanOpen.VqeConfig.lDefaultErlDb = 0;
	
	/* Loop to reserve the proper entry for the debug channel */
	if ( pSharedInfo->ChipConfig.fAllowDynamicRecording == TRUE )
		Oct6100UserMemSet( pSharedInfo->MiscVars.ausSuperArray, 0xFF, sizeof( pSharedInfo->MiscVars.ausSuperArray ) );

	for( usChanIndex = 0; usChanIndex < ( pSharedInfo->DebugInfo.usRecordChanIndex + 1 ); usChanIndex ++ )
	{
		ulResult = Oct6100ApiReserveEchoEntry( f_pApiInstance, &usDummyEchoIndex );
		if( ulResult != cOCT6100_ERR_OK )
		{
			if ( pSharedInfo->ChipConfig.fEnableChannelRecording == TRUE )
				return ulResult;
		}
		else
		{
			if ( ( pSharedInfo->ChipConfig.fAllowDynamicRecording == TRUE )
				&& ( usDummyEchoIndex == pSharedInfo->DebugInfo.usRecordChanIndex ) )
				break;

			if ( ( pSharedInfo->ChipConfig.fEnableChannelRecording == FALSE )
				&& ( pSharedInfo->ChipConfig.fAllowDynamicRecording == TRUE ) )
				pSharedInfo->MiscVars.ausSuperArray[ usChanIndex ] = usDummyEchoIndex;
		}
	}

	if ( pSharedInfo->ChipConfig.fAllowDynamicRecording == TRUE )
	{
		if ( usChanIndex == ( pSharedInfo->DebugInfo.usRecordChanIndex + 1 ) )
			return cOCT6100_ERR_FATAL_EE;
	}

	/* Loop to free all entries except the one for the debug channel */
	for( usChanIndex = pSharedInfo->DebugInfo.usRecordChanIndex; usChanIndex > 0; ) 
	{
		usChanIndex--;
		if ( ( pSharedInfo->ChipConfig.fEnableChannelRecording == FALSE )
			&& ( pSharedInfo->ChipConfig.fAllowDynamicRecording == TRUE ) )
		{
			if ( pSharedInfo->MiscVars.ausSuperArray[ usChanIndex ] != 0xFFFF )
			{
				ulResult = Oct6100ApiReleaseEchoEntry( f_pApiInstance, pSharedInfo->MiscVars.ausSuperArray[ usChanIndex ] );
				if( ulResult != cOCT6100_ERR_OK )
					return ulResult;
			}
		}
		else
		{
			ulResult = Oct6100ApiReleaseEchoEntry( f_pApiInstance, usChanIndex );
			if( ulResult != cOCT6100_ERR_OK )
				return ulResult;
		}
	}

	ulResult = Oct6100ApiWriteDebugChanMemory( f_pApiInstance,
										  &TempChanOpen.TdmConfig,
										  &TempChanOpen.VqeConfig,
										  &TempChanOpen,
										  pSharedInfo->DebugInfo.usRecordChanIndex,
										  pSharedInfo->DebugInfo.usRecordMemIndex,
										  pSharedInfo->DebugInfo.usRecordRinRoutTsiMemIndex,
										  pSharedInfo->DebugInfo.usRecordSinSoutTsiMemIndex );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiEnableChannelRecordingSer

Description:	Open the debug channel.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiEnableChannelRecordingSer(
				IN		tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT	tPOCT6100_ENABLE_CHANNEL_RECORDING		f_pChannelRecord )
{
	tPOCT6100_SHARED_INFO		pSharedInfo;
	tPOCT6100_API_CHANNEL		pChanEntry;
	UINT32						ulResult;

	pSharedInfo = f_pApiInstance->pSharedInfo;
	
	if ( pSharedInfo->ChipConfig.fAllowDynamicRecording == FALSE )
		return cOCT6100_ERR_CHANNEL_RECORDING_DISABLED;

	if ( f_pChannelRecord->pulChannelHndlConflict == NULL )
		return cOCT6100_ERR_CHANNEL_RECORDING_INVALID_HANDLE;

	if ( pSharedInfo->DebugInfo.fRecordChanUp == TRUE )
		return cOCT6100_ERR_CHANNEL_RECORDING_ALREADY_ENABLED;

	/* Obtain record channel pointer using recording index */
	mOCT6100_GET_CHANNEL_ENTRY_PNT( f_pApiInstance->pSharedInfo, pChanEntry, pSharedInfo->DebugInfo.usRecordChanIndex )
	if ( pChanEntry->fReserved == TRUE )
	{
		/* Form handle returned to user.  The channel must be closed first. */
		*f_pChannelRecord->pulChannelHndlConflict = cOCT6100_HNDL_TAG_CHANNEL | (pChanEntry->byEntryOpenCnt << cOCT6100_ENTRY_OPEN_CNT_SHIFT) | pSharedInfo->DebugInfo.usRecordChanIndex;
		return cOCT6100_ERR_CHANNEL_RECORDING_HANDLE_USED;
	}

	ulResult = Oct6100ApiDebugChannelOpen( f_pApiInstance );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	pSharedInfo->DebugInfo.fRecordChanUp = TRUE;
	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiDisableChannelRecordingSer

Description:	Close the debug channel.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiDisableChannelRecordingSer(
				IN		tPOCT6100_INSTANCE_API					f_pApiInstance,
				IN OUT	tPOCT6100_DISABLE_CHANNEL_RECORDING		f_pChannelRecord )
{
	tPOCT6100_SHARED_INFO		pSharedInfo;
	tOCT6100_WRITE_PARAMS		WriteParams;
	tOCT6100_WRITE_SMEAR_PARAMS	SmearParams;
	tPOCT6100_API_CHANNEL		pChanEntry;
	UINT32						ulResult;	
	UINT32						ulTempData;
	UINT32						ulBaseAddress;
	UINT32						ulOffset;

	pSharedInfo = f_pApiInstance->pSharedInfo;

	if ( pSharedInfo->ChipConfig.fAllowDynamicRecording == FALSE )
		return cOCT6100_ERR_CHANNEL_RECORDING_DISABLED;

	/* If a channel is currently being recorded, it must be disabled first. */
	if ( pSharedInfo->DebugInfo.usCurrentDebugChanIndex != cOCT6100_INVALID_INDEX )
		return cOCT6100_ERR_DEBUG_CHANNEL_RECORDING_ENABLED;

	WriteParams.pProcessContext = f_pApiInstance->pProcessContext;

	WriteParams.ulUserChipId = pSharedInfo->ChipConfig.ulUserChipId;

	SmearParams.pProcessContext = f_pApiInstance->pProcessContext;

	SmearParams.ulUserChipId = pSharedInfo->ChipConfig.ulUserChipId;

	/* We let through even though this could already be disabled.. */
	if ( pSharedInfo->DebugInfo.fRecordChanUp == TRUE )
	{
		/* Obtain a pointer to the new buffer's list entry. */
		mOCT6100_GET_CHANNEL_ENTRY_PNT( pSharedInfo, pChanEntry, pSharedInfo->DebugInfo.usRecordChanIndex );

		/*------------------------------------------------------------------------------*/
		/* Deactivate the ECHO control memory entry.*/
		
		/* Set the input Echo control entry to unused.*/
		WriteParams.ulWriteAddress  = cOCT6100_ECHO_CONTROL_MEM_BASE + ( pSharedInfo->DebugInfo.usRecordChanIndex * cOCT6100_ECHO_CONTROL_MEM_ENTRY_SIZE );
		WriteParams.usWriteData = 0x85FF;	/* TSI index 1535 reserved for power-down mode */

		mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
		if ( ulResult != cOCT6100_ERR_OK  )
			return ulResult;

		WriteParams.ulWriteAddress += 2;
		WriteParams.usWriteData = 0xC5FF;	/* TSI index 1535 reserved for power-down mode */

		mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
		if ( ulResult != cOCT6100_ERR_OK  )
			return ulResult;
		/*------------------------------------------------------------------------------*/


		/*------------------------------------------------------------------------------*/
		/* Clear the VQE memory. */
		
		ulBaseAddress = cOCT6100_CHANNEL_ROOT_BASE + ( pSharedInfo->DebugInfo.usRecordChanIndex * cOCT6100_CHANNEL_ROOT_SIZE ) + pSharedInfo->MemoryMap.ulChanRootConfOfst + 0x20;
		ulTempData = 0x0000;
		
		/* Save the new DWORD where the field is located.*/
		mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
										pChanEntry,
										ulBaseAddress,
										ulTempData,
										ulResult );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;
		/*------------------------------------------------------------------------------*/


		/*------------------------------------------------------------------------------*/
		/* Clear the NLP memory. */

		ulBaseAddress = cOCT6100_CHANNEL_ROOT_BASE + ( pSharedInfo->DebugInfo.usRecordChanIndex * cOCT6100_CHANNEL_ROOT_SIZE ) + pSharedInfo->MemoryMap.ulChanRootConfOfst + 0x28;
		ulTempData = 0x0000;
		
		/* Save the new DWORD where the field is located.*/
		mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
										pChanEntry,
										ulBaseAddress,
										ulTempData,
										ulResult );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;
		/*------------------------------------------------------------------------------*/


		/*------------------------------------------------------------------------------*/
		/* Clear the AF information memory. */

		ulBaseAddress = pSharedInfo->MemoryMap.ulChanMainMemBase + ( pSharedInfo->DebugInfo.usRecordChanIndex * f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainMemSize ) + f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainIoMemOfst;
		ulTempData = 0x0000;
		
		for(ulOffset=0; ulOffset<=0x14; ulOffset+=4)
		{		
			/* Save the new DWORD where the field is located.*/
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulBaseAddress + ulOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;
		}
		/*------------------------------------------------------------------------------*/


		/* Release echo mem entry */
		ulResult = Oct6100ApiReleaseEchoEntry( f_pApiInstance, pSharedInfo->DebugInfo.usRecordChanIndex );
		if( ulResult != cOCT6100_ERR_OK )
			return ulResult;

		pSharedInfo->DebugInfo.fRecordChanUp = FALSE;
	}
	
	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiMuteChannelPort

Description:	This function will verify if a input TSST is bound to the RIN and
				SIN port. If not, the port will be muted.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance				Pointer to API instance. This memory is used to keep
							the present state of the chip and all its resources.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32	Oct6100ApiMutePorts( 
					IN	tPOCT6100_INSTANCE_API		f_pApiInstance,
					IN	UINT16						f_usEchoIndex,
					IN	UINT16						f_usRinTsstIndex,
					IN	UINT16						f_usSinTsstIndex,
					IN	BOOL						f_fCheckBridgeIndex )
{
	tPOCT6100_SHARED_INFO		pSharedInfo;
	tPOCT6100_API_CHANNEL		pChanEntry;
	tOCT6100_WRITE_PARAMS		WriteParams;
	UINT32						ulResult;

	pSharedInfo = f_pApiInstance->pSharedInfo;

	WriteParams.pProcessContext = f_pApiInstance->pProcessContext;

	WriteParams.ulUserChipId = pSharedInfo->ChipConfig.ulUserChipId;

	/* Obtain a pointer to the new buffer's list entry. */
	mOCT6100_GET_CHANNEL_ENTRY_PNT( pSharedInfo, pChanEntry, f_usEchoIndex );

	/* Mute the Rin port. */

	{
		/* If the channel is in bidir mode, do not create the Rin silence event!!! */
		if ( pChanEntry->fBiDirChannel == FALSE )
		{
			if ( ( ( f_usRinTsstIndex == cOCT6100_INVALID_INDEX ) || ( ( pChanEntry->usMutedPorts & cOCT6100_CHANNEL_MUTE_PORT_RIN ) != 0x0 ) ) 
				&& ( pChanEntry->usRinSilenceEventIndex == cOCT6100_INVALID_INDEX ) ) 
			{
				ulResult = Oct6100ApiReserveMixerEventEntry( f_pApiInstance, 
															 &pChanEntry->usRinSilenceEventIndex );
				if ( ulResult != cOCT6100_ERR_OK )
					return ulResult;

				/* Now, write the mixer event used to copy the RIN signal of the silence channel
				   into the RIN signal of the current channel. */

				WriteParams.ulWriteAddress = cOCT6100_MIXER_CONTROL_MEM_BASE + ( pChanEntry->usRinSilenceEventIndex * cOCT6100_MIXER_CONTROL_MEM_ENTRY_SIZE );
				
				WriteParams.usWriteData = cOCT6100_MIXER_CONTROL_MEM_COPY;
				WriteParams.usWriteData |= 1534;
				WriteParams.usWriteData |= cOCT6100_PCM_U_LAW << cOCT6100_MIXER_CONTROL_MEM_LAW_OFFSET;

				mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
				if ( ulResult != cOCT6100_ERR_OK )
					return ulResult;

				WriteParams.ulWriteAddress += 2;
				WriteParams.usWriteData = pChanEntry->usRinRoutTsiMemIndex;

				mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
				if ( ulResult != cOCT6100_ERR_OK  )
					return ulResult;

				/*=======================================================================*/


				/*=======================================================================*/
				/* Now insert the Sin copy event into the list.*/

				ulResult = Oct6100ApiMixerEventAdd( f_pApiInstance,
													pChanEntry->usRinSilenceEventIndex,
													cOCT6100_EVENT_TYPE_SOUT_COPY,
													f_usEchoIndex );
				if ( ulResult != cOCT6100_ERR_OK )
					return ulResult;
			}
		}
	}

	/* Mute the Sin port. */
	if ( ( ( f_usSinTsstIndex == cOCT6100_INVALID_INDEX ) || ( ( pChanEntry->usMutedPorts & cOCT6100_CHANNEL_MUTE_PORT_SIN ) != 0x0 ) ) 
		&& ( pChanEntry->usSinSilenceEventIndex == cOCT6100_INVALID_INDEX ) )
	{
		ulResult = Oct6100ApiReserveMixerEventEntry( f_pApiInstance, 
													 &pChanEntry->usSinSilenceEventIndex );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;

		/* Now, write the mixer event used to copy the SIN signal of the silence channel
		   into the SIN signal of the current channel. */

		WriteParams.ulWriteAddress = cOCT6100_MIXER_CONTROL_MEM_BASE + ( pChanEntry->usSinSilenceEventIndex * cOCT6100_MIXER_CONTROL_MEM_ENTRY_SIZE );
		
		WriteParams.usWriteData = cOCT6100_MIXER_CONTROL_MEM_COPY;
		WriteParams.usWriteData |= 1534;
		WriteParams.usWriteData |= cOCT6100_PCM_U_LAW << cOCT6100_MIXER_CONTROL_MEM_LAW_OFFSET;

		mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;

		WriteParams.ulWriteAddress += 2;
		WriteParams.usWriteData = pChanEntry->usSinSoutTsiMemIndex;

		mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
		if ( ulResult != cOCT6100_ERR_OK  )
			return ulResult;

		/*=======================================================================*/


		/*=======================================================================*/
		/* Now insert the Sin copy event into the list.*/

		ulResult = Oct6100ApiMixerEventAdd( f_pApiInstance,
											pChanEntry->usSinSilenceEventIndex,
											cOCT6100_EVENT_TYPE_SOUT_COPY,
											f_usEchoIndex );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;
	}

	/* Unmute the Rin port if it was muted. */
	if ( ( ( f_usRinTsstIndex != cOCT6100_INVALID_INDEX ) && ( ( pChanEntry->usMutedPorts & cOCT6100_CHANNEL_MUTE_PORT_RIN ) == 0x0 ) ) 
		&& ( pChanEntry->usRinSilenceEventIndex != cOCT6100_INVALID_INDEX ) )
	{
		/* Remove the event from the list.*/
		ulResult = Oct6100ApiMixerEventRemove(	f_pApiInstance,
												pChanEntry->usRinSilenceEventIndex,
												cOCT6100_EVENT_TYPE_SOUT_COPY );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;

		ulResult = Oct6100ApiReleaseMixerEventEntry( f_pApiInstance, pChanEntry->usRinSilenceEventIndex );
		if ( ulResult != cOCT6100_ERR_OK  )
			return cOCT6100_ERR_FATAL_E1;

		pChanEntry->usRinSilenceEventIndex = cOCT6100_INVALID_INDEX;
	}

	/* Unmute the Sin port if it was muted. */
	if ( ( ( f_usSinTsstIndex != cOCT6100_INVALID_INDEX ) && ( ( pChanEntry->usMutedPorts & cOCT6100_CHANNEL_MUTE_PORT_SIN ) == 0x0 ) )
		&& ( pChanEntry->usSinSilenceEventIndex != cOCT6100_INVALID_INDEX ) )
	{
		/* Remove the event from the list.*/
		ulResult = Oct6100ApiMixerEventRemove(	f_pApiInstance,
												pChanEntry->usSinSilenceEventIndex,
												cOCT6100_EVENT_TYPE_SOUT_COPY );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;

		ulResult = Oct6100ApiReleaseMixerEventEntry( f_pApiInstance, pChanEntry->usSinSilenceEventIndex );
		if ( ulResult != cOCT6100_ERR_OK  )
			return cOCT6100_ERR_FATAL_E2;

		pChanEntry->usSinSilenceEventIndex = cOCT6100_INVALID_INDEX;
	}

	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiSetChannelLevelControl

Description:	This function will configure the level control on a given
				channel.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

f_pVqeConfig			VQE config of the channel.
f_usChanIndex			Index of the channel within the API instance.
f_usEchoMemIndex		Index of the echo channel within the SSPX memory.
f_fClearAlcHlcStatusBit	If this is set, the ALC-HLC status bit must be
						incremented.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiSetChannelLevelControl(
				IN	tPOCT6100_INSTANCE_API		f_pApiInstance,
				IN	tPOCT6100_CHANNEL_OPEN_VQE	f_pVqeConfig,
				IN	UINT16						f_usChanIndex,
				IN	UINT16						f_usEchoMemIndex,
				IN	BOOL						f_fClearAlcHlcStatusBit )
{
	tPOCT6100_API_CHANNEL			pChanEntry;
	tPOCT6100_SHARED_INFO			pSharedInfo;
	UINT32							ulResult;
	UINT32							ulTempData;
	UINT32							ulBaseAddress;
	UINT32							ulFeatureBytesOffset;
	UINT32							ulFeatureBitOffset;
	UINT32							ulFeatureFieldLength;
	UINT32							ulMask;
	UINT32							i;
	UINT16							usTempData;
	UINT8							byLastStatus;
	BOOL							fDisableAlcFirst;
	
	/* Get local pointer to shared portion of the API instance. */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	/* Obtain a pointer to the channel list entry. */
	mOCT6100_GET_CHANNEL_ENTRY_PNT( pSharedInfo, pChanEntry, f_usChanIndex );

	/* Before doing anything, check if the configuration has changed. */
	if ( ( f_fClearAlcHlcStatusBit == TRUE )
		|| ( f_pVqeConfig->fRinLevelControl != pChanEntry->VqeConfig.fRinLevelControl ) 
		|| ( f_pVqeConfig->lRinLevelControlGainDb != pChanEntry->VqeConfig.chRinLevelControlGainDb ) 
		|| ( f_pVqeConfig->fRinAutomaticLevelControl != pChanEntry->VqeConfig.fRinAutomaticLevelControl ) 
		|| ( f_pVqeConfig->lRinAutomaticLevelControlTargetDb != pChanEntry->VqeConfig.chRinAutomaticLevelControlTargetDb ) 
		|| ( f_pVqeConfig->fRinHighLevelCompensation != pChanEntry->VqeConfig.fRinHighLevelCompensation ) 
		|| ( f_pVqeConfig->lRinHighLevelCompensationThresholdDb != pChanEntry->VqeConfig.chRinHighLevelCompensationThresholdDb ) 
		|| ( f_pVqeConfig->fSoutLevelControl != pChanEntry->VqeConfig.fSoutLevelControl ) 
		|| ( f_pVqeConfig->lSoutLevelControlGainDb != pChanEntry->VqeConfig.chSoutLevelControlGainDb ) 
		|| ( f_pVqeConfig->fSoutAutomaticLevelControl != pChanEntry->VqeConfig.fSoutAutomaticLevelControl ) 
		|| ( f_pVqeConfig->lSoutAutomaticLevelControlTargetDb != pChanEntry->VqeConfig.chSoutAutomaticLevelControlTargetDb ) 
		|| ( f_pVqeConfig->fSoutNaturalListenerEnhancement != pChanEntry->VqeConfig.fSoutNaturalListenerEnhancement ) 
		|| ( f_pVqeConfig->ulSoutAutomaticListenerEnhancementGainDb != pChanEntry->VqeConfig.bySoutAutomaticListenerEnhancementGainDb )
		|| ( f_pVqeConfig->ulSoutNaturalListenerEnhancementGainDb != pChanEntry->VqeConfig.bySoutNaturalListenerEnhancementGainDb ) )
	{
		/* Calculate base address for manual level control configuration. */
		ulBaseAddress = cOCT6100_CHANNEL_ROOT_BASE + ( f_usEchoMemIndex * cOCT6100_CHANNEL_ROOT_SIZE ) + pSharedInfo->MemoryMap.ulChanRootConfOfst;

		/* Set the Level control on RIN port.*/
		ulFeatureBytesOffset = pSharedInfo->MemoryMap.RinLevelControlOfst.usDwordOffset * 4;
		ulFeatureBitOffset	 = pSharedInfo->MemoryMap.RinLevelControlOfst.byBitOffset;
		ulFeatureFieldLength = pSharedInfo->MemoryMap.RinLevelControlOfst.byFieldSize;

		/* First read the DWORD where the field is located.*/
		mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulBaseAddress + ulFeatureBytesOffset,
											&ulTempData,
											ulResult );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;

		/* Clear previous value set in the feature field.*/
		mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

		ulTempData &= (~ulMask);

		if ( ( f_pVqeConfig->fRinLevelControl == TRUE ) 
			|| ( f_pVqeConfig->fRinAutomaticLevelControl == TRUE ) 
			|| ( f_pVqeConfig->fRinHighLevelCompensation == TRUE ) )
		{
			/* Set the level control value.*/
			if ( ( f_pVqeConfig->fRinAutomaticLevelControl == TRUE ) 
				|| ( f_pVqeConfig->fRinHighLevelCompensation == TRUE ) )
				ulTempData |= ( 0xFF << ulFeatureBitOffset );
			else 
			{
				/* Convert the dB value into OctFloat format.*/
				usTempData = Oct6100ApiDbAmpHalfToOctFloat( f_pVqeConfig->lRinLevelControlGainDb );
				usTempData -= 0x3800;
				usTempData &= 0x0FF0;
				usTempData >>= 4;

				ulTempData |= ( usTempData << ulFeatureBitOffset ); 
			}
		}
		else /* ( ( f_pVqeConfig->fRinLevelControl == FALSE ) && ( f_pVqeConfig->fRinAutomaticLevelControl == FALSE ) && ( f_pVqeConfig->fRinHighLevelCompensation == FALSE ) ) */
		{
			ulTempData |= ( cOCT6100_PASS_THROUGH_LEVEL_CONTROL << ulFeatureBitOffset );
		}

		/* Save the DWORD where the field is located.*/
		mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
										pChanEntry,
										ulBaseAddress + ulFeatureBytesOffset,
										ulTempData,
										ulResult );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;	

		/* Set the Level control on SOUT port.*/
		ulFeatureBytesOffset = pSharedInfo->MemoryMap.SoutLevelControlOfst.usDwordOffset * 4;
		ulFeatureBitOffset	 = pSharedInfo->MemoryMap.SoutLevelControlOfst.byBitOffset;
		ulFeatureFieldLength = pSharedInfo->MemoryMap.SoutLevelControlOfst.byFieldSize;

		/* First read the DWORD where the field is located.*/
		mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulBaseAddress + ulFeatureBytesOffset,
											&ulTempData,
											ulResult );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;

		/* Clear previous value set in the feature field.*/
		mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

		ulTempData &= (~ulMask);

		if ( ( f_pVqeConfig->fSoutLevelControl == TRUE ) 
			|| ( f_pVqeConfig->fSoutAutomaticLevelControl == TRUE )
			|| ( f_pVqeConfig->fSoutNaturalListenerEnhancement == TRUE )
			|| ( f_pVqeConfig->ulSoutAutomaticListenerEnhancementGainDb != 0x0 ) )
		{
			/* Set the level control value.*/
			if ( ( f_pVqeConfig->fSoutAutomaticLevelControl == TRUE ) 
				|| ( f_pVqeConfig->fSoutNaturalListenerEnhancement == TRUE ) 
				|| ( f_pVqeConfig->ulSoutAutomaticListenerEnhancementGainDb != 0x0 ) )
				ulTempData |= ( 0xFF << ulFeatureBitOffset );
			else 
			{
				/* Convert the dB value into OctFloat format.*/
				usTempData = Oct6100ApiDbAmpHalfToOctFloat( f_pVqeConfig->lSoutLevelControlGainDb );
				usTempData -= 0x3800;
				usTempData &= 0x0FF0;
				usTempData >>= 4;

				ulTempData |= ( usTempData << ulFeatureBitOffset ); 
			}
		}
		else
		{
			ulTempData |= ( cOCT6100_PASS_THROUGH_LEVEL_CONTROL << ulFeatureBitOffset );
		}

		/* Save the DWORD where the field is located.*/
		mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
										pChanEntry,
										ulBaseAddress + ulFeatureBytesOffset,
										ulTempData,
										ulResult );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;	
		
		/* Calculate base address for auto level control + high level compensation configuration. */
		ulBaseAddress = pSharedInfo->MemoryMap.ulChanMainMemBase + ( f_usEchoMemIndex * pSharedInfo->MemoryMap.ulChanMainMemSize ) + f_pApiInstance->pSharedInfo->MemoryMap.ulChanMainIoMemOfst;

		/* Check which one is to be disabled first. */
		if ( f_pVqeConfig->fRinAutomaticLevelControl == TRUE )
			fDisableAlcFirst = FALSE;
		else
			fDisableAlcFirst = TRUE;

		for ( i = 0; i < 2; i ++ )
		{
			/* Set the auto level control target Db for the Rin port. */
			if ( ( ( i == 0 ) && ( fDisableAlcFirst == TRUE ) ) || ( ( i == 1 ) && ( fDisableAlcFirst == FALSE ) ) )
			{
				if ( pSharedInfo->ImageInfo.fRinAutoLevelControl == TRUE )
				{
					ulFeatureBytesOffset = pSharedInfo->MemoryMap.RinAutoLevelControlTargetOfst.usDwordOffset * 4;
					ulFeatureBitOffset	 = pSharedInfo->MemoryMap.RinAutoLevelControlTargetOfst.byBitOffset;
					ulFeatureFieldLength = pSharedInfo->MemoryMap.RinAutoLevelControlTargetOfst.byFieldSize;

					/* First read the DWORD where the field is located.*/
					mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
														pChanEntry,
														ulBaseAddress + ulFeatureBytesOffset,
														&ulTempData,
														ulResult );
					if ( ulResult != cOCT6100_ERR_OK )
						return ulResult;

					/* Clear previous value set in the feature field.*/
					mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

					ulTempData &= (~ulMask);

					if ( f_pVqeConfig->fRinAutomaticLevelControl == TRUE )
					{
						/* Convert the dB value into OctFloat format.*/
						usTempData = Oct6100ApiDbAmpHalfToOctFloat( 2 * f_pVqeConfig->lRinAutomaticLevelControlTargetDb );

						/* Set auto level control target on the Rin port. */
						ulTempData |= ( usTempData << ulFeatureBitOffset ); 
					}
					else /* if ( f_pVqeConfig->fRinAutomaticLevelControl == FALSE ) */
					{
						/* Disable auto level control. */
						ulTempData |= ( 0xFFFF << ulFeatureBitOffset ); 
					}

					/* Save the DWORD where the field is located.*/
					mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
													pChanEntry,
													ulBaseAddress + ulFeatureBytesOffset,
													ulTempData,
													ulResult );
					if ( ulResult != cOCT6100_ERR_OK )
						return ulResult;	
				}
			}
			else
			{
				/* Set the high level compensation threshold Db for the Rin port. */
				if ( pSharedInfo->ImageInfo.fRinHighLevelCompensation == TRUE )
				{
					ulFeatureBytesOffset = pSharedInfo->MemoryMap.RinHighLevelCompensationThresholdOfst.usDwordOffset * 4;
					ulFeatureBitOffset	 = pSharedInfo->MemoryMap.RinHighLevelCompensationThresholdOfst.byBitOffset;
					ulFeatureFieldLength = pSharedInfo->MemoryMap.RinHighLevelCompensationThresholdOfst.byFieldSize;

					/* First read the DWORD where the field is located.*/
					mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
														pChanEntry,
														ulBaseAddress + ulFeatureBytesOffset,
														&ulTempData,
														ulResult );
					if ( ulResult != cOCT6100_ERR_OK )
						return ulResult;

					/* Clear previous value set in the feature field.*/
					mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

					ulTempData &= (~ulMask);

					if ( f_pVqeConfig->fRinHighLevelCompensation == TRUE )
					{
						/* Convert the dB value into OctFloat format.*/
						usTempData = Oct6100ApiDbAmpHalfToOctFloat( 2 * f_pVqeConfig->lRinHighLevelCompensationThresholdDb );

						/* Set high level compensation threshold on the Rin port. */
						ulTempData |= ( usTempData << ulFeatureBitOffset ); 
					}
					else /* if ( f_pVqeConfig->fRinHighLevelCompensation == FALSE ) */
					{
						/* Disable high level compensation. */
						ulTempData |= ( 0xFFFF << ulFeatureBitOffset ); 
					}

					/* Save the DWORD where the field is located.*/
					mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
													pChanEntry,
													ulBaseAddress + ulFeatureBytesOffset,
													ulTempData,
													ulResult );
					if ( ulResult != cOCT6100_ERR_OK )
						return ulResult;	
				}
			}
		}

		/* Set the auto level control target Db for the Sout port. */
		if ( pSharedInfo->ImageInfo.fRinAutoLevelControl == TRUE )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.SoutAutoLevelControlTargetOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.SoutAutoLevelControlTargetOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.SoutAutoLevelControlTargetOfst.byFieldSize;

			/* First read the DWORD where the field is located.*/
			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);

			if ( f_pVqeConfig->fSoutAutomaticLevelControl == TRUE )
			{
				/* Convert the dB value into OctFloat format.*/
				usTempData = Oct6100ApiDbAmpHalfToOctFloat( 2 * f_pVqeConfig->lSoutAutomaticLevelControlTargetDb );

				/* Set auto level control target on the Sout port. */
				ulTempData |= ( usTempData << ulFeatureBitOffset ); 
			}
			else /* if ( f_pVqeConfig->fSoutAutomaticLevelControl == FALSE ) */
			{
				/* Disable auto level control. */
				ulTempData |= ( 0xFFFF << ulFeatureBitOffset ); 
			}

			/* Save the DWORD where the field is located.*/
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}

		/* Set the high level compensation threshold Db for the Sout port. */
		if ( pSharedInfo->ImageInfo.fSoutHighLevelCompensation == TRUE )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.SoutHighLevelCompensationThresholdOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.SoutHighLevelCompensationThresholdOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.SoutHighLevelCompensationThresholdOfst.byFieldSize;

			/* First read the DWORD where the field is located.*/
			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);

			/* Disable high level compensation on Sout for now. */
			ulTempData |= ( 0xFFFF << ulFeatureBitOffset ); 

			/* Save the DWORD where the field is located.*/
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}

		/* Check if have to clear the ALC-HLC status. */
		if ( ( pSharedInfo->ImageInfo.fAlcHlcStatus == TRUE ) 
			&& ( ( f_fClearAlcHlcStatusBit == TRUE )

				) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.AlcHlcStatusOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.AlcHlcStatusOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.AlcHlcStatusOfst.byFieldSize;

			/* First read the DWORD where the field is located.*/
			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Get previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			/* Retrieve last status. */
			byLastStatus = (UINT8)( ( ( ulTempData & ulMask ) >> ulFeatureBitOffset ) & 0xFF );

			/* Increment to reset context. */
			byLastStatus ++;

			/* Just in case, not to overwrite some context in external memory. */
			byLastStatus &= ( 0x1 << ulFeatureFieldLength ) - 1;

			/* Clear last status. */
			ulTempData &= (~ulMask);

			/* Set new status. */
			ulTempData |= ( byLastStatus << ulFeatureBitOffset ); 

			/* Save the DWORD where the field is located.*/
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;			
		}
	}

	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiSetChannelTailConfiguration

Description:	This function will configure the tail displacement and length
				on a given channel.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

f_pVqeConfig			VQE config of the channel.
f_usChanIndex			Index of the channel within the API instance.
f_usEchoMemIndex		Index of the echo channel within the SSPX memory.
f_fModifyOnly			Function called from a modify or open?	

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiSetChannelTailConfiguration(
				IN	tPOCT6100_INSTANCE_API		f_pApiInstance,
				IN	tPOCT6100_CHANNEL_OPEN_VQE	f_pVqeConfig,
				IN	UINT16						f_usChanIndex,
				IN	UINT16						f_usEchoMemIndex,
				IN	BOOL						f_fModifyOnly )
{
	tPOCT6100_API_CHANNEL	pChanEntry;
	tPOCT6100_SHARED_INFO	pSharedInfo;
	UINT32					ulResult;
	UINT32					ulTempData;
	UINT32					ulNlpConfBaseAddress;
	UINT32					ulAfConfBaseAddress;
	UINT32					ulFeatureBytesOffset;
	UINT32					ulFeatureBitOffset;
	UINT32					ulFeatureFieldLength;
	UINT32					ulMask;
	UINT32					ulTailSum;
	BOOL					fTailDisplacementModified = FALSE;
	
	/* Get local pointer to shared portion of the API instance. */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	/* Obtain a pointer to the channel list entry. */
	mOCT6100_GET_CHANNEL_ENTRY_PNT( pSharedInfo, pChanEntry, f_usChanIndex );

	/* Calculate base addresses of NLP + AF configuration structure for the specified channel. */
	ulNlpConfBaseAddress = cOCT6100_CHANNEL_ROOT_BASE + ( f_usEchoMemIndex * cOCT6100_CHANNEL_ROOT_SIZE ) + pSharedInfo->MemoryMap.ulChanRootConfOfst;
	ulAfConfBaseAddress = pSharedInfo->MemoryMap.ulChanMainMemBase + ( f_usEchoMemIndex * pSharedInfo->MemoryMap.ulChanMainMemSize ) + pSharedInfo->MemoryMap.ulChanMainIoMemOfst;

	/* Set the tail displacement.*/
	if ( pSharedInfo->ImageInfo.fTailDisplacement == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( ( f_pVqeConfig->fEnableTailDisplacement != pChanEntry->VqeConfig.fEnableTailDisplacement ) 
					|| ( f_pVqeConfig->ulTailDisplacement != pChanEntry->VqeConfig.usTailDisplacement ) 
					|| ( f_pVqeConfig->fAcousticEcho != pChanEntry->VqeConfig.fAcousticEcho ) ) ) )
		{
			/* Remember that the tail displacement parameters were changed. */
			fTailDisplacementModified = TRUE;

			/* Check if we must set the tail displacement value. */
			if ( ( f_pVqeConfig->fEnableTailDisplacement == TRUE ) 
				&& ( pSharedInfo->ImageInfo.fPerChannelTailDisplacement == TRUE ) )
			{
				ulFeatureBytesOffset = pSharedInfo->MemoryMap.PerChanTailDisplacementFieldOfst.usDwordOffset * 4;
				ulFeatureBitOffset	 = pSharedInfo->MemoryMap.PerChanTailDisplacementFieldOfst.byBitOffset;
				ulFeatureFieldLength = pSharedInfo->MemoryMap.PerChanTailDisplacementFieldOfst.byFieldSize;

				/* First read the DWORD where the field is located.*/
				mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
													pChanEntry,
													ulNlpConfBaseAddress + ulFeatureBytesOffset,
													&ulTempData,
													ulResult );
				if ( ulResult != cOCT6100_ERR_OK )
					return ulResult;

				/* Clear previous value set in the feature field.*/
				mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

				ulTempData &= (~ulMask);
				if ( ( f_pVqeConfig->fEnableTailDisplacement == TRUE ) 
					&& ( f_pVqeConfig->ulTailDisplacement != 0x0 ) )
				{
					if ( pSharedInfo->ImageInfo.fAfTailDisplacement == FALSE )
					{
						if ( f_pVqeConfig->ulTailDisplacement == cOCT6100_AUTO_SELECT_TAIL )
						{
							ulTempData |= ( ( ( pSharedInfo->ChipConfig.usTailDisplacement / 16 ) ) << ulFeatureBitOffset );
						}
						else
						{
							ulTempData |= ( ( ( f_pVqeConfig->ulTailDisplacement / 16 ) ) << ulFeatureBitOffset );
						}
					}
					else /* if ( pSharedInfo->ImageInfo.fAfTailDisplacement == TRUE ) */
					{
						/* If AEC is not activated, this must be set to the requested tail displacement. */
						if ( f_pVqeConfig->fAcousticEcho == FALSE )
						{
							if ( f_pVqeConfig->ulTailDisplacement == cOCT6100_AUTO_SELECT_TAIL )
							{
								ulTailSum = pSharedInfo->ChipConfig.usTailDisplacement;
							}
							else
							{
								ulTailSum = f_pVqeConfig->ulTailDisplacement;
							}
							
							if ( ulTailSum == 0 )
							{
								ulTempData |= ( ( 0 ) << ulFeatureBitOffset );
							}
							else if ( ulTailSum <= 128 )
							{
								ulTempData |= ( ( 1 ) << ulFeatureBitOffset );
							}
							else if ( ulTailSum <= 384 )
							{
								ulTempData |= ( ( 3 ) << ulFeatureBitOffset );
							}
							else /* if ( ulTailSum <= 896 ) */
							{
								ulTempData |= ( ( 7 ) << ulFeatureBitOffset );
							}
						}
						else /* if ( f_pVqeConfig->fAcousticEcho == FALSE ) */
						{
							/* Otherwise, the tail displacement is configured differently.  This field stays to 0. */
							ulTempData |= ( 0x0 << ulFeatureBitOffset );
						}
					}
				}

				/* Then save the new DWORD where the field is located.*/
				mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulNlpConfBaseAddress + ulFeatureBytesOffset,
												ulTempData,
												ulResult );
				if ( ulResult != cOCT6100_ERR_OK )
					return ulResult;	
			}

			if ( pSharedInfo->ImageInfo.fAfTailDisplacement == TRUE )
			{
				/* Set the tail displacement offset in the AF. */
				ulFeatureBytesOffset = pSharedInfo->MemoryMap.AfTailDisplacementFieldOfst.usDwordOffset * 4;
				ulFeatureBitOffset	 = pSharedInfo->MemoryMap.AfTailDisplacementFieldOfst.byBitOffset;
				ulFeatureFieldLength = pSharedInfo->MemoryMap.AfTailDisplacementFieldOfst.byFieldSize;

				/* First read the DWORD where the field is located.*/
				mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
													pChanEntry,
													ulAfConfBaseAddress + ulFeatureBytesOffset,
													&ulTempData,
													ulResult );
				if ( ulResult != cOCT6100_ERR_OK )
					return ulResult;

				/* Clear previous value set in the feature field.*/
				mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

				ulTempData &= (~ulMask);

				if ( f_pVqeConfig->ulTailDisplacement == cOCT6100_AUTO_SELECT_TAIL )
				{
					ulTempData |= ( ( ( pSharedInfo->ChipConfig.usTailDisplacement / 16 ) ) << ulFeatureBitOffset );
				}
				else
				{
					ulTempData |= ( ( ( f_pVqeConfig->ulTailDisplacement / 16 ) ) << ulFeatureBitOffset );
				}

				/* Then save the DWORD where the field is located.*/
				mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulAfConfBaseAddress + ulFeatureBytesOffset,
												ulTempData,
												ulResult );
				if ( ulResult != cOCT6100_ERR_OK )
					return ulResult;
			}

			ulFeatureBytesOffset = pSharedInfo->MemoryMap.TailDisplEnableOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.TailDisplEnableOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.TailDisplEnableOfst.byFieldSize;

			/* First read the DWORD where the field is located.*/
			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulNlpConfBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);
			ulTempData |= ( ( (UINT32)f_pVqeConfig->fEnableTailDisplacement ) << ulFeatureBitOffset );

			/* Then save the DWORD where the field is located.*/
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}

	/* Set the tail length. */
	if ( pSharedInfo->ImageInfo.fPerChannelTailLength == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( f_pVqeConfig->ulTailLength != pChanEntry->VqeConfig.usTailLength ) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.PerChanTailLengthFieldOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.PerChanTailLengthFieldOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.PerChanTailLengthFieldOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulAfConfBaseAddress + ulFeatureBytesOffset,
												&ulTempData, 
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;

			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);
			/* Check if must automatically select maximum or if must use user specific value. */
			if ( f_pVqeConfig->ulTailLength == cOCT6100_AUTO_SELECT_TAIL )
			{
				ulTempData |= ( ( ( pSharedInfo->ImageInfo.usMaxTailLength - 32 ) / 4 )  << ulFeatureBitOffset );
			}
			else
			{
				ulTempData |= ( ( ( f_pVqeConfig->ulTailLength - 32 ) / 4 )  << ulFeatureBitOffset );
			}

			/* Then save the DWORD where the field is located.*/
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulAfConfBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}

	/* Configure AEC tail length. */
	if ( pSharedInfo->ImageInfo.fAecTailLength == TRUE )
	{
		/* Check if the configuration has been changed. */
		if ( ( f_fModifyOnly == FALSE )
			|| ( fTailDisplacementModified == TRUE )
			|| ( ( f_fModifyOnly == TRUE ) 
				&& ( ( f_pVqeConfig->ulAecTailLength != pChanEntry->VqeConfig.usAecTailLength ) 
				|| ( f_pVqeConfig->fAcousticEcho != pChanEntry->VqeConfig.fAcousticEcho ) ) ) )
		{
			ulFeatureBytesOffset = pSharedInfo->MemoryMap.AecTailLengthFieldOfst.usDwordOffset * 4;
			ulFeatureBitOffset	 = pSharedInfo->MemoryMap.AecTailLengthFieldOfst.byBitOffset;
			ulFeatureFieldLength = pSharedInfo->MemoryMap.AecTailLengthFieldOfst.byFieldSize;

			mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
												pChanEntry,
												ulNlpConfBaseAddress + ulFeatureBytesOffset,
												&ulTempData,
												ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;
			
			/* Clear previous value set in the feature field.*/
			mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

			ulTempData &= (~ulMask);

			/* Set acoustic echo tail length. */
			if ( f_pVqeConfig->fAcousticEcho == TRUE )
			{
				switch( f_pVqeConfig->ulAecTailLength )
				{
				case 1024:
					ulTempData |= ( ( 3 ) << ulFeatureBitOffset );
					break;
				case 512:
					ulTempData |= ( ( 2 ) << ulFeatureBitOffset );
					break;
				case 256:
					ulTempData |= ( ( 1 ) << ulFeatureBitOffset );
					break;
				case 128:
				default:
					ulTempData |= ( ( 0 ) << ulFeatureBitOffset );
					break;
				}
			}
			else if ( f_pVqeConfig->fEnableTailDisplacement == TRUE )
			{
				/* No acoustic echo case. */

				/* Start with requested tail displacement. */
				if ( f_pVqeConfig->ulTailDisplacement == cOCT6100_AUTO_SELECT_TAIL )
				{
					ulTailSum = pSharedInfo->ChipConfig.usTailDisplacement;
				}
				else
				{
					ulTailSum = f_pVqeConfig->ulTailDisplacement;
				}

				/* Add requested tail length. */
				if ( f_pVqeConfig->ulTailLength == cOCT6100_AUTO_SELECT_TAIL )
				{
					ulTailSum += pSharedInfo->ImageInfo.usMaxTailLength;
				}
				else
				{
					ulTailSum += f_pVqeConfig->ulTailLength;
				}

				/* Round this value up. */
				if ( ulTailSum <= 128 )
				{
					ulTempData |= ( ( 0 ) << ulFeatureBitOffset );
				}
				else if ( ulTailSum <= 256 )
				{
					ulTempData |= ( ( 1 ) << ulFeatureBitOffset );
				}
				else if ( ulTailSum <= 512 )
				{
					ulTempData |= ( ( 2 ) << ulFeatureBitOffset );
				}
				else /* if ( ulTailSum <= 1024 ) */
				{
					ulTempData |= ( ( 3 ) << ulFeatureBitOffset );
				}
			}
			else
			{
				/* Keep this to zero. */
				ulTempData |= ( ( 0 ) << ulFeatureBitOffset );
			}
			
			/* Write the new DWORD where the field is located. */
			mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulNlpConfBaseAddress + ulFeatureBytesOffset,
											ulTempData,
											ulResult );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;	
		}
	}

	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ChannelMuteSer

Description:	This function will mute some of the ports on a given
				channel.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

f_pChannelMute			What channel/ports to mute.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ChannelMuteSer(
				IN	tPOCT6100_INSTANCE_API		f_pApiInstance,
				IN	tPOCT6100_CHANNEL_MUTE		f_pChannelMute )
{
	UINT32	ulResult;
	UINT16	usChanIndex;
	UINT16	usPortMask;

	/* Verify that all the parameters given match the state of the API. */
	ulResult = Oct6100ApiAssertChannelMuteParams(	f_pApiInstance, 
													f_pChannelMute, 
													&usChanIndex,
													&usPortMask );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	/* Call the actual channel mute ports function. */
	ulResult = Oct6100ApiMuteChannelPorts(	f_pApiInstance, 
											usChanIndex,
											usPortMask,
											TRUE );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiAssertChannelMuteParams

Description:	Check the user parameters passed to the channel mute function.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

f_pChannelMute			What channel/ports to mute.
f_pusChanIndex			Resulting channel index where the muting should
						be applied.
f_pusPorts				Port mask on which to apply the muting.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiAssertChannelMuteParams(	
				IN	tPOCT6100_INSTANCE_API		f_pApiInstance, 
				IN	tPOCT6100_CHANNEL_MUTE		f_pChannelMute, 
				OUT PUINT16						f_pusChanIndex,
				OUT PUINT16						f_pusPorts )
{
	tPOCT6100_SHARED_INFO			pSharedInfo;
	tPOCT6100_API_CHANNEL			pChanEntry;
	UINT32							ulEntryOpenCnt;

	/* Get local pointer(s). */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	/* Check the provided handle. */
	if ( (f_pChannelMute->ulChannelHndl & cOCT6100_HNDL_TAG_MASK) != cOCT6100_HNDL_TAG_CHANNEL )
		return cOCT6100_ERR_CHANNEL_INVALID_HANDLE;

	*f_pusChanIndex = (UINT16)( f_pChannelMute->ulChannelHndl & cOCT6100_HNDL_INDEX_MASK );
	if ( *f_pusChanIndex  >= pSharedInfo->ChipConfig.usMaxChannels )
		return cOCT6100_ERR_CHANNEL_INVALID_HANDLE;

	/*=======================================================================*/
	/* Get a pointer to the channel's list entry. */

	mOCT6100_GET_CHANNEL_ENTRY_PNT( pSharedInfo, pChanEntry, *f_pusChanIndex  )

	/* Extract the entry open count from the provided handle. */
	ulEntryOpenCnt = ( f_pChannelMute->ulChannelHndl >> cOCT6100_ENTRY_OPEN_CNT_SHIFT) & cOCT6100_ENTRY_OPEN_CNT_MASK;

	/* Check for errors. */
	if ( pChanEntry->fReserved != TRUE )
		return cOCT6100_ERR_CHANNEL_NOT_OPEN;
	if ( ulEntryOpenCnt != pChanEntry->byEntryOpenCnt )
		return cOCT6100_ERR_CHANNEL_INVALID_HANDLE;
	if ( pChanEntry->fBiDirChannel == TRUE )
		return cOCT6100_ERR_CHANNEL_PART_OF_BIDIR_CHANNEL;

	/*=======================================================================*/

	/* Check the provided port mask. */

	if ( ( f_pChannelMute->ulPortMask &
		~(	cOCT6100_CHANNEL_MUTE_PORT_NONE | 
			cOCT6100_CHANNEL_MUTE_PORT_RIN |
			cOCT6100_CHANNEL_MUTE_PORT_ROUT |
			cOCT6100_CHANNEL_MUTE_PORT_SIN | 
			cOCT6100_CHANNEL_MUTE_PORT_SOUT |
			cOCT6100_CHANNEL_MUTE_PORT_SIN_WITH_FEATURES ) ) != 0 )
		return cOCT6100_ERR_CHANNEL_MUTE_MASK;

	/* Sin + Sin with features cannot be muted simultaneously. */
	if ( ( ( f_pChannelMute->ulPortMask & cOCT6100_CHANNEL_MUTE_PORT_SIN ) != 0x0 )
		&& ( ( f_pChannelMute->ulPortMask & cOCT6100_CHANNEL_MUTE_PORT_SIN_WITH_FEATURES ) != 0x0 ) )
		return cOCT6100_ERR_CHANNEL_MUTE_MASK_SIN;

	/* Check if Sin mute with features is supported by the firmware. */
	if ( ( ( f_pChannelMute->ulPortMask & cOCT6100_CHANNEL_MUTE_PORT_SIN_WITH_FEATURES ) != 0x0 )
		&& ( pSharedInfo->ImageInfo.fSinMute == FALSE ) )
		return cOCT6100_ERR_NOT_SUPPORTED_CHANNEL_SIN_MUTE_FEATURES;

	/* Return the ports to the calling function. */
	*f_pusPorts = (UINT16)( f_pChannelMute->ulPortMask & 0xFFFF );

	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ChannelUnMuteSer

Description:	This function will unmute some of the ports on a given
				channel.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

f_pChannelUnMute		What channel/ports to unmute.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ChannelUnMuteSer(
				IN	tPOCT6100_INSTANCE_API		f_pApiInstance,
				IN	tPOCT6100_CHANNEL_UNMUTE	f_pChannelUnMute )
{
	UINT32	ulResult;
	UINT16	usChanIndex;
	UINT16	usPortMask;

	/* Verify that all the parameters given match the state of the API. */
	ulResult = Oct6100ApiAssertChannelUnMuteParams(	f_pApiInstance, 
													f_pChannelUnMute, 
													&usChanIndex,
													&usPortMask );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	/* Call the actual channel mute ports function. */
	ulResult = Oct6100ApiMuteChannelPorts(	f_pApiInstance, 
											usChanIndex,
											usPortMask,
											FALSE );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	return cOCT6100_ERR_OK;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiAssertChannelUnMuteParams

Description:	Check the user parameters passed to the channel unmute function.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

f_pChannelUnMute		What channel/ports to Unmute.
f_pusChanIndex			Resulting channel index where the muting should
						be applied.
f_pusPorts				Port mask on which to apply the muting.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiAssertChannelUnMuteParams(	
				IN	tPOCT6100_INSTANCE_API		f_pApiInstance, 
				IN	tPOCT6100_CHANNEL_UNMUTE	f_pChannelUnMute, 
				OUT PUINT16						f_pusChanIndex,
				OUT PUINT16						f_pusPorts )
{
	tPOCT6100_SHARED_INFO			pSharedInfo;
	tPOCT6100_API_CHANNEL			pChanEntry;
	UINT32							ulEntryOpenCnt;

	/* Get local pointer(s). */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	/* Check the provided handle. */
	if ( (f_pChannelUnMute->ulChannelHndl & cOCT6100_HNDL_TAG_MASK) != cOCT6100_HNDL_TAG_CHANNEL )
		return cOCT6100_ERR_CHANNEL_INVALID_HANDLE;

	*f_pusChanIndex = (UINT16)( f_pChannelUnMute->ulChannelHndl & cOCT6100_HNDL_INDEX_MASK );
	if ( *f_pusChanIndex  >= pSharedInfo->ChipConfig.usMaxChannels )
		return cOCT6100_ERR_CHANNEL_INVALID_HANDLE;

	/*=======================================================================*/
	/* Get a pointer to the channel's list entry. */

	mOCT6100_GET_CHANNEL_ENTRY_PNT( pSharedInfo, pChanEntry, *f_pusChanIndex  )

	/* Extract the entry open count from the provided handle. */
	ulEntryOpenCnt = ( f_pChannelUnMute->ulChannelHndl >> cOCT6100_ENTRY_OPEN_CNT_SHIFT) & cOCT6100_ENTRY_OPEN_CNT_MASK;

	/* Check for errors. */
	if ( pChanEntry->fReserved != TRUE )
		return cOCT6100_ERR_CHANNEL_NOT_OPEN;
	if ( ulEntryOpenCnt != pChanEntry->byEntryOpenCnt )
		return cOCT6100_ERR_CHANNEL_INVALID_HANDLE;
	if ( pChanEntry->fBiDirChannel == TRUE )
		return cOCT6100_ERR_CHANNEL_PART_OF_BIDIR_CHANNEL;

	/*=======================================================================*/

	/* Check the provided port mask. */

	if ( ( f_pChannelUnMute->ulPortMask &
		~(	cOCT6100_CHANNEL_MUTE_PORT_NONE | 
			cOCT6100_CHANNEL_MUTE_PORT_RIN |
			cOCT6100_CHANNEL_MUTE_PORT_ROUT |
			cOCT6100_CHANNEL_MUTE_PORT_SIN | 
			cOCT6100_CHANNEL_MUTE_PORT_SOUT |
			cOCT6100_CHANNEL_MUTE_PORT_SIN_WITH_FEATURES ) ) != 0 )
		return cOCT6100_ERR_CHANNEL_MUTE_MASK;
	
	/* Return the ports to the calling function. */
	*f_pusPorts = (UINT16)( f_pChannelUnMute->ulPortMask & 0xFFFF );

	return cOCT6100_ERR_OK;
}


/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiMuteSinWithFeatures

Description:	Mute or Unmute the sin with features port.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance				Pointer to API instance. This memory is used to keep
							the present state of the chip and all its resources.

f_usChanIndex				Resulting channel index where the muting should
							be applied.
f_fEnableSinWithFeatures	Whether to enable the feature or not.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiMuteSinWithFeatures(
				IN	tPOCT6100_INSTANCE_API		f_pApiInstance,
				IN	UINT16						f_usChanIndex,
				IN	BOOL						f_fEnableSinWithFeatures )
{
	tPOCT6100_SHARED_INFO			pSharedInfo;
	tPOCT6100_API_CHANNEL			pChanEntry;
	tOCT6100_WRITE_PARAMS			WriteParams;
	UINT32							ulResult;

	UINT32							ulTempData;
	UINT32							ulBaseAddress;
	UINT32							ulFeatureBytesOffset;
	UINT32							ulFeatureBitOffset;
	UINT32							ulFeatureFieldLength;
	UINT32							ulMask;
	
	/* Get local pointer(s). */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	WriteParams.pProcessContext = f_pApiInstance->pProcessContext;

	WriteParams.ulUserChipId = pSharedInfo->ChipConfig.ulUserChipId;

	/* Get a pointer to the channel's list entry. */
	mOCT6100_GET_CHANNEL_ENTRY_PNT( pSharedInfo, pChanEntry, f_usChanIndex  )

	ulBaseAddress = cOCT6100_CHANNEL_ROOT_BASE + ( pChanEntry->usEchoMemIndex * cOCT6100_CHANNEL_ROOT_SIZE ) + pSharedInfo->MemoryMap.ulChanRootConfOfst;
	
	if ( pSharedInfo->ImageInfo.fSinMute == TRUE )
	{
		ulFeatureBytesOffset = pSharedInfo->MemoryMap.SinMuteOfst.usDwordOffset * 4;
		ulFeatureBitOffset	 = pSharedInfo->MemoryMap.SinMuteOfst.byBitOffset;
		ulFeatureFieldLength = pSharedInfo->MemoryMap.SinMuteOfst.byFieldSize;

		mOCT6100_RETRIEVE_NLP_CONF_DWORD(	f_pApiInstance,
											pChanEntry,
											ulBaseAddress + ulFeatureBytesOffset,
											&ulTempData,
											ulResult );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;	
		
		/* Clear previous value set in the feature field.*/
		mOCT6100_CREATE_FEATURE_MASK( ulFeatureFieldLength, ulFeatureBitOffset, &ulMask );

		/* Clear the mute flag. */
		ulTempData &= (~ulMask);

		/* Set the mute flag on the Sin port.*/
		if ( f_fEnableSinWithFeatures == TRUE )
			ulTempData |= ( 0x1 << ulFeatureBitOffset );

		/* Write the new DWORD where the field is located. */
		mOCT6100_SAVE_NLP_CONF_DWORD(	f_pApiInstance,
										pChanEntry,
										ulBaseAddress + ulFeatureBytesOffset,
										ulTempData,
										ulResult );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;	
	}

	return cOCT6100_ERR_OK;
}


/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiMuteChannelPorts

Description:	Mute or Unmute the specified ports, according to the mask.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep
						the present state of the chip and all its resources.

f_usChanIndex			Resulting channel index where the muting should
						be applied.
f_usPortMask			Port mask on which to apply the muting/unmuting.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiMuteChannelPorts(	
				IN	tPOCT6100_INSTANCE_API		f_pApiInstance,
				IN	UINT16						f_usChanIndex,
				IN	UINT16						f_usPortMask,
				IN	BOOL						f_fMute )
{
	tPOCT6100_SHARED_INFO			pSharedInfo;
	tPOCT6100_API_CHANNEL			pChanEntry;
	tOCT6100_WRITE_PARAMS			WriteParams;
	UINT32							ulResult;
	BOOL							fDisableSinWithFeatures = FALSE;
	BOOL							fEnableSinWithFeatures = FALSE;
	
	/* Get local pointer(s). */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	WriteParams.pProcessContext = f_pApiInstance->pProcessContext;

	WriteParams.ulUserChipId = pSharedInfo->ChipConfig.ulUserChipId;

	/* Get a pointer to the channel's list entry. */
	mOCT6100_GET_CHANNEL_ENTRY_PNT( pSharedInfo, pChanEntry, f_usChanIndex  )

	/* Rin port. */
	if ( ( f_fMute == TRUE )
		&& ( ( f_usPortMask & cOCT6100_CHANNEL_MUTE_PORT_RIN ) != 0x0 )
		&& ( ( pChanEntry->usMutedPorts & cOCT6100_CHANNEL_MUTE_PORT_RIN ) == 0x0 ) )
	{
		/* Mute this port. */
		pChanEntry->usMutedPorts |= cOCT6100_CHANNEL_MUTE_PORT_RIN;

		ulResult = Oct6100ApiMutePorts( f_pApiInstance, f_usChanIndex, pChanEntry->usRinTsstIndex, pChanEntry->usSinTsstIndex, TRUE );
		if ( ulResult != cOCT6100_ERR_OK )
		{
			pChanEntry->usMutedPorts &= ~cOCT6100_CHANNEL_MUTE_PORT_RIN;
			return ulResult;
		}
	}
	else if ( ( f_fMute == FALSE ) 
		&& ( ( f_usPortMask & cOCT6100_CHANNEL_MUTE_PORT_RIN ) != 0x0 )
		&& ( ( pChanEntry->usMutedPorts & cOCT6100_CHANNEL_MUTE_PORT_RIN ) != 0x0 ) )
	{
		/* Unmute this port. */
		pChanEntry->usMutedPorts &= ~cOCT6100_CHANNEL_MUTE_PORT_RIN;

		ulResult = Oct6100ApiMutePorts( f_pApiInstance, f_usChanIndex, pChanEntry->usRinTsstIndex, pChanEntry->usSinTsstIndex, TRUE );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;
	}

	/* Rout port. */
	if ( ( f_fMute == TRUE )
		&& ( ( f_usPortMask & cOCT6100_CHANNEL_MUTE_PORT_ROUT ) != 0x0 )
		&& ( ( pChanEntry->usMutedPorts & cOCT6100_CHANNEL_MUTE_PORT_ROUT ) == 0x0 ) )
	{
		/* Mute this port. */

		if ( pChanEntry->usRoutTsstIndex != cOCT6100_INVALID_INDEX )
		{
			ulResult = Oct6100ApiWriteOutputTsstControlMemory( f_pApiInstance,
															   pChanEntry->usRoutTsstIndex,

															   1534 );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;
		}

		pChanEntry->usMutedPorts |= cOCT6100_CHANNEL_MUTE_PORT_ROUT;
	}
	else if ( ( f_fMute == FALSE ) 
		&& ( ( f_usPortMask & cOCT6100_CHANNEL_MUTE_PORT_ROUT ) != 0x0 )
		&& ( ( pChanEntry->usMutedPorts & cOCT6100_CHANNEL_MUTE_PORT_ROUT ) != 0x0 ) )
	{
		/* Unmute this port. */

		if ( pChanEntry->usRoutTsstIndex != cOCT6100_INVALID_INDEX )
		{
			ulResult = Oct6100ApiWriteOutputTsstControlMemory( f_pApiInstance,
															   pChanEntry->usRoutTsstIndex,

															   pChanEntry->usRinRoutTsiMemIndex );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;
		}

		pChanEntry->usMutedPorts &= ~cOCT6100_CHANNEL_MUTE_PORT_ROUT;
	}

	/* Sin port. */
	if ( ( f_fMute == TRUE )
		&& ( ( f_usPortMask & cOCT6100_CHANNEL_MUTE_PORT_SIN ) != 0x0 )
		&& ( ( pChanEntry->usMutedPorts & cOCT6100_CHANNEL_MUTE_PORT_SIN ) == 0x0 ) )
	{
		/* Mute this port. */
		pChanEntry->usMutedPorts |= cOCT6100_CHANNEL_MUTE_PORT_SIN;

		ulResult = Oct6100ApiMutePorts( f_pApiInstance, f_usChanIndex, pChanEntry->usRinTsstIndex, pChanEntry->usSinTsstIndex, TRUE );
		if ( ulResult != cOCT6100_ERR_OK )
		{
			pChanEntry->usMutedPorts &= ~cOCT6100_CHANNEL_MUTE_PORT_SIN;
			return ulResult;
		}
	}
	else if ( 
			( ( f_fMute == FALSE ) 
			&& ( ( f_usPortMask & cOCT6100_CHANNEL_MUTE_PORT_SIN ) != 0x0 )
			&& ( ( pChanEntry->usMutedPorts & cOCT6100_CHANNEL_MUTE_PORT_SIN ) != 0x0 ) ) 
		|| 
			( ( f_fMute == TRUE )  
			&& ( ( f_usPortMask & cOCT6100_CHANNEL_MUTE_PORT_SIN_WITH_FEATURES ) != 0x0 ) 
			&& ( ( pChanEntry->usMutedPorts & cOCT6100_CHANNEL_MUTE_PORT_SIN ) != 0x0 ) ) )
	{
		/* Unmute this port. */
		pChanEntry->usMutedPorts &= ~cOCT6100_CHANNEL_MUTE_PORT_SIN;

		ulResult = Oct6100ApiMutePorts( f_pApiInstance, f_usChanIndex, pChanEntry->usRinTsstIndex, pChanEntry->usSinTsstIndex, TRUE );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;
	}

	/* Sout port. */
	if ( ( f_fMute == TRUE )
		&& ( ( f_usPortMask & cOCT6100_CHANNEL_MUTE_PORT_SOUT ) != 0x0 )
		&& ( ( pChanEntry->usMutedPorts & cOCT6100_CHANNEL_MUTE_PORT_SOUT ) == 0x0 ) )
	{
		/* Mute this port. */

		if ( pChanEntry->usSoutTsstIndex != cOCT6100_INVALID_INDEX )
		{
			ulResult = Oct6100ApiWriteOutputTsstControlMemory( f_pApiInstance,
															   pChanEntry->usSoutTsstIndex,

															   1534 );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;
		}

		pChanEntry->usMutedPorts |= cOCT6100_CHANNEL_MUTE_PORT_SOUT;
	}
	else if ( ( f_fMute == FALSE ) 
		&& ( ( f_usPortMask & cOCT6100_CHANNEL_MUTE_PORT_SOUT ) != 0x0 )
		&& ( ( pChanEntry->usMutedPorts & cOCT6100_CHANNEL_MUTE_PORT_SOUT ) != 0x0 ) )
	{
		/* Unmute this port. */

		if ( pChanEntry->usSoutTsstIndex != cOCT6100_INVALID_INDEX )
		{
			ulResult = Oct6100ApiWriteOutputTsstControlMemory( f_pApiInstance,
															   pChanEntry->usSoutTsstIndex,

															   pChanEntry->usSinSoutTsiMemIndex );
			if ( ulResult != cOCT6100_ERR_OK )
				return ulResult;
		}

		pChanEntry->usMutedPorts &= ~cOCT6100_CHANNEL_MUTE_PORT_SOUT;
	}

	/* Sin with features port. */
	if ( ( f_fMute == TRUE )
		&& ( ( f_usPortMask & cOCT6100_CHANNEL_MUTE_PORT_SIN_WITH_FEATURES ) != 0x0 )
		&& ( ( pChanEntry->usMutedPorts & cOCT6100_CHANNEL_MUTE_PORT_SIN_WITH_FEATURES ) == 0x0 ) )
	{
		/* Mute this port. */
		pChanEntry->usMutedPorts |= cOCT6100_CHANNEL_MUTE_PORT_SIN_WITH_FEATURES;
		fEnableSinWithFeatures = TRUE;
	}
	else if ( 
			( ( f_fMute == FALSE ) 
			&& ( ( f_usPortMask & cOCT6100_CHANNEL_MUTE_PORT_SIN_WITH_FEATURES ) != 0x0 )
			&& ( ( pChanEntry->usMutedPorts & cOCT6100_CHANNEL_MUTE_PORT_SIN_WITH_FEATURES ) != 0x0 ) )
		|| 
			( ( f_fMute == TRUE )  
			&& ( ( f_usPortMask & cOCT6100_CHANNEL_MUTE_PORT_SIN ) != 0x0 ) 
			&& ( ( pChanEntry->usMutedPorts & cOCT6100_CHANNEL_MUTE_PORT_SIN_WITH_FEATURES ) != 0x0 ) ) )
	{
		/* Unmute this port. */
		pChanEntry->usMutedPorts &= ~cOCT6100_CHANNEL_MUTE_PORT_SIN_WITH_FEATURES;

		fDisableSinWithFeatures = TRUE;
	}

	/* Check if must enable or disable SIN mute with features. */
	if ( fDisableSinWithFeatures == TRUE || fEnableSinWithFeatures == TRUE )
	{
		ulResult = Oct6100ApiMuteSinWithFeatures( f_pApiInstance, f_usChanIndex, fEnableSinWithFeatures );
		if ( ulResult != cOCT6100_ERR_OK )
			return ulResult;	
	}

	return cOCT6100_ERR_OK;
}



