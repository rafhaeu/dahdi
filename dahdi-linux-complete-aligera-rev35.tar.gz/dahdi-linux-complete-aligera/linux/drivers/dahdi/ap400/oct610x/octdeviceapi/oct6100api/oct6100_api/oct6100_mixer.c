/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

File: oct6100_mixer.c

    Copyright (c) 2001-2017 Octasic Inc. All rights reserved.
    
Description: 

	This file contains the functions used to manage the allocation of mixer
	blocks in memories.

This source code is Octasic Confidential. Use of and access to this code 
is covered by the Octasic Device Enabling Software License Agreement. 
Acknowledgement of the Octasic Device Enabling Software License was 
required for access to this code. A copy was also provided with the release.

$Octasic_Release: OCT610xAPI-01.04.08 $

$Octasic_Revision: 45 $

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/


/*****************************  INCLUDE FILES  *******************************/

#include "octdef.h"

#include "oct6100api/oct6100_defines.h"
#include "oct6100api/oct6100_errors.h"

#include "apilib/octapi_llman.h"

#include "oct6100api/oct6100_apiud.h"
#include "oct6100api/oct6100_tlv_inst.h"
#include "oct6100api/oct6100_chip_open_inst.h"
#include "oct6100api/oct6100_chip_stats_inst.h"
#include "oct6100api/oct6100_interrupts_inst.h"
#include "oct6100api/oct6100_remote_debug_inst.h"
#include "oct6100api/oct6100_debug_inst.h"
#include "oct6100api/oct6100_api_inst.h"
#include "oct6100api/oct6100_channel_inst.h"
#include "oct6100api/oct6100_mixer_inst.h"

#include "oct6100api/oct6100_interrupts_pub.h"
#include "oct6100api/oct6100_chip_open_pub.h"
#include "oct6100api/oct6100_channel_pub.h"


#include "oct6100_chip_open_priv.h"
#include "oct6100_miscellaneous_priv.h"
#include "oct6100_channel_priv.h"
#include "oct6100_mixer_priv.h"

/****************************  PUBLIC FUNCTIONS  ****************************/





/****************************  PRIVATE FUNCTIONS  ****************************/


/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiGetMixerSwSizes

Description:    Gets the sizes of all portions of the API instance pertinent
				to the management of mixer events.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------

f_pOpenChip				User chip configuration.
f_pInstSizes			Pointer to struct containing instance sizes.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiGetMixerSwSizes(
				IN		tPOCT6100_CHIP_OPEN				f_pOpenChip,
				OUT		tPOCT6100_API_INSTANCE_SIZES	f_pInstSizes )
{
	UINT32	ulTempVar;
	UINT32	ulResult;

	/* Calculate the API memory required for the resource entry lists. */
	f_pInstSizes->ulMixerEventList = cOCT6100_MAX_MIXER_EVENTS * sizeof( tOCT6100_API_MIXER_EVENT );

	/* Calculate memory needed for mixers entry allocation. */
	ulResult = OctapiLlmAllocGetSize( cOCT6100_MAX_MIXER_EVENTS, &f_pInstSizes->ulMixerEventAlloc );
	if ( ulResult != cOCT6100_ERR_OK )
		return cOCT6100_ERR_FATAL_1D;

	mOCT6100_ROUND_MEMORY_SIZE( f_pInstSizes->ulMixerEventList, ulTempVar )
	mOCT6100_ROUND_MEMORY_SIZE( f_pInstSizes->ulMixerEventAlloc, ulTempVar )



	return cOCT6100_ERR_OK;
}


/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiMixerSwInit

Description:    Initializes all elements of the instance structure associated
				to the mixer events.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This mixer is used to keep
						the present state of the chip and all its resources.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiMixerSwInit(
				IN OUT	tPOCT6100_INSTANCE_API		f_pApiInstance )
{
	tPOCT6100_SHARED_INFO			pSharedInfo;
	tPOCT6100_API_MIXER_EVENT		pMixerEventList;
	PVOID	pMixerEventAlloc;

	UINT32	ulTempVar;
	UINT32	ulResult;

	/* Get local pointer(s). */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	/*===================================================================*/
	/* Initialize the mixer event list. */
	mOCT6100_GET_MIXER_EVENT_LIST_PNT( pSharedInfo, pMixerEventList );

	/* Initialize the mixer event allocation software to "all free". */
	Oct6100UserMemSet( pMixerEventList, 0x00, cOCT6100_MAX_MIXER_EVENTS * sizeof( tOCT6100_API_MIXER_EVENT ));

	mOCT6100_GET_MIXER_EVENT_ALLOC_PNT( pSharedInfo, pMixerEventAlloc )
	
	ulResult = OctapiLlmAllocInit( &pMixerEventAlloc, cOCT6100_MAX_MIXER_EVENTS );
	if ( ulResult != cOCT6100_ERR_OK )
		return cOCT6100_ERR_FATAL_1F;

	/* Now reserve the first entry as the first node. */
	ulResult = OctapiLlmAllocAlloc( pMixerEventAlloc, &ulTempVar );
	if ( ulResult != cOCT6100_ERR_OK )
	{
		return cOCT6100_ERR_FATAL_20;
	}

	/* Check that we obtain the first event. */
	if ( ulTempVar != 0 )
		return cOCT6100_ERR_FATAL_21;

	/* Now reserve the tail entry. */
	ulResult = OctapiLlmAllocAlloc( pMixerEventAlloc, &ulTempVar );
	if ( ulResult != cOCT6100_ERR_OK )
	{
		return cOCT6100_ERR_FATAL_AA;
	}
	/* Check that we obtain the first event. */
	if ( ulTempVar != 1 )
		return cOCT6100_ERR_FATAL_AB;

	/* Program the head node. */
	pMixerEventList[ cOCT6100_MIXER_HEAD_NODE ].fReserved = TRUE;
	pMixerEventList[ cOCT6100_MIXER_HEAD_NODE ].usNextEventPtr = cOCT6100_MIXER_TAIL_NODE;
	pMixerEventList[ cOCT6100_MIXER_HEAD_NODE ].usEventType = cOCT6100_MIXER_CONTROL_MEM_NO_OP;

	/* Program the tail node. */
	pMixerEventList[ cOCT6100_MIXER_TAIL_NODE ].fReserved = TRUE;
	pMixerEventList[ cOCT6100_MIXER_TAIL_NODE ].usNextEventPtr = cOCT6100_INVALID_INDEX;
	pMixerEventList[ cOCT6100_MIXER_TAIL_NODE ].usEventType = cOCT6100_MIXER_CONTROL_MEM_NO_OP;

	/* Now reserve the entry used for channel recording if the feature is enabled. */
	if ( ( pSharedInfo->ChipConfig.fEnableChannelRecording == TRUE )
		|| ( pSharedInfo->ChipConfig.fAllowDynamicRecording == TRUE ) )
	{
		UINT32 ulAllocIndex;

		/* Reserve an entry to copy the desire SOUT signal to the SIN signal of the recording channel. */
		ulResult = OctapiLlmAllocAlloc( pMixerEventAlloc, &ulAllocIndex );
		if ( ulResult != cOCT6100_ERR_OK )
		{
			return cOCT6100_ERR_FATAL_90;
		}

		pSharedInfo->MixerInfo.usRecordCopyEventIndex = (UINT16)( ulAllocIndex & 0xFFFF );

		/* Reserve an entry to copy the saved SIN signal of the debugged channel into it's original location. */
		ulResult = OctapiLlmAllocAlloc( pMixerEventAlloc, &ulAllocIndex );
		if ( ulResult != cOCT6100_ERR_OK )
		{
			return cOCT6100_ERR_FATAL_90;
		}

		pSharedInfo->MixerInfo.usRecordSinEventIndex = (UINT16)( ulAllocIndex & 0xFFFF );
	
		/* Configure the SIN event. */
		pMixerEventList[ pSharedInfo->MixerInfo.usRecordSinEventIndex ].fReserved = TRUE;
		pMixerEventList[ pSharedInfo->MixerInfo.usRecordSinEventIndex ].usNextEventPtr = cOCT6100_MIXER_TAIL_NODE;
		pMixerEventList[ pSharedInfo->MixerInfo.usRecordSinEventIndex ].usEventType = cOCT6100_MIXER_CONTROL_MEM_NO_OP;

		/* Configure the SOUT copy event. */
		pMixerEventList[ pSharedInfo->MixerInfo.usRecordCopyEventIndex ].fReserved = TRUE;
		pMixerEventList[ pSharedInfo->MixerInfo.usRecordCopyEventIndex ].usNextEventPtr = pSharedInfo->MixerInfo.usRecordSinEventIndex;
		pMixerEventList[ pSharedInfo->MixerInfo.usRecordCopyEventIndex ].usEventType = cOCT6100_MIXER_CONTROL_MEM_NO_OP;
		
		/* Program the head node. */
		pMixerEventList[ cOCT6100_MIXER_HEAD_NODE ].usNextEventPtr = pSharedInfo->MixerInfo.usRecordCopyEventIndex;
	}



	return cOCT6100_ERR_OK;
}


/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiMixerEventAdd

Description:    This function adds a mixer event event to the list of events 
				based on the event type passed to the function.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance				Pointer to API instance. This memory is used to keep 
							the present state of the chip and all its resources.
f_usEventIndex				Index of the event within the API's mixer event list.
f_usEventType				Type of mixer event.
f_usDestinationChanIndex	Index of the destination channel within the API's 
							channel list.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32	Oct6100ApiMixerEventAdd( 
				IN OUT	tPOCT6100_INSTANCE_API			f_pApiInstance,
				IN		UINT16							f_usEventIndex,
				IN		UINT16							f_usEventType,
				IN		UINT16							f_usDestinationChanIndex )
{
	tPOCT6100_SHARED_INFO			pSharedInfo;
	tPOCT6100_API_MIXER_EVENT		pCurrentEventEntry;
	tPOCT6100_API_MIXER_EVENT		pTempEventEntry;
	tPOCT6100_API_CHANNEL			pDestinationEntry;
	tOCT6100_WRITE_PARAMS			WriteParams;
	UINT32	ulResult;
	UINT16	usTempEventIndex;

	/* Obtain local pointer to shared portion of instance. */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	WriteParams.pProcessContext = f_pApiInstance->pProcessContext;

	WriteParams.ulUserChipId = pSharedInfo->ChipConfig.ulUserChipId;

	/* Get a pointer to the event entry. */
	mOCT6100_GET_MIXER_EVENT_ENTRY_PNT( pSharedInfo, pCurrentEventEntry, f_usEventIndex );

	/* Get a pointer to the destination channel entry. */
	mOCT6100_GET_CHANNEL_ENTRY_PNT( pSharedInfo, pDestinationEntry, f_usDestinationChanIndex );

	/* Now proceed according to the event type. */
	switch ( f_usEventType )
	{
	case cOCT6100_EVENT_TYPE_SOUT_COPY:

		/* Now insert the Sin copy event */
		if ( pSharedInfo->MixerInfo.usFirstSoutCopyEventPtr == cOCT6100_INVALID_INDEX )
		{
			/* The only node in the list before the point where the node needs to */
			/* be inserted is the head node. */
			usTempEventIndex = cOCT6100_MIXER_HEAD_NODE;

			/* This node will be the first one in the Sout copy section. */
			pSharedInfo->MixerInfo.usFirstSoutCopyEventPtr = f_usEventIndex;
			pSharedInfo->MixerInfo.usLastSoutCopyEventPtr  = f_usEventIndex;
		}
		else /* pSharedInfo->MixerInfo.usFirstSoutCopyEventPtr != cOCT6100_INVALID_INDEX */
		{
			usTempEventIndex = pSharedInfo->MixerInfo.usLastSoutCopyEventPtr;
			pSharedInfo->MixerInfo.usLastSoutCopyEventPtr  = f_usEventIndex;
		}

		break;

	case cOCT6100_EVENT_TYPE_SIN_COPY:

		/* Now insert the Sin copy event. */
		if ( pSharedInfo->MixerInfo.usFirstSinCopyEventPtr == cOCT6100_INVALID_INDEX )
		{
			/* This is the first Sin copy event. We must find the event that comes before */
			/* the event we want to add. First let's check for a bridge event. */
			if ( pSharedInfo->MixerInfo.usLastBridgeEventPtr == cOCT6100_INVALID_INDEX )
			{
				/* No event in the bridge section, now let's check in the Sout copy section. */
				if ( pSharedInfo->MixerInfo.usLastSoutCopyEventPtr == cOCT6100_INVALID_INDEX )
				{
					/* The only node in the list then is the head node. */
					usTempEventIndex = cOCT6100_MIXER_HEAD_NODE;
				}
				else
				{
					usTempEventIndex = pSharedInfo->MixerInfo.usLastSoutCopyEventPtr;
				}
			}
			else
			{
				usTempEventIndex = pSharedInfo->MixerInfo.usLastBridgeEventPtr;
			}

			/* This node will be the first one in the Sin copy section. */
			pSharedInfo->MixerInfo.usFirstSinCopyEventPtr = f_usEventIndex;
			pSharedInfo->MixerInfo.usLastSinCopyEventPtr  = f_usEventIndex;
		}
		else /* pSharedInfo->MixerInfo.usFirstSinCopyEventPtr != cOCT6100_INVALID_INDEX */
		{
			usTempEventIndex = pSharedInfo->MixerInfo.usLastSinCopyEventPtr;
			pSharedInfo->MixerInfo.usLastSinCopyEventPtr = f_usEventIndex;
		}

		break;

	default:
		return cOCT6100_ERR_FATAL_AF;

	}

	mOCT6100_GET_MIXER_EVENT_ENTRY_PNT( pSharedInfo, pTempEventEntry, usTempEventIndex );

	/*=======================================================================*/
	/* Program the Copy event. */

	/* Set the Copy event first. */
	pCurrentEventEntry->usEventType = cOCT6100_MIXER_CONTROL_MEM_COPY;
	pCurrentEventEntry->usNextEventPtr = pTempEventEntry->usNextEventPtr;

	WriteParams.ulWriteAddress  = cOCT6100_MIXER_CONTROL_MEM_BASE + ( f_usEventIndex * cOCT6100_MIXER_CONTROL_MEM_ENTRY_SIZE );
	WriteParams.ulWriteAddress += 4;
	WriteParams.usWriteData		= pCurrentEventEntry->usNextEventPtr;
	
	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	/*=======================================================================*/

	/*=======================================================================*/
	/* Modify the previous node. */

	/* Set the last Sub-store entry. */
	pTempEventEntry->usNextEventPtr = f_usEventIndex;

	WriteParams.ulWriteAddress  = cOCT6100_MIXER_CONTROL_MEM_BASE + ( usTempEventIndex * cOCT6100_MIXER_CONTROL_MEM_ENTRY_SIZE );
	WriteParams.ulWriteAddress += 4;
	WriteParams.usWriteData		= f_usEventIndex;
	
	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	/*=======================================================================*/	

	/* Save the destination channel index, needed when removing the event from the mixer. */
	pCurrentEventEntry->usDestinationChanIndex = f_usDestinationChanIndex;

	/* Mark the entry as reserved. */
	pCurrentEventEntry->fReserved = TRUE;

	/* Increment the event count on that particular destination channel */
	pDestinationEntry->usMixerEventCnt++;

	return cOCT6100_ERR_OK;
}


/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiMixerEventRemove

Description:    This function removes a mixer event event from the list of events based
				on the event type passed to the function.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.

f_usEventIndex			Index of event within the API's mixer event list.
f_usEventType			Type of mixer event.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiMixerEventRemove( 
				IN OUT	tPOCT6100_INSTANCE_API			f_pApiInstance,
				IN		UINT16							f_usEventIndex,
				IN		UINT16							f_usEventType )
{
	tPOCT6100_SHARED_INFO			pSharedInfo;
	tPOCT6100_API_MIXER_EVENT		pCurrentEventEntry;
	tPOCT6100_API_MIXER_EVENT		pTempEventEntry;
	tPOCT6100_API_CHANNEL			pDestinationEntry;
	tOCT6100_WRITE_BURST_PARAMS		BurstWriteParams;
	tOCT6100_WRITE_PARAMS			WriteParams;
	BOOL	fFirstSinCopyEvent = FALSE;
	UINT32	ulResult;
	UINT16	usTempEventIndex;
	UINT32	ulLoopCount = 0;
	UINT16	ausWriteData[ 4 ] = { 0 };

	/* Obtain local pointer to shared portion of instance. */
	pSharedInfo = f_pApiInstance->pSharedInfo;

	WriteParams.pProcessContext = f_pApiInstance->pProcessContext;

	WriteParams.ulUserChipId = pSharedInfo->ChipConfig.ulUserChipId;

	BurstWriteParams.pProcessContext = f_pApiInstance->pProcessContext;

	BurstWriteParams.ulUserChipId = pSharedInfo->ChipConfig.ulUserChipId;
	BurstWriteParams.pusWriteData = ausWriteData;
	BurstWriteParams.ulWriteLength = 4;

	/* Get a pointer to the event entry. */
	mOCT6100_GET_MIXER_EVENT_ENTRY_PNT( pSharedInfo, pCurrentEventEntry, f_usEventIndex );

	/* Get the pointer to the channel entry. */
	mOCT6100_GET_CHANNEL_ENTRY_PNT( pSharedInfo, pDestinationEntry, pCurrentEventEntry->usDestinationChanIndex );

	/* Now proceed according to the event type. */
	switch ( f_usEventType )
	{
	case cOCT6100_EVENT_TYPE_SOUT_COPY:

		if ( f_usEventIndex == pSharedInfo->MixerInfo.usFirstSoutCopyEventPtr )
		{
			usTempEventIndex = cOCT6100_MIXER_HEAD_NODE;
		}
		else
		{
			/* Now insert the Sin copy event. */
			usTempEventIndex = pSharedInfo->MixerInfo.usFirstSoutCopyEventPtr;
		}

		/* Find the copy entry before the entry to remove. */
		mOCT6100_GET_MIXER_EVENT_ENTRY_PNT( pSharedInfo, pTempEventEntry, usTempEventIndex );

		while( pTempEventEntry->usNextEventPtr != f_usEventIndex )
		{
			usTempEventIndex = pTempEventEntry->usNextEventPtr;

			mOCT6100_GET_MIXER_EVENT_ENTRY_PNT( pSharedInfo, pTempEventEntry, usTempEventIndex );

			ulLoopCount++;
			if ( ulLoopCount == cOCT6100_MAX_LOOP )
				return cOCT6100_ERR_FATAL_B2;
		}

		/*=======================================================================*/
		/* Update the global mixer pointers. */
		if ( f_usEventIndex == pSharedInfo->MixerInfo.usFirstSoutCopyEventPtr )
		{
			if ( f_usEventIndex == pSharedInfo->MixerInfo.usLastSoutCopyEventPtr )
			{
				/* This event was the only of the list.*/
				pSharedInfo->MixerInfo.usFirstSoutCopyEventPtr = cOCT6100_INVALID_INDEX;
				pSharedInfo->MixerInfo.usLastSoutCopyEventPtr  = cOCT6100_INVALID_INDEX;
			}
			else
			{
				pSharedInfo->MixerInfo.usFirstSoutCopyEventPtr = pCurrentEventEntry->usNextEventPtr;
			}
		}
		else if ( f_usEventIndex == pSharedInfo->MixerInfo.usLastSoutCopyEventPtr )
		{
			pSharedInfo->MixerInfo.usLastSoutCopyEventPtr = usTempEventIndex;
		}
		/*=======================================================================*/

		break;


	case cOCT6100_EVENT_TYPE_SIN_COPY:

		if ( f_usEventIndex == pSharedInfo->MixerInfo.usFirstSinCopyEventPtr )
		{
			fFirstSinCopyEvent = TRUE;

			if ( pSharedInfo->MixerInfo.usLastBridgeEventPtr != cOCT6100_INVALID_INDEX )
			{
				usTempEventIndex = pSharedInfo->MixerInfo.usLastBridgeEventPtr;
			}
			else if ( pSharedInfo->MixerInfo.usLastSoutCopyEventPtr != cOCT6100_INVALID_INDEX )
			{
				usTempEventIndex = pSharedInfo->MixerInfo.usLastSoutCopyEventPtr;
			}
			else
			{
				usTempEventIndex = cOCT6100_MIXER_HEAD_NODE;
			}	
		}
		else
		{
			/* Now insert the Sin copy event. */
			usTempEventIndex = pSharedInfo->MixerInfo.usFirstSinCopyEventPtr;
		}

		/* Find the copy entry before the entry to remove. */
		mOCT6100_GET_MIXER_EVENT_ENTRY_PNT( pSharedInfo, pTempEventEntry, usTempEventIndex );
		
		/* If we are not the first event of the Sin copy list. */
		if ( fFirstSinCopyEvent == FALSE )
		{
			while( pTempEventEntry->usNextEventPtr != f_usEventIndex )
			{
				usTempEventIndex = pTempEventEntry->usNextEventPtr;
				mOCT6100_GET_MIXER_EVENT_ENTRY_PNT( pSharedInfo, pTempEventEntry, usTempEventIndex );

				ulLoopCount++;
				if ( ulLoopCount == cOCT6100_MAX_LOOP )
					return cOCT6100_ERR_FATAL_B1;
			}
		}

		/*=======================================================================*/
		/* Update the global mixer pointers. */
		if ( f_usEventIndex == pSharedInfo->MixerInfo.usFirstSinCopyEventPtr )
		{
			if ( f_usEventIndex == pSharedInfo->MixerInfo.usLastSinCopyEventPtr )
			{
				/* This event was the only of the list. */
				pSharedInfo->MixerInfo.usFirstSinCopyEventPtr = cOCT6100_INVALID_INDEX;
				pSharedInfo->MixerInfo.usLastSinCopyEventPtr  = cOCT6100_INVALID_INDEX;
			}
			else
			{
				pSharedInfo->MixerInfo.usFirstSinCopyEventPtr = pCurrentEventEntry->usNextEventPtr;
			}
		}
		else if ( f_usEventIndex == pSharedInfo->MixerInfo.usLastSinCopyEventPtr )
		{
			pSharedInfo->MixerInfo.usLastSinCopyEventPtr = usTempEventIndex;
		}
		/*=======================================================================*/

		break;

	default:
		return cOCT6100_ERR_FATAL_B0;

	}

	/*=======================================================================*/
	/* Modify the previous event. */

	pTempEventEntry->usNextEventPtr = pCurrentEventEntry->usNextEventPtr;

	WriteParams.ulWriteAddress  = cOCT6100_MIXER_CONTROL_MEM_BASE + ( usTempEventIndex * cOCT6100_MIXER_CONTROL_MEM_ENTRY_SIZE );
	WriteParams.ulWriteAddress += 4;
	WriteParams.usWriteData		= pTempEventEntry->usNextEventPtr;
	
	mOCT6100_DRIVER_WRITE_API( WriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	/*=======================================================================*/


	/*=======================================================================*/
	/* Clear the current event. */

	BurstWriteParams.ulWriteAddress  = cOCT6100_MIXER_CONTROL_MEM_BASE + ( f_usEventIndex * cOCT6100_MIXER_CONTROL_MEM_ENTRY_SIZE );
	
	mOCT6100_DRIVER_WRITE_BURST_API( BurstWriteParams, ulResult );
	if ( ulResult != cOCT6100_ERR_OK )
		return ulResult;

	/*=======================================================================*/


	/*=======================================================================*/
	/* Decrement the mixer event count active on that channel. */
	pDestinationEntry->usMixerEventCnt--;

	/*=======================================================================*/

	
	/*=======================================================================*/

	/* This index of this channel is not valid anymore! */
	pCurrentEventEntry->usDestinationChanIndex = cOCT6100_INVALID_INDEX;

	/* Mark this entry as free. */
	pCurrentEventEntry->fReserved = FALSE;

	return cOCT6100_ERR_OK;
}





/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiReserveMixerEventEntry

Description:    Reserves a free entry in the mixer event list.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance		Pointer to API instance. This memory is used to keep the
					present state of the chip and all its resources.

f_pusEventIndex		List entry reserved.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiReserveMixerEventEntry(
				IN OUT	tPOCT6100_INSTANCE_API			f_pApiInstance,
				OUT		PUINT16							f_pusEventIndex )
{
	PVOID	pMixerEventAlloc;
	UINT32	ulResult;
	UINT32	ulEventIndex;

	mOCT6100_GET_MIXER_EVENT_ALLOC_PNT( f_pApiInstance->pSharedInfo, pMixerEventAlloc )

	ulResult = OctapiLlmAllocAlloc( pMixerEventAlloc, &ulEventIndex );
	if ( ulResult != cOCT6100_ERR_OK )
	{
		if ( ulResult == OCTAPI_LLM_NO_STRUCTURES_LEFT )
			return cOCT6100_ERR_MIXER_ALL_MIXER_EVENT_ENTRY_OPENED;
		else
			return cOCT6100_ERR_FATAL_2B;
	}

	*f_pusEventIndex = (UINT16)( ulEventIndex & 0xFFFF );

	return cOCT6100_ERR_OK;
}


/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiReleaseMixerEventEntry

Description:    Release an entry from the mixer event list.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance		Pointer to API instance. This memory is used to keep the
					present state of the chip and all its resources.

f_usEventIndex		List entry reserved.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiReleaseMixerEventEntry(
				IN OUT	tPOCT6100_INSTANCE_API			f_pApiInstance,
				IN		UINT16							f_usEventIndex )
{
	PVOID	pMixerEventAlloc;
	UINT32	ulResult;

	mOCT6100_GET_MIXER_EVENT_ALLOC_PNT( f_pApiInstance->pSharedInfo, pMixerEventAlloc )

	ulResult = OctapiLlmAllocDealloc( pMixerEventAlloc, f_usEventIndex );
	if ( ulResult != cOCT6100_ERR_OK )
		return cOCT6100_ERR_FATAL_2C;

	return cOCT6100_ERR_OK;
}


/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

Function:		Oct6100ApiGetFreeMixerEventCnt

Description:    Retrieve the number of events left in the list.

-------------------------------------------------------------------------------
|	Argument		|	Description
-------------------------------------------------------------------------------
f_pApiInstance			Pointer to API instance. This memory is used to keep the
						present state of the chip and all its resources.

f_pulFreeEventCnt		How many events left.

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
UINT32 Oct6100ApiGetFreeMixerEventCnt(
				IN OUT	tPOCT6100_INSTANCE_API			f_pApiInstance,
				OUT		PUINT32							f_pulFreeEventCnt )
{
	PVOID	pMixerEventAlloc;
	UINT32	ulResult;
	UINT32	ulAllocatedEvents;
	UINT32	ulAvailableEvents;

	mOCT6100_GET_MIXER_EVENT_ALLOC_PNT( f_pApiInstance->pSharedInfo, pMixerEventAlloc )

	ulResult = OctapiLlmAllocInfo( pMixerEventAlloc, &ulAllocatedEvents, &ulAvailableEvents );
	if ( ulResult != cOCT6100_ERR_OK )
		return cOCT6100_ERR_FATAL_E8;

	/* Return number of free events. */
	*f_pulFreeEventCnt = ulAvailableEvents;

	return cOCT6100_ERR_OK;
}



