/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\

File:  oct6100_events_priv.h

    Copyright (c) 2001-2017 Octasic Inc. All rights reserved.
    
Description: 

  	File containing all private defines, macros, structures and prototypes 
	pertaining to the file oct6100_events.c.  All elements defined in this 
	file are for private usage of the API.  All public elements are defined 
	in the oct6100_events_pub.h file.

This source code is Octasic Confidential. Use of and access to this code 
is covered by the Octasic Device Enabling Software License Agreement. 
Acknowledgement of the Octasic Device Enabling Software License was 
required for access to this code. A copy was also provided with the release.

$Octasic_Release: OCT610xAPI-01.04.08 $

$Octasic_Revision: 14 $

\*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

#ifndef __OCT6100_EVENTS_PRIV_H__
#define __OCT6100_EVENTS_PRIV_H__

/*****************************  INCLUDE FILES  *******************************/


/*****************************  DEFINES  *************************************/





/*****************************  TYPES  ***************************************/


/************************** FUNCTION PROTOTYPES  *****************************/

UINT32 Oct6100ApiGetEventsSwSizes(
				IN		tPOCT6100_CHIP_OPEN					f_pOpenChip,
				OUT		tPOCT6100_API_INSTANCE_SIZES		f_pInstSizes );







#endif /* __OCT6100_EVENTS_PRIV_H__ */
