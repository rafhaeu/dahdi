/*
 * AP400 PCI Card Driver
 *
 * Written by Ronaldo Valiati and Wagner Gegler <wagner@aligera.com.br>
 *
 * Based on previous works, designs, and architectures conceived and
 * written by Jim Dixon <jim@lambdatel.com> and Mark Spencer <markster@digium.com>.
 *
 * Copyright (C) 2001 Jim Dixon / Zapata Telephony.
 * Copyright (C) 2001-2005, Digium, Inc.
 *
 * All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/init.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/time.h>
#include <linux/delay.h>
#include <linux/proc_fs.h>
#include <linux/moduleparam.h>
#include <linux/spinlock.h>
#include <dahdi/kernel.h>
#include <dahdi/ap_user.h>
#include "ap400.h"

/* #define AP400_DEBUG */
#ifdef AP400_DEBUG
#define PDEBUG(fmt, args...) { \
	printk(KERN_DEBUG "AP400 (%d): ",__LINE__); \
	printk(fmt "\n", ## args); \
}
#else
#define PDEBUG(fmt, args...)
#endif

#define AP400_DMA

#define AP4_SPAN_MAX	8

#ifdef APEC_OCT_SUPPORT
#define APEC_OCT_SETUP_ONCE
#include "apec_oct.h"
#endif

#define AP400_E1_TEST

/* Workarounds */
#ifndef __iomem
#define __iomem
#endif

/* Define to get more attention-grabbing but slightly more I/O using
   alarm status */
#define FANCY_ALARM

#define DEBUG_MAIN 		(1 << 0)
#define DEBUG_DTMF 		(1 << 1)
#define DEBUG_REGS 		(1 << 2)
#define DEBUG_TSI  		(1 << 3)
#define DEBUG_ECHOCAN 		(1 << 4)
#define DEBUG_RBS 		(1 << 5)
#define DEBUG_FRAMER		(1 << 6)

static int clock_source = -1;
static int tdm_loop = 0;
static int apec_enable = 1;
static int r2_double_answer = 0;
static int send_ais = 0;	/* Force AIS transmission on E1 span
				   bit0: span1, bit1: span2, etc. */

module_param(clock_source, int, 0400);
module_param(tdm_loop, int, 0600);
module_param(apec_enable, int, 0600);
module_param(r2_double_answer, int, 0600);
module_param(send_ais, int, 0600);

/* #define AP4_CYCLES_STATS */
#ifdef AP4_CYCLES_STATS
#include <linux/jiffies.h>
static int rx_mean_cycles = 0;
static int tx_mean_cycles = 0;
module_param(rx_mean_cycles, int, 0600);
module_param(tx_mean_cycles, int, 0600);
static int rx_max_cycles = 0;
static int tx_max_cycles = 0;
module_param(rx_max_cycles, int, 0600);
module_param(tx_max_cycles, int, 0600);
static int rx_min_cycles = 0;
static int tx_min_cycles = 0;
module_param(rx_min_cycles, int, 0600);
module_param(tx_min_cycles, int, 0600);
#define MEAN_CYCLES_SHIFT 8

static int irq_interval_mean_cycles = 0;
module_param(irq_interval_mean_cycles, int, 0600);

static cycles_t last_cycles;

static inline void ap4_update_rx_cycles_stats(cycles_t start)
{
	int irq_interval;
	int cycles = (int) (get_cycles() - start);
	if (cycles > rx_max_cycles)
		rx_max_cycles = cycles;
	if ((cycles < rx_min_cycles) || (rx_min_cycles == 0))
		rx_min_cycles = cycles;
	rx_mean_cycles += (cycles - rx_mean_cycles) >> MEAN_CYCLES_SHIFT;
	irq_interval = (int) (start - last_cycles);
	irq_interval_mean_cycles +=
			(irq_interval - irq_interval_mean_cycles)
			>> MEAN_CYCLES_SHIFT;
	last_cycles = start;
}

static inline void ap4_update_tx_cycles_stats(cycles_t start)
{
	int cycles = (int) (get_cycles() - start);
	if (cycles > tx_max_cycles)
		tx_max_cycles = cycles;
	if ((cycles < tx_min_cycles) || (tx_min_cycles == 0))
		tx_min_cycles = cycles;
	tx_mean_cycles += (cycles - tx_mean_cycles) >> MEAN_CYCLES_SHIFT;
}
#endif

static int debug=0;
static int timingcable;
static int highestorder;
static int loopback = 0;
static int alarmdebounce = 0;

/* Enabling bursting can more efficiently utilize PCI bus bandwidth, but
   can also cause PCI bus starvation, especially in combination with other
   aggressive cards.  Please note that burst mode has no effect on CPU
   utilization / max number of calls / etc. */
static int noburst = 1;
static int debugslips = 0;
static int polling = 0;

#ifdef FANCY_ALARM
static int altab[] = {
	0, 0, 0, 1, 2, 3, 4, 6, 8, 9, 11, 13, 16, 18, 20, 22, 24,
	25, 27, 28, 29, 30, 31, 31, 32, 31, 31, 30, 29, 28, 27, 25,
	23, 22, 20, 18, 16, 13,	11, 9, 8, 6, 4, 3, 2, 1, 0, 0,
};
#endif

#define FLAG_STARTED (1 << 0)
#define FLAG_NMF (1 << 1)
#define FLAG_SENDINGYELLOW (1 << 2)

#define	TYPE_T1	1		/* is a T1 card */
#define	TYPE_E1	2		/* is an E1 card */
#define TYPE_J1 3		/* is a running J1 */

#define AP4_CAS_SYNC_MASK	0xF0
#define AP4_CAS_SYNC_WORD	0x00
#define AP4_CAS_FRAME_WORD	0x0B

/* Number of times span stats will be updated in each second */
#define UPDATE_STATS_RATE	10
/* Period to update span stats in ms */
#define UPDATE_STATS_PERIOD 	(1000 / UPDATE_STATS_RATE)

struct devtype {
	char *desc;
	unsigned int flags;
};

static struct devtype ap401  = { "Aligera AP401", 0 };
static struct devtype ap402  = { "Aligera AP402", 0 };
static struct devtype ap404  = { "Aligera AP404", 0 };
static struct devtype ap408  = { "Aligera AP408", 0 };
static struct devtype ape401  = { "Aligera APE401", 0 };
static struct devtype ape402  = { "Aligera APE402", 0 };
static struct devtype ape404  = { "Aligera APE404", 0 };
static struct devtype ape408  = { "Aligera APE408", 0 };
static struct devtype ape411  = { "Aligera APE411", 0 };

struct ap4;

/* Used to keep track of span status so we can implement the counters, times, etc */
struct ap4_span_status {
	/* will keep a copy here too */
	unsigned int old_status;	/* AP_E1_LOS_STATUS, AP_E1_CAS_STATUS, etc */
	unsigned int seconds;		/* timer count */
	unsigned int losc;		/* LOS seconds timer count */
	unsigned int aisc;		/* AIS seconds timer count */
	unsigned int raic;		/* RAI seconds timer count */
	unsigned int bfaec;		/* BFAE seconds timer count */
	unsigned int mfaec;		/* MFAE seconds timer count */
};

/* Span stats used on driver totals */
struct ap4_span_stats {
	unsigned int seconds;		/* Seconds since last clear */
	unsigned int los_count;		/* Number of times LOS was detected */
	unsigned int los_seconds;	/* Number of seconds while in LOS */
	unsigned int ais_count;		/* Number of times AIS was detected */
	unsigned int ais_seconds;	/* Number of seconds while in AIS */
	unsigned int rai_count;		/* Number of times Remote Alarm Indication was detected */
	unsigned int rai_seconds;	/* Number of seconds while in RAI */
	unsigned int bfae_count;	/* Number of times the frame sync was lost */
	unsigned int bfae_seconds;	/* Number of seconds while not locked */
	unsigned int mfae_count;	/* Number of times the multi-frame sync was lost */
	unsigned int mfae_seconds;	/* Number of seconds while not locked */
	unsigned int cas_count;		/* Number of CAS errors */
};

struct ap4_span {
	struct ap4 *owner;
	unsigned int *writechunk;	/* Dword aligned write memory */
	unsigned int *readchunk;	/* Dword aligned read memory */
	int spantype;	/* card type, T1 or E1 or J1 */
	int sync;
	int psync;
	int alarmtimer;
	int redalarms;
	int alarmcount;
	int spanflags;
	int syncpos;
	int reload_cas;
	int casenable;
	int cassync;
	unsigned char casbuf[32];
	unsigned int slipcount;
	struct dahdi_span span;
	unsigned char txsigs[16];	/* Transmit sigs */
	int loopupcnt;
	int loopdowncnt;
	unsigned char ec_chunk1[31][DAHDI_CHUNKSIZE]; /* first EC chunk */
	unsigned char ec_chunk2[31][DAHDI_CHUNKSIZE]; /* second EC chunk */
	struct dahdi_chan *chans[31];	/* Individual channels */
	struct dahdi_echocan_state ec[31];
	int apec_id;
#ifdef APEC_OCT_SUPPORT
	struct apec_oct *apec_oct;
#endif
	struct semaphore stats_lock;
	struct ap4_span_status status;
	struct ap4_span_stats stats;
	int log_level;
	int send_ais;
};

struct ap4_tdm_errors {
	volatile u8 cv;		/* Code violations */
	volatile u8 crc;	/* CRC errors */
	volatile u8 slip;	/* Slips */
	u8 __unused;
} __attribute__ ((packed));

struct ap4_tdm_regs {
	volatile u8 config;
	volatile u8 status;
	volatile u8 led;
	volatile u8 liu;
	struct ap4_tdm_errors errors;
	u32 __reserved[2];
} __attribute__ ((packed));

struct ap4_regs {
	volatile u32 card_id;		/*  0: 0x00 */
	volatile u16 fpga_ver;		/*  1: 0x04 */
	volatile u16 span_num;		/*  1: 0x06 */
	volatile u32 __unused;		/*  2: 0x08 */
	volatile u32 liu_config;	/*  3: 0x0C */
	volatile u32 e1_config;		/*  4: 0x10 */
	volatile u32 e1_status;		/*  5: 0x14 */
	volatile u32 leds;		/*  6: 0x18 */
	volatile u32 clock_source;	/*  7: 0x1C */
	volatile u32 hw_id;		/*  8: 0x20 */
	volatile u32 irq_config;	/*  9: 0x24 */
	volatile u8 tdm_page;		/* 10: 0x28 */
	volatile u8 tdm_page_num;	/* 10: 0x29 */
	volatile u16 tdm_page_bytes;	/* 10: 0x2A */
	volatile u32 irq_count;		/* 11: 0x2C */
	volatile u32 cvs;		/* 12: 0x30 */
	volatile u32 crc_errors;	/* 13: 0x34 */
	volatile u32 irq_clear;		/* 14: 0x38 */
	volatile u32 slips;		/* 15: 0x3C */
	volatile u32 echo_ctrl;		/* 16: 0x40 */
	volatile u32 echo_data;		/* 17: 0x44 */
	volatile u32 dma_config;	/* 18: 0x48 */
	volatile u32 dma_baseaddr;	/* 19: 0x4C */
	volatile u32 dna_low;		/* 20: 0x50 */
	volatile u32 dna_high;		/* 21: 0x54 */
	volatile u16 spi_data;		/* 22: 0x58 */
	volatile u16 spi_control;	/* 23: 0x5A */
	volatile u32 auth;		/* 24: 0x5C */
	volatile u32 ec_tdm_config;	/* 25: 0x60 */
	volatile u32 __reserved[5];
	volatile u32 ddr_ctrl;		/* 30: 0x78 */
	volatile u32 ddr_data;		/* 31: 0x7C */
	struct ap4_tdm_regs tdm[8];	/* 32: 0x80 */
} __attribute__ ((packed));

struct ap4 {
	/* This structure exists one per card */
	struct pci_dev *dev;		/* Pointer to PCI device */
	struct ap4_regs *hw_regs;
	struct ap4_tdm_regs *tdm_regs;
	unsigned int intcount;
	int flag_1st_irq;
	int num;			/* Which card we are */
	int fpgaver;			/* version of FPGA */
	int hwid;			/* hardware ID */
	int syncsrc;			/* active sync source */
	struct ap4_span *tspans[AP4_SPAN_MAX];	/* Individual spans */
	int numspans;			/* Number of spans on the card */
	int blinktimer[4];
#ifdef FANCY_ALARM
	int alarmpos[4];
#endif
	int irq;			/* IRQ used by device */
	int order;			/* Order */
	int flags;			/* Device flags */
	int ledreg;			/* LED Register */
	int e1recover;			/* E1 recovery timer */
	volatile unsigned int *membase;	/* Base address of card */
	volatile u32 *database;		/* Data base address of card */
	int spansstarted;		/* number of spans started */
	/* spinlock_t lock; */		/* lock context */
	spinlock_t reglock;		/* lock register access */
	spinlock_t  echo_lock;		/* echo lock register access */
	volatile unsigned int *writechunk;	/* Dword aligned write memory */
	volatile unsigned int *readchunk;	/* Dword aligned read memory */
	unsigned int readpage;
	unsigned int writepage;
	unsigned int numpages;
	unsigned int pagebytes;
	unsigned int pagesize;
	unsigned int pageoffset;
	unsigned int passno;	/* number of interrupt passes */
	struct devtype *dt;
	char *variety;
	int last0;		/* for detecting double-missed IRQ */
	int checktiming;	/* Set >0 to check the timing source */
#ifdef AP400_DMA
	int dma_enable;
	dma_addr_t dma_addr;
#endif
#ifdef AP400_E1_TEST
	int e1_test;
	int e1_result[AP4_SPAN_MAX];
#endif
	int apec_detect;
	unsigned int apec_ctrl_mask;
#ifdef APEC_OCT_SUPPORT
	struct apec_oct *apec_oct[2];
#endif
	struct dahdi_device *ddev;
};

static int ap4_startup(struct file *file, struct dahdi_span *span);
static int ap4_shutdown(struct dahdi_span *span);
static int ap4_maint(struct dahdi_span *span, int cmd);
static int ap4_ioctl(struct dahdi_chan *chan, unsigned int cmd,
                     unsigned long data);
static int __ap4_rbsbits(struct dahdi_chan *chan, int bits);
static int ap4_rbsbits(struct dahdi_chan *chan, int bits);
static int ap4_chanconfig(struct file *file, struct dahdi_chan *chan, int sigtype);
static int ap4_open(struct dahdi_chan *chan);
static int ap4_close(struct dahdi_chan *chan);
static void __ap4_set_timing_source(struct ap4 *wc, int unit);
static void __ap4_check_alarms(struct ap4 *wc, int span);
static void __ap4_check_sigbits(struct ap4 *wc, int span);
#ifdef AP400_E1_TEST
static void ap4_e1_test(struct ap4 *wc);
#endif


#define MAX_AP4_CARDS 64

static struct ap4 *cards[MAX_AP4_CARDS];

#define AP4_PCI_DEVICE_ID	0x1004

static inline void __ap4_set_led(struct ap4 *wc, int span, int color)
{
	if (wc->tdm_regs) {
		wc->tdm_regs[span].led = color;
	} else {
		wc->ledreg &= ~(1 << span);
		wc->ledreg |= color << span;
		wc->hw_regs->leds &= ~0x0000000F;
		wc->hw_regs->leds |= (wc->ledreg) & 0x0F;
	}
}

static inline void ap4_irq_enable(struct ap4 *wc) {
	/* Enable interrupt */
	wc->hw_regs->irq_config |= AP_INT_CTL_ENABLE;
}

static inline void ap4_irq_disable(struct ap4 *wc) {
	/* Disable interrupt */
	wc->hw_regs->irq_config &= ~AP_INT_CTL_ENABLE;
}

static inline volatile u32 *ap4_get_page_address(struct ap4 * wc,
                                                 int page,
                                                 int span,
                                                 int chan)
{
	/* Select page */
	unsigned int offset = wc->pageoffset * page;
	/* Select span */
	offset += span * wc->pagesize * 32;
	offset += chan * wc->pagesize;
	return &wc->database[offset];
}

static inline unsigned int ap4_next_read_page(struct ap4 *wc) {
	return wc->readpage = (wc->hw_regs->tdm_page + 1) % 2;
}

static inline unsigned int ap4_next_write_page(struct ap4 *wc) {
	return wc->writepage = (wc->hw_regs->tdm_page + 1) % 2;
}

static inline unsigned int ap4_cas_read(struct ap4 *wc, int span, int caspos)
{
	volatile u32 *caspage = ap4_get_page_address(wc, caspos / 2, span, 16);
	return (unsigned int) caspage[caspos % 2];
}

static inline void ap4_cas_write(struct ap4 *wc, int span, int caspos)
{
	unsigned int *casdata = (unsigned int *) wc->tspans[span]->txsigs;
	volatile u32 *caspage = ap4_get_page_address(wc, caspos / 2, span, 16);
	caspage[caspos % 2] = casdata[caspos % 4];
}

#define APEC_CTRL_RESET_WORD	0xE0000000
#define APEC_CTRL_OCT_DISABLE	0x20000000
#define APEC_CTRL_MOD_PROG	0x40000000
#define APEC_CTRL_EC_ENABLE	0x08000000
#define APEC_CTRL_EC0_ENABLE	0x01000000
#define APEC_CTRL_EC1_ENABLE	0x02000000
#define APEC_CTRL_DAS		0x00080000
#define APEC_CTRL_RD		0x00040000
#define APEC_CTRL_REQ		0x00020000
#define APEC_CTRL_READY		0x00010000
#define APEC_CTRL_ACCESS_MASK	0x000FFFFF

#define APEC_ACCESS_TIMEOUT	100

/* Poll echo machine ready bit until timeout */
static inline void apec_ready_poll(struct ap4 *wc)
{
	int i = APEC_ACCESS_TIMEOUT;

	while ((wc->hw_regs->echo_ctrl & APEC_CTRL_READY) == 0 && i-- > 0)
		udelay(1);
#if 0
	if (i < 0)
		printk(KERN_DEBUG "APEC Timeout!\n");
#endif
}

static inline u32 apec_get_req_mask(struct ap4 *wc, unsigned mod_num)
{
	return wc->apec_ctrl_mask | (mod_num & 0x3) << 20 | APEC_CTRL_REQ;
}

static inline u16 apec_raw_read(struct ap4 *wc, unsigned mod, u16 addr)
{
	unsigned short data;
	/* Write control bits and address */
	wc->hw_regs->echo_ctrl = apec_get_req_mask(wc, mod) | APEC_CTRL_RD | addr;
	/* Poll ready bit */
	apec_ready_poll(wc);
	data = (u16) wc->hw_regs->echo_data;
#if 0
	printk(KERN_DEBUG "APEC Raw Read 0x%04x @ 0x%04x (0x%08x)\n", data, addr, wc->echo_ctrl);
#endif
	return data;
}

static inline void apec_raw_write(struct ap4 *wc, unsigned mod, u16 addr, u16 data)
{
	/* Write data, then control bits and address */
	wc->hw_regs->echo_data = data;
	wc->hw_regs->echo_ctrl = apec_get_req_mask(wc, mod) | addr;
	/* Poll ready bit */
	apec_ready_poll(wc);
#if 0
	printk(KERN_DEBUG "APEC Raw Write 0x%04x @ 0x%04x (0x%08x)\n", data, addr, wc->echo_ctrl);
#endif
}

static u16 apec_mod_read(struct ap4 *wc, unsigned mod, u16 addr)
{
	u16 data;
	spin_lock_bh(&wc->echo_lock);
	data = apec_raw_read(wc, mod, addr);
	spin_unlock_bh(&wc->echo_lock);
	return data;
}

static void apec_mod_write(struct ap4 *wc, unsigned mod, u16 addr, u16 data)
{
	spin_lock_bh(&wc->echo_lock);
	apec_raw_write(wc, mod, addr, data);
	spin_unlock_bh(&wc->echo_lock);
}

static void apec_mod_ddr_write(struct ap4* wc, unsigned mod, u32 addr, u16 *data)
{
	int i;

	spin_lock_bh(&wc->echo_lock);

	/* Write DDR Address */
	apec_raw_write(wc, mod, 0x6, addr & 0xffff);
	apec_raw_write(wc, mod, 0x7, addr >> 16);
	
	/* Write DDR Data */
	for (i = 0; i < 8; i++) {
		apec_raw_write(wc, mod, 0x8 + i, data[i]);
	}
	
	/* Request DDR Write */
	apec_raw_write(wc, mod, 0x5, 0x4);
	
	/* Poll DDR Idle */
	i = APEC_ACCESS_TIMEOUT;
	while (!(apec_raw_read(wc, mod, 0x5) & 0x2) && i-- > 0);
	if (i <= 0)
		printk(KERN_WARNING "APEC DDR write timeout\n");

	spin_unlock_bh(&wc->echo_lock);
}

static void apec_mod_ddr_read(struct ap4* wc, unsigned mod, u32 addr, u16 *data)
{
	int i = APEC_ACCESS_TIMEOUT;

	spin_lock_bh(&wc->echo_lock);

	/* Write DDR Address */
	apec_raw_write(wc, mod, 0x6, addr & 0xffff);
	apec_raw_write(wc, mod, 0x7, addr >> 16);
	
	/* DDR Read Request */
	apec_raw_write(wc, mod, 0x5, 0x8);
	
	/* Poll DDR Idle */
	while (!(apec_raw_read(wc, mod, 0x5) & 0x2) && i-- > 0);
	if (i <= 0) {
		printk(KERN_WARNING "APEC DDR read timeout\n");
		return;
	}
	
	/* Read DDR Data */
	for (i = 0; i < 8; i++) {
		data[i] = apec_raw_read(wc, mod, 0x8 + i);
	}

	spin_unlock_bh(&wc->echo_lock);
}

#ifdef APEC_OCT_SUPPORT

static inline void oct_ext_wait(struct ap4 *wc, unsigned mod)
{
	int i = APEC_ACCESS_TIMEOUT;

	do {
		udelay(1);
	} while ((apec_raw_read(wc, mod, 0x0) & 0x100) && (i-- > 0));

	if (i < 0)
		printk(KERN_WARNING "Wait access request timeout\n");
}

static inline u16 oct_ind_read(struct ap4 *wc, unsigned mod, unsigned int addr)
{
	/* Write extended indirect registers */
	apec_raw_write(wc, mod, 0x8, (addr >> 20) & 0x1FFF);
	apec_raw_write(wc, mod, 0xA, (addr >> 4) & 0xFFFF);
	apec_raw_write(wc, mod, 0x0, ((addr & 0xE) << 8) | 0x101);
	/* Poll access_req bit */
	oct_ext_wait(wc, mod);
	/* Return data */
	return apec_raw_read(wc, mod, 0x4);
}

static inline void oct_ind_write(struct ap4 *wc, unsigned mod, unsigned int addr, unsigned short data)
{
	apec_raw_write(wc, mod, 0x8, (addr >> 20) & 0x1FFF);
	apec_raw_write(wc, mod, 0xA, (addr >> 4) & 0xFFFF);
	apec_raw_write(wc, mod, 0x4, data);
	apec_raw_write(wc, mod, 0x0, ((addr & 0xE) << 8) | 0x3101);
	/* Poll access_req bit */
	oct_ext_wait(wc, mod);
}

static inline u16 oct_dir_read(struct ap4 *wc, unsigned mod, unsigned int addr)
{
	/* Write extended direct registers */
	apec_raw_write(wc, mod, 0x8, (addr >> 20) & 0x1FFF);
	apec_raw_write(wc, mod, 0xA, (addr >> 4) & 0xFFFF);
	apec_raw_write(wc, mod, 0x0, 0x1);
	wc->hw_regs->echo_ctrl = apec_get_req_mask(wc, mod) | APEC_CTRL_DAS |
			APEC_CTRL_RD | (addr & 0xFFFF);
	/* Poll ready bit */
	apec_ready_poll(wc);
	/* Return data */
	return (u16) wc->hw_regs->echo_data & 0xFFFF;
}

static inline void oct_dir_write(struct ap4 *wc, unsigned mod, unsigned int addr, unsigned short data)
{
	/* Write extended direct registers */
	apec_raw_write(wc, mod, 0x8, (addr >> 20) & 0x1FFF);
	apec_raw_write(wc, mod, 0xA, (addr >> 4) & 0xFFFF);
	apec_raw_write(wc, mod, 0x0, 0x3001);
	wc->hw_regs->echo_data = data & 0xFFFF;
	wc->hw_regs->echo_ctrl = apec_get_req_mask(wc, mod) | APEC_CTRL_DAS | (addr & 0xFFFF);
	/* Poll ready bit */
	apec_ready_poll(wc);
}

unsigned int oct_read(void *card, int index, unsigned int addr)
{
	struct ap4 *wc = card;
	unsigned short data;
	spin_lock_bh(&wc->echo_lock);
	data = oct_ind_read(wc, index, addr);
	spin_unlock_bh(&wc->echo_lock);
	PDEBUG("Read 0x%04hX @ 0x%08X", data, addr);
	return data;
}

void oct_write(void *card, int index, unsigned int addr, unsigned int data)
{
	struct ap4 *wc = card;
	unsigned long flags;
	spin_lock_bh(&wc->echo_lock);
	oct_ind_write(wc, index, addr, data);
	spin_unlock_bh(&wc->echo_lock);
	PDEBUG("Write 0x%04hX @ 0x%08X", data, addr);
}

static int ap4_apec_oct_init_one(struct ap4 *wc, int offset)
{
	int laws[AP4_SPAN_MAX];
	int i;
	unsigned int capacity;
	struct firmware embedded_firmware;
	const struct firmware *firmware = &embedded_firmware;
#if !defined(HOTPLUG_FIRMWARE)
	extern void _binary_OCT6104E_32D_ima_size;
	extern u8 _binary_OCT6104E_32D_ima_start[];
	extern void _binary_OCT6104E_64D_ima_size;
	extern u8 _binary_OCT6104E_64D_ima_start[];
	extern void _binary_OCT6104E_128D_ima_size;
	extern u8 _binary_OCT6104E_128D_ima_start[];
#else
	int res;
	static const char oct64_firmware[] = "OCT6104E-32D.ima";
	static const char oct64_firmware[] = "OCT6104E-64D.ima";
	static const char oct128_firmware[] = "OCT6104E-128D.ima";
#endif

	/* Load Octasic Firmware according to module capacity */
	switch (capacity = apec_oct_capacity_get(wc, offset)) {
	case 32:
#if defined(HOTPLUG_FIRMWARE)
		res = request_firmware(&firmware, oct32_firmware,
				&wc->dev->dev);
		if ((res != 0) || !firmware) {
			printk("%s: firmware %s not available from userspace\n",
					wc->variety, oct32_firmware);
			return -1;
		}
#else
		embedded_firmware.data = _binary_OCT6104E_32D_ima_start;
		/* Yes... this is weird. objcopy gives us a symbol containing
		   the size of the firmware, not a pointer to a variable
		   containing the size. The only way we can get the value of
		   the symbol is to take its address, so we define it as a
		   pointer and then cast that value to the proper type.
		*/
		embedded_firmware.size = (size_t) &_binary_OCT6104E_32D_ima_size;
#endif
		break;
	case 64:
#if defined(HOTPLUG_FIRMWARE)
		res = request_firmware(&firmware, oct64_firmware,
				&wc->dev->dev);
		if ((res != 0) || !firmware) {
			printk("%s: firmware %s not available from userspace\n",
					wc->variety, oct64_firmware);
			return -1;
		}
#else
		embedded_firmware.data = _binary_OCT6104E_64D_ima_start;
		/* Yes... this is weird. objcopy gives us a symbol containing
		   the size of the firmware, not a pointer to a variable
		   containing the size. The only way we can get the value of
		   the symbol is to take its address, so we define it as a
		   pointer and then cast that value to the proper type.
		*/
		embedded_firmware.size = (size_t) &_binary_OCT6104E_64D_ima_size;
#endif
		break;
	case 128:
#if defined(HOTPLUG_FIRMWARE)
		res = request_firmware(&firmware, oct128_firmware, &wc->dev->dev);
		if ((res != 0) || !firmware) {
			printk("%s: firmware %s not available from userspace\n",
					wc->variety, oct128_firmware);
			return -1;
		}
#else
		embedded_firmware.data = _binary_OCT6104E_128D_ima_start;
		/* Yes... this is weird. objcopy gives us a symbol containing
		   the size of the firmware, not a pointer to a variable
		   containing the size. The only way we can get the value of
		   the symbol is to take its address, so we define it as a
		   pointer and then cast that value to the proper type.
		*/
		embedded_firmware.size = (size_t)
				&_binary_OCT6104E_128D_ima_size;
#endif
		break;
	default:
		printk(KERN_INFO "Unsupported channel capacity found on echo "
				"cancellation module (%d).\n", capacity);
		return -1;
	}

	/* Initialize Octasic Firmware */
	capacity = capacity / 32;
	wc->apec_oct[offset] = apec_oct_init(wc, offset, capacity, firmware);

	/* Unload Firmware */
	if (firmware != &embedded_firmware)
		release_firmware(firmware);

	/* Check firmware initialization */
	if (!wc->apec_oct[offset]) {
		printk(KERN_WARNING "APEC_OCT%d: Failed to initialize\n", offset);
		return -1;
	}

	/* Enable APEC Octasic */
	for (i = 4 * offset; i < 4 * offset + capacity; ++i) {
		if (wc->tspans[i]) {
			wc->tspans[i]->apec_id = 1;
			wc->tspans[i]->apec_oct = wc->apec_oct[offset];
		}
	}
	wc->apec_ctrl_mask |= (APEC_CTRL_EC0_ENABLE << offset);
	wc->hw_regs->echo_ctrl = wc->apec_ctrl_mask;

	printk(KERN_INFO "APEC_OCT%d: Present and operational servicing "
			"%d span(s)\n", offset, capacity);
	return capacity;
}

#endif /* APEC_OCT_SUPPORT */

#define APEC_MOD_FWID	0x4543

static int ap4_apec_mod_init_one(struct ap4* wc, int mod)
{
	struct firmware firmware;
	extern void _binary_echo_mod_bin_size;
	extern u8 _binary_echo_mod_bin_start[];
	int i;
	int j;
	u16 buf[8];

	/* Load embedded firmware */
	firmware.data = _binary_echo_mod_bin_start;
	/* Yes... this is weird. objcopy gives us a symbol containing
	   the size of the firmware, not a pointer to a variable
	   containing the size. The only way we can get the value of
	   the symbol is to take its address, so we define it as a
	   pointer and then cast that value to the proper type.
	*/
	firmware.size = (size_t) &_binary_echo_mod_bin_size;

	/* Assert PROG_B during 5 ms */
	if (mod == 0) {
		wc->apec_ctrl_mask = APEC_CTRL_OCT_DISABLE;
		wc->hw_regs->echo_ctrl = wc->apec_ctrl_mask | APEC_CTRL_MOD_PROG;
		mdelay(5);
		wc->hw_regs->echo_ctrl = wc->apec_ctrl_mask;
		mdelay(5);
	}

	/* Write FPGA Configuration */
	for (i = 0; i < firmware.size; i += 2) {
		u32 data = *((u16 *) &firmware.data[i]) << 16;
		for (j = 0; j < 16; j++)
			data |= (data >> (2 * j + 1)) & (0x8000 >> j);
		apec_mod_write(wc, mod, 0, (u16) data);
	}

	/* Additional write cycles for startup sequence */
	for (i = 0; i < 32; ++i) {
		apec_mod_write(wc, mod, 0, 0);
	}

	/* Check APEC module */
	buf[0] = apec_mod_read(wc, mod, 0);
	buf[1] = apec_mod_read(wc, mod, 1);
	if (buf[0] != APEC_MOD_FWID) {
		printk(KERN_WARNING "APEC%d: Unknown module ID: 0x%04x/0x%04x\n",
				mod, buf[0], buf[1]);
		return -1;
	}
	printk(KERN_INFO "APEC%d: Found module FW ID: 0x%04x Version: %d.%d\n",
			mod, buf[0], buf[1] >> 8, buf[1] & 0xff);
	printk(KERN_INFO "APEC%d: Echo cancellation for %d channels\n",
			mod, apec_mod_read(wc, mod, 3));

	/* Check APEC access */
	for (i = 0; i < 16; ++i) {
		apec_mod_write(wc, mod, 6, 1 << i);
		buf[0] = apec_mod_read(wc, mod, 6);
		if (1 << i != buf[0]) {
			printk(KERN_WARNING "APEC%d: Access Error! "
					"Write: 0x%04x Read: 0x%04x\n",
					mod, 1 << i, buf[0]);
			return -1;
		}
	}

	/* Wait DDR calibration */
	apec_mod_write(wc, mod, 0x4, 0x2);
	i = 1000000;
	do {
		udelay(1);
		buf[0] = apec_mod_read(wc, mod, 0x4);
	} while (!(buf[0] & 0x1) && --i > 0);

	/* Check DDR Calibration */
	if (buf[0] & 0x1) {
		printk(KERN_INFO "APEC%d: DDR Calibration OK (0x%04x)\n", mod, buf[0]);
	} else {
		printk(KERN_WARNING "APEC%d: DDR Calibration Timeout (0x%04x)\n", mod, buf[0]);
		return -1;
	}

	/* Check APEC DDR integrity */
	for (i = 0; i < 65536; i += 255) {
		for (j = 0; j < 8; j++)
			buf[j] = i;
		apec_mod_ddr_write(wc, mod, i << 4, buf);
	}
	for (i = 0; i < 65536; i += 255) {
		apec_mod_ddr_read(wc, mod, i << 4, buf);
		for (j = 0; j < 8; j++) {
			if (buf[j] != i) {
				printk("APEC%d: DDR integrity failed! "
						"Write %04x%04x%04x%04x%04x%04x%04x%04x "
						"Read %04x%04x%04x%04x%04x%04x%04x%04x @ 0x%08x\n",
						mod, i, i, i, i, i, i, i, i,
						buf[7], buf[6], buf[5], buf[4],
						buf[1], buf[2], buf[3], buf[0], i * 16);
				return -1;
			}
		}
	}

	/* Enable APEC module */
	apec_mod_write(wc, mod, 0x4, 0x6);
	wc->apec_ctrl_mask |= APEC_CTRL_EC_ENABLE | (APEC_CTRL_EC0_ENABLE << mod);
	wc->apec_ctrl_mask |= (APEC_CTRL_EC0_ENABLE << mod);
	wc->hw_regs->echo_ctrl = wc->apec_ctrl_mask;

	/* Set APEC module to spans */
	for (i = 0; i < 4; ++i) {
		if (wc->tspans[i + 4 * mod]) {
			wc->tspans[i + 4 * mod]->apec_id = 3;
		}
	}
	printk(KERN_INFO "APEC%d: Present and operational servicing %d spans\n", mod, i);
}

void ap4_apec_release(struct ap4 *wc)
{
	int i;

	/* Disable APEC Octasic Module */
	wc->hw_regs->echo_ctrl = APEC_CTRL_RESET_WORD;
#ifdef APEC_OCT_SUPPORT
	for (i = 0; i < 2; ++i) {
		if (wc->apec_oct[i])
			apec_oct_release(wc->apec_oct[i]);
	}
#endif
}

static int ap4_apec_init(struct ap4 *wc)
{
	/* Check APEC detection is enabled */
	if (!wc->apec_detect)
		return 0;
	wc->apec_detect = 0;

	/* Initialize APEC Module */
	if ((wc->hw_regs->hw_id & AP_HWID_EC0_MASK) == AP_HWID_EC0_MOD) {
		if (wc->fpgaver < 0x0A00) {
			printk("AP400: Unsupported echo cancellation module\n");
			return -1;
		}
		
		ap4_apec_mod_init_one(wc, 0);
		if (wc->numspans > 4)
			ap4_apec_mod_init_one(wc, 1);
		return 0;
	}

#ifdef APEC_OCT_SUPPORT
	/* Initialize APEC Octasic module */
	wc->hw_regs->echo_ctrl = APEC_CTRL_RESET_WORD;
	udelay(500);
	wc->apec_ctrl_mask = APEC_CTRL_EC_ENABLE;
	wc->hw_regs->echo_ctrl = wc->apec_ctrl_mask;
	
	ap4_apec_oct_init_one(wc, 0);
	if (wc->numspans > 4)
		ap4_apec_oct_init_one(wc, 1);
	
	/* APEC Octasic Module initialized */
	if (wc->apec_oct[0] || wc->apec_oct[1])
		return 0;
#endif

	/* Check for APE411 embedded Echo Canceller */
	if (wc->numspans == 1 && (wc->hw_regs->hw_id & AP_HWID_EC_INT)) {
		printk(KERN_INFO "APEC: Echo cancellation for 31 channels\n");
		wc->hw_regs->echo_ctrl = APEC_CTRL_RESET_WORD | APEC_CTRL_EC_ENABLE;
		printk(KERN_INFO "APEC: Present and operational servicing 1 span\n");
		wc->tspans[0]->apec_id = 2;
		return 0;
	}

	/* Disable APEC, none detected */
	printk(KERN_INFO "%s: No echo cancelation module found for this card\n", wc->variety);
	wc->hw_regs->echo_ctrl = APEC_CTRL_RESET_WORD;

	return -1;
}

static int ap4_echocan_create(struct dahdi_chan *chan,
                              struct dahdi_echocanparams *ecp,
                              struct dahdi_echocanparam *p,
                              struct dahdi_echocan_state **ec);

static void ap4_echocan_free(struct dahdi_chan *chan,
                             struct dahdi_echocan_state *ec);

static const struct dahdi_echocan_features ap4_apec_features = {
	.NLP_automatic = 1,
	.CED_tx_detect = 1,
	.CED_rx_detect = 1,
};

static const struct dahdi_echocan_ops ap4_apec_ops = {
	.echocan_free = ap4_echocan_free,
};

const char *apec_oct_name = "APEC_OCT";
const char *apec_name = "APEC";

static const char *ap4_echocan_name(const struct dahdi_chan *chan)
{
	struct ap4 *wc = chan->pvt;
	struct ap4_span *ts = container_of(chan->span, struct ap4_span, span);

#ifdef APEC_OCT_SUPPORT
	if (ts->apec_oct)
		return apec_oct_name;
#endif

	if (ts->apec_id >= 2)
		return apec_name;

	return NULL;
}

static int ap4_echocan_create(struct dahdi_chan *chan,
                              struct dahdi_echocanparams *ecp,
                              struct dahdi_echocanparam *p,
                              struct dahdi_echocan_state **ec)
{
	struct ap4 *wc = chan->pvt;
	struct ap4_span *ts = container_of(chan->span, struct ap4_span, span);
	int channel;

	if (!ts->apec_id)
		return -ENODEV;

	if (ecp->param_count > 0) {
		printk(KERN_WARNING "%s echo canceller does not support "
				"parameters. Failing request\n",
				ap4_echocan_name(chan));
		return -EINVAL;
	}

	*ec = &ts->ec[chan->chanpos - 1];
	(*ec)->ops = &ap4_apec_ops;
	(*ec)->features = ap4_apec_features;

#ifndef APEC_OCT_SETUP_ONCE
	channel = (chan->chanpos << 2) | (chan->span->offset & 3);
	apec_oct_setec(ts->apec_oct, channel, ecp->tap_length);
#endif

	/* Enable APEC to TDM channel */
	channel = chan->span->offset * 32 + chan->chanpos;
	if (ts->apec_id == 2) {
		wc->hw_regs->ec_tdm_config = channel | 0x670000;
	} else {
		wc->hw_regs->ec_tdm_config = channel | 0x010000;
	}

	/* Enable APEC Mod */
	if (ts->apec_id == 3) {
		apec_mod_write(wc, channel >> 7, (channel & 0x7F) | 0x8000, 0x67);
	}

	if (debug & DEBUG_ECHOCAN)
		printk(KERN_DEBUG "AP400: ap4_echocan @ Span %d Channel %d "
				"Length: %d\n", chan->span->offset,
				chan->chanpos, ecp->tap_length);
	return 0;
}

static void ap4_echocan_free(struct dahdi_chan *chan,
                             struct dahdi_echocan_state *ec)
{
	struct ap4 *wc = chan->pvt;
	struct ap4_span *ts = container_of(chan->span, struct ap4_span, span);
	int channel;

	memset(ec, 0, sizeof(*ec));

#ifndef APEC_OCT_SETUP_ONCE
	if (ts->apec_oct) {
		channel = (chan->chanpos << 2) | (chan->span->offset & 3);
		apec_oct_setec(ts->apec, channel, 0);
	}
#endif

	/* Disable APEC from TDM channel */
	channel = chan->span->offset * 32 + chan->chanpos;
	wc->hw_regs->ec_tdm_config = channel;

	/* Reset APEC Mod */
	if (ts->apec_id == 3) {
		apec_mod_write(wc, channel >> 7, (channel & 0x7F) | 0x8000, 0);
	}
}

#define AP4_SPI_READY	0x0001
#define AP4_SPI_SEL	0x0002

static inline int ap4_spi_data(struct ap4 *wc, char *data)
{
	int timeout = 10000;

	/* Write data to SPI */
	wc->hw_regs->spi_data = *data;

	/* Wait SPI completion */
	while(!(wc->hw_regs->spi_control & AP4_SPI_READY) && timeout >= 0)
		timeout--;

	/* Check if timeout has occurred */
	if (timeout <= 0) {
		printk("SPI access timeout!\n");
		return -1;
	}

	/* Read data from SPI */
	*data = wc->hw_regs->spi_data;

	return 0;
}

static int ap4_ioctl_spi(struct ap4 *wc, unsigned long data)
{
	struct ap_ioctl_spi_cmd cmd;
	int i;

	if (copy_from_user(&cmd, (void *) data, sizeof(cmd)))
		return -EFAULT;

	/* Enable SPI CS */
	wc->hw_regs->spi_control = 0;

	for (i = 0; i < cmd.len; i++) {
		if (ap4_spi_data(wc, &cmd.data[i]))
			return -EIO;
	}

	/* Disable SPI CS */
	wc->hw_regs->spi_control = AP4_SPI_SEL;

	if (copy_to_user((void *) data, &cmd, sizeof(cmd)))
		return -EFAULT;

	return 0;
}

static int ap4_ioctl(struct dahdi_chan *chan,
                     unsigned int cmd,
                     unsigned long data)
{
	struct ap4 *wc = chan->pvt;
	int span = chan->span->offset;
	int alarms = 0;
	unsigned char config, status;
	struct ap_ioctl_hwinfo hw_info;
	struct ap4_ioctl_span_stats span_stats;
	struct ap4_ioctl_log log;

	PDEBUG("AP4_IOCTL: %d", cmd);

	switch(cmd) {
	case AP4_GET_ALARMS:
		/* Read status and configuration from span */
		if (wc->tdm_regs) {
			status = wc->tdm_regs[span].status;
			config = wc->tdm_regs[span].config;
		} else {
			status = wc->hw_regs->e1_status >> (8 * span);
			config = wc->hw_regs->e1_config >> (8 * span);
		}

		if (status & AP_E1_LOS_STATUS) {
			alarms = AP4_ALARM_LOS;
		} else if (status & AP_E1_AIS_STATUS) {
			alarms = AP4_ALARM_AIS;
		} else if (status & AP_E1_BFAE_STATUS) {
			alarms = AP4_ALARM_BFAE;
		} else {
			if (status & AP_E1_RAI_STATUS)
				alarms |= AP4_ALARM_RAI;
			if ((status & AP_E1_MFAE_STATUS) &&
					(config & AP_E1_CRCEN_CONFIG))
				alarms |= AP4_ALARM_MFAE;
			if ((!(status & AP_E1_CAS_STATUS)) &&
					(config & AP_E1_PCM30_CONFIG))
				alarms |= AP4_ALARM_CAS;
		}

		if (debug)
			printk(KERN_DEBUG "AP4_GET_ALARMS: span = %d, "
					"alarms = 0x%02x\n", span+1, alarms);
		PDEBUG("\n");
		if (copy_to_user((int *)data, &alarms, sizeof(int)))
			return -EFAULT;
		PDEBUG("\n");
		break;

	case AP4_GET_SLIPS:
		down_interruptible(&wc->tspans[span]->stats_lock);
		alarms = wc->tspans[span]->slipcount;
		up(&wc->tspans[span]->stats_lock);
		if (debug)
			printk("AP4_GET_SLIPS: span = %d, "
					"slips = 0x%02x\n", span+1, alarms);
		if (copy_to_user((int *)data, &alarms, sizeof(int)))
			return -EFAULT;
		break;

	case AP4_GET_STATS:
		down_interruptible(&wc->tspans[span]->stats_lock);
		span_stats.span = span+1;
		span_stats.seconds = wc->tspans[span]->stats.seconds;
		span_stats.slipcount = wc->tspans[span]->slipcount;
		span_stats.irqmisses = wc->ddev->irqmisses;
		span_stats.los_count = wc->tspans[span]->stats.los_count;
		span_stats.los_seconds = wc->tspans[span]->stats.los_seconds;
		span_stats.ais_count = wc->tspans[span]->stats.ais_count;
		span_stats.ais_seconds = wc->tspans[span]->stats.ais_seconds;
		span_stats.rai_count = wc->tspans[span]->stats.rai_count;
		span_stats.rai_seconds = wc->tspans[span]->stats.rai_seconds;
		span_stats.bfae_count = wc->tspans[span]->stats.bfae_count;
		span_stats.bfae_seconds = wc->tspans[span]->stats.bfae_seconds;
		span_stats.mfae_count = wc->tspans[span]->stats.mfae_count;
		span_stats.mfae_seconds = wc->tspans[span]->stats.mfae_seconds;
		span_stats.crc_count = wc->tspans[span]->span.count.crc4;
		span_stats.bpv_count = wc->tspans[span]->span.count.bpv;
		span_stats.cas_count = wc->tspans[span]->stats.cas_count;

		up(&wc->tspans[span]->stats_lock);

		if (copy_to_user((struct ap4_ioctl_span_stats*)data,
				&span_stats, sizeof(struct ap4_ioctl_span_stats)))
			return -EFAULT;
		break;

	case AP4_RESET_STATS:
		down_interruptible(&wc->tspans[span]->stats_lock);

		memset(&wc->tspans[span]->stats, '\0', sizeof(struct ap4_span_stats));
		memset(&wc->tspans[span]->status, '\0', sizeof(struct ap4_span_status));

		wc->tspans[span]->slipcount = 0;
		wc->ddev->irqmisses = 0;
		wc->tspans[span]->span.count.crc4 = 0;
		wc->tspans[span]->span.count.bpv = 0;

		up(&wc->tspans[span]->stats_lock);

		break;

	case AP_GET_HWINFO:
		memset(&hw_info, '\0', sizeof(struct ap_ioctl_hwinfo));
		hw_info.fpga_major = wc->fpgaver >> 8;
		hw_info.fpga_minor = wc->fpgaver & 0xFF;
		hw_info.irq = wc->irq;
		strncpy(hw_info.prod_name, wc->variety, 31);
		hw_info.dna_low = wc->hw_regs->dna_low;
		hw_info.dna_high = wc->hw_regs->dna_high;

		if (copy_to_user((struct ap_ioctl_hwinfo*) data,
				&hw_info, sizeof(struct ap_ioctl_hwinfo)))
			return -EFAULT;

		break;

	case AP4_GET_CONFIG:
		/* Read status and configuration from span */
		if (wc->tdm_regs) {
			status = wc->tdm_regs[span].status;
			config = wc->tdm_regs[span].config;
		} else {
			status = wc->hw_regs->e1_status >> (8 * span);
			config = wc->hw_regs->e1_config >> (8 * span);
		}

		if (config & AP_E1_CRCEN_CONFIG)
			alarms |= AP4_CONFIG_CRC4;

		if (wc->database) { /* new FW version */
			if (wc->tspans[span]->casenable)
				alarms |= AP4_CONFIG_PCM30;
		} else {
			if (config & AP_E1_PCM30_CONFIG)
				alarms |= AP4_CONFIG_PCM30;
		}
#ifdef APEC_OCT_SUPPORT
		if (span < 4 && wc->apec_oct[0])
			alarms |= AP4_CONFIG_ECHO;

		if (span >= 4 && wc->apec_oct[1])
			alarms |= AP4_CONFIG_ECHO;
#endif
		if (debug)
			printk(KERN_DEBUG "AP4_GET_CONFIG: span = %d, "
					"config = 0x%02x\n", span+1, config);
		if (copy_to_user((int *)data, &alarms, sizeof(int)))
			return -EFAULT;
		break;

	case AP4_GET_LOGLEVEL:
		log.level = wc->tspans[span]->log_level;
		if (copy_to_user((int *)data, &log, sizeof(struct ap4_ioctl_log)))
			return -EFAULT;
		break;

	case AP4_SET_LOGLEVEL:
		if (copy_from_user(&log, (struct ap4_ioctl_log*) data,
				sizeof(struct ap4_ioctl_log)))
			return -EFAULT;
		if( log.level < AP400_LOGLEVEL_min || log.level > AP400_LOGLEVEL_max )
			return -ENOTTY;

		wc->tspans[span]->log_level = log.level;

		break;

	case AP_IOC_SPI:
		if (wc->fpgaver >= 0x0802)
			return ap4_ioctl_spi(wc, data);
		return -ENOTTY;

	case AP_FPGA_PROG:
		if (wc->fpgaver <= 0x0805)
			return -ENOTTY;
		/* Disable IRQ and DMA before reloading FPGA Program */
		ap4_irq_disable(wc);
		free_irq(wc->dev->irq, wc);
		wc->dev->irq = 0;
		wc->hw_regs->dma_config = 0;
		wc->hw_regs->spi_control = 0x8000;
		printk("SPI CTRL: %04x\n", wc->hw_regs->spi_control);
		return 0;
	
	default:
		PDEBUG("%s: Unknown IOCTL CODE (0x%8X!", wc->variety, cmd);
		return -ENOTTY;
	}
	return 0;
}

static int ap4_maint(struct dahdi_span *span, int cmd)
{
	struct ap4_span *ts = container_of(span, struct ap4_span, span);
	struct ap4 *wc = ts->owner;

	PDEBUG("AP4_MAINT %d", cmd);
	switch(cmd) {
	case DAHDI_MAINT_NONE:
		printk(KERN_INFO "%s: Turn off local and remote loops on E1"
				"#%d\n", wc->variety, span->spanno);
		if (wc->tdm_regs)
			wc->tdm_regs[span->offset].config &= ~AP_E1_LOOP_CONFIG;
		else
			wc->hw_regs->e1_config &= ~(AP_E1_LOOP_CONFIG <<
					(span->offset * 8));
		break;
	case DAHDI_MAINT_LOCALLOOP:
	case DAHDI_MAINT_REMOTELOOP:
	case DAHDI_MAINT_LOOPUP:
	case DAHDI_MAINT_LOOPDOWN:
		printk(KERN_INFO "%s: Turn on local and remote loops on E1"
				"#%d\n", wc->variety, span->spanno);
		if (wc->tdm_regs)
			wc->tdm_regs[span->offset].config |= AP_E1_LOOP_CONFIG;
		else
			wc->hw_regs->e1_config |=
					AP_E1_LOOP_CONFIG << (span->offset * 8);
		break;
	default:
		printk("%s: Unknown E1 maint command: %d\n", wc->variety, cmd);
		break;
	}
	return 0;
}

static int ap4_rbsbits(struct dahdi_chan *chan, int bits)
{
	struct ap4 *wc = chan->pvt;
	unsigned long flags;
	int res;
	spin_lock_irqsave(&wc->reglock, flags);
	res = __ap4_rbsbits(chan, bits);
	spin_unlock_irqrestore(&wc->reglock, flags);
	return res;
}

static int __ap4_rbsbits(struct dahdi_chan *chan, int bits)
{
	u_char m,c;
	int k,n,b;
	struct ap4 *wc = chan->pvt;
	struct ap4_span *ts = container_of(chan->span, struct ap4_span, span);
	volatile unsigned int *writecas;
	unsigned int allspansbits;

	if (debug & DEBUG_RBS)
		printk(KERN_DEBUG "Setting bits to %d on channel %s\n",
				bits, chan->name);

	if (wc->database) {
		if (ts->spantype != TYPE_E1)
			return 0;
		if (chan->chanpos < 1 || chan->chanpos > 32)
			return 0;
		if (chan->chanpos < 16) {
			ts->txsigs[chan->chanpos] &= 0x0F;
			ts->txsigs[chan->chanpos] |= (bits & 0x0F) << 4;
		} else {
			ts->txsigs[chan->chanpos % 16] &= 0xF0;
			ts->txsigs[chan->chanpos % 16] |= bits & 0x0F;
		}
		ap4_cas_write(wc, chan->span->offset, (chan->chanpos % 16) / 4);
	} else {
		writecas =  wc->membase + AP_CAS_BASE;

		k = chan->span->offset;
		if (chan->chanpos == 16)
			return 0;
		n = chan->chanpos - 1;
		if (chan->chanpos > 15)
			n--;
		b = (n % 15);
		c = ts->txsigs[b];
		m = (n / 15) << 2; /* nibble selector */
		c &= (0xf << m); /* keep the other nibble */
		c |= (bits & 0xf) << (4 - m); /* put our new nibble here */
		ts->txsigs[b] = c;
		/* Concatenate signalling Dword for 4 spans */
		allspansbits =  wc->tspans[0]->txsigs[b];
		if (wc->numspans > 1) {
			allspansbits |=	(wc->tspans[1]->txsigs[b] << 8);
		}
		if (wc->numspans == 4) {
			allspansbits |=	(wc->tspans[2]->txsigs[b] << 16) |
					(wc->tspans[3]->txsigs[b] << 24);
		}
		/* output them to the chip */
		writecas[b] = allspansbits;
	}
	if (debug & DEBUG_RBS)
		printk(KERN_DEBUG "Finished setting RBS bits\n");
	return 0;
}

static int ap4_shutdown(struct dahdi_span *span)
{
	int tspan;
	int wasrunning;
	unsigned long flags;
	struct ap4_span *ts = container_of(span, struct ap4_span, span);
	struct ap4 *wc = ts->owner;
	int i;
	int running;

	tspan = span->offset + 1;
	if (tspan < 0) {
		printk("%s: '%d' isn't us?\n", wc->variety, span->spanno);
		return -1;
	}

	spin_lock_irqsave(&wc->reglock, flags);
	wasrunning = span->flags & DAHDI_FLAG_RUNNING;

	span->flags &= ~DAHDI_FLAG_RUNNING;
	if (wasrunning)
		wc->spansstarted--;
	/* Turn off LED from interface */
	__ap4_set_led(wc, span->offset, AP4_LED_OFF);
	if (wc->tdm_regs)
		wc->tdm_regs[span->offset].config = AP_E1_RESET_CONFIG;

	/* Test if are there any other spans running */
	running = 0;
	for (i = 0; i < wc->numspans; ++i) {
		running |= wc->tspans[i]->span.flags & DAHDI_FLAG_RUNNING;
	}

	/* Disable interrupts or re-check timing source */
	if (!running) {
		printk(KERN_NOTICE "%s: Disabling interrupts since there are "
				"no active spans\n", wc->variety);
		ap4_irq_disable(wc);
	} else
		wc->checktiming = 1;

	spin_unlock_irqrestore(&wc->reglock, flags);

	if (debug & DEBUG_MAIN)
		printk(KERN_DEBUG "Span %d (%s) shutdown\n", span->spanno,
				span->name);
	return 0;
}

static int ap4_spanconfig(struct file *file,
                          struct dahdi_span *span,
                          struct dahdi_lineconfig *lc)
{
	int i;
	struct ap4_span *ts = container_of(span, struct ap4_span, span);
	struct ap4 *wc = ts->owner;
	unsigned int temp;

	printk(KERN_INFO "About to enter spanconfig!\n");
	if (debug & DEBUG_MAIN)
		printk(KERN_DEBUG "%s: Configuring span %d\n", wc->variety,
				span->spanno);
	/* XXX We assume lineconfig is okay and shouldn't XXX */
	span->lineconfig = lc->lineconfig;
	span->txlevel = lc->lbo;
	span->rxlevel = 0;
	if (lc->sync < 0)
		lc->sync = 0;
	if (lc->sync > wc->numspans)
		lc->sync = 0;

	/* remove this span number from the current sync sources, if there */
	for(i = 0; i < wc->numspans; i++) {
		if (wc->tspans[i]->sync == span->spanno) {
			wc->tspans[i]->sync = 0;
			wc->tspans[i]->psync = 0;
		}
	}
	wc->tspans[span->offset]->syncpos = lc->sync;
	/* if a sync src, put it in proper place */
	if (lc->sync) {
		wc->tspans[lc->sync - 1]->sync = span->spanno;
		wc->tspans[lc->sync - 1]->psync = span->offset + 1;
	}
	wc->checktiming = 1;
	/* If we're already running, then go ahead and apply the changes */
	if (span->flags & DAHDI_FLAG_RUNNING)
		return ap4_startup(file, span);

	if (apec_enable)
		ap4_apec_init(wc);

	/* Clear error registers */
	if (wc->tdm_regs) {
		temp = readl((u32 *) &wc->tdm_regs->errors);
	} else {
		temp = wc->hw_regs->slips;
		temp = wc->hw_regs->crc_errors;
		temp = wc->hw_regs->cvs;
	}

	printk(KERN_INFO "Done with spanconfig!\n");
	return 0;
}

static int ap4_chanconfig(struct file *file,
                          struct dahdi_chan *chan,
                          int sigtype)
{
	struct ap4 *wc = chan->pvt;
	struct ap4_span *ts = container_of(chan->span, struct ap4_span, span);

#ifdef APEC_OCT_SETUP_ONCE
	/* Enable APEC only on audio channels */
	if ((sigtype & DAHDI_SIG_HDLCRAW) != DAHDI_SIG_HDLCRAW && ts->apec_oct) {
		int channel = (chan->chanpos << 2) | (chan->span->offset & 3);
		apec_oct_setec(ts->apec_oct, channel, 0);
		apec_oct_setec(ts->apec_oct, channel, 1);
	}
#endif

	PDEBUG("AP4_chanconfig on channel %d", chan->chanpos);
	if (debug & DEBUG_MAIN) {
		if (ts->span.flags & DAHDI_FLAG_RUNNING)
			printk(KERN_DEBUG "%s: Reconfigured channel %d (%s) "
					"sigtype %d\n", wc->variety,
					chan->channo, chan->name, sigtype);
		else
			printk(KERN_DEBUG "%s: Configured channel %d (%s) "
					"sigtype %d\n", wc->variety,
					chan->channo, chan->name, sigtype);
	}
	return 0;
}

static int ap4_open(struct dahdi_chan *chan)
{
	try_module_get(THIS_MODULE);
	return 0;
}

static int ap4_close(struct dahdi_chan *chan)
{
	module_put(THIS_MODULE);
	return 0;
}

static const struct dahdi_span_ops ap4_span_ops = {
	.owner = THIS_MODULE,
	.spanconfig = ap4_spanconfig,
	.chanconfig = ap4_chanconfig,
	.startup = ap4_startup,
	.shutdown = ap4_shutdown,
	.rbsbits = ap4_rbsbits,
	.maint = ap4_maint,
	.open = ap4_open,
	.close  = ap4_close,
	.ioctl = ap4_ioctl,
	.echocan_create = ap4_echocan_create,
	.echocan_name = ap4_echocan_name,
};

static void ap4_init_spans(struct ap4 *wc)
{
	int i, j;
	struct ap4_span *ts;

	for (i = 0; i < wc->numspans; i++) {
		ts = wc->tspans[i];
		snprintf(ts->span.name, sizeof(ts->span.name) - 1,
				"AP4%d%d/%d/%d", 0, wc->numspans,
				wc->num + 1, i + 1);
		snprintf(ts->span.desc, sizeof(ts->span.desc) - 1,
				 "AP4%d%d Card %d Span %d",
				 0, wc->numspans, wc->num + 1, i + 1);
		ts->span.ops = &ap4_span_ops;
		ts->span.channels = 31;
		ts->span.deflaw = DAHDI_LAW_ALAW;
		ts->span.spantype = SPANTYPE_DIGITAL_E1;
		ts->span.chans = ts->chans;
		ts->span.flags = DAHDI_FLAG_RBS;
		ts->span.linecompat = DAHDI_CONFIG_HDB3 | DAHDI_CONFIG_CCS |
				DAHDI_CONFIG_CRC4 | DAHDI_CONFIG_AMI;
		ts->owner = wc;
		ts->span.offset = i;
		ts->writechunk = (void *)(wc->writechunk + i * 32 * 2);
		ts->readchunk = (void *)(wc->readchunk + i * 32 * 2);
		for (j = 0; j < wc->tspans[i]->span.channels; j++) {
			struct dahdi_chan *chan = ts->chans[j];
			sprintf(chan->name, "AP4%d%d/%d/%d/%d", 0,
					wc->numspans, wc->num, i + 1, j + 1);
			chan->sigcap = DAHDI_SIG_EM | DAHDI_SIG_CLEAR |
					DAHDI_SIG_FXSLS | DAHDI_SIG_FXSGS |
					DAHDI_SIG_FXSKS | DAHDI_SIG_FXOLS |
					DAHDI_SIG_FXOGS | DAHDI_SIG_FXOKS |
					DAHDI_SIG_CAS | DAHDI_SIG_EM_E1 |
					DAHDI_SIG_DACS_RBS | DAHDI_SIG_MTP2;
			chan->pvt = wc;
			chan->chanpos = j + 1;
			chan->writechunk = ((void *) ts->writechunk) +
					(j + 1) * 8;
			chan->readchunk = ((void *) ts->readchunk) +
					(j + 1) * 8;
		}
		sema_init(&ts->stats_lock, 1);
		list_add_tail(&ts->span.device_node, &wc->ddev->spans);
	}
	printk("%s: Spans initialized\n", wc->variety);
}

static void __ap4_set_timing_source(struct ap4 *wc, int unit)
{
	int i;

	if (unit != wc->syncsrc) {
		if ((unit > 0) && (unit <= wc->numspans)) {
			/* Set clock source to span select by unit */
			wc->hw_regs->clock_source = unit;
		} else {
			/* Set clock to internal */
			wc->hw_regs->clock_source = 0;
		}
		if ((unit < 0) || (unit > wc->numspans))
			unit = 0;
		wc->syncsrc = unit;
		for (i = 0; i < wc->numspans; i++)
			wc->tspans[i]->span.syncsrc = unit;
	} else {
		if (debug & DEBUG_MAIN)
			printk(KERN_DEBUG "%s: Timing source already set to "
					"%d\n", wc->variety, unit);
	}
	if (debug)
		printk("%s: Timing source set to %d (clksrc_reg = 0x%08x)\n",
			wc->variety, unit, wc->hw_regs->clock_source);
}

static void __ap4_set_timing_source_auto(struct ap4 *wc)
{
	int i;
	struct ap4_span *tsync;
	int alarms;

	wc->checktiming = 0;
	for (i = 0; i < wc->numspans; i++) {
		if (wc->tspans[i]->sync) {
			tsync = wc->tspans[wc->tspans[i]->psync - 1];
			alarms = tsync->span.alarms;
			/* Check if it is running */
			if (!(tsync->span.flags & DAHDI_FLAG_RUNNING))
				continue;
			/* Check alarms */
			if (alarms & (DAHDI_ALARM_RED | DAHDI_ALARM_BLUE))
				continue;
			/* If span is running and has no alarms,
			   then is valid timing source */
			__ap4_set_timing_source(wc, wc->tspans[i]->psync);
			return;
		}
	}
	__ap4_set_timing_source(wc, 0);
}

static void __ap4_configure_e1(struct ap4 *wc, int unit, int lineconfig)
{
	char *crc4 = "";
	char *framing, *line;
	unsigned int config = 0;
	unsigned int param = 0;
	unsigned int linecode = 0;

	wc->tspans[unit]->spantype = TYPE_E1;
	wc->tspans[unit]->span.channels = 31;
	wc->tspans[unit]->span.deflaw = DAHDI_LAW_ALAW;
	wc->tspans[unit]->span.spantype = SPANTYPE_DIGITAL_E1;

	/* Frame configuration */
	param = AP_E1_FRAME_CONFIG;
	if (lineconfig & DAHDI_CONFIG_CCS) {
		framing = "CCS";
		wc->tspans[unit]->casenable = 0;
	} else {
		framing = "CAS";
		param |= AP_E1_CASEN_CONFIG | AP_E1_PCM30_CONFIG;
		wc->tspans[unit]->txsigs[0] = AP4_CAS_FRAME_WORD;
		wc->tspans[unit]->cassync = -1;
		wc->tspans[unit]->casenable = 1;
	}

	if (lineconfig & DAHDI_CONFIG_CRC4) {
		crc4 = "/CRC4";
		param |= AP_E1_CRCEN_CONFIG;
	}

	if (wc->tdm_regs) {
		wc->tdm_regs[unit].config = param;
	} else {
		config = wc->hw_regs->e1_config;
		config &= ~(0x000000ff << (8 * unit));
		config |= (param << (8 * unit));
		wc->hw_regs->e1_config = config;
	}

	/* Line interface Configuration */
	if (unit < 2)
		linecode = AP_LIU1_LINECODE;
	else
		linecode = AP_LIU2_LINECODE;

	if (lineconfig & DAHDI_CONFIG_AMI) {
		wc->hw_regs->leds |= linecode;
		line = "AMI";
	} else {
		wc->hw_regs->leds &= ~linecode;
		line = "HDB3";
	}

	/* Configure LIU Signaling for E1 */
	config = wc->hw_regs->liu_config;
	config &= ~(0x000000ff << (8 * unit));
	config |= (AP_PULS_E1_120 << (8 * unit));
	wc->hw_regs->liu_config = config;

	if (!polling) {
		__ap4_check_alarms(wc, unit);
		__ap4_check_sigbits(wc, unit);
	}
	printk(KERN_NOTICE "%s: Span %d configured for %s/%s%s\n",
			wc->variety, unit + 1, framing, line, crc4);
}

static int ap4_startup(struct file *file, struct dahdi_span *span)
{
	int i;
	int tspan;
	unsigned long flags;
	int alreadyrunning;
	struct ap4_span *ts = container_of(span, struct ap4_span, span);
	struct ap4 *wc = ts->owner;
	unsigned int temp;

	printk(KERN_INFO "About to enter startup!\n");
	tspan = span->offset + 1;
	if (tspan < 0) {
		printk("%s: Span '%d' isn't us?\n", wc->variety, span->spanno);
		return -1;
	}

	spin_lock_irqsave(&wc->reglock, flags);

	alreadyrunning = span->flags & DAHDI_FLAG_RUNNING;

	/* initialize the start value for the entire chunk of last ec buffer */
	for(i = 0; i < span->channels; i++) {
		memset(ts->ec_chunk1[i],
			DAHDI_LIN2X(0, span->chans[i]), DAHDI_CHUNKSIZE);
		memset(ts->ec_chunk2[i],
			DAHDI_LIN2X(0, span->chans[i]), DAHDI_CHUNKSIZE);
	}

	/* Force re-evaluation of timing source */
	wc->syncsrc = -1;

	if ((span->lineconfig & DAHDI_CONFIG_D4) ||
			(span->lineconfig & DAHDI_CONFIG_ESF)) {
		/* T1 configuration */
		printk("%s: T1 is not supported on this card\n", wc->variety);
		return -1;
	} else { /* E1 configuration */
		__ap4_configure_e1(wc, span->offset, span->lineconfig);
	}

	if (!alreadyrunning) {
		span->flags |= DAHDI_FLAG_RUNNING;
		if (!wc->spansstarted) {
			/* Enable interrupt */
			ap4_irq_enable(wc);
			/* Disregard first IRQ misses */
			wc->flag_1st_irq = 16;
			/* Clear IRQ status */
			temp = wc->hw_regs->irq_clear;
		}
		wc->spansstarted++;
		if (!polling) {
			__ap4_check_alarms(wc, span->offset);
			__ap4_check_sigbits(wc, span->offset);
		}
	}
	spin_unlock_irqrestore(&wc->reglock, flags);

#if 1
	for (i = 0; i < wc->numspans; ++i) {
		if (wc->tspans[i]->sync == span->spanno)
			printk("SPAN %d: Sync Source %d\n",
					span->spanno, i + 1);
	}
#else
	if (wc->tspans[0]->sync == span->spanno)
		printk("SPAN %d: Primary Sync Source\n", span->spanno);
	if (wc->numspans == 2  && wc->tspans[1]->sync == span->spanno)
		printk("SPAN %d: Secondary Sync Source\n", span->spanno);
	if (wc->numspans == 4) {
		if (wc->tspans[2]->sync == span->spanno)
			printk("SPAN %d: Tertiary Sync Source\n", span->spanno);
		if (wc->tspans[3]->sync == span->spanno)
			printk("SPAN %d: Quaternary Sync Source\n",
					span->spanno);
	}
	if (wc->numspans == 8) {
		if (wc->tspans[4]->sync == span->spanno)
			printk("SPAN %d: Quinary Sync Source\n", span->spanno);
		if (wc->tspans[5]->sync == span->spanno)
			printk("SPAN %d: Senary Sync Source\n", span->spanno);
		if (wc->tspans[6]->sync == span->spanno)
			printk("SPAN %d: Septenary Sync Source\n",
					span->spanno);
		if (wc->tspans[7]->sync == span->spanno)
			printk("SPAN %d: Octonary Sync Source\n", span->spanno);
	}
#endif

	printk(KERN_INFO "Completed startup!\n");
	return 0;
}

static inline void ap4_handle_dma(struct ap4 *wc)
{
	int i;
	struct ap4_span *ts;
	int offset;

	if (wc->hw_regs->dma_config & AP4_DMA_ERROR) {
		/* Check DMA error */
		printk(KERN_WARNING "%s: DMA Error! Restarting...\n",
						wc->variety);
		wc->hw_regs->dma_config |= AP4_DMA_RESET;
		return;
	}

#ifdef AP400_E1_TEST
	if (tdm_loop < 0) {
		/* E1 Test */
		ap4_e1_test(wc);
		return;
	} else
#endif
	if (tdm_loop) {
		/* Loop */
		memcpy((void *) wc->writechunk, (void *) wc->readchunk,
				wc->pageoffset * 4);
		return;
	}

	for (i = 0; i < wc->numspans; i++) {
		ts = wc->tspans[i];
		/* Receive / Transmit */
		if (ts->span.flags & DAHDI_FLAG_RUNNING) {
			dahdi_ec_span(&wc->tspans[i]->span);
			dahdi_receive(&wc->tspans[i]->span);
			dahdi_transmit(&wc->tspans[i]->span);
		}
		/* Handle CAS */
		offset = (wc->intcount % 2) * 8;
		if (wc->tspans[i]->casenable) {
			/* Read CAS */
			memcpy(ts->casbuf + offset,
					ts->chans[15]->readchunk, 8);
			/* Write CAS */
			memcpy(ts->chans[15]->writechunk,
					wc->tspans[i]->txsigs + offset, 8);
		}
	}
}

static inline void ap4_receiveprep(struct ap4 *wc)
{
#ifdef AP4_CYCLES_STATS
	cycles_t start = get_cycles();
#endif
	volatile unsigned int *readdata;
	unsigned int buffer[32];
	unsigned char *byte = (unsigned char *) buffer;
	int i, j, k;
	struct ap4_span *ts;
	struct dahdi_chan *chan;

	if (wc->database) { /* New way */
		/* Update read page number */
		wc->readpage = ap4_next_read_page(wc);
		for (i = 0; i < wc->numspans; ++i) {
			/* Get read page address from channel 1 from each span */
			readdata = ap4_get_page_address(wc, wc->readpage, i, 1);
			ts = wc->tspans[i];
			/* Read data only from opened channel on running span */
			if (!(ts->span.flags & DAHDI_FLAG_RUNNING))
				continue;
			for (j = 0; j < ts->span.channels; ++j) {
				chan = ts->span.chans[j];
				if (chan->flags & DAHDI_FLAG_OPEN)
					memcpy_fromio(chan->readchunk, readdata,
							DAHDI_CHUNKSIZE);
				readdata += DAHDI_CHUNKSIZE / 4;
			}
		}
	} else { /* Old way */
		readdata = wc->membase + AP_DATA_BASE;
		for (i = 0; i < DAHDI_CHUNKSIZE; i++) {
			/* Prefetch Card data */
			for (j = 0; j < 32; ++j) {
				buffer[j] = readdata[j];
			}
			for (j = 0; j < wc->numspans; j++) {
				ts = wc->tspans[j];
				/* Set first timeslot for first channel */
				for (k = 0; k < 31; ++k) {
					chan = ts->span.chans[k];
					/* Skip first timeslot from E1 */
					chan->readchunk[i] = byte[4*(k+1)+j];
				}
			}
			readdata += 32;
		}
	}
#ifdef AP4_CYCLES_STATS
	ap4_update_rx_cycles_stats(start);
#endif

	for (i = 0; i < wc->numspans; i++) {
		ts = wc->tspans[i];
		if (ts->span.flags & DAHDI_FLAG_RUNNING) {
			for (j = 0; j < ts->span.channels; j++) {
				chan = ts->span.chans[j];
				/* Echo cancel double buffered data */
				dahdi_ec_chunk(chan, chan->readchunk,
						ts->ec_chunk2[j]);
				memcpy(ts->ec_chunk2[j], ts->ec_chunk1[j],
						DAHDI_CHUNKSIZE);
				memcpy(ts->ec_chunk1[j], chan->writechunk,
						DAHDI_CHUNKSIZE);
			}
			dahdi_receive(&ts->span);
		}
	}
}

#if (DAHDI_CHUNKSIZE != 8)
#error Sorry, AP400 driver does not support chunksize != 8
#endif

static inline void ap4_transmitprep(struct ap4 *wc)
{
	volatile unsigned int *writedata;
	int i, j, k;
	unsigned int tmp;
	struct ap4_span *ts;
	struct dahdi_chan *chan;
#ifdef AP4_CYCLES_STATS
	cycles_t start;
#endif
	for (i = 0; i < wc->numspans; i++) {
		if (wc->tspans[i]->span.flags & DAHDI_FLAG_RUNNING)
			dahdi_transmit(&wc->tspans[i]->span);
	}
#ifdef AP4_CYCLES_STATS
	start = get_cycles();
#endif

	if (wc->database) { /* New way */
		/* Update write page number */
		wc->writepage = ap4_next_write_page(wc);
		for (i = 0; i < wc->numspans; ++i) {
			/* Get write page address from channel 1 from each span */
			writedata = ap4_get_page_address(wc, wc->writepage,
					i, 1);
			ts = wc->tspans[i];
			/* Write data only on opened channel on running span */
			if (!(ts->span.flags & DAHDI_FLAG_RUNNING))
				continue;
			for (j = 0; j < ts->span.channels; ++j) {
				chan = ts->span.chans[j];
				if (chan->flags & DAHDI_FLAG_OPEN) {
					memcpy_toio(writedata, chan->writechunk,
							DAHDI_CHUNKSIZE);
				}
				writedata += DAHDI_CHUNKSIZE / 4;
			}
		}
	} else { /* Old way */
		writedata = wc->membase + AP_DATA_BASE;
		for (i = 0; i < DAHDI_CHUNKSIZE; i++) {
			/* Once per chunk */
			for (k = 0; k < 31; k++) {
				/* Skip E1 first timeslot */
				tmp = 0;
				for (j = 0; j < wc->numspans; ++j) {
					chan = wc->tspans[j]->span.chans[k];
					tmp |= chan->writechunk[i] << (8 * j);
				}
				writedata[k + 1] = tmp;
			}
			/* Advance pointer by 4 TDM frame lengths */
			writedata += 32;
		}
	}
#ifdef AP4_CYCLES_STATS
	ap4_update_tx_cycles_stats(start);
#endif
}

static inline void ap4_tdm_loop(struct ap4 *wc)
{
	volatile unsigned int *buf_ptr;
	volatile unsigned int *readdata;
	volatile unsigned int *writedata;
	int i, j;
	unsigned int tmp;

	if (wc->database) {
		wc->readpage = ap4_next_read_page(wc);
		wc->writepage = ap4_next_write_page(wc);
		readdata = &wc->database[wc->readpage * wc->pageoffset];
		writedata = &wc->database[wc->writepage * wc->pageoffset];
		for (i = 0; i < wc->pageoffset; ++i)
			writedata[i] = readdata[i];
	} else {
		buf_ptr = wc->membase + AP_DATA_BASE;
		for (i = 0; i < DAHDI_CHUNKSIZE; i++) {
			/* Once per chunk */
			for (j = 0; j < 32; j++) {
				tmp = buf_ptr[j];
				buf_ptr[j] = tmp;
			}
			buf_ptr += 32;
		}
	}
}

#ifdef AP400_E1_TEST
#define AP4_E1_TEST_SET_TIME	2000
#define AP4_E1_TEST_END_TIME	3000
#define AP4_E1_TEST_STEP	0x07070707

static void ap4_e1_test(struct ap4 *wc)
{
	volatile unsigned int *data;
	unsigned int testdata;
	unsigned int buffer[32];
	unsigned char *byte = (unsigned char *) buffer;
	int i, j, k;
	struct ap4_span *ts;

	/* Bypass APEC during AP400 test */
	wc->hw_regs->echo_ctrl = APEC_CTRL_OCT_DISABLE;

	/* Write data */
	if (wc->e1_test < AP4_E1_TEST_SET_TIME) {
#ifdef AP400_DMA
		if (wc->dma_enable) {
			/* DMA */
			for (i = 0; i < wc->numspans; i++) {
				data = wc->writechunk + i * wc->pagesize * 32;
				for (j = 1; j < 32; j++) {
					data[2 * j] = j * AP4_E1_TEST_STEP;
					data[2 * j + 1] = j * AP4_E1_TEST_STEP;
				}
			}
		} else
#endif
		if (wc->database) { /* New way */
			wc->writepage = ap4_next_write_page(wc);
			data = ap4_get_page_address(wc, wc->writepage, 0, 0);
			for (i = 0; i < 256; ++i) {
				if (i % 32 == 0)
					continue;
				data[2 * i] = (i % 32) * AP4_E1_TEST_STEP;
				data[2 * i + 1] = (i % 32) * AP4_E1_TEST_STEP;
			}
		} else { /* Old way */
			data = wc->membase + AP_DATA_BASE;
			for (i = 0; i < DAHDI_CHUNKSIZE; i++) {
				for (j = 1; j < 32; j++) {
					data[j] =  j * AP4_E1_TEST_STEP;
				}
				/* Advance pointer to next E1 Frame */
				data += 32;
			}
		}
	}
	/* Read and check data */
	if ((wc->e1_test >= AP4_E1_TEST_SET_TIME)
			&& (wc->e1_test < AP4_E1_TEST_END_TIME)) {
#ifdef AP400_DMA
		if (wc->dma_enable) {
			/* DMA */
			for (i = 0; i < wc->numspans; i++) {
				data = wc->readchunk + i * wc->pagesize * 32;
				for (j = 1; j < 32; j++) {
					if ((data[2 * j + 1] != j * AP4_E1_TEST_STEP) ||
							(data[2 * j] != j * AP4_E1_TEST_STEP))
						wc->e1_result[i]++;
				}
			}
		} else
#endif
		if (wc->database) { /* New Way */
			wc->readpage = ap4_next_read_page(wc);
			data = ap4_get_page_address(wc, wc->readpage, 0, 0);
			for (i = 0; i < 256; ++i) {
				if (i % 32 == 0)
					continue;
				testdata = (i % 32) * AP4_E1_TEST_STEP;
				if ((data[2 * i + 1] != testdata) ||
						(data[2 * i] != testdata))
					wc->e1_result[(i / 32) % 8]++;
			}
		} else { /* Old Way */
			data = wc->membase + AP_DATA_BASE;
			for (i = 0; i < DAHDI_CHUNKSIZE; i++) {
				/* Prefetch Card data */
				for (k = 0; k < 32; ++k)
					buffer[k] = data[k];
				for (j = 0; j < wc->numspans; j++) {
					/* Skip first timeslot from E1 */
					for (k = 1; k < 32; ++k) {
						if ((int)(byte[4 * k + j]) != k)
							wc->e1_result[j]++;
					}
				}
				data += 32;
			}
		}
	}
	/* Increment test time */
	wc->e1_test++;
	/* Report fails */
	if (wc->e1_test == AP4_E1_TEST_END_TIME) {
		/* Re-enable APEC */
		wc->hw_regs->echo_ctrl = wc->apec_ctrl_mask;

		for (i = 0; i < wc->numspans; i++) {
			ts = wc->tspans[i];
			if (wc->e1_result[i]) {
				printk(KERN_ERR "Falha teste E1: Problema "
						"com %s\n", ts->span.desc);
			} else {
				printk(KERN_ERR "Teste E1: "
						"%s OK\n", ts->span.desc);
			}
			wc->e1_result[i] = 0;
		}

		/* Set tdm_loop = 0 only if all boards finished the test */
		for (i = 0; i < MAX_AP4_CARDS; i++) {
			if (!cards[i])
				break;

			/* Check if a card is still in test */
			if (cards[i]->e1_test < AP4_E1_TEST_END_TIME)
				return;
		}

		/* If reached here, no more card in test */
		/* End test for all cards */
		tdm_loop = 0;
		for (i = 0; i < MAX_AP4_CARDS; i++) {
			if (!cards[i])
				break;
			cards[i]->e1_test = 0;
		}
	}
}
#endif

static void ap4_r2_da_handler(struct dahdi_chan *chan, int rxsig)
{
	struct ap4 *wc = chan->pvt;
	struct ap4_span *ts;
	struct dahdi_chan *conf;

	if (r2_double_answer != 1)
		return;

	if (!chan->confna)
		return;

	if (((rxsig & 0xC) != 0x4) && ((rxsig & 0xC) != 0xC))
		return;

	ts = wc->tspans[(chan->confna - 1) / 31];
	conf = ts->chans[(chan->confna - 1) % 31];
	__ap4_rbsbits(conf, rxsig);
}

static inline int ap4_cas_sync(unsigned char *buf)
{
	int i;
	int offset = -1;	/* Returns -1, if no sync found */
	for (i = 0; i < 16; ++i) {
		if ((buf[i] & AP4_CAS_SYNC_MASK) == AP4_CAS_SYNC_WORD) {
			if (offset > -1)
				return -2;	/* Two sync words found */
			else
				offset = i;	/* Set offset from sync */
		}
	}
	return offset;
}

static inline void ap4_cas_handle(struct ap4 *wc, int span)
{
	struct ap4_span *ts = wc->tspans[span];
	int i, j;
	unsigned int oldcas, newcas, rxs;
	unsigned char *newcasbuf = ts->casbuf;
	unsigned char *oldcasbuf = ts->casbuf + 16;
	int newsync;
	struct dahdi_chan *chan;

	/* Span in alarm, send blocked signaling */
	if (ts->reload_cas) {
		for (i = 0; i < 31; ++i) {
			if (!(ts->span.chans[i]->sig & DAHDI_SIG_CLEAR)) {
				if (ts->span.chans[i]->rxsig != 0xd) {
					dahdi_rbsbits(ts->span.chans[i], 0xd);
				}
			}
		}
	}
#ifdef AP400_DMA
	if (!wc->dma_enable)
#endif
		/* Read new CAS from E1 */
		for (i = 0; i < 4; i++) {
			newcas = ap4_cas_read(wc, span, i);
			for (j = 0; j < 4; ++j) {
				newcasbuf[4 * i + j] = newcas & 0xFF;
				newcas >>= 8;
			}
		}
	/* Search new CAS sync */
	newsync = ap4_cas_sync(newcasbuf);
	if (newsync < 0) { /* No CAS sync found */
		return;
	}
	/* Check CAS data, if CAS OK */
	if (ts->cassync == newsync) { /* CAS OK */
		for (i = 0; i < 15; ++i) {
			/* Fetch CAS data with sync offset */
			oldcas = oldcasbuf[(i + 1 + newsync) % 16];
			newcas = newcasbuf[(i + 1 + newsync) % 16];
			/* Test if old and new CAS data are equal
			   to prevent glitches */
			/* Check first nibble */
			if ((newcas & 0xF) == (oldcas & 0xF)) {
				rxs = newcas & 0xF;
				chan = ts->span.chans[i+16];
				if (!(chan->sig & DAHDI_SIG_CLEAR) &&
						(chan->rxsig != rxs)) {
					dahdi_rbsbits(chan, rxs);
					ap4_r2_da_handler(chan, rxs);
				}
			}
			/* Check second nibble */
			if ((newcas & 0xF0) == (oldcas & 0xF0)) {
				rxs = (newcas >> 4) & 0xF;
				chan = ts->span.chans[i];
				if (!(chan->sig & DAHDI_SIG_CLEAR) &&
						(chan->rxsig != rxs)) {
					dahdi_rbsbits(chan, rxs);
					ap4_r2_da_handler(chan, rxs);
				}
			}
		}
	}
	/* Copy new data over old data */
	ts->cassync = newsync;
	memcpy(oldcasbuf, newcasbuf, 16);
	return;
}

static void __ap4_check_sigbits(struct ap4 *wc, int span)
{
	int a,i,rxs;
	struct ap4_span *ts = wc->tspans[span];
	volatile unsigned int *readcas = wc->membase + AP_CAS_BASE;
	struct dahdi_chan *chan;

	if (!(ts->span.flags & DAHDI_FLAG_RUNNING))
		return;
	/* If Alarm is RED or Blue, set timeout to change CAS from block */
	if ((ts->span.alarms & DAHDI_ALARM_RED) ||
			(ts->span.alarms & DAHDI_ALARM_BLUE)) {
		ts->reload_cas = 4;
	} else if(ts->reload_cas > 0) {
		ts->reload_cas--;
	}

	if (wc->database) {
		if (ts->spantype != TYPE_E1)
			return;
		ap4_cas_handle(wc, span);
		return;
	}

	for (i = 0; i < 15; i++) {
		/* if Span is in alarm, send blocked 1101 */
		if(ts->reload_cas) {
			a = 0xdd;
		} else {
			a = (int) ts->casbuf[i+1];
		}
		ts->casbuf[i+1] = (unsigned char)
				(readcas[i] >> (8 * span)) & 0xff;

		/* Get high channel in low bits */
		rxs = (a & 0xf);
		chan = ts->span.chans[i+16];
		if (!(chan->sig & DAHDI_SIG_CLEAR)) {
			if (chan->rxsig != rxs) {
				dahdi_rbsbits(chan, rxs);
				ap4_r2_da_handler(chan, rxs);
			}
		}
		rxs = (a >> 4) & 0xf;
		chan = ts->span.chans[i];
		if (!(chan->sig & DAHDI_SIG_CLEAR)) {
			if (chan->rxsig != rxs) {
				dahdi_rbsbits(chan, rxs);
				ap4_r2_da_handler(chan, rxs);
			}
		}
	}
}

static void __ap4_check_alarms(struct ap4 *wc, int span)
{
	unsigned char status;
	unsigned char config;
	int alarms;
	int i, j;
	struct ap4_span *ts = wc->tspans[span];

	if (!(ts->span.flags & DAHDI_FLAG_RUNNING))
		return;

	/* Assume no alarms */
	alarms = DAHDI_ALARM_NONE;

	/* And consider only carrier alarms */
	ts->span.alarms &= DAHDI_ALARM_RED | DAHDI_ALARM_BLUE |
			DAHDI_ALARM_NOTOPEN;

	if (ts->span.lineconfig & DAHDI_CONFIG_NOTOPEN) {
		for (i = 0, j = 0; i < ts->span.channels; i++)
			if ((ts->span.chans[i]->flags & DAHDI_FLAG_OPEN) ||
					dahdi_have_netdev(ts->span.chans[i]))
				j++;
		if (!j)
			alarms |= DAHDI_ALARM_NOTOPEN;
	}

	/* Read status and configuration from span */
	if (wc->tdm_regs) {
		status = wc->tdm_regs[span].status;
		config = wc->tdm_regs[span].config;
	} else {
		status = wc->hw_regs->e1_status >> (8 * span);
		config = wc->hw_regs->e1_config >> (8 * span);
	}

	if ((status & AP_E1_LOS_STATUS) ||
			(status & AP_E1_BFAE_STATUS) ||
			(status & AP_E1_AIS_STATUS)) {
		if (ts->alarmcount >= alarmdebounce)
			alarms |= DAHDI_ALARM_RED;
		else
			ts->alarmcount++;
	} else
		ts->alarmcount = 0;

	if ((status & AP_E1_MFAE_STATUS) && (config & AP_E1_CRCEN_CONFIG))
		alarms |= DAHDI_ALARM_BLUE;

	if ((!(status & AP_E1_CAS_STATUS)) && (config & AP_E1_PCM30_CONFIG))
		alarms |= DAHDI_ALARM_BLUE;

#if 0
	if (ts->casenable && (ts->cassync < 0)) {
		alarms |= DAHDI_ALARM_BLUE;
	}
#endif

	if (((!ts->span.alarms) && alarms) || (ts->span.alarms && (!alarms)))
		wc->checktiming = 1;

	/* Keep track of recovering */
	if ((!alarms) && ts->span.alarms)
		ts->alarmtimer = DAHDI_ALARMSETTLE_TIME;
	if (ts->alarmtimer)
		alarms |= DAHDI_ALARM_RECOVER;

	/* If receiving alarms, go into Yellow alarm state */
	if (alarms && !(ts->spanflags & FLAG_SENDINGYELLOW)) {
		printk(KERN_WARNING "Setting yellow alarm on span %d\n",
				span + 1);
		if (wc->tdm_regs)
			wc->tdm_regs[span].config |= AP_E1_RAI_CONFIG;
		else
			wc->hw_regs->e1_config |=
					AP_E1_RAI_CONFIG << (8 * span);
		ts->spanflags |= FLAG_SENDINGYELLOW;
	} else if ((!alarms) && (ts->spanflags & FLAG_SENDINGYELLOW)) {
		printk(KERN_NOTICE "Clearing yellow alarm on span %d\n",
				span + 1);
		if (wc->tdm_regs)
			wc->tdm_regs[span].config &= ~AP_E1_RAI_CONFIG;
		else
			wc->hw_regs->e1_config &=
					~(AP_E1_RAI_CONFIG << (8 * span));
		ts->spanflags &= ~FLAG_SENDINGYELLOW;
	}

	/* Check if AIS transmission is enable for span (FW version 7.3+ or 8.4+) */
	if (wc->tdm_regs &&
			(wc->fpgaver >= 0x0804 ||
			(wc->fpgaver >= 0x0703 && wc->fpgaver < 0x0800))) {
		if (!(config & AP_E1_AIS_CONFIG) && (send_ais & (1UL << span))) {
			/* Enable AIS transmission */
			wc->tdm_regs[span].config |= AP_E1_AIS_CONFIG;
			ts->send_ais = 1;
			printk(KERN_NOTICE "Enable AIS transmission on span %d\n", span + 1);
		} else if (wc->tdm_regs && ts->send_ais && !(send_ais & (1UL << span))) {
			/* Disable AIS transmission */
			wc->tdm_regs[span].config &= ~AP_E1_AIS_CONFIG;
			ts->send_ais = 0;
			printk(KERN_NOTICE "Disable AIS transmission on span %d\n", span + 1);
		}
	}

	/* Re-check the timing source when we enter/leave alarm
	   not withstanding yellow alarm */
	if (status & AP_E1_RAI_STATUS)
		alarms |= DAHDI_ALARM_YELLOW;

	if (ts->span.mainttimer || ts->span.maintstat)
		alarms |= DAHDI_ALARM_LOOPBACK;

	ts->span.alarms = alarms;
	dahdi_alarm_notify(&ts->span);
}

static void __ap4_do_counters(struct ap4 *wc)
{
	int span;

	for (span = 0; span < wc->numspans; span++) {
		struct ap4_span *ts = wc->tspans[span];
		int docheck=0;
		if (ts->loopupcnt || ts->loopdowncnt)
			docheck++;
		if (ts->alarmtimer) {
			if (!--ts->alarmtimer) {
				docheck++;
				ts->span.alarms &= ~(DAHDI_ALARM_RECOVER);
			}
		}
		if (docheck) {
			if (!polling)
				__ap4_check_alarms(wc, span);
			dahdi_alarm_notify(&ts->span);
		}
	}
}

#define MAX_BLINKTIMER	0x14

static inline void __handle_leds(struct ap4 *wc)
{
	int i;
	unsigned char status;
	struct ap4_span *ts;

	if (wc->tdm_regs) {
		for (i = 0; i < wc->numspans; i++) {
			status = wc->tdm_regs[i].status;
			ts = wc->tspans[i];
			if (!(ts->span.flags & DAHDI_FLAG_RUNNING)) {
				__ap4_set_led(wc, i, AP4_LED_OFF);
			} else if (status & AP_E1_LOS_STATUS) {
				__ap4_set_led(wc, i, AP4_LED_SLOW);
			} else if (ts->span.alarms &
					(DAHDI_ALARM_RED | DAHDI_ALARM_BLUE)) {
				__ap4_set_led(wc, i, AP4_LED_FAST);
			} else	{ /* No Alarm */
				__ap4_set_led(wc, i, AP4_LED_ON);
			}
		}
	} else {
		for (i = 0; i < wc->numspans; i++) {
			ts = wc->tspans[i];
			/* Read Status from E1 Interface */
			status = wc->hw_regs->e1_status >> (8 * i);
			if (!(ts->span.flags & DAHDI_FLAG_RUNNING)) {
				/* Interface not running */
				__ap4_set_led(wc, i, AP4_LED_OFF);
			} else if (status & AP_E1_LOS_STATUS) {
				if (wc->blinktimer[i] >= altab[wc->alarmpos[i]])
					__ap4_set_led(wc, i, AP4_LED_ON);
				if (wc->blinktimer[i] >= (MAX_BLINKTIMER - 1))
					__ap4_set_led(wc, i, AP4_LED_OFF);
				wc->blinktimer[i] += 1;
			} else if (ts->span.alarms &
					(DAHDI_ALARM_RED | DAHDI_ALARM_BLUE)) {
				if (wc->blinktimer[i] >= altab[wc->alarmpos[i]])
					__ap4_set_led(wc, i, AP4_LED_ON);
				if (wc->blinktimer[i] >= (MAX_BLINKTIMER-2))
					__ap4_set_led(wc, i, AP4_LED_OFF);
				wc->blinktimer[i] += 3;
			} else {
				/* No Alarm */
				__ap4_set_led(wc, i, AP4_LED_ON);
			}
			if (wc->blinktimer[i] > MAX_BLINKTIMER) {
				wc->blinktimer[i] = 0;
				wc->alarmpos[i]++;
				if (wc->alarmpos[i] >= (sizeof(altab) /
						sizeof(altab[0])))
					wc->alarmpos[i] = 0;
			}
		}
	}
}

#define AP400_LOG(a, c, b...) { \
		if (ts->log_level >= a) { \
			printk(KERN_WARNING "%s Log (interface %d): ", wc->variety, c+1);\
			printk(b);\
		} \
}

static inline void ap4_update_stats(struct ap4 *wc)
{
	int i;
	unsigned int bpv = 0;
	unsigned int crc4 = 0;
	unsigned int slips, status, config;
	struct ap4_span *ts;
	clock_source = wc->hw_regs->clock_source;

	if (wc->tdm_regs == NULL) {
		bpv = wc->hw_regs->cvs;
		crc4 = wc->hw_regs->crc_errors;
	}

	for (i = 0; i < wc->numspans; i++) {
		ts = wc->tspans[i];

		if ((ts->span.flags & DAHDI_FLAG_RUNNING) == 0)
			continue;

		/* If we can get the semaphore, just give up, we'll update on the next IRQ */
		if (down_trylock(&ts->stats_lock)) {
			if (debug)
				printk(KERN_DEBUG "down_trylock failed!!\n");
			return;
		}

		if (wc->tdm_regs) {
			ts->span.count.bpv += wc->tdm_regs[i].errors.cv;
			ts->span.count.crc4 += wc->tdm_regs[i].errors.crc;
			slips = wc->tdm_regs[i].errors.slip;

			status = wc->tdm_regs[i].status;
			config = wc->tdm_regs[i].config;
		} else {
			ts->span.count.bpv += (bpv >> (8 * i)) & 0xff;
			ts->span.count.crc4 += (crc4 >> (8 * i)) & 0xff;
			slips = (wc->hw_regs->slips >> (8 * i)) & 0xff;

			status = (wc->hw_regs->e1_status >> (8 * i)) & 0xff;
			config = (wc->hw_regs->e1_config >> (8 * i)) & 0xff;
		}

		if (!(ts->span.alarms & DAHDI_ALARM_RED)) {
			if (slips) {
				ts->slipcount += slips;
				AP400_LOG(AP400_LOGLEVEL_lots, i, "Slip detected\n");
			}
		}

		if (status & AP_E1_LOS_STATUS) {
			status &= AP_E1_LOS_STATUS;
			ts->status.losc++;
			if (!(ts->status.old_status & AP_E1_LOS_STATUS)) {
				ts->stats.los_count++;
				AP400_LOG(AP400_LOGLEVEL_basic, i, "LOS detected\n");
			}
			goto ap4_update_stats_end;
		} else {
			if (ts->status.old_status & AP_E1_LOS_STATUS) {
				AP400_LOG(AP400_LOGLEVEL_basic, i, "LOS cleared\n");
			}
		}
		if (status & AP_E1_AIS_STATUS) {
			status &= AP_E1_AIS_STATUS;
			ts->status.aisc++;
			if (!(ts->status.old_status & AP_E1_AIS_STATUS)) {
				ts->stats.ais_count++;
				AP400_LOG(AP400_LOGLEVEL_basic, i, "AIS detected\n");
			}
			goto ap4_update_stats_end;
		} else {
			if (ts->status.old_status & AP_E1_AIS_STATUS) {
				AP400_LOG(AP400_LOGLEVEL_basic, i, "AIS cleared\n");
			}
		}
		if (status & AP_E1_BFAE_STATUS) {
			status &= AP_E1_BFAE_STATUS;
			ts->status.bfaec++;
			if (!(ts->status.old_status & AP_E1_BFAE_STATUS)) {
				ts->stats.bfae_count++;
				AP400_LOG(AP400_LOGLEVEL_basic, i, "BFAE detected\n");
			}
		} else {
			if (ts->status.old_status & AP_E1_BFAE_STATUS) {
				AP400_LOG(AP400_LOGLEVEL_basic, i, "BFAE cleared\n");
			}
			if (status & AP_E1_RAI_STATUS) {
				ts->status.raic++;
				if (!(ts->status.old_status & AP_E1_RAI_STATUS)) {
					ts->stats.rai_count++;
					AP400_LOG(AP400_LOGLEVEL_basic, i, "RAI detected\n");
				}
			} else {
				if (ts->status.old_status & AP_E1_RAI_STATUS) {
					AP400_LOG(AP400_LOGLEVEL_basic, i, "RAI cleared\n");
				}
			}
			if(config & AP_E1_CRCEN_CONFIG) {
				if (status & AP_E1_MFAE_STATUS) {
					ts->status.mfaec++;
					if ((ts->status.old_status & AP_E1_MFAE_STATUS) == 0) {
						ts->stats.mfae_count++;
						AP400_LOG(AP400_LOGLEVEL_lots, i, "MFAE detected\n");
					}
				} else {
					if ((ts->status.old_status & AP_E1_MFAE_STATUS)) {
						AP400_LOG(AP400_LOGLEVEL_lots, i, "MFAE cleared\n");
					}
				}
			}
			if (!(status & AP_E1_CAS_STATUS) && (config & AP_E1_PCM30_CONFIG)) {
				ts->stats.cas_count++;
			}
		}

ap4_update_stats_end:
		ts->status.old_status = status;

		ts->status.seconds++;
		if (ts->status.seconds >= UPDATE_STATS_RATE) {
			ts->status.seconds = 0;
			ts->stats.seconds++;
		}

		if (ts->status.aisc >= UPDATE_STATS_RATE) {
			ts->status.aisc = 0;
			ts->stats.ais_seconds++;
		}
		if (ts->status.bfaec >= UPDATE_STATS_RATE) {
			ts->status.bfaec = 0;
			ts->stats.bfae_seconds++;
		}
		if (ts->status.losc >= UPDATE_STATS_RATE) {
			ts->status.losc = 0;
			ts->stats.los_seconds++;
		}
		if (ts->status.mfaec >= UPDATE_STATS_RATE) {
			ts->status.mfaec = 0;
			ts->stats.mfae_seconds++;
		}
		if (ts->status.raic >= UPDATE_STATS_RATE) {
			ts->status.raic = 0;
			ts->stats.rai_seconds++;
		}

		up(&ts->stats_lock);
	}
}

DAHDI_IRQ_HANDLER(ap4_interrupt)
{
	struct ap4 *wc = dev_id;
	int i;
	unsigned int temp;

	/* Check if it is our IRQ */
	temp = wc->hw_regs->irq_config;
	if ((temp & AP_INT_CTL_ENABLE) == 0 ||
			(temp & AP_INT_CTL_ACTIVE) == 0) {
		return IRQ_NONE;
	}

	/* Acknowledge IRQ */
	temp = wc->hw_regs->irq_clear;

	/* Update IRQ misses counter */
	if (wc->flag_1st_irq > 0) {
		/* Disregard first 16 IRQ misses */
		temp = wc->hw_regs->irq_count;
		if (temp > 0) {
			wc->flag_1st_irq--;
			wc->hw_regs->irq_count = 0;
			for (i = 0; i < wc->numspans; i++)
				wc->ddev->irqmisses= 0;
		}
		/* Disregard first CRC errors */
		temp = wc->hw_regs->crc_errors;
	} else {
		/* Read IRQ counter, should be 1, else we missed some IRQ */
		temp = wc->hw_regs->irq_count;
		/* Reset counter */
		wc->hw_regs->irq_count = 0;
		/* Increment IRQ misses */
		if (temp > 0) {
			wc->ddev->irqmisses += (temp - 1);
		}
	}

	if (!wc->spansstarted) {
		/* Not prepped yet! */
		return IRQ_NONE;
	}

	wc->intcount++;

#ifdef AP400_DMA
	if (wc->dma_enable) {
		ap4_handle_dma(wc);
	} else
#endif
	if (!tdm_loop) {
		ap4_receiveprep(wc);
		ap4_transmitprep(wc);
#ifdef AP400_E1_TEST
	} else if (tdm_loop < 0) {
		ap4_e1_test(wc);
#endif
	} else {
		ap4_tdm_loop(wc);
	}

	/* Update stats every 100 ms */
	if (!(wc->intcount % UPDATE_STATS_PERIOD))
		ap4_update_stats(wc);

	__handle_leds(wc);

	__ap4_do_counters(wc);

	/* Check alarms and sigbits */
	if (wc->intcount % 2)
		__ap4_check_alarms(wc, (wc->intcount / 2) % wc->numspans);
	else
		__ap4_check_sigbits(wc, (wc->intcount / 2) % wc->numspans);

	if (wc->checktiming > 0)
		__ap4_set_timing_source_auto(wc);

	return IRQ_HANDLED;
}

static inline int ap4_liu_reset(struct ap4 *wc)
{
	wc->hw_regs->leds |= AP_LIU_RESET_BIT;
	udelay(1);	/* Reset > 100 ns */
	wc->hw_regs->leds &= ~AP_LIU_RESET_BIT;
	return 0;
}

static int ap4_bus_test(struct ap4 *wc)
{
	int tst_result = 0;
	unsigned int val;

	*(wc->membase+AP_E1_CONFIG_REG) = 0xAAAAAAAA;
	*wc->membase = 0;
	val = *(wc->membase+AP_E1_CONFIG_REG);
	if(val != 0xAAAAAAAA) {
		printk("Escrito 0xAAAAAAAA, lido 0x%08X!\n", val);
		tst_result++;
	}
	*(wc->membase+AP_E1_CONFIG_REG) = 0x55555555;
	*wc->membase = 0;
	val = *(wc->membase+AP_E1_CONFIG_REG);
	if(val != 0x55555555) {
		printk("Escrito 0x55555555, lido 0x%08X!\n", val);
		tst_result++;
	}
	*(wc->membase+AP_E1_CONFIG_REG) = 0xFFFFFFFF;
	*wc->membase = 0;
	val = *(wc->membase+AP_E1_CONFIG_REG);
	if(val != 0xFFFFFFFF) {
		printk("Escrito 0xFFFFFFFF, lido 0x%08X!\n", val);
		tst_result++;
	}
	*(wc->membase+AP_E1_CONFIG_REG) = 0x00000000;
	*wc->membase = 0xFFFFFFFF;
	val = *(wc->membase+AP_E1_CONFIG_REG);
	if(val != 0x00000000) {
		printk("Escrito 0x00000000, lido 0x%08X!\n", val);
		tst_result++;
	}
	return tst_result;
}

static int ap4_ddr_test(struct ap4 *wc)
{
	int i;
	
	/* Check DDR calibration */
	if (!(wc->hw_regs->ddr_ctrl & AP_DDR_CALIB_OK)) {
		printk(KERN_WARNING "AP400: DDR calibration failed!\n");
		return -EPERM;
	}
	
	/* Check DDR access */
	/* Writes */
	for (i = 0; i < 65536; i++) {
		wc->hw_regs->ddr_ctrl = (i & AP_DDR_ADDR_MASK);
		wc->hw_regs->ddr_data = i * 0x10001;
		while (wc->hw_regs->ddr_ctrl & AP_DDR_BUSY);
	}
	/* Reads */
	for (i = 0; i < 65536; i++) {
		unsigned data;
		wc->hw_regs->ddr_ctrl = AP_DDR_READ_REQ | (i & AP_DDR_ADDR_MASK);
		while (wc->hw_regs->ddr_ctrl & AP_DDR_BUSY);
		data = wc->hw_regs->ddr_data;
		if (((i * 0x10001) & 0xFFFFFFFF) != data) {
			printk(KERN_WARNING "DDR Error! Write %08x Read %08x Status %08x\n",
					(i * 0x10001) & 0xFFFFFFFF, data,
					wc->hw_regs->ddr_ctrl);
			return -EPERM;
		}
	}
	/* Reset DDR data */
	for (i = 0; i < 65536; i++) {
		wc->hw_regs->ddr_ctrl = i & AP_DDR_ADDR_MASK;
		wc->hw_regs->ddr_data = 0;
		while (wc->hw_regs->ddr_ctrl & AP_DDR_BUSY);
	}
	return 0;
}

static inline int ap4_card_detect(struct ap4 *wc) {
	int i;
	if ((wc->hw_regs->card_id != AP4XX_CARD_ID) &&
			(wc->hw_regs->card_id != APE4XX_CARD_ID)) {
		printk(KERN_WARNING "AP400: Unknown card ID(0x%08X)! "
				"Aborting...\n", wc->hw_regs->card_id);
		return -EPERM;
	}
	/* Test bus integrity */
	for (i=0; i < 1000; i++) {
		if (ap4_bus_test(wc)) {
			printk(KERN_WARNING "AP400: Bus integrity test failed! "
					"Aborting...\n");
			return -EIO;
		}
	}
	printk(KERN_INFO "AP400: Bus integrity OK!\n");

	wc->fpgaver = wc->hw_regs->fpga_ver;
	wc->numspans = wc->hw_regs->span_num;
	wc->hwid = wc->hw_regs->hw_id & AP_HWID_MASK;

	if ((wc->hwid == AP_HWID_1E1_RJ && wc->numspans != 1) ||
			(wc->hwid == AP_HWID_2E1_RJ && wc->numspans != 2) ||
			(wc->hwid == AP_HWID_4E1_RJ && wc->numspans != 4) ||
			(wc->hwid == AP_HWID_8E1_RJ && wc->numspans != 8)) {
		printk(KERN_WARNING "AP400: Incompatible Hardware ID (0x%02x)! "
				"Aborting...\n", wc->hwid);
		return -EIO;
	}

	if (wc->fpgaver >= 0x0400)
		wc->apec_detect = 1;

	if (wc->fpgaver >= 0x0600) {
		wc->tdm_regs = wc->hw_regs->tdm;
		wc->database = ioremap_nocache(pci_resource_start(wc->dev, 1),
				pci_resource_len(wc->dev, 1));
		if (wc->database == NULL) {
			printk(KERN_WARNING "AP400: ioremap failed!\n");
			return -EIO;
		}
		wc->numpages = wc->hw_regs->tdm_page_num;
		wc->pagebytes = wc->hw_regs->tdm_page_bytes;
		wc->pagesize = wc->pagebytes / 4;
		wc->pageoffset = wc->pagesize * wc->numspans * 32;
	}
#ifdef AP400_DMA
	if (wc->fpgaver >= 0x0700) {
		wc->dma_enable = 1;
	}
#endif
	if (wc->hw_regs->card_id == AP4XX_CARD_ID)
		switch (wc->numspans) {
		case 1:
			wc->dt = (struct devtype *) &ap401;
			break;
		case 2:
			wc->dt = (struct devtype *) &ap402;
			break;
		case 4:
			wc->dt = (struct devtype *) &ap404;
			break;
		case 8:
			wc->dt = (struct devtype *) &ap408;
			break;
		default:
			printk(KERN_WARNING "AP400: Unsupported spans number(%d)! "
					"Aborting...\n", wc->numspans);
			return -EPERM;
		}
	else
		switch (wc->numspans) {
		case 1:
			wc->dt = (struct devtype *) &ape401;
			break;
		case 2:
			wc->dt = (struct devtype *) &ape402;
			break;
		case 4:
			wc->dt = (struct devtype *) &ape404;
			break;
		case 8:
			wc->dt = (struct devtype *) &ape408;
			break;
		default:
			printk(KERN_WARNING "APE400: Unsupported spans number(%d)! "
					"Aborting...\n", wc->numspans);
			return -EPERM;
	}

	/* Check internal APEC and DDR */
	if (wc->fpgaver >= 0x0900 &&  wc->numspans == 1 &&
			(wc->hw_regs->hw_id & AP_HWID_EC_INT)) {
		/* Check DDR test */
		if (ap4_ddr_test(wc)) {
			printk(KERN_WARNING "AP400: DDR initialization failed! "
					"Aborting...\n");
			return -EPERM;
		}
		printk(KERN_INFO "AP400: DDR test OK!\n");
		wc->dt = (struct devtype *) &ape411;
	}

	wc->variety = wc->dt->desc;
	printk("Found a %s (firmware version %d.%d) at %p\n", wc->variety,
			wc->fpgaver >> 8, wc->fpgaver & 0xFF, wc->membase);
	printk("\t%s DNA: %08X%08X\n", wc->variety, wc->hw_regs->dna_high, wc->hw_regs->dna_low);

	return 0;
}

static void __devexit ap4_remove_one(struct pci_dev *pdev);

static int __devinit ap4_init_one(struct pci_dev *pdev,
                                  const struct pci_device_id *ent)
{
	int res;
	struct ap4 *wc;
	int i, j;
	int basesize;
	struct dahdi_chan *chan;

	/* Initialize PCI Device */
	if ((res = pci_enable_device(pdev)) != 0) {
		goto out;
	}

	/* Allocate card struct */
	wc = kmalloc(sizeof(struct ap4), GFP_KERNEL);
	if (wc == NULL) {
		res = -ENOMEM;
		goto out;
	}

	memset(wc, 0x0, sizeof(struct ap4));
	spin_lock_init(&wc->reglock);
	spin_lock_init(&wc->echo_lock);

	wc->dev = pdev;

	/* Request PCI regions */
	if ((res = pci_request_regions(pdev, "ap400")) != 0) {
		printk("AP400: Unable to request regions!\n");
		goto out;
	}

	/* Remap PCI address */
	wc->membase = ioremap_nocache(pci_resource_start(pdev, 2),
			pci_resource_len(pdev, 2));
	if (wc->membase == NULL) {
		printk("AP400: ioremap failed!\n");
		res = -EIO;
		goto out;
	}
	wc->hw_regs = (struct ap4_regs *) wc->membase;

	/* Detect Card model */
	if ((res = ap4_card_detect(wc)) != 0)
		goto out;

	basesize = DAHDI_MAX_CHUNKSIZE * 32 * wc->numspans;

	ap4_liu_reset(wc);

	/* This rids of the Double missed interrupt message after loading */
	wc->last0 = 1;

#ifdef AP400_DMA
	wc->writechunk = pci_alloc_consistent(pdev, basesize * 2, &wc->dma_addr);
	if (!wc->writechunk) {
		printk("%s: Unable to allocate DMA-able memory!\n",
				wc->variety);
		res = -ENOMEM;
		goto out;
	}
	/* Enable bus mastering */
	pci_set_master(pdev);

	/* Enable card DMA */
	wc->hw_regs->dma_baseaddr = wc->dma_addr;
	wc->hw_regs->dma_config = AP4_DMA_ENABLE;
#else
	/* 32 channels, Double-buffer, Read/Write, n spans */
	wc->writechunk = kmalloc(basesize * 2, GFP_KERNEL);
	if (!wc->writechunk) {
		printk("%s: Unable to allocate memory!\n", wc->variety);
		res = -ENOMEM;
		goto out;
	}
#endif /* AP400_DMA */

	/* Read is after the whole write piece (in words) */
	wc->readchunk = wc->writechunk + basesize / 4;

	/* Initialize Write/Buffers to all blank data */
	memset((void *) wc->writechunk, 0x00, basesize);
	memset((void *) wc->readchunk, 0xff, basesize);

	/* Keep track of which device we are */
	pci_set_drvdata(pdev, wc);

	/* Reset interruption counter */
	wc->intcount = 0;

	for(i = 0; i < MAX_AP4_CARDS; i++) {
		if (!cards[i]) break;
	}

	if (i >= MAX_AP4_CARDS) {
		printk("No cards[] slot available!!\n");
		res = -ENOMEM;
		goto out;
	}

	wc->ddev = dahdi_create_device();
	if( wc->ddev == NULL ) {
		printk("Error creating DAHDI device!!\n");
		res = -ENOMEM;
		goto out;
	}

	wc->num = i;
	cards[i] = wc;

	/* Allocate pieces we need here, consider 31 channels for E1*/
	for (i = 0; i < wc->numspans; i++) {
		wc->tspans[i] = kmalloc(sizeof(struct ap4_span), GFP_KERNEL);
		if (wc->tspans[i]) {
			memset(wc->tspans[i], 0, sizeof(struct ap4_span));
			wc->tspans[i]->spantype = TYPE_E1;
		} else {
			res = -ENOMEM;
			goto out;
		}
		for (j = 0; j < 31; j++) {
			chan = kmalloc(sizeof(struct dahdi_chan), GFP_KERNEL);
			if (!chan) {
				res = -ENOMEM;
				goto out;
			}
			memset(chan, 0, sizeof(struct dahdi_chan));
			wc->tspans[i]->chans[j] = chan;
		}
		wc->tspans[i]->spanflags |= wc->dt->flags;
	}

	if (request_irq(pdev->irq, ap4_interrupt, IRQF_SHARED, "ap400", wc)) {
		printk("%s: Unable to request IRQ %d\n", wc->variety,
				pdev->irq);
		res = -EIO;
		goto out;
	}
	wc->irq = pdev->irq;

	wc->ddev->manufacturer = "Aligera";
	wc->ddev->devicetype = wc->variety;
	wc->ddev->location = kasprintf(GFP_KERNEL, "PCI Bus %02d Slot %02d",
				      wc->dev->bus->number,
				      PCI_SLOT(wc->dev->devfn) + 1);
	if (!wc->ddev->location) {
		res = -ENOMEM;
		goto out;
	}

	ap4_init_spans(wc);

	if (dahdi_register_device(wc->ddev, &wc->dev->dev)) {
		printk(KERN_NOTICE "Unable to register span with DAHDI\n");
		res = -ENOMEM;
		goto out;
	}

	/* Launch cards as appropriate */
	i = 0;
	for(;;) {
		/* Find a card to activate */
		j = 0;
		for (i = 0; cards[i]; i++) {
			if (cards[i]->order <= highestorder) {
				wc->checktiming = 1;
				if (cards[i]->order == highestorder)
					j = 1;
			}
		}
		/* If we found at least one, increment the highest order
		   and search again, otherwise stop */
		if (j)
			highestorder++;
		else
			break;
	}

	res = 0;
out:
	if (res != 0) {
		ap4_remove_one(pdev);
	}
	return res;
}

static void __devexit ap4_remove_one(struct pci_dev *pdev)
{
	struct ap4 *wc = pci_get_drvdata(pdev);
	int i;

	if (wc) {
		/* Disable Interrupt */
		ap4_irq_disable(wc);

		dahdi_unregister_device(wc->ddev);

		if (pdev->irq)
			free_irq(pdev->irq, wc);

		/* Stop echo cancellation module */
		ap4_apec_release(wc);

		/* Disable card DMA */
		if (wc->hw_regs)
			wc->hw_regs->dma_config = 0;

		if (wc->database)
			iounmap(wc->database);

		wc->hw_regs = NULL;
		if (wc->membase)
			iounmap((void *)wc->membase);

		/* Immediately free resources */
#ifdef AP400_DMA
		pci_free_consistent(wc->dev,
		                    DAHDI_MAX_CHUNKSIZE * 32 * wc->numspans,
		                    (void *) wc->writechunk, wc->dma_addr);
#else
		kfree((void *) wc->writechunk);
#endif

		cards[wc->num] = NULL;
		for (i = 0; i < wc->numspans; i++) {
			if (wc->tspans[i])
				kfree(wc->tspans[i]);
		}
		dahdi_free_device(wc->ddev);
		kfree(wc);
	}
	pci_release_regions(pdev);
	pci_disable_device(pdev);
	pci_set_drvdata(pdev, NULL);
	printk(KERN_INFO "AP400 driver removed\n");
}

static struct pci_device_id ap4_pci_tbl[] __devinitdata =
{
	{ PCI_DEVICE(PCI_VENDOR_ID_XILINX, AP4_PCI_DEVICE_ID), },
	{ 0, }
};

static struct pci_driver ap4_driver = {
	name: 	"Unified ap400 driver",
	probe: 	ap4_init_one,
	remove:	__devexit_p(ap4_remove_one),
	suspend: NULL,
	resume:	NULL,
	id_table: ap4_pci_tbl,
};

static int __init ap4_init(void)
{
	int res;
	printk("Unified AP400 PCI Card Driver\n");
	res = dahdi_pci_module(&ap4_driver);
	if (res) {
		return -ENODEV;
	}
	return 0;
}

static void __exit ap4_cleanup(void)
{
	printk("Unified AP400 PCI Card Driver Cleanup\n");
	pci_unregister_driver(&ap4_driver);
}

MODULE_AUTHOR("Aligera AP400 Maintainer (ap400@aligera.com.br)");
MODULE_DESCRIPTION("Unified AP400 PCI Card Driver");
#ifdef MODULE_LICENSE
MODULE_LICENSE("GPL");
#endif

module_param(debug, int, 0600);
module_param(loopback, int, 0600);
module_param(noburst, int, 0600);
module_param(debugslips, int, 0600);
module_param(polling, int, 0600);
module_param(timingcable, int, 0600);
module_param(alarmdebounce, int, 0600);

MODULE_DEVICE_TABLE(pci, ap4_pci_tbl);

module_init(ap4_init);
module_exit(ap4_cleanup);
