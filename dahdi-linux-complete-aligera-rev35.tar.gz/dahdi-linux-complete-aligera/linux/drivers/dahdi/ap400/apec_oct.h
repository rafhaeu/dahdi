/*
 * AP400 Echo Cancelation Hardware support
 *
 * Written by Wagner Gegler <aligera@aligera.com.br>
 * 
 * Based on previous work written by Mark Spencer <markster@digium.com>
 * 
 * Copyright (C) 2005-2006 Digium, Inc.
 *
 * Mark Spencer <markster@digium.com>
 *
 * All Rights Reserved
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#ifndef _APEC_OCT_H_
#define _APEC_OCT_H_

#include <linux/firmware.h>

struct apec_oct;

/* From AP400 */
unsigned int oct_read(void *card, int index, unsigned int addr);
void oct_write(void *card, int index, unsigned int addr, unsigned int data);

/* From APEC_OCT */
struct apec_oct *apec_oct_init(void *wc, int index, int numspans, const struct firmware *firmware);
unsigned int apec_oct_capacity_get(void *wc, int index);
void apec_oct_setec(struct apec_oct *instance, int channel, int eclen);
int apec_oct_checkirq(struct apec_oct *apec);
void apec_oct_release(struct apec_oct *instance);

#endif /*_APEC_OCT_H_*/
