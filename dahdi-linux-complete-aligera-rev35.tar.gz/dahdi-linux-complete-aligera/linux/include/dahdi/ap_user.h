/*
 * AP400/APE400/AP200 PCI Driver Userspace Header File
 *
 * Written by Leonardo Santos <leonardo@aligera.com.br>
 *
 * Based on previous works, designs, and archetectures conceived and
 * written by Jim Dixon <jim@lambdatel.com> and Mark Spencer <markster@digium.com>.
 *
 * Copyright (C) 2001 Jim Dixon / Zapata Telephony.
 * Copyright (C) 2001-2005, Digium, Inc.
 *
 * All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#ifndef AP_DAHDI_USER_H_
#define AP_DAHDI_USER_H_

#include <linux/ioctl.h>

struct ap_ioctl_hwinfo {
	unsigned int fpga_major;	/* Major version */
	unsigned int fpga_minor;	/* Minor version */
	unsigned int irq;		/* IRQ used */
	char prod_name[32];		/* Product Name */
	unsigned int dna_high;
	unsigned int dna_low;
};

struct ap_ioctl_spi_cmd {
	size_t len;
	char data[264];
};

#define AP4_ALARM_LOS		0x01
#define AP4_ALARM_AIS		0x02
#define AP4_ALARM_BFAE		0x04
#define AP4_ALARM_RAI		0x08
#define AP4_ALARM_MFAE		0x10
#define AP4_ALARM_CAS		0x40

#define AP4_CONFIG_PCM30	0x01	/* 1 = PCM30, 0 = PCM31 */
#define AP4_CONFIG_CRC4		0x02	/* 1 = CRC4 enable */
#define AP4_CONFIG_ECHO		0x04	/* 1 = echo cancel detected and enabled */

/* Span stats used on IOCTL  */
struct ap4_ioctl_span_stats {
	unsigned int span;		/* Span # */
	unsigned int seconds;		/* Seconds since last clear */
	unsigned int slipcount;		/* Number of E1 clock slips */
	unsigned int irqmisses;		/* Number of IRQ misses (per card, not span) */
	unsigned int los_count;		/* Number of times LOS was detected */
	unsigned int los_seconds;	/* Number of seconds while in LOS */
	unsigned int ais_count;		/* Number of times AIS was detected */
	unsigned int ais_seconds;	/* Number of seconds while in AIS */
	unsigned int rai_count;		/* Number of times Remote Alarm Indication was detected */
	unsigned int rai_seconds;	/* Number of seconds while in RAI */
	unsigned int bfae_count;	/* Number of times the frame sync was lost */
	unsigned int bfae_seconds;	/* Number of seconds while not locked */
	unsigned int mfae_count;	/* Number of times the multi-frame sync was lost */
	unsigned int mfae_seconds;	/* Number of seconds while not locked */
	unsigned int crc_count;		/* Number of CRC4 erros */
	unsigned int bpv_count;		/* Number of Bipolar Violations */
	unsigned int cas_count;		/* Number of CAS errors */
	unsigned int tx_level;		/* TX signal level in dbm */
	unsigned int rx_level;		/* RX signal level in dbm */
};

struct ap4_ioctl_log {
	unsigned int span;		/* Span # */
	unsigned int level;		/* Log level */
};

enum AP400_LOGLEVEL {
	AP400_LOGLEVEL_off	= 0,
	AP400_LOGLEVEL_min	= AP400_LOGLEVEL_off,
	AP400_LOGLEVEL_basic	= 1,
	AP400_LOGLEVEL_lots	= 2,
	AP400_LOGLEVEL_max	= AP400_LOGLEVEL_lots
};

#define AP4_GET_ALARMS		_IOR (DAHDI_CODE, 60, int)
#define AP4_GET_SLIPS		_IOR (DAHDI_CODE, 61, int)
#define AP4_GET_STATS		_IOR (DAHDI_CODE, 62, struct ap4_ioctl_span_stats)
#define AP4_RESET_STATS		_IOW (DAHDI_CODE, 63, int)
#define AP_GET_HWINFO		_IOR (DAHDI_CODE, 64, struct ap_ioctl_hwinfo)
#define AP4_GET_CONFIG		_IOR (DAHDI_CODE, 65, int)
#define AP4_GET_LOGLEVEL	_IOR (DAHDI_CODE, 66, struct ap4_ioctl_log)
#define AP4_SET_LOGLEVEL	_IOW (DAHDI_CODE, 67, struct ap4_ioctl_log)
#define AP_IOC_SPI		_IOWR (DAHDI_CODE, 68, struct ap_ioctl_spi_cmd)
#define AP_FPGA_PROG		_IO (DAHDI_CODE, 69)


#endif /* AP_DAHDI_USER_H_ */

